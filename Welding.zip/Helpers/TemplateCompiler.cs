﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using GemBox.Document;
using GemBox.Document.Tables;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using QAWebApiClient;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.FileManagement;

namespace WeldingManagement
{
    public static class TemplateCompiler
    {
        #region Insert Functions
        public static void FindAndReplaceText(DocumentModel document, string replacetxt, string newtxt)
        {
            foreach (ContentRange searchedContent in document.Content.Find(replacetxt).Reverse())
            {
                searchedContent.LoadText(newtxt);
            }
        }

        public static void InsertTableCellText(Table tbl, int rowIdx, int cellIdx, string newtxt)
        {
            tbl.Rows[rowIdx].Cells[cellIdx].Blocks[0].Content.LoadText(newtxt);
        }

        #region Image Functions
        public static void FindAndReplaceImage(DocumentModel document, string replacetxt, string picpath, double cellWdth = 100, double cellHgt = 100)
        {
            double scaleRto;
            double scaleVal = 100;
            double checkRto = -1;

            ContentRange content = document.Content.Find(replacetxt).First();
            Picture picture = new Picture(document, picpath);

            if (cellWdth == 100 && cellHgt == 100)
            {
                IEnumerable<Element> elements = content.GetChildElements();
                foreach (Element element in elements)
                {
                    if (element.Parent.Parent.Parent != null)
                    {
                        scaleVal = ((TableRow)element.Parent.Parent.Parent).RowFormat.Height.Value;
                    }
                }

                scaleRto = scaleVal / picture.Layout.Size.Height;
            }
            else if (cellHgt == 100)
            {
                IEnumerable<Element> elements = content.GetChildElements();
                foreach (Element element in elements)
                {
                    if (element.Parent.Parent.Parent != null)
                    {
                        checkRto = ((TableRow)element.Parent.Parent.Parent).RowFormat.Height.Value / picture.Layout.Size.Height;
                    }
                }

                if (checkRto == -1)
                {
                    scaleRto = cellWdth / picture.Layout.Size.Width;
                }
                else
                {
                    scaleRto = Math.Min(cellWdth / picture.Layout.Size.Width, checkRto);
                }
            }
            else
            {
                scaleRto = Math.Min(cellHgt / picture.Layout.Size.Height, cellWdth / picture.Layout.Size.Width);
            }

            picture.Layout.Size = new Size(picture.Layout.Size.Width * scaleRto, picture.Layout.Size.Height * scaleRto);

            content.Set(picture.Content);
        }
        #endregion

        #endregion

        public static string CompleteWelderQual(Welder_Qualification wq)
        {
            Datasheet ds = ApiClient.ApiCalls.ReadDatasheet(wq.Datasheet.DatasheetId);
            Visual_Inspection vi = ApiClient.ApiCalls.ReadVisualInspection(wq.Visual_Inspection.Visual_InspectionId);

            DocumentModel datasheetWord = FillDatasheet(ds);
            DocumentModel visualWord = FillInspection(vi);

            DocumentModel commbinedWord = new DocumentModel();

            commbinedWord.Content.End.InsertRange(datasheetWord.Content);
            commbinedWord.Content.End.InsertRange(visualWord.Content);
            
            string templatePath = Save(wq.WeldingAction.Job.QuoteNumber, "Welder_Qualification", commbinedWord);

            string[] reportsPath = wq.Attachments
                .Where(w => w.AttachmentType == AttachmentTypes.NATA_Report)
                .Select(w => w.ServerPath)
                .ToArray();

            string[] combinedPaths = new[] { templatePath }
                .Concat(reportsPath)
                .ToArray();

            return CombinePDFs(combinedPaths, wq.WeldingAction.Job.QuoteNumber, "Welder_Qualification " + wq.Datasheet.WPQRNumber + " " + wq.Datasheet.WelderEID);
        }

        public static string CompleteDatasheet(Datasheet ds)
        {
            DocumentModel document = FillDatasheet(ds);

            return Save(ds.Welder_Qualification.WeldingAction.Job.QuoteNumber, "Datasheet", document);
        }

        public static DocumentModel FillDatasheet(Datasheet ds)
        {
            int i;

            int consumableidx = 2;
            int notesRow = 1;
            int notesCell = 5;

            int parameteridx = 2;
            int imageRow = 1;
            int imageCell = 14;
            int numRows = 0;
            int minRows = 15;

            double totalHeight = 0;

            using (MemoryStream stream = new MemoryStream(Properties.Resources.New_Datasheet_Template))
            {
                DocumentModel document = DocumentModel.Load(stream);

                #region simple find and replace
                FindAndReplaceText(document, "{{client}}", ds.Welder_Qualification.WeldingAction.Job.Client);
                FindAndReplaceText(document, "{{jointdesign}}", ds.JointDesign);
                FindAndReplaceText(document, "{{jointtype}}", ds.JointType);
                FindAndReplaceText(document, "{{testdate}}", ds.TestDate?.ToString("dd MMMM yyyy"));

                FindAndReplaceText(document, "{{rootface}}", ds.RootFace.ToString());
                FindAndReplaceText(document, "{{rootgap}}", ds.RootGap.ToString());
                FindAndReplaceText(document, "{{includedangle}}", ds.IncludedAngle.ToString());
                FindAndReplaceText(document, "{{position}}", ds.WeldingPosition);

                FindAndReplaceText(document, "{{materialstd}}", ds.MaterialStd);
                FindAndReplaceText(document, "{{materialgrd}}", ds.MaterialGrd);
                FindAndReplaceText(document, "{{thickness}}", ds.MaterialThickness.ToString());
                FindAndReplaceText(document, "{{process}}", ds.WeldingProcess);
                FindAndReplaceText(document, "{{weldingstandard}}", ds.WeldingStandard);

                FindAndReplaceText(document, "{{preheat}}", ds.PreheatTemp.ToString());
                FindAndReplaceText(document, "{{maxinterpass}}", ds.Datasheet_Run.Max(dr => dr.Interpass).ToString());

                FindAndReplaceText(document, "{{wpqrnumber}}", ds.WPQRNumber.ToString());
                FindAndReplaceText(document, "{{weldername}}", ApiCalls.GetPerson(ds.WelderEID).EmployeeName);
                FindAndReplaceText(document, "{{employeenumber}}", ds.WelderEID);

                FindAndReplaceText(document, "{{notes}}", ds.Notes);
                #endregion

                #region dynamic table insert
                Table[] tables = document.GetChildElements(true, ElementType.Table).Cast<Table>().ToArray();
                Table consumableTbl = tables[1];
                Table parameterTbl = tables[2];

                //Consumables
                for (i = 1; i < ds.Consumables.Count; i++)
                {
                    consumableTbl.Rows.Insert(consumableidx, consumableTbl.Rows[consumableidx].Clone(true));

                    consumableTbl.Rows[notesRow].Cells[notesCell].RowSpan++;
                }

                i = consumableidx;

                foreach (Consumable co in ds.Consumables)
                {
                    InsertTableCellText(consumableTbl, i, 0, co.Manufacturer);
                    InsertTableCellText(consumableTbl, i, 1, co.ProductName);
                    InsertTableCellText(consumableTbl, i, 2, co.Classification);
                    InsertTableCellText(consumableTbl, i, 3, co.BatchNumber);
                    InsertTableCellText(consumableTbl, i, 4, ds.HeatNumber);

                    i++;
                }

                // Parameters
                numRows = Math.Max(minRows, ds.Datasheet_Run.Count);
                totalHeight += parameterTbl.Rows[1].RowFormat.Height.Value;

                for (i = 1; i < numRows; i++)
                {
                    parameterTbl.Rows.Insert(parameteridx, parameterTbl.Rows[parameteridx].Clone(true));

                    totalHeight += parameterTbl.Rows[i].RowFormat.Height.Value;
                    parameterTbl.Rows[imageRow].Cells[imageCell].RowSpan++;
                }

                i = parameteridx;

                foreach (Datasheet_Run dr in ds.Datasheet_Run)
                {
                    InsertTableCellText(parameterTbl, i, 0, dr.Side.ToString());
                    InsertTableCellText(parameterTbl, i, 1, dr.Pass.ToString());
                    InsertTableCellText(parameterTbl, i, 2, dr.FillerDia.ToString());
                    InsertTableCellText(parameterTbl, i, 3, dr.Supply);
                    InsertTableCellText(parameterTbl, i, 4, dr.Amps.ToString());
                    InsertTableCellText(parameterTbl, i, 5, dr.Volts.ToString());
                    InsertTableCellText(parameterTbl, i, 6, dr.Interpass.ToString());
                    InsertTableCellText(parameterTbl, i, 7, dr.CalculatedLength.ToString());
                    InsertTableCellText(parameterTbl, i, 8, dr.ActualLength.ToString());
                    InsertTableCellText(parameterTbl, i, 9, dr.WeldTime.ToString());
                    InsertTableCellText(parameterTbl, i, 10, dr.WeldSpeed.ToString());
                    InsertTableCellText(parameterTbl, i, 11, dr.HeatInput.ToString());
                    InsertTableCellText(parameterTbl, i, 12, dr.ShieldGas.ToString());
                    InsertTableCellText(parameterTbl, i, 13, dr.PurgeGas.ToString());

                    i++;
                }
                #endregion

                #region insert image
                double cellWidth = parameterTbl.Columns[14].PreferredWidth;
                Attachment weldSequence = ds.Attachments.First(d => d.AttachmentType == AttachmentTypes.WQ_Sequence);
                FindAndReplaceImage(document, "{{weldsequence}}", weldSequence.ServerPath, cellWidth, totalHeight);

                cellWidth = consumableTbl.Columns[6].PreferredWidth;
                Attachment weldStamp = ds.Welder_Qualification.Attachments.First(d => d.AttachmentType == AttachmentTypes.Weld_Stamp);
                FindAndReplaceImage(document, "{{weldstamp}}", weldStamp.ServerPath, cellWdth: cellWidth);
                #endregion

                return document;
            }
        }

        public static string CompleteInspection(Visual_Inspection vi)
        {
            DocumentModel document = FillInspection(vi);

            return Save(vi.Welder_Qualification.WeldingAction.Job.QuoteNumber, "Visual_Inspection", document);
        }

        public static DocumentModel FillInspection(Visual_Inspection vi)
        {
            using (MemoryStream stream = new MemoryStream(Properties.Resources.Inspection_Template))
            {
                DocumentModel document = DocumentModel.Load(stream);

                #region simple find and replace
                FindAndReplaceText(document, "{{client}}", vi.Welder_Qualification.WeldingAction.Job.Client);
                FindAndReplaceText(document, "{{job_number}}", vi.Welder_Qualification.WeldingAction.Job.JobNo);
                FindAndReplaceText(document, "{{job_title}}", vi.Welder_Qualification.WeldingAction.Job.ItemDescription);
                FindAndReplaceText(document, "{{welding_standard}}", vi.WeldingStandard);
                FindAndReplaceText(document, "{{location}}", vi.Location);
                FindAndReplaceText(document, "{{weld_map}}", vi.WeldMap);

                FindAndReplaceText(document, "{{inspection_date}}", vi.Date?.ToString("dd MMMM yyyy"));
                FindAndReplaceText(document, "{{material_std}}", vi.MaterialStd);
                FindAndReplaceText(document, "{{material_grd}}", vi.MaterialGrd);
                FindAndReplaceText(document, "{{drawing_number}}", vi.DrawingNumber);
                FindAndReplaceText(document, "{{wpqr_number}}", vi.Welder_Qualification.Datasheet.WPQRNumber.ToString());
                FindAndReplaceText(document, "{{serial_number}}", vi.SerialNumbers);

                FindAndReplaceText(document, "{{wi}}", vi.Weld_Id == true ? "S" : "U");
                FindAndReplaceText(document, "{{wli}}", vi.Welder_Id == true ? "S" : "U");
                FindAndReplaceText(document, "{{ii}}", vi.Initial == true ? "S" : "U");
                FindAndReplaceText(document, "{{rwi}}", vi.Repair == true ? "S" : "U");
                FindAndReplaceText(document, "{{fi}}", vi.Final == true ? "S" : "U");
                FindAndReplaceText(document, "{{wp}}", vi.Procedure == true ? "S" : "U");
                FindAndReplaceText(document, "{{wq}}", vi.Qualification == true ? "S" : "U");
                FindAndReplaceText(document, "{{mc}}", vi.Control == true ? "S" : "U");
                FindAndReplaceText(document, "{{ws}}", vi.Profile == true ? "S" : "U");
                FindAndReplaceText(document, "{{wl}}", vi.WeldLocation == true ? "S" : "U");
                FindAndReplaceText(document, "{{c}}", vi.Cracks == true ? "S" : "U");
                FindAndReplaceText(document, "{{ip}}", vi.Penetration == true ? "S" : "U");
                FindAndReplaceText(document, "{{if}}", vi.Fusion == true ? "S" : "U");
                FindAndReplaceText(document, "{{p}}", vi.Porosity == true ? "S" : "U");
                FindAndReplaceText(document, "{{bt}}", vi.BurnThrough == true ? "S" : "U");
                FindAndReplaceText(document, "{{u}}", vi.Undercut == true ? "S" : "U");
                FindAndReplaceText(document, "{{as}}", vi.ArcStrike == true ? "S" : "U");
                FindAndReplaceText(document, "{{wr}}", vi.Repair == true ? "S" : "U");
                FindAndReplaceText(document, "{{sb}}", vi.SuckBack == true ? "S" : "U");
                FindAndReplaceText(document, "{{cs}}", vi.Crater == true ? "S" : "U");
                FindAndReplaceText(document, "{{r}}", vi.Satisfactory == true ? "S" : "U");

                FindAndReplaceText(document, "{{notes}}", vi.Notes);
                #endregion

                #region insert image
                Table[] tables = document.GetChildElements(true, ElementType.Table).Cast<Table>().ToArray();
                Table stampTbl = tables[1];

                Datasheet ds = ApiClient.ApiCalls.ReadDatasheet(vi.Welder_Qualification.Datasheet.DatasheetId);

                double cellWidth = stampTbl.Columns[1].PreferredWidth;
                Attachment weldStamp = ds.Welder_Qualification.Attachments.First(d => d.AttachmentType == AttachmentTypes.Weld_Stamp);
                FindAndReplaceImage(document, "{{weldstamp}}", weldStamp.ServerPath, cellWdth: cellWidth);
                #endregion

                return document;
            }
        }

        public static string CompleteWPQR(WPQR wpqr)
        {
            DocumentModel wpqrWord = FillWPQR(wpqr);

            Datasheet ds = ApiClient.ApiCalls.ReadDatasheet(wpqr.Welder_Qualification.Datasheet.DatasheetId);
            Visual_Inspection vi = ApiClient.ApiCalls.ReadVisualInspection(wpqr.Welder_Qualification.Visual_Inspection.Visual_InspectionId);

            DocumentModel datasheetWord = FillDatasheet(ds);
            DocumentModel visualWord = FillInspection(vi);

            DocumentModel combinedWord = new DocumentModel();

            combinedWord.Content.End.InsertRange(wpqrWord.Content);
            combinedWord.Content.End.InsertRange(datasheetWord.Content);
            combinedWord.Content.End.InsertRange(visualWord.Content);

            string templatePath = Save(wpqr.Welder_Qualification.WeldingAction.Job.QuoteNumber, "WPQR", combinedWord);

            string[] reportsPath = wpqr.Welder_Qualification.Attachments
                .Where(w => w.AttachmentType == AttachmentTypes.NATA_Report)
                .Select(w => w.ServerPath)
                .ToArray();

            string[] certsPath = wpqr.Attachments
                .Where(w => w.AttachmentType == AttachmentTypes.Certificates)
                .Select(w => w.ServerPath)
                .ToArray();

            string[] combinedPaths = new[] { templatePath }
                .Concat(reportsPath)
                .Concat(certsPath)
                .ToArray();

            return CombinePDFs(combinedPaths, wpqr.Welder_Qualification.WeldingAction.Job.QuoteNumber, "WPQR " + wpqr.WPQRNumber);
        }

        public static DocumentModel FillWPQR(WPQR wpqr)
        {
            int i = 0;
            int parameteridx = 2;

            using (MemoryStream stream = new MemoryStream(Properties.Resources.WPQR_Template))
            {
                DocumentModel document = DocumentModel.Load(stream);

                #region simple find and replace
                FindAndReplaceText(document, "{{wpqr}}", wpqr.WPQRNumber);
                FindAndReplaceText(document, "{{weldingstd}}", wpqr.WeldingStandard);
                FindAndReplaceText(document, "{{jointtype}}", wpqr.JointType);
                FindAndReplaceText(document, "{{preparedname}}", ApiCalls.GetPerson(wpqr.WPQRPreparerEID).EmployeeName);
                FindAndReplaceText(document, "{{weldingtype}}", wpqr.WeldingType);
                FindAndReplaceText(document, "{{thickness}}", wpqr.Thickness.ToString());
                FindAndReplaceText(document, "{{wpqrdate}}", wpqr.Date?.ToString("dd MMMM yyyy"));
                FindAndReplaceText(document, "{{diameter}}", wpqr.Diameter.ToString());

                //TODO: WPS Number

                FindAndReplaceText(document, "{{materialstd}}", wpqr.BMSpecfication);
                FindAndReplaceText(document, "{{materialgrd}}", wpqr.BMGrade);
                FindAndReplaceText(document, "{{pno}}", wpqr.BMGroupPNumber);
                FindAndReplaceText(document, "{{maxpass}}", wpqr.MaxThickness.ToString());
                FindAndReplaceText(document, "{{other}}", wpqr.Other);

                FindAndReplaceText(document, "{{fs}}", wpqr.FillerSpecification);
                FindAndReplaceText(document, "{{fc}}", wpqr.FillerClassification);
                FindAndReplaceText(document, "{{fn}}", wpqr.FillerFNumber);
                FindAndReplaceText(document, "{{an}}", wpqr.FillerANumber);
                FindAndReplaceText(document, "{{efc}}", wpqr.EFluxClassification);
                FindAndReplaceText(document, "{{sf}}", wpqr.FillerSize.ToString());
                FindAndReplaceText(document, "{{ff}}", wpqr.FillerForm);
                FindAndReplaceText(document, "{{ft}}", wpqr.FluxType);
                FindAndReplaceText(document, "{{ftn}}", wpqr.FluxTradeName);
                FindAndReplaceText(document, "{{wmt}}", wpqr.WMThickness.ToString());
                FindAndReplaceText(document, "{{ff}}", wpqr.FillerNotes);

                FindAndReplaceText(document, "{{pp}}", wpqr.Position);
                FindAndReplaceText(document, "{{pwp}}", wpqr.WeldProgression);
                FindAndReplaceText(document, "{{po}}", wpqr.PositionNotes);

                FindAndReplaceText(document, "{{pht}}", wpqr.PreheatTemp.ToString());
                FindAndReplaceText(document, "{{pit}}", wpqr.InterpassTemp.ToString());
                FindAndReplaceText(document, "{{pro}}", wpqr.PreheatNotes);

                FindAndReplaceText(document, "{{ptm}}", wpqr.PWHTTemp.ToString());
                FindAndReplaceText(document, "{{pti}}", wpqr.PWHTTime.ToString());
                FindAndReplaceText(document, "{{phr}}", wpqr.HeatingRate.ToString());
                FindAndReplaceText(document, "{{pcr}}", wpqr.CoolingRate.ToString());
                FindAndReplaceText(document, "{{pwo}}", wpqr.PWHTNotes);

                FindAndReplaceText(document, "{{gsc}}", wpqr.ShieldComposition);
                FindAndReplaceText(document, "{{gsf}}", wpqr.ShieldFlowRate.ToString());
                FindAndReplaceText(document, "{{gtc}}", wpqr.TrailingComposition);
                FindAndReplaceText(document, "{{gtf}}", wpqr.TrailingFlowRate.ToString());
                FindAndReplaceText(document, "{{gbc}}", wpqr.BackingComposition);
                FindAndReplaceText(document, "{{gbf}}", wpqr.BackingFlowRate.ToString());
                FindAndReplaceText(document, "{{go}}", wpqr.GasNotes);

                FindAndReplaceText(document, "{{ec}}", wpqr.Current);
                FindAndReplaceText(document, "{{ep}}", wpqr.Polarity);
                FindAndReplaceText(document, "{{ea}}", wpqr.MinAmps.ToString() + "-" + wpqr.MaxAmps.ToString());
                FindAndReplaceText(document, "{{ev}}", wpqr.MinVolts.ToString() + "-" + wpqr.MaxVolts.ToString());
                FindAndReplaceText(document, "{{ete}}", wpqr.TESize.ToString());
                FindAndReplaceText(document, "{{mom}}", wpqr.MetalTransfer);
                FindAndReplaceText(document, "{{ehi}}", wpqr.ElectrodeType);
                FindAndReplaceText(document, "{{go}}", wpqr.ElectricalNotes);

                FindAndReplaceText(document, "{{tsb}}", wpqr.BeadType);
                FindAndReplaceText(document, "{{tts}}", wpqr.MinTravelSpeed.ToString() + "-" + wpqr.MaxTravelSpeed.ToString());
                FindAndReplaceText(document, "{{tos}}", wpqr.Oscillation);
                FindAndReplaceText(document, "{{tmp}}", wpqr.PassType);
                FindAndReplaceText(document, "{{tsm}}", wpqr.ElectrodeType);
                FindAndReplaceText(document, "{{to}}", wpqr.TechniqueNotes);

                FindAndReplaceText(document, "{{ndt}}", wpqr.NDTReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{vi}}", wpqr.VIReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{dpi}}", wpqr.DPIReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{mpi}}", wpqr.MPIReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{rt}}", wpqr.RTReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{ut}}", wpqr.UTReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{dt}}", wpqr.DTReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{mcro}}", wpqr.MacroReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{hrd}}", wpqr.HardnessReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{bend}}", wpqr.BendReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{ten}}", wpqr.TensilReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{imp}}", wpqr.ImpactReq == true ? "✔" : "✖");

                FindAndReplaceText(document, "{{notes}}", wpqr.Notes);
                #endregion

                #region dynamic table insert
                Table[] tables = document.GetChildElements(true, ElementType.Table).Cast<Table>().ToArray();
                Table imageTbl = tables[1];
                Table stampTbl = tables[5];
                Table parameterTbl = tables[3];

                //Parameters
                for (i = 1; i < wpqr.WPQR_Run.Count; i++)
                {
                    parameterTbl.Rows.Insert(parameteridx, parameterTbl.Rows[parameteridx].Clone(true));
                }

                i = parameteridx;

                foreach (WPQR_Run wr in wpqr.WPQR_Run)
                {
                    InsertTableCellText(parameterTbl, i, 0, wr.Side.ToString());
                    InsertTableCellText(parameterTbl, i, 1, wr.Pass.ToString());
                    InsertTableCellText(parameterTbl, i, 2, wr.WeldingProcess);
                    InsertTableCellText(parameterTbl, i, 3, wr.WeldingPosition);
                    InsertTableCellText(parameterTbl, i, 4, wr.FillerDia.ToString());
                    InsertTableCellText(parameterTbl, i, 5, wr.Specification);
                    InsertTableCellText(parameterTbl, i, 6, wr.Classification);
                    InsertTableCellText(parameterTbl, i, 7, wr.Supply);
                    InsertTableCellText(parameterTbl, i, 8, wr.ShieldGas.ToString());
                    InsertTableCellText(parameterTbl, i, 9, wr.HeatInput.ToString());
                    InsertTableCellText(parameterTbl, i, 10, wr.Amps.ToString());
                    InsertTableCellText(parameterTbl, i, 11, wr.Volts.ToString());
                    InsertTableCellText(parameterTbl, i, 12, wr.WeldSpeed.ToString());

                    i++;
                }
                #endregion

                #region insert image
                double cellWidth = imageTbl.Columns[0].PreferredWidth;

                Attachment weldPrep = wpqr.Attachments.First(d => d.AttachmentType == AttachmentTypes.WPQR_Preparation);
                FindAndReplaceImage(document, "{{weldpreparation}}", weldPrep.ServerPath, cellWdth: cellWidth);

                cellWidth = imageTbl.Columns[1].PreferredWidth;
                Attachment passLoc = wpqr.Attachments.First(d => d.AttachmentType == AttachmentTypes.WPQR_Sequence);
                FindAndReplaceImage(document, "{{passlocation}}", passLoc.ServerPath, cellWdth: cellWidth);

                cellWidth = stampTbl.Columns[1].PreferredWidth;
                Attachment weldStamp = wpqr.Attachments.First(d => d.AttachmentType == AttachmentTypes.Weld_Stamp);
                FindAndReplaceImage(document, "{{weldstamp}}", weldStamp.ServerPath, cellWdth: cellWidth);
                #endregion

                return document;
            }
        }

        public static string CompleteWPS(WPS wps, bool withJNo=true)
        {
            DocumentModel document = FillWPS(wps, withJNo);

            return Save(wps.WPQR.Welder_Qualification.WeldingAction.Job.QuoteNumber, "WPS " + wps.WPSNumber, document);
        }

        public static DocumentModel FillWPS(WPS wps, bool withJNo)
        {
            int i = 0;
            int parameteridx = 2;

            using (MemoryStream stream = new MemoryStream(Properties.Resources.WPS_Template))
            {
                DocumentModel document = DocumentModel.Load(stream);

                #region simple find and replace

                if (withJNo)
                {
                    FindAndReplaceText(document, "{{jobnumber}}", wps.WPQR.Welder_Qualification.WeldingAction.Job.JobNo);
                }
                else
                {
                    FindAndReplaceText(document, "{{jobnumber}}", "");
                }
                
                FindAndReplaceText(document, "{{wps}}", wps.WPSNumber);
                FindAndReplaceText(document, "{{wpqrnumber}}", wps.WPQR.WPQRNumber);

                FindAndReplaceText(document, "{{preparedname}}", ApiCalls.GetPerson(wps.WPSPreparerEID).EmployeeName);
                FindAndReplaceText(document, "{{wpsdate}}", wps.Date?.ToString("dd MMMM yyyy"));
                FindAndReplaceText(document, "{{jointtype}}", wps.JointType);
                FindAndReplaceText(document, "{{thickness}}", wps.MinThickness.ToString() + "-" + wps.MaxThickness.ToString());
                FindAndReplaceText(document, "{{diameter}}", wps.MinDiameter.ToString() + "-" + wps.MaxDiameter.ToString());

                FindAndReplaceText(document, "{{materialstd}}", wps.MaterialStd);
                FindAndReplaceText(document, "{{materialgrd}}", wps.MaterialGrd);
                FindAndReplaceText(document, "{{pno}}", wps.MaterialPNo);
                FindAndReplaceText(document, "{{prepmethod}}", wps.PrepMethod);
                FindAndReplaceText(document, "{{gougingmethod}}", wps.GougingMethod);

                FindAndReplaceText(document, "{{pwht}}", wps.PWHT.ToString());
                FindAndReplaceText(document, "{{preheat}}", wps.Preheat.ToString());
                FindAndReplaceText(document, "{{interpass}}", wps.Interpass.ToString());

                FindAndReplaceText(document, "{{ndt}}", wps.NDTReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{vi}}", wps.VIReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{dpi}}", wps.DPIReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{mpi}}", wps.MPIReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{rt}}", wps.RTReq == true ? "✔" : "✖");
                FindAndReplaceText(document, "{{ut}}", wps.UTReq == true ? "✔" : "✖");

                FindAndReplaceText(document, "{{notes}}", wps.Notes);
                #endregion

                #region dynamic table insert
                Table[] tables = document.GetChildElements(true, ElementType.Table).Cast<Table>().ToArray();
                Table imageTbl = tables[1];
                Table stampTbl = tables[5];
                Table parameterTbl = tables[3];

                //Parameters
                for (i = 1; i < wps.WPS_Run.Count; i++)
                {
                    parameterTbl.Rows.Insert(parameteridx, parameterTbl.Rows[parameteridx].Clone(true));
                }

                i = parameteridx;

                foreach (WPS_Run wr in wps.WPS_Run)
                {
                    InsertTableCellText(parameterTbl, i, 0, wr.Side.ToString());
                    InsertTableCellText(parameterTbl, i, 1, wr.Pass.ToString());
                    InsertTableCellText(parameterTbl, i, 2, wr.WeldingProcess);
                    InsertTableCellText(parameterTbl, i, 3, wr.WeldingPosition);
                    InsertTableCellText(parameterTbl, i, 4, wr.FillerDia.ToString());
                    InsertTableCellText(parameterTbl, i, 5, wr.Specification);
                    InsertTableCellText(parameterTbl, i, 6, wr.Classification);
                    InsertTableCellText(parameterTbl, i, 7, wr.Supply);
                    InsertTableCellText(parameterTbl, i, 8, wr.ShieldGas.ToString());
                    InsertTableCellText(parameterTbl, i, 9, wr.HeatInput);
                    InsertTableCellText(parameterTbl, i, 10, wr.Amps);
                    InsertTableCellText(parameterTbl, i, 11, wr.Volts);
                    InsertTableCellText(parameterTbl, i, 12, wr.WeldSpeed);

                    i++;
                }
                #endregion

                #region insert image
                double cellWidth = imageTbl.Columns[0].PreferredWidth;

                Attachment weldPrep = wps.Attachments.First(d => d.AttachmentType == AttachmentTypes.WPS_Preparation);
                FindAndReplaceImage(document, "{{weldpreparation}}", weldPrep.ServerPath, cellWdth: cellWidth);

                cellWidth = imageTbl.Columns[1].PreferredWidth;
                Attachment passLoc = wps.Attachments.First(d => d.AttachmentType == AttachmentTypes.WPS_Sequence);
                FindAndReplaceImage(document, "{{passlocation}}", passLoc.ServerPath, cellWdth: cellWidth);

                cellWidth = stampTbl.Columns[1].PreferredWidth;
                Attachment weldStamp = wps.Attachments.First(d => d.AttachmentType == AttachmentTypes.Weld_Stamp);
                FindAndReplaceImage(document, "{{weldstamp}}", weldStamp.ServerPath, cellWdth: cellWidth);
                #endregion

                return document;
            }
        }

        private static string Save(string quoteNo, string type, DocumentModel document)
        {
            string jobPath = Path.Combine(serverDirectory, quoteNo);

            if (!Directory.Exists(jobPath))
                Directory.CreateDirectory(jobPath);

            string statusPath = Path.Combine(jobPath, type);

            if (!Directory.Exists(statusPath))
                Directory.CreateDirectory(statusPath);

            string fileName = Path.Combine(statusPath, type + ".pdf"); // " {0}.pdf");
            string uniqueName = fileName; // MakeUniqueFileName(fileName); //

            document.Save(uniqueName);

            return uniqueName;
        }

        private static string Save(string quoteNo, string type, PdfDocument document)
        {
            string jobPath = Path.Combine(serverDirectory, quoteNo);

            if (!Directory.Exists(jobPath))
                Directory.CreateDirectory(jobPath);

            string statusPath = Path.Combine(jobPath, type);

            if (!Directory.Exists(statusPath))
                Directory.CreateDirectory(statusPath);

            string fileName = Path.Combine(statusPath, type + ".pdf"); // " {0}.pdf");
            string uniqueName = fileName; // MakeUniqueFileName(fileName); //

            document.Save(uniqueName);

            return uniqueName;
        }

        public static void DownloadPDF(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    using (var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                    {
                        var memoryStream = new MemoryStream();
                        stream.CopyTo(memoryStream);
                        memoryStream.Position = 0;

                        string fileName = Path.GetFileName(filePath);
                        Application.Download(memoryStream, fileName);
                    }
                }
                else
                {
                    MessageBox.Show("File not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while downloading the file: {ex.Message}");
            }
        }

        public static string CombinePDFs(string[] fileNames, string quoteNo, string type)
        {
            using (PdfDocument outputDocument = new PdfDocument())
            {
                foreach (string file in fileNames)
                {
                    using (PdfDocument inputDocument = PdfReader.Open(file, PdfDocumentOpenMode.Import))
                    {
                        for (int i = 0; i < inputDocument.PageCount; i++)
                        {
                            PdfPage page = inputDocument.Pages[i];
                            outputDocument.AddPage(page);
                        }
                    }
                }
                return Save(quoteNo, type, outputDocument);
            }
        }
    }
}