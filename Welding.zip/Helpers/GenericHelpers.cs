﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Welding.DAL;
using Wisej.Web;

namespace WeldingManagement.Helpers
{
    public static class GenericHelpers
    {
        public enum TriState
        {
            True,
            False,
            Indeterminant
        }

        public static bool CheckComplete(Job job)
        {
            int completeActions = 0;

            foreach (WeldingAction action in job.WeldingActions)
            {
                if (action.NewWeldingForm.OperationalReview != null)
                {
                    bool condition1 = action.Welder_Qualification.Count >= action.NewWeldingForm.OperationalReview.WeldersAmount;
                    bool condition2 = action.Welder_Qualification.All(wq => wq.Status == Actions.Complete);

                    bool condition3 = action.WPQRs.Count >= action.NewWeldingForm.OperationalReview.WPQRAmount;
                    bool condition4 = action.WPQRs.All(wpqr => wpqr.Status == Actions.Complete);

                    bool condition5 = action.WPS.Count >= action.NewWeldingForm.OperationalReview.WPSAmount;
                    bool condition6 = action.WPS.All(wps => wps.Status == Actions.Complete);

                    bool condition7 = action.NewWeldingForm.Status == Actions.Complete;

                    if (condition1 && condition2 && condition3 && condition4 && condition5 && condition6 && condition7)
                    {
                        completeActions++;
                    }
                }
            }
            return (job.WeldingActions.Count == completeActions);
        }

        public static List<ListViewItem> FilterItems(List<ListViewItem> items, string filter, string property, ListView lv)
        {
            return items.Where(item =>
            {
                int propertyIndex = lv.Columns.IndexOf(lv.Columns[property]);
                return item.SubItems[propertyIndex].Text.Contains(filter);
            }).ToList();
        }
    }
}