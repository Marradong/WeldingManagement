﻿using System;
using System.IO;
using Wisej.Web;
using System.Drawing;
using WeldingManagement.UserControls;
using System.Diagnostics;
using System.Web;
using Welding.DAL;
using System.Reflection;
using System.Linq;
using System.Runtime.Versioning;
using System.Drawing.Imaging;
using ApiClient;

namespace WeldingManagement
{
    public static class FileManagement
    {
        public static string serverDirectory = @"D:\CamcoApps\FileStore\WeldingManagement\";
        public static bool StoreFile(HttpPostedFile file, AttachmentTypes attType, string quoteNo, Type linkObjType, long linkObjId)
        {
            bool success = false;

            if (file == null)
            {
                return success;
            }

            //Create Directory for job
            string jobPath = Path.Combine(serverDirectory, quoteNo);

            if (!Directory.Exists(jobPath))
                Directory.CreateDirectory(jobPath);

            string folder = linkObjType.Name;

            string statusPath = Path.Combine(jobPath, linkObjType.Name);

            if (!Directory.Exists(statusPath))
                Directory.CreateDirectory(statusPath);

            string ext = Path.GetExtension(file.FileName);
            string fileName = Path.Combine(statusPath, Path.GetFileName(file.FileName).Split('.')[0] + " {0}" + $"{ext}");
            string uniqueName = MakeUniqueFileName(fileName);

            try
            {
                file.SaveAs(uniqueName);

                Attachment newAttachment = new Attachment();
                newAttachment.ServerPath = uniqueName;
                newAttachment.AttachmentType = attType;

                ApiClient.ApiCalls.CreateAttachment(newAttachment, linkObjType.Name, linkObjId);

                success = true;
            }
            catch (Exception ex)
            {
                string message = $"<ERROR> Saving File\r\nFilename : {fileName}\r\n {ex.Message}";
                if (Debugger.IsAttached)
                    throw new ApplicationException(message);
            }

            return success;
        }

        public static bool StoreBitmap(Bitmap bmp, string fName, AttachmentTypes attType, string quoteNo, Type linkObjType, long linkObjId)
        {
            bool success = false;

            if (bmp == null)
            {
                return success;
            }

            //Create Directory for job
            string jobPath = Path.Combine(serverDirectory, quoteNo);

            if (!Directory.Exists(jobPath))
                Directory.CreateDirectory(jobPath);

            string folder = linkObjType.Name;

            string statusPath = Path.Combine(jobPath, linkObjType.Name);

            if (!Directory.Exists(statusPath))
                Directory.CreateDirectory(statusPath);

            string fileName = Path.Combine(statusPath, fName + " {0}.jpeg");
            string uniqueName = MakeUniqueFileName(fileName);

            try
            {
                bmp.Save(uniqueName, System.Drawing.Imaging.ImageFormat.Jpeg);

                Attachment newAttachment = new Attachment();
                newAttachment.ServerPath = uniqueName;
                newAttachment.AttachmentType = attType;

                ApiClient.ApiCalls.CreateAttachment(newAttachment, linkObjType.Name, linkObjId);

                success = true;
            }
            catch (Exception ex)
            {
                string message = $"<ERROR> Saving File\r\nFilename : {fileName}\r\n {ex.Message}";
                if (Debugger.IsAttached)
                    throw new ApplicationException(message);
            }

            return success;
        }

        public static bool CopyFile(Attachment attToCopy, string quoteNo, Type linkObjType, long linkObjId)
        {
            bool success = false;

            string fromPath = attToCopy.ServerPath;

            if (string.IsNullOrEmpty(fromPath) || !File.Exists(fromPath))
            {
                return success;
            }

            //Create Directory for job
            string jobPath = Path.Combine(serverDirectory, quoteNo);

            if (!Directory.Exists(jobPath))
                Directory.CreateDirectory(jobPath);

            string folder = linkObjType.Name;

            string statusPath = Path.Combine(jobPath, linkObjType.Name);

            if (!Directory.Exists(statusPath))
                Directory.CreateDirectory(statusPath);

            string ext = Path.GetExtension(fromPath);
            string fileName = Path.Combine(statusPath, Path.GetFileName(fromPath).Split('.')[0] + " {0}" + $"{ext}");
            string uniqueName = MakeUniqueFileName(fileName);

            try
            {
                File.Copy(fromPath, uniqueName);

                attToCopy.ServerPath = uniqueName;

                ApiClient.ApiCalls.CreateAttachment(attToCopy, linkObjType.Name, linkObjId);

                success = true;
            }
            catch (Exception ex)
            {
                string message = $"<ERROR> Saving File\r\nFilename : {fileName}\r\n {ex.Message}";
                if (Debugger.IsAttached)
                    throw new ApplicationException(message);
            }

            return success;
        }

        public static string MakeUniqueFileName(string file)
        {
            string dir = Path.GetDirectoryName(file);
            string fn;

            for (int i = 0; ; ++i)
            {
                fn = Path.Combine(dir, string.Format(file, i));

                if (!File.Exists(fn))
                    return fn;
            }
        }

        public static Image GetImageFromStream(Stream stream)
        {
            Image Capture = Image.FromStream(stream);

            try
            {
                int quality = 90;
                EncoderParameters encoderParameters = new EncoderParameters(1);
                encoderParameters.Param[0] = new EncoderParameter(Encoder.Quality, (long)quality);

                MemoryStream ms = new MemoryStream();

                Capture.Save(ms, GetImageCodeInfo("image/jpeg"), encoderParameters);
                ms.Seek(0, SeekOrigin.Begin);

                Image returnImage = Image.FromStream(ms);

                return returnImage;
            }
            catch
            {
                return Capture;
            }


        }
        public static ImageCodecInfo GetImageCodeInfo(string mimeType)
        {
            ImageCodecInfo[] info = ImageCodecInfo.GetImageEncoders();
            foreach (ImageCodecInfo ici in info)
                if (ici.MimeType.Equals(mimeType, StringComparison.OrdinalIgnoreCase))
                    return ici;
            return null;
        }

        public static void DeleteAttachment(Attachment att, PictureBox pb=null)
        {
            try
            {
                File.Delete(att.ServerPath);

                if (pb != null)
                {
                    pb.Image.Dispose();
                }

                ApiCalls.DeleteAttachment(att.AttachmentId);
            }
            catch (Exception ex)
            {
                string message = $"<ERROR> Deleting File\r\nFilename : {att.ServerPath}\r\n {ex.Message}";
                if (Debugger.IsAttached)
                    throw new ApplicationException(message);
            }
        }

        public static void DeleteAttachment(Tag itemTag, PictureBox pb = null, PdfViewer pdf = null)
        {
            if (itemTag.getTagType() == TagType.Attachment)
            {
                Attachment att = ApiCalls.ReadAttachment(((Attachment)itemTag.getTagObject()).AttachmentId);

                try
                {
                    if (pb != null && pb.Image != null)
                    {
                        pb.Image.Dispose();
                    }

                    if (pdf != null && pdf.PdfStream != null)
                    {
                        pdf.PdfStream = null;
                    }

                    File.Delete(att.ServerPath);
                    ApiCalls.DeleteAttachment(att.AttachmentId);
                }
                catch (Exception ex)
                {
                    string message = $"<ERROR> Deleting File\r\nFilename : {att.ServerPath}\r\n {ex.Message}";
                    if (Debugger.IsAttached)
                        throw new ApplicationException(message);
                }
            }
        }

        public static void ViewAttachment(Tag itemTag, PictureBox pb, PdfViewer pdf, TableLayoutPanel tlp)
        {
            if (itemTag.getTagType() == TagType.Attachment)
            {
                Attachment selectedAtt = ApiCalls.ReadAttachment(((Attachment)itemTag.getTagObject()).AttachmentId);

                ViewAttachment(selectedAtt.ServerPath, pb, pdf, tlp);
            }
        }

        public static void ViewAttachment(string path, PictureBox pb, PdfViewer pdf, TableLayoutPanel tlp)
        {
            string ext = Path.GetExtension(path);

            int pvHeight = 0;
            int pbHeight = 0;

            if (ext == ".pdf")
            {
                pdf.Visible = true;
                pb.Visible = false;

                pvHeight = 80;

                using (FileStream fStream = new FileStream(path, FileMode.Open, FileAccess.Read))
                {
                    var reader = new BinaryReader(fStream);
                    var buffer = reader.ReadBytes((int)fStream.Length);
                    var mem = new MemoryStream(buffer);

                    pdf.PdfStream = mem;
                }
            }
            else
            {
                pdf.Visible = false;
                pb.Visible = true;

                pbHeight = 80;

                try
                {
                    using (FileStream fStream = new FileStream(path, FileMode.Open, FileAccess.Read))
                    {
                        Image temp = GetImageFromStream(fStream);
                        pb.Image = temp;
                    }
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine($"File timed out and is likely too large to preview: {ex}");
                }
            }

            tlp.RowStyles[tlp.GetCellPosition(pdf).Row].SizeType = SizeType.Percent;
            tlp.RowStyles[tlp.GetCellPosition(pdf).Row].Height = pvHeight;

            tlp.RowStyles[tlp.GetCellPosition(pb).Row].SizeType = SizeType.Percent;
            tlp.RowStyles[tlp.GetCellPosition(pb).Row].Height = pbHeight;
        }
    }
}