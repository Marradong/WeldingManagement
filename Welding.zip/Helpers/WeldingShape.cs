﻿using System;
using System.Collections.Generic;
using System.Drawing;
using Org.BouncyCastle.Asn1.Mozilla;

namespace WeldingManagement
{
    public enum ShapeType
    {
        Rectangle,
        Ellipse,
        Bevel,
        Groove
    }
    public class WeldingShape
    {
        // Rectangle Constuctor
        public WeldingShape(ShapeType pShapeType, List<Point> pShapePath, float pRotation, RotatedRectangle boundingBox)
        {
            ShapeType = pShapeType;
            ShapePath = pShapePath;
            Rotation = pRotation;
            BoundingBox = boundingBox;
        }

        //Ellipse Constructor
        public WeldingShape(ShapeType pShapeType, List<Point> pShapePath, float pRotation, int pRunId, RotatedRectangle boundingBox)
        {
            ShapeType = pShapeType;
            ShapePath = pShapePath;
            Rotation = pRotation;
            RunId = pRunId;
            BoundingBox = boundingBox;
        }

        //Bevel Constructor
        public WeldingShape(ShapeType pShapeType, List<Point> pShapePath, float pRotation, double pRootFace, double pIncludedAngle, double pThickness, bool pHFlip, bool pVflip, bool pDouble, RotatedRectangle boundingBox)
        {
            ShapeType = pShapeType;
            ShapePath = pShapePath;
            Rotation = pRotation;
            Thickness = pThickness;
            RootFace = pRootFace;
            IncludedAngle = pIncludedAngle;
            HFlip = pHFlip;
            VFlip = pVflip;
            Double = pDouble;
            BoundingBox = boundingBox;
        }

        //Groove Constructor
        public WeldingShape(ShapeType pShapeType, List<Point> pShapePath, float pRotation, double pRootFace, double pIncludedAngle, double pThickness, double pRadius, Point pArcCentre, bool pHFlip, bool pVflip, bool pDouble, RotatedRectangle boundingBox)
        {
            ShapeType = pShapeType;
            ShapePath = pShapePath;
            Rotation = pRotation;
            Thickness = pThickness;
            RootFace = pRootFace;
            Radius = pRadius;
            IncludedAngle = pIncludedAngle;
            HFlip = pHFlip;
            VFlip = pVflip;
            Double = pDouble;
            ArcCentre = pArcCentre;
            BoundingBox = boundingBox;
        }

        // Shared Properties
        public ShapeType ShapeType { get; set; }

        public List<Point> ShapePath { get; set; }

        private RotatedRectangle _BoundingBox;
        public RotatedRectangle BoundingBox
        {
            get
            {
                return _BoundingBox;
            }
            set
            {
                _BoundingBox = value;

                AnchorPoints = new List<Point>
                {
                    _BoundingBox.TopLeft,
                    _BoundingBox.TopRight,
                    _BoundingBox.BottomLeft,
                    _BoundingBox.BottomRight,
                };
            }
        }

        public List<Point> AnchorPoints { get; set; }

        public float Rotation { get; set; }

        public double Thickness { get; set; }

        // Unique to Ellipse
        private int _RunId;

        public int RunId
        {
            get
            {
                if (ShapeType == ShapeType.Ellipse)
                {
                    return _RunId;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
            set
            {
                if (ShapeType == ShapeType.Ellipse)
                {
                    _RunId = value;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
        }

        // Unique to Bevel and Groove
        private double _RootFace;

        public double RootFace
        {
            get
            {
                if (ShapeType == ShapeType.Bevel || ShapeType == ShapeType.Groove)
                {
                    return _RootFace;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
            set
            {
                if (ShapeType == ShapeType.Bevel || ShapeType == ShapeType.Groove)
                {
                    _RootFace = value;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
        }

        private double _IncludedAngle;

        public double IncludedAngle
        {
            get
            {
                if (ShapeType == ShapeType.Bevel || ShapeType == ShapeType.Groove)
                {
                    return _IncludedAngle;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
            set
            {
                if (ShapeType == ShapeType.Bevel || ShapeType == ShapeType.Groove)
                {
                    _IncludedAngle = value;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
        }

        private bool _HFlip;

        public bool HFlip
        {
            get
            {
                if (ShapeType == ShapeType.Bevel || ShapeType == ShapeType.Groove)
                {
                    return _HFlip;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
            set
            {
                if (ShapeType == ShapeType.Bevel || ShapeType == ShapeType.Groove)
                {
                    _HFlip = value;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
        }

        private bool _VFlip;

        public bool VFlip
        {
            get
            {
                if (ShapeType == ShapeType.Bevel || ShapeType == ShapeType.Groove)
                {
                    return _VFlip;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
            set
            {
                if (ShapeType == ShapeType.Bevel || ShapeType == ShapeType.Groove)
                {
                    _VFlip = value;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
        }

        private bool _Double;

        public bool Double
        {
            get
            {
                if (ShapeType == ShapeType.Bevel || ShapeType == ShapeType.Groove)
                {
                    return _Double;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
            set
            {
                if (ShapeType == ShapeType.Bevel || ShapeType == ShapeType.Groove)
                {
                    _Double = value;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
        }

        // Unique to Groove
        private double _Radius;

        public double Radius
        {
            get
            {
                if (ShapeType == ShapeType.Groove)
                {
                    return _Radius;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
            set
            {
                if (ShapeType == ShapeType.Groove)
                {
                    _Radius = value;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
        }

        private Point _ArcCentre;
        public Point ArcCentre
        {
            get
            {
                if (ShapeType == ShapeType.Groove)
                {
                    return _ArcCentre;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
            set
            {
                if (ShapeType == ShapeType.Groove)
                {
                    _ArcCentre = value;
                }
                else
                {
                    throw new InvalidOperationException("Property not applicable to the current shape type.");
                }
            }
        }
    }
}
