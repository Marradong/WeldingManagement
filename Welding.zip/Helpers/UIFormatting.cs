﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.Linq;
using System.Reflection;
using Wisej.Web;

namespace WeldingManagement
{
    public class UIFormatting
    {
        public static List<string> adminUsers = new List<string> { "2596", "3215", "1541", "2930", "2572" };

        public static void ResizeColumnsFor(ListView lv, int margin = 0)
        {
            if (lv == null || lv.Columns.Count == 0) 
                return;

            int availableWidth = lv.Width - margin;

            if (lv.Columns.Count == 1)
            {
                lv.Columns[0].Width = Math.Max(0, availableWidth);
            }
            else
            {
                int titleWidth = availableWidth / lv.Columns.Count;
                
                lv.Columns[0].Width = titleWidth;
                availableWidth -= titleWidth;

                if (lv.Columns.Count > 1)
                {
                    for (int i = 1; i < lv.Columns.Count; i++)
                    {
                        lv.Columns[i].Width = availableWidth / (lv.Columns.Count - i);
                        availableWidth -= availableWidth / (lv.Columns.Count - i);
                    }
                }
            }
        }

        public static void ResizeColumnsFor(DataGridView dgv, int margin = 0)
        {
            if (dgv == null || dgv.Columns.Count == 0)
                return;

            int availableWidth = dgv.Width - margin;

            if (dgv.Columns.Count == 1)
            {
                dgv.Columns[0].Width = Math.Max(0, availableWidth);
            }
            else
            {
                int titleWidth = availableWidth / dgv.Columns.Count;

                dgv.Columns[0].Width = titleWidth;
                availableWidth -= titleWidth;

                if (dgv.Columns.Count > 1)
                {
                    for (int i = 1; i < dgv.Columns.Count; i++)
                    {
                        dgv.Columns[i].Width = availableWidth / (dgv.Columns.Count - i);
                        availableWidth -= availableWidth / (dgv.Columns.Count - i);
                    }
                }
            }
        }

        public static void StartLoader(Control ctrl)
        {
            ctrl.Call("showLoader");
            Application.Update(ctrl);
        }

        public static void StopLoader(Control ctrl) 
        {
            ctrl.Call("hideLoader");
            Application.Update(ctrl);
        }

        public static void SetBackForeColours(Control ctrl, string backName, string foreName)
        {
            ctrl.BackColor = Color.FromName(backName);
            ctrl.ForeColor = Color.FromName(foreName);
        }

        public static void AdjustFontsForAllControls(Control parentCtrl)
        {
            foreach (Control ctrl in parentCtrl.Controls)
            {
                AdjustFontSize(ctrl);

                if (ctrl.HasChildren)
                {
                    AdjustFontsForAllControls(ctrl);
                }
            }
        }

        public static void AdjustFontSize(Control ctrl, int minFontSize = 8, int maxFontSize = 72)
        {
            if (ctrl == null || string.IsNullOrEmpty(ctrl.Text))
            {
                return;
            }

            ctrl.Font = FindOptimalFont(ctrl, minFontSize, maxFontSize);
        }

        private static Font FindOptimalFont(Control ctrl, int min, int max)
        {
            Font testFont = ctrl.Font;

            using (Graphics g = ctrl.CreateGraphics())
            {
                while (min <= max)
                {
                    int mid = (min + max) / 2;
                    testFont = new Font(ctrl.Font.FontFamily, mid);
                    SizeF textSize = g.MeasureString(ctrl.Text, testFont);

                    if (textSize.Width <= ctrl.Width && textSize.Height <= ctrl.Height)
                    {
                        min = mid + 1;
                    }
                    else
                    {
                        max = mid - 1;
                    }
                }
            }

            testFont.Dispose();

            return new Font(ctrl.Font.FontFamily, max);
        }

        public static string GetEnumDisplayName(Enum value)
        {
            var field = value.GetType().GetField(value.ToString());
            var attribute = field.GetCustomAttribute<DisplayAttribute>();
            return attribute != null ? attribute.Name : value.ToString();
        }

        public static string GetPropertyDisplayName<T>(string propertyName)
        {
            var prop = typeof(T).GetProperty(propertyName);
            var displayAttribute = prop?.GetCustomAttribute<DisplayAttribute>();

            return displayAttribute?.Name ?? propertyName;
        }

        public static PropertyInfo GetPropertyByDisplayName<T>(string displayName)
        {
            foreach (var prop in typeof(T).GetProperties())
            {
                var displayAttribute = prop.GetCustomAttributes(typeof(DisplayAttribute), false)
                                           .FirstOrDefault() as DisplayAttribute;
                if (displayAttribute != null && displayAttribute.Name == displayName)
                {
                    return prop;
                }
            }

            return null;
        }

        public static PropertyInfo GetPropertyByDisplayName(Type type, string displayName)
        {
            foreach (var prop in type.GetProperties())
            {
                var displayAttribute = prop.GetCustomAttributes(typeof(DisplayAttribute), false)
                                            .FirstOrDefault() as DisplayAttribute;
                if (displayAttribute != null && displayAttribute.Name == displayName)
                {
                    return prop;
                }
            }

            return null;
        }
    }
}