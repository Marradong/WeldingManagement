﻿using Google.Protobuf.WellKnownTypes;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Web;

namespace WeldingManagement
{
    public static class DrawingFunctionality
    {
        private static Font GetScaledFont(Graphics g, string pText, SizeF pTargetSize)
        {
            float fontSize = 10;
            Font font = new Font("Arial", fontSize);

            while (g.MeasureString(pText, font).Width < pTargetSize.Width && g.MeasureString(pText, font).Height < pTargetSize.Height)
            {
                fontSize += 1;
                font = new Font("Arial", fontSize);
            }

            return new Font("Arial", fontSize - 1);
        }

        #region Shapes
        public static void DrawScaledString(Graphics g, string input, Rectangle bounds)
        {
            Font font = GetScaledFont(g, input, bounds.Size);

            SizeF textSize = g.MeasureString(input, font);

            PointF textLocation = new PointF(bounds.Left + (bounds.Width - textSize.Width) / 2, bounds.Top + (bounds.Height - textSize.Height) / 2);

            g.DrawString(input, font, Brushes.Black, textLocation);
        }

        public static void DrawRectangle(Graphics pG, RotatedRectangle pRect, float pAngle, Point initialClickPoint)
        {
            Pen pen = new Pen(Color.Black);
            SolidBrush brush = new SolidBrush(Color.White);

            GraphicsState originalState = pG.Save();

            GraphicsPath pPath = new GraphicsPath();
            pPath.StartFigure();
            pPath.AddLine(pRect.TopLeft, pRect.TopRight);
            pPath.AddLine(pRect.TopRight, pRect.BottomRight);
            pPath.AddLine(pRect.BottomRight, pRect.BottomLeft);
            pPath.AddLine(pRect.BottomLeft, pRect.TopLeft);
            pPath.CloseFigure();

            try
            {
                pG.FillPath(brush, pPath);
                pG.DrawPath(pen, pPath);
            }
            catch (Exception e) { };

            pG.Restore(originalState);

            pen.Dispose();
            brush.Dispose();
        }

        public static void DrawEllipse(Graphics pG, RotatedRectangle pRect, float pAngle, string pRunId, Point initialClickPoint)
        {
            Pen pen = new Pen(Color.Black);
            SolidBrush brush = new SolidBrush(Color.White);

            GraphicsState originalState = pG.Save();

            Rectangle newRect = new Rectangle(pRect.TopLeft, new Size(pRect.Width, pRect.Height));

            RotateGraphic(pG, pAngle, pRect.TopLeft);

            pG.FillEllipse(brush, newRect);
            pG.DrawEllipse(pen, newRect);

            DrawScaledString(pG, pRunId, newRect);

            pG.Restore(originalState);

            pen.Dispose();
            brush.Dispose();
        }

        public static void DrawPath(Graphics pG, GraphicsPath pPath, float pAngle, Point initialClickPoint, int hDist, int vDist, bool hFlip, bool vFlip)
        {
            Pen pen = new Pen(Color.Black);
            SolidBrush brush = new SolidBrush(Color.White);
            SolidBrush brushr = new SolidBrush(Color.Red);

            GraphicsState originalState = pG.Save();

            ScaleGraphic(pG, hFlip ? -1 : 1, vFlip ? -1 : 1, initialClickPoint, hFlip ? hDist : 0, vFlip ? vDist : 0);

            try
            {
                pG.FillPath(brush, pPath);
                pG.DrawPath(pen, pPath);
            }
            catch (Exception e) { };
            

            pG.Restore(originalState);

            pen.Dispose();
            brush.Dispose();
        }
        #endregion

        #region Transforms

        public static void RotateGraphic(Graphics g, float ang, Point start)
        {
            g.TranslateTransform(start.X, start.Y);
            g.RotateTransform(ang);
            g.TranslateTransform(-start.X, -start.Y);
        }

        public static void ScaleGraphic(Graphics g, float scaleX, float scaleY, Point start, int hDist, int vDist)
        {
            g.TranslateTransform(start.X, start.Y);
            g.ScaleTransform(scaleX, scaleY);
            g.TranslateTransform(-start.X - hDist, -start.Y - vDist);
        }

        #endregion

        #region Paths
        public static GraphicsPath BevelPath(List<Point> pathPoints, bool dble)
        {
            GraphicsPath path = new GraphicsPath();

            path.StartFigure();
            path.AddLine(pathPoints[0], pathPoints[1]);
            path.AddLine(pathPoints[1], pathPoints[2]);
            path.AddLine(pathPoints[2], pathPoints[3]);
            path.AddLine(pathPoints[3], pathPoints[4]);

            if (dble)
            {
                path.AddLine(pathPoints[4], pathPoints[5]);
                path.AddLine(pathPoints[5], pathPoints[0]);
            }
            else
            {
                path.AddLine(pathPoints[4], pathPoints[0]);
            }

            path.CloseFigure();

            return path;
        }

        public static GraphicsPath GroovePath(List<Point> pathPoints, Point arcCentre, Point arcCentre2, double radius, float sweepAng, double rotateAng, bool dble)
        {
            GraphicsPath path = new GraphicsPath();

            path.StartFigure();
            path.AddLine(pathPoints[0], pathPoints[1]);
            path.AddLine(pathPoints[1], pathPoints[2]);
            path.AddLine(pathPoints[2], pathPoints[3]);

            Rectangle rect1 = new Rectangle()
            {
                Location = new Point((int)(arcCentre.X - radius), (int)(arcCentre.Y - radius)),
                Height = (int)(2 * radius),
                Width = (int)(2 * radius)
            };

            if (rect1.Height > 0 && rect1.Width > 0)
            {
                if (dble)
                {
                    path.AddArc(rect1, 270 + (float)rotateAng - sweepAng, sweepAng);
                }
                else
                {
                    path.AddArc(rect1, 90 + (float)rotateAng, sweepAng);
                }
            }

            path.AddLine(pathPoints[4], pathPoints[5]);

            if (dble)
            {
                Rectangle rect2 = new Rectangle()
                {
                    Location = new Point((int)(arcCentre2.X - radius), (int)(arcCentre2.Y - radius)),
                    Height = (int)(2 * radius),
                    Width = (int)(2 * radius)
                };

                if (rect2.Height > 0 && rect2.Width > 0)
                {
                    path.AddArc(rect2, 90 + (float)rotateAng, sweepAng);
                }

                path.AddLine(pathPoints[6], pathPoints[7]);
                path.AddLine(pathPoints[7], pathPoints[0]);
            }
            else
            {
                path.AddLine(pathPoints[5], pathPoints[0]);
            }

            path.CloseFigure();

            return path;
        }
        #endregion

        #region Points

        public static List<Point> BevelPoints(RotatedRectangle bounds, double rfHgt, double ang)
        {
            double chfHgt = (bounds.Height - rfHgt);
            double chfWdt = chfHgt * Math.Tan(ang * Math.PI / 180);

            (int brX, int brY) = bounds.ConvertToShapeCoords(bounds.BottomRight.X, bounds.BottomRight.Y);
            (int trX, int trY) = bounds.ConvertToShapeCoords(bounds.TopRight.X, bounds.TopRight.Y);

            (int p4X, int p4Y) = bounds.ConvertToGlobalCoords(brX, brY - (int)rfHgt);
            (int p5X, int p5Y) = bounds.ConvertToGlobalCoords(trX - (int)chfWdt, trY);


            List<Point> points = new List<Point>()
            {
                bounds.TopLeft,
                bounds.BottomLeft,
                bounds.BottomRight,

                new Point(p4X, p4Y),
                new Point(p5X, p5Y)
            };

            return points;
        }

        public static List<Point> DoubleBevelPoints(RotatedRectangle bounds, double rfHgt, double ang)
        {
            double chfHgt = (bounds.Height - rfHgt) / 2;
            double chfWdt = chfHgt * Math.Tan(ang * Math.PI / 180);

            (int brX, int brY) = bounds.ConvertToShapeCoords(bounds.BottomRight.X, bounds.BottomRight.Y);
            (int trX, int trY) = bounds.ConvertToShapeCoords(bounds.TopRight.X, bounds.TopRight.Y);

            (int p3X, int p3Y) = bounds.ConvertToGlobalCoords(brX - (int)chfWdt, brY);
            (int p4X, int p4Y) = bounds.ConvertToGlobalCoords(brX, brY - (int)chfHgt);
            (int p5X, int p5Y) = bounds.ConvertToGlobalCoords(trX, trY + (int)chfHgt);
            (int p6X, int p6Y) = bounds.ConvertToGlobalCoords(trX - (int)chfWdt, trY);

            List<Point> points = new List<Point>()
            {
                bounds.TopLeft,
                bounds.BottomLeft,
                new Point(p3X, p3Y),
                new Point(p4X, p4Y),
                new Point(p5X, p5Y),
                new Point(p6X, p6Y)
            };

            return points;
        }

        public static Tuple<List<Point>, Point> GroovePoints(RotatedRectangle bounds, double rfHgt, double ang, double scaledRad, double rx, double r_ry)
        {
            double chfHgt = (bounds.Height - rfHgt - r_ry);
            double chfWdt = chfHgt * Math.Tan(ang * Math.PI / 180);

            (int brX, int brY) = bounds.ConvertToShapeCoords(bounds.BottomRight.X, bounds.BottomRight.Y);
            (int trX, int trY) = bounds.ConvertToShapeCoords(bounds.TopRight.X, bounds.TopRight.Y);

            (int p4X, int p4Y) = bounds.ConvertToGlobalCoords(brX, brY - (int)rfHgt);
            (int p5X, int p5Y) = bounds.ConvertToGlobalCoords(brX - (int)rx, brY - (int)rfHgt - (int)r_ry);
            (int p6X, int p6Y) = bounds.ConvertToGlobalCoords(brX - (int)chfWdt - (int)rx, trY);

            (int pACX, int pACY) = bounds.ConvertToGlobalCoords(brX, brY - (int)rfHgt - (int)scaledRad);

            Point arcCentre = new Point(pACX, pACY);

            List<Point> points = new List<Point>
            {
                bounds.TopLeft,
                bounds.BottomLeft,
                bounds.BottomRight,
                new Point(p4X, p4Y),
                new Point(p5X, p5Y),
                new Point(p6X, p6Y)
            };

            return new Tuple<List<Point>, Point>(points, arcCentre);
        }

        public static Tuple<List<Point>, Point> DoubleGroovePoints(RotatedRectangle bounds, double rfHgt, double ang, double scaledRad, double rx, double r_ry)
        {
            double chfHgt = (bounds.Height - rfHgt - 2 * r_ry) / 2;
            double chfWdt = chfHgt * Math.Tan(ang * Math.PI / 180);

            (int brX, int brY) = bounds.ConvertToShapeCoords(bounds.BottomRight.X, bounds.BottomRight.Y);
            (int trX, int trY) = bounds.ConvertToShapeCoords(bounds.TopRight.X, bounds.TopRight.Y);

            (int p3X, int p3Y) = bounds.ConvertToGlobalCoords(brX - (int)chfWdt - (int)rx, brY);
            (int p4X, int p4Y) = bounds.ConvertToGlobalCoords(brX - (int)rx, brY - (int)chfHgt);
            (int p5X, int p5Y) = bounds.ConvertToGlobalCoords(brX, brY - (int)chfHgt - (int)r_ry);
            (int p6X, int p6Y) = bounds.ConvertToGlobalCoords(brX, trY + (int)chfHgt + (int)r_ry);
            (int p7X, int p7Y) = bounds.ConvertToGlobalCoords(brX - (int)rx, trY + (int)chfHgt);
            (int p8X, int p8Y) = bounds.ConvertToGlobalCoords(brX - (int)chfWdt - (int)rx, trY);

            (int pACX, int pACY) = bounds.ConvertToGlobalCoords(brX, brY - (int)chfHgt - (int)r_ry + (int)scaledRad);

            Point arcCentre = new Point(pACX, pACY);

            List<Point> points = new List<Point>
            {
                bounds.TopLeft,
                bounds.BottomLeft,
                new Point(p3X, p3Y),
                new Point(p4X, p4Y),
                new Point(p5X, p5Y),
                new Point(p6X, p6Y),
                new Point(p7X, p7Y),
                new Point(p8X, p8Y),
            };

            return new Tuple<List<Point>, Point>(points, arcCentre);
        }

        public static Point DoubleGrooveArcCentre2(WeldingShape dblGroove)
        {
            (int pACX1, int pACY1) = dblGroove.BoundingBox.ConvertToShapeCoords(dblGroove.ArcCentre.X, dblGroove.ArcCentre.Y);
            (int _, int p1Y) = dblGroove.BoundingBox.ConvertToShapeCoords(dblGroove.BoundingBox.TopLeft.X, dblGroove.BoundingBox.TopLeft.Y);
            (int _, int p2Y) = dblGroove.BoundingBox.ConvertToShapeCoords(dblGroove.BoundingBox.BottomLeft.X, dblGroove.BoundingBox.BottomLeft.Y);

            (int pACX2, int pACY2) = dblGroove.BoundingBox.ConvertToGlobalCoords(pACX1, p1Y + p2Y - pACY1);

            return new Point(pACX2, pACY2);
        }

        public static Point DoubleGrooveArcCentre2(Point arcCentre, RotatedRectangle boundingBox)
        {
            (int pACX1, int pACY1) = boundingBox.ConvertToShapeCoords(arcCentre.X, arcCentre.Y);
            (int _, int p1Y) = boundingBox.ConvertToShapeCoords(boundingBox.TopLeft.X, boundingBox.TopLeft.Y);
            (int _, int p2Y) = boundingBox.ConvertToShapeCoords(boundingBox.BottomLeft.X, boundingBox.BottomLeft.Y);

            (int pACX2, int pACY2) = boundingBox.ConvertToGlobalCoords(pACX1, p1Y + p2Y - pACY1);

            return new Point(pACX2, pACY2);
        }

        #endregion
    }
}