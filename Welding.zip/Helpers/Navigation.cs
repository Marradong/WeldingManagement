﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Wisej.Web;

namespace WeldingManagement
{
    public static class Navigation
    {
        private static void ShowUserControl(UserControl targetControl)
        {
            Page pg = targetControl.ParentPage;

            // Hide all user controls
            pg.SuspendLayout();

            // Hide all user controls
            foreach (Control ctrl in pg.Controls)
            {
                ctrl.Dock = DockStyle.None;
                ctrl.Visible = false;
            }

            // Show the target user control
            targetControl.Dock = DockStyle.Fill;
            targetControl.Visible = true;

            pg.ResumeLayout();
        }

        public static void FromHome(Func<UserControl> initCtrl, Tag tag)
        {
            UserControl ucTo = initCtrl?.Invoke();

            ucTo.Tag = tag;

            ShowUserControl(ucTo);
        }

        public static void ToHome(UserControl ucFrom, UserControl ucHome) 
        {
            ucFrom.Tag = null;

            ShowUserControl(ucHome);
        }

        public static void ToControl(Func<UserControl> initCtrl, UserControl ucFrom)
        {
            UserControl ucTo = initCtrl?.Invoke();

            ucTo.Tag = ucFrom.Tag; // pass tag to

            ucFrom.Tag = null; // nullify old tag

            ShowUserControl(ucTo);
        }
    }
}