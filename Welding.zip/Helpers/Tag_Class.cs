﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WeldingManagement
{
    public enum TagType
    {
        [Display(Name = "New Welding Form")]
        New_Welding_Form = 0,

        [Display(Name = "Welder Qualification")]
        Welder_Qualification = 1,

        [Display(Name = "WPQR")]
        WPQR = 2,

        [Display(Name = "WPS")]
        WPS = 3,

        [Display(Name = "Welding Action")]
        Welding_Action = 4,

        [Display(Name = "Attachment")]
        Attachment = 5,

        [Display(Name = "Job")]
        Job = 6,

        [Display(Name = "NDT")]
        NDT = 7,

        [Display(Name = "WPQR Sequence")]
        WPQR_Sequence = 8,

        [Display(Name = "WPQR Preparation")]
        WPQR_Preparation = 9,

        [Display(Name = "WPS Sequence")]
        WPS_Sequence = 10,

        [Display(Name = "WPS Preparation")]
        WPS_Preparation = 11,

        [Display(Name = "None")]
        None = 12
    }

    public class Tag
    {
        private object _tagObject;
        private TagType _tagType;
        private string _tagName;

        public Tag(object obj, TagType tagType, string name = null) 
        { 
            setTag(obj, tagType, name);
        }

        public void setTag(object obj, TagType tagType, string name=null)
        {
            setTagObject(obj);
            setTagType(tagType);
            setTagName(name);
        }

        public void setTagObject(object obj)
        {
            _tagObject = obj;
        }

        public void setTagType(TagType tagType)
        {
            _tagType = tagType;
        }

        public void setTagName(string name)
        {
            _tagName = name;
        }

        public object getTagObject()
        {
            return _tagObject;
        }

        public TagType getTagType()
        {
            return _tagType;
        }

        public string getTagName()
        {
            return _tagName;
        }

        public override string ToString()
        {
            return getTagName();
        }
    }
}