﻿
## Construct an OpenAPI annotation type that is used to describe an endpoint

parameters, 
responses, 
metadata (Class)

Add OpenAPI annotations to endpoints via WithOpenApi
Calling WithOpenApi on the endpoint adds to the endpoint's metadata. This metadata can be:


.WithOpenApi(generatedOperation =>
{
    var parameter = generatedOperation.Parameters[0];
    parameter.Description = "The ID associated with the created Todo";
    return generatedOperation;
});


// ODATA Service : Endpoint Discovery
// ----------------------------------

// Enable endpoint documentation
            config.Services

Enable output documentation

bin\Debug\WebApi.xml