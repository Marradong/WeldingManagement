﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.CRUD;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the WPQR_Run class
    /// </summary>
    public class WPQR_RunController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a WPQR_Run by ID
        /// </summary>
        /// <group>WPQR_Run Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQR_Run/1</url>
        /// <param name="id" cref="long" in="header">WPQR_Run ID</param>
        /// <response code="200"><see cref="WPQR_Run"/>WPQR_Run Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(WPQR_Run))]
        public IHttpActionResult GetWPQR_Run(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetWPQR_Run <- (id: {id})");

            WPQRRunActionResponse response = CRUD.ReadWPQRRun(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPQR_Run);
        }

        /// <summary>
        /// Get all WPQR_Runs
        /// </summary>
        /// <group>WPQR_Run Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQR_Run</url>
        /// <response code="200"><see cref="List&lt;WPQR_Run&gt;"/>WPQR_Run List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<WPQR_Run>))]
        public IHttpActionResult GetWPQR_Runs()
        {
            Console.WriteLine($">HTTP Web Request : GetWPQR_Runs");

            WPQRRunsActionResponse response = CRUD.ReadWPQRRuns(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPQR_Runs);
        }

        /// <summary>
        /// Update a WPQR_Run
        /// </summary>
        /// <group>WPQR_Run Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQR_Run/1</url>
        /// <param name="wpqrRunId" cref="long" in="header">WPQR_Run ID</param>
        /// <param name="dto" in="body"><see cref="WPQR_Run"/>WPQR_Run Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWPQR_Run(long wpqrRunId, [FromBody] WPQR_Run dto)
        {
            Console.WriteLine($">HTTP Web Request : PutWPQR_Run <- (wpqrRunId: {wpqrRunId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                WPQRRunActionResponse response = CRUD.UpdateWPQRRun(wpqrRunId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a WPQR_Run
        /// </summary>
        /// <group>WPQR_Run Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQR_Run</url>
        /// <param name="wpqrId" cref="long" in="header">WPQR ID</param>
        /// <param name="dto" in="body"><see cref="WPQR_Run"/>WPQR_Run Data Transfer Object</param>
        /// <response code="200"><see cref="WPQR_Run"/>WPQR_Run Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(WPQR_Run))]
        public IHttpActionResult PostWPQR_Run(long wpqrId, [FromBody] WPQR_Run dto)
        {
            Console.WriteLine($">HTTP Web Request : PostWPQR_Run <- (wpqrId: {wpqrId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            WPQR_Run wpqrRun = CRUD.CreateWPQRRun(wpqrId, dto, db).WPQR_Run;

            return CreatedAtRoute("DefaultApi", new { id = wpqrRun.WPQR_RunId }, wpqrRun);
        }

        /// <summary>
        /// Delete a WPQR_Run by ID
        /// </summary>
        /// <group>WPQR_Run Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQR_Run/1</url>
        /// <param name="id" cref="long" in="header">WPQR_Run ID</param>
        [HttpDelete]
        [ResponseType(typeof(WPQR_Run))]
        public IHttpActionResult DeleteWPQR_Run(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteWPQR_Run <- (id: {id})");

            WPQRRunActionResponse response = CRUD.DeleteWPQRRun(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPQR_Run);
        }
    }
}
