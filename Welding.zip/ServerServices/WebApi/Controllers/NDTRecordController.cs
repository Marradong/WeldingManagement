﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;
using static Welding.DAL.CRUD;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the NDT_Record class
    /// </summary>
    public class NDTRecordController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a NDT_Record by ID
        /// </summary>
        /// <group>NDT_Record Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/NDT_Record/1</url>
        /// <param name="id" cref="long" in="header">NDT_Record ID</param>
        /// <response code="200"><see cref="NDT_Record"/>NDT_Record Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(NDT_Record))]
        [Route("api/NDTRecord/{id}")]
        public IHttpActionResult GetNDT_Record(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetNDT_Record <- (id: {id})");

            NDTRecordActionResponse response = CRUD.ReadNDTRecord(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.NDT_Record);
        }

        /// <summary>
        /// Get all NDT_Records
        /// </summary>
        /// <group>NDT_Record Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/NDT_Record</url>
        /// <response code="200"><see cref="List&lt;NDT_Record&gt;"/>NDT_Record List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<NDT_Record>))]
        public IHttpActionResult GetNDT_Records()
        {
            Console.WriteLine($">HTTP Web Request : GetNDT_Records");

            NDTRecordsActionResponse response = CRUD.ReadNDTRecords(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.NDT_Records);
        }

        /// <summary>
        /// Update a NDT_Record
        /// </summary>
        /// <group>NDT_Record Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/NDT_Record/1</url>
        /// <param name="ndtRecordId" cref="long" in="header">NDT_Record ID</param>
        /// <param name="dto" in="body"><see cref="NDT_Record"/>NDT_Record Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        [Route("api/NDTRecord/{id}")]
        public IHttpActionResult PutNDT_Record(long ndtRecordId, [FromBody] NDT_Record dto)
        {
            Console.WriteLine($">HTTP Web Request : PutNDT_Record <- (ndtRecordId: {ndtRecordId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                NDTRecordActionResponse response = CRUD.UpdateNDTRecord(ndtRecordId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a NDT_Record
        /// </summary>
        /// <group>NDT_Record Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/NDT_Record</url>
        /// <param name="wpsId" cref="wpsId" in="header">NDT_Record Data Transfer Object</param>
        /// <param name="dto" in="body"><see cref="NDT_Record"/>NDT_Record Data Transfer Object</param>
        /// <response code="200"><see cref="NDT_Record"/>NDT_Record Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(NDT_Record))]
        public IHttpActionResult PostNDT_Record(long wpsId, [FromBody] NDT_Record dto)
        {
            Console.WriteLine($">HTTP Web Request : PostNDT_Record <- (wpsId: {wpsId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            NDT_Record nDT_Record = CRUD.CreateNDTRecord(wpsId, dto, db).NDT_Record;

            return CreatedAtRoute("DefaultApi", new { id = nDT_Record.NDT_RecordId }, nDT_Record);
        }

        /// <summary>
        /// Delete a NDT_Record by ID
        /// </summary>
        /// <group>NDT_Record Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/NDT_Record/1</url>
        /// <param name="id" cref="long" in="header">NDT_Record ID</param>
        [HttpDelete]
        [ResponseType(typeof(NDT_Record))]
        [Route("api/NDTRecord/{id}")]
        public IHttpActionResult DeleteNDT_Record(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteNDT_Record <- (id: {id})");

            NDTRecordActionResponse response = CRUD.DeleteNDTRecord(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.NDT_Record);
        }
    }
}
