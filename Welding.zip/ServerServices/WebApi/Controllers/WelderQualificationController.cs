﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.CRUD;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the Consumable class
    /// </summary>
    public class WelderQualificationController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a Welder_Qualification by ID
        /// </summary>
        /// <group>Welder_Qualification Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Welder_Qualification/1</url>
        /// <param name="id" cref="long" in="header">Welder_Qualification ID</param>
        /// <response code="200"><see cref="Welder_Qualification"/>Welder_Qualification Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(Welder_Qualification))]
        public IHttpActionResult GetWelderQualification(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetWelderQualification <- (id: {id})");

            WelderQualificationActionResponse response = CRUD.ReadWelderQualification(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Welder_Qualification);
        }

        /// <summary>
        /// Get all Welder_Qualifications
        /// </summary>
        /// <group>Welder_Qualification Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Welder_Qualification</url>
        /// <response code="200"><see cref="List&lt;Welder_Qualification&gt;"/>Welder_Qualification List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<Welder_Qualification>))]
        public IHttpActionResult GetWelderQualifications()
        {
            Console.WriteLine($">HTTP Web Request : GetWelderQualifications");

            WelderQualificationsActionResponse response = CRUD.ReadWelderQualifications(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Welder_Qualifications);
        }

        /// <summary>
        /// Update a Welder_Qualification
        /// </summary>
        /// <group>Welder_Qualification Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Welder_Qualification/1</url>
        /// <param name="welderQualificationId" cref="long" in="header">Welder_Qualification ID</param>
        /// <param name="dto" in="body"><see cref="Welder_Qualification"/>Welder_Qualification Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWelderQualification(long welderQualificationId, [FromBody] Welder_Qualification dto)
        {
            Console.WriteLine($">HTTP Web Request : PutWelderQualification <- (welderQualificationId: {welderQualificationId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                WelderQualificationActionResponse response = CRUD.UpdateWelderQualification(welderQualificationId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a Welder_Qualification
        /// </summary>
        /// <group>Welder_Qualification Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Welder_Qualification</url>
        /// <param name="weldingActionId" cref="long" in="header">WeldingAction ID</param>
        /// <param name="dto" in="body"><see cref="Welder_Qualification"/>Welder_Qualification Data Transfer Object</param>
        /// <response code="200"><see cref="Welder_Qualification"/>Welder_Qualification Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(Welder_Qualification))]
        public IHttpActionResult PostWelderQualification(long weldingActionId, [FromBody] Welder_Qualification dto)
        {
            Console.WriteLine($">HTTP Web Request : PostWelderQualification <- (weldingActionId: {weldingActionId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Welder_Qualification welderQual = CRUD.CreateWelderQualification(weldingActionId, dto, db).Welder_Qualification;

            return CreatedAtRoute("DefaultApi", new { id = welderQual.Welder_QualificationId}, welderQual);
        }

        /// <summary>
        /// Delete a Welder_Qualification by ID
        /// </summary>
        /// <group>Welder_Qualification Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Welder_Qualification/1</url>
        /// <param name="id" cref="long" in="header">Welder_Qualification ID</param>
        [HttpDelete]
        [ResponseType(typeof(Welder_Qualification))]
        public IHttpActionResult DeleteWelderQualification(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteWelderQualification <- (id: {id})");

            WelderQualificationActionResponse response = CRUD.DeleteWelderQualification(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Welder_Qualification);
        }
    }
}
