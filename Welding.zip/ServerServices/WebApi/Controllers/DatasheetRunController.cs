﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;
using static Welding.DAL.CRUD;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the Datasheet_Run class
    /// </summary>
    public class Datasheet_RunController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a Datasheet_Run by ID
        /// </summary>
        /// <group>Datasheet_Run Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Datasheet_Run/1</url>
        /// <param name="id" cref="long" in="header">Datasheet_Run ID</param>
        /// <response code="200"><see cref="Datasheet_Run"/>Datasheet_Run Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(Datasheet_Run))]
        public IHttpActionResult GetDatasheet_Run(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetDatasheet_Run <- (id: {id})");

            DatasheetRunActionResponse response = CRUD.ReadDatasheetRun(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Datasheet_Run);
        }

        /// <summary>
        /// Get all Datasheet_Run
        /// </summary>
        /// <group>Datasheet_Run Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Datasheet_Run</url>
        /// <response code="200"><see cref="List&lt;Datasheet_Run&gt;"/>Datasheet_Run List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<Datasheet_Run>))]
        public IHttpActionResult GetDatasheet_Runs()
        {
            Console.WriteLine($">HTTP Web Request : GetDatasheet_Runs");

            DatasheetRunsActionResponse response = CRUD.ReadDatasheetRuns(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Datasheet_Runs);
        }

        /// <summary>
        /// Update a Datasheet_Run
        /// </summary>
        /// <group>Datasheet_Run Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Datasheet_Run/1</url>
        /// <param name="datasheetRunId" cref="long" in="header">Datasheet_Run ID</param>
        /// <param name="dto" in="body"><see cref="Datasheet_Run"/>Datasheet_Run Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDatasheet_Run(long datasheetRunId, [FromBody] Datasheet_Run dto)
        {
            Console.WriteLine($">HTTP Web Request : PutDatasheet_Run <- (datasheetRunId: {datasheetRunId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                DatasheetRunActionResponse response = CRUD.UpdateDatasheetRun(datasheetRunId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a Datasheet_Run
        /// </summary>
        /// <group>Datasheet_Run Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Datasheet_Run</url>
        /// <param name="datasheetId" cref="long" in="header">Datasheet ID</param>
        /// <param name="dto" in="body"><see cref="Datasheet_Run"/>Datasheet_Run Data Transfer Object</param>
        /// <response code="200"><see cref="Datasheet_Run"/>Datasheet_Run Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(Datasheet_Run))]
        public IHttpActionResult PostDatasheet_Run(long datasheetId, [FromBody] Datasheet_Run dto)
        {
            Console.WriteLine($">HTTP Web Request : PostDatasheet_Run <- (datasheetId: {datasheetId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Datasheet_Run datasheetRun = CRUD.CreateDatasheetRun(datasheetId, dto, db).Datasheet_Run;

            return CreatedAtRoute("DefaultApi", new { id = datasheetRun.Datasheet_RunId }, datasheetRun);
        }

        /// <summary>
        /// Delete a Datasheet_Run by ID
        /// </summary>
        /// <group>Datasheet_Run Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Datasheet_Run/1</url>
        /// <param name="id" cref="long" in="header">Datasheet_Run ID</param>
        [HttpDelete]
        [ResponseType(typeof(Datasheet_Run))]
        public IHttpActionResult DeleteDatasheet_Run(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteDatasheet_Run <- (id: {id})");

            DatasheetRunActionResponse response = CRUD.DeleteDatasheetRun(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Datasheet_Run);
        }
    }
}
