﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;
using static Welding.DAL.CRUD;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the NewWeldingForm class
    /// </summary>
    public class NewWeldingFormsController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a NewWeldingForm by ID
        /// </summary>
        /// <group>NewWeldingForm Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/NewWeldingForms/1</url>
        /// <param name="id" cref="long" in="header">NewWeldingForm ID</param>
        /// <response code="200"><see cref="NewWeldingForm"/>NewWeldingForm Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(NewWeldingForm))]
        public IHttpActionResult GetNewWeldingForm(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetNewWeldingForm <- (id: {id})");

            NewWeldingFormActionResponse response = CRUD.ReadNewWeldingForm(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.NewWeldingForm);
        }

        /// <summary>
        /// Get all NewWeldingForms
        /// </summary>
        /// <group>NewWeldingForm Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/NewWeldingForms</url>
        /// <response code="200"><see cref="List&lt;NewWeldingForm&gt;"/>NewWeldingForm List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<NewWeldingForm>))]
        public IHttpActionResult GetNewWeldingForms()
        {
            Console.WriteLine($">HTTP Web Request : GetNewWeldingForms");

            NewWeldingFormsActionResponse response = CRUD.ReadNewWeldingForms(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.NewWeldingForms);
        }

        /// <summary>
        /// Update a NewWeldingForm
        /// </summary>
        /// <group>NewWeldingForm Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/NewWeldingForms/1</url>
        /// <param name="nwfId" cref="long" in="header">NewWeldingForm ID</param>
        /// <param name="dto" in="body"><see cref="NewWeldingForm"/>NewWeldingForm Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutNewWeldingForm(long nwfId, [FromBody] NewWeldingForm dto)
        {
            Console.WriteLine($">HTTP Web Request : PutNewWeldingForm <- (nwfId: {nwfId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                NewWeldingFormActionResponse response = CRUD.UpdateNewWeldingForm(nwfId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a NewWeldingForm
        /// </summary>
        /// <group>NewWeldingForm Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/NewWeldingForms</url>
        /// <param name="weldingActionId" cref="long" in="header">WeldingAction ID</param>
        /// <param name="dto" in="body"><see cref="NewWeldingForm"/>NewWeldingForm Data Transfer Object</param>
        /// <response code="200"><see cref="NewWeldingForm"/>NewWeldingForm Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(NewWeldingForm))]
        public IHttpActionResult PostNewWeldingForm(long weldingActionId, [FromBody] NewWeldingForm dto)
        {
            Console.WriteLine($">HTTP Web Request : PostNewWeldingForm <- (weldingActionId: {weldingActionId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            NewWeldingForm newWeldingForm = CRUD.CreateNewWeldingForm(weldingActionId, dto, db).NewWeldingForm;

            return CreatedAtRoute("DefaultApi", new { id = newWeldingForm.NewWeldingFormId }, newWeldingForm);
        }

        /// <summary>
        /// Delete a NewWeldingForm by ID
        /// </summary>
        /// <group>NewWeldingForm Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/NewWeldingForms/1</url>
        /// <param name="id" cref="long" in="header">NewWeldingForm ID</param>
        [HttpDelete]
        [ResponseType(typeof(NewWeldingForm))]
        public IHttpActionResult DeleteNewWeldingForm(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteNewWeldingForm <- (id: {id})");

            NewWeldingFormActionResponse response = CRUD.DeleteNewWeldingForm(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.NewWeldingForm);
        }
    }
}
