﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.CRUD;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the Consumable class
    /// </summary>
    public class ConsumablesController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a Consumable by ID
        /// </summary>
        /// <group>Consumable Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Consumables/1</url>
        /// <param name="id" cref="long" in="header">Consumable ID</param>
        /// <response code="200"><see cref="Consumable"/>Consumable Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(Consumable))]
        public IHttpActionResult GetConsumable(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetConsumable <- (id: {id}) ");

            ConsumableActionResponse response = CRUD.ReadConsumable(id, db);
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Consumable);
        }

        /// <summary>
        /// Get all Consumables
        /// </summary>
        /// <group>Consumable Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Consumables</url>
        /// <response code="200"><see cref="List&lt;Consumable&gt;"/>Consumable List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<Consumable>))]
        public IHttpActionResult GetConsumables()
        {
            Console.WriteLine($">HTTP Web Request : GetConsumables");

            ConsumablesActionResponse response = CRUD.ReadConsumables(db);
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Consumables);
        }

        /// <summary>
        /// Update a Consumable
        /// </summary>
        /// <group>Consumable Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Consumables/1</url>
        /// <param name="consumableId" cref="long" in="header">Consumable ID</param>
        /// <param name="dto" in="body"><see cref="Consumable"/>Consumable Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutConsumable(long consumableId, [FromBody] Consumable dto)
        {
            Console.WriteLine($">HTTP Web Request : PutConsumable <- (consumableId: {consumableId}, dto) ");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                ConsumableActionResponse response = CRUD.UpdateConsumable(consumableId, dto, db);
                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a Consumable
        /// </summary>
        /// <group>Consumable Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Consumables</url>
        /// <param name="datasheetId" cref="long" in="header">Datasheet ID</param>
        /// <param name="dto" in="body"><see cref="Consumable"/>Consumable Data Transfer Object</param>
        /// <response code="200"><see cref="Consumable"/>Consumable Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(Consumable))]
        public IHttpActionResult PostConsumable(long datasheetId, [FromBody] Consumable dto)
        {
            Console.WriteLine($">HTTP Web Request : PostConsumable <- (datasheetId: {datasheetId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Consumable consumable = CRUD.CreateConsumable(datasheetId, dto, db).Consumable;

            return CreatedAtRoute("DefaultApi", new { id = consumable.ConsumableId }, consumable);
        }

        /// <summary>
        /// Delete a Consumable by ID
        /// </summary>
        /// <group>Consumable Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Consumables/1</url>
        /// <param name="id" cref="long" in="header">Consumable ID</param>
        [HttpDelete]
        [ResponseType(typeof(Consumable))]
        public IHttpActionResult DeleteConsumable(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteConsumable <- (id: {id})");

            ConsumableActionResponse response = CRUD.DeleteConsumable(id, db);
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Consumable);
        }
    }
}
