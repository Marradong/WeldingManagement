﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using static Welding.DAL.CRUD;
using System.Web.Http.Description;
using Welding.DAL;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the WPSNumberList class
    /// </summary>
    public class WPSNumberListController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a WPSNumberList by ID
        /// </summary>
        /// <group>WPSNumberList Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPSNumberList/{id}</url>
        /// <param name="id" cref="long" in="header">WPSNumberList ID</param>
        /// <response code="200"><see cref="WPSNumberList"/>WPSNumberList Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(WPSNumberList))]
        public IHttpActionResult GetWPSNumberList(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetWPSNumberList <- (id: {id})");

            WPSNumberListActionResponse response = CRUD.ReadWPSNumberList(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPSNumberList);
        }

        /// <summary>
        /// Get all WPSNumberLists
        /// </summary>
        /// <group>WPSNumberList Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPSNumberList</url>
        /// <response code="200"><see cref="List&lt;WPSNumberList&gt;"/>WPSNumberList List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<WPSNumberList>))]
        public IHttpActionResult GetWPSNumberLists()
        {
            Console.WriteLine($">HTTP Web Request : GetWPSNumberLists");

            WPSNumberListsActionResponse response = CRUD.ReadWPSNumberLists(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPSNumberLists);
        }

        /// <summary>
        /// Update a WPSNumberList
        /// </summary>
        /// <group>WPSNumberList Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPSNumberList/1</url>
        /// <param name="id" cref="long" in="header">WPSNumberList ID</param>
        /// <param name="dto" in="body"><see cref="WPSNumberList"/>WPSNumberList Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWPSNumberList(long id, [FromBody] WPSNumberList dto)
        {
            Console.WriteLine($">HTTP Web Request : PutWPSNumberList <- (id: {id}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                WPSNumberListActionResponse response = CRUD.UpdateWPSNumberList(id, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a WPSNumberList
        /// </summary>
        /// <group>WPSNumberList Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPSNumberList</url>
        /// <param name="operationalReviewId" cref="long" in="header">OperationalReview ID</param>
        /// <param name="dto" in="body"><see cref="WPSNumberList"/>WPSNumberList Data Transfer Object</param>
        /// <response code="200"><see cref="WPSNumberList"/>WPSNumberList Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(WPSNumberList))]
        public IHttpActionResult PostWPSNumberList(long operationalReviewId, [FromBody] WPSNumberList dto)
        {
            Console.WriteLine($">HTTP Web Request : PostWPSNumberList <- (operationalReviewId: {operationalReviewId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            WPSNumberList employeeNumber = CRUD.CreateWPSNumberList(operationalReviewId, dto, db).WPSNumberList;

            return CreatedAtRoute("DefaultApi", new { id = employeeNumber.Id }, employeeNumber);
        }

        /// <summary>
        /// Delete a WPSNumberList by ID
        /// </summary>
        /// <group>WPSNumberList Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPSNumberList/1</url>
        /// <param name="id" cref="long" in="header">WPSNumberList ID</param>
        [HttpDelete]
        [ResponseType(typeof(WPSNumberList))]
        public IHttpActionResult DeleteWPSNumberList(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteWPSNumberList <- (id: {id})");

            WPSNumberListActionResponse response = CRUD.DeleteWPSNumberList(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPSNumberList);
        }

        /// <summary>
        /// Delete all WPSNumberLists
        /// </summary>
        /// <group>WPSNumberList Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPSNumberList</url>
        /// <param name="operationalReviewId" cref="long" in="header">Operational Review ID</param>
        [HttpDelete]
        [ResponseType(typeof(void))]
        public IHttpActionResult DeleteWPSNumberLists(long operationalReviewId)
        {
            Console.WriteLine($">HTTP Web Request : DeleteWPSNumberLists <- (operationalReviewId: {operationalReviewId})");

            WPSNumberListActionResponse response = CRUD.DeleteWPSNumberLists(operationalReviewId, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }
    }
}
