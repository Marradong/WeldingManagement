﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.CRUD;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the WPQR class
    /// </summary>
    public class WPQRsController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a WPQR by ID
        /// </summary>
        /// <group>WPQR Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQRs/1</url>
        /// <param name="id" cref="long" in="header">WPQR ID</param>
        /// <response code="200"><see cref="WPQR"/>WPQR Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(WPQR))]
        public IHttpActionResult GetWPQR(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetWPQR <- (id: {id})");

            WPQRActionResponse response = CRUD.ReadWPQR(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPQR);
        }

        /// <summary>
        /// Get all WPQRs
        /// </summary>
        /// <group>WPQR Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQRs</url>
        /// <response code="200"><see cref="List&lt;WPQR&gt;"/>WPQR List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<WPQR>))]
        public IHttpActionResult GetWPQRs()
        {
            Console.WriteLine($">HTTP Web Request : GetWPQRs");

            WPQRActionsResponse response = CRUD.ReadWPQRs(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPQRs);
        }

        /// <summary>
        /// Update a WPQR
        /// </summary>
        /// <group>WPQR Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQRs/1</url>
        /// <param name="wpqrId" cref="long" in="header">WPQR ID</param>
        /// <param name="dto" in="body"><see cref="WPQR"/>WPQR Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWPQR(long wpqrId, [FromBody] WPQR dto)
        {
            Console.WriteLine($">HTTP Web Request : PutWPQR <- (wpqrId: {wpqrId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                WPQRActionResponse response = CRUD.UpdateWPQR(wpqrId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a WPQR
        /// </summary>
        /// <group>WPQR Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQRs</url>
        /// <param name="welderQualId" cref="long" in="header">Welder_Qualification ID</param>
        /// <param name="dto" in="body"><see cref="WPQR"/>WPQR Data Transfer Object</param>
        /// <response code="200"><see cref="WPQR"/>WPQR Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(WPQR))]
        public IHttpActionResult PostWPQR(long welderQualId, [FromBody] WPQR dto)
        {
            Console.WriteLine($">HTTP Web Request : PostWPQR <- (welderQualId: {welderQualId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            WPQR wpqr = CRUD.CreateWPQR(welderQualId, dto, db).WPQR;
            return CreatedAtRoute("DefaultApi", new { id = wpqr.WPQRId }, wpqr);
        }

        /// <summary>
        /// Delete a WPQR by ID
        /// </summary>
        /// <group>WPQR Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQRs/1</url>
        /// <param name="id" cref="long" in="header">WPQR ID</param>
        [HttpDelete]
        [ResponseType(typeof(WPQR))]
        public IHttpActionResult DeleteWPQR(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteWPQR <- (id: {id})");

            WPQRActionResponse response = CRUD.DeleteWPQR(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPQR);
        }
    }
}
