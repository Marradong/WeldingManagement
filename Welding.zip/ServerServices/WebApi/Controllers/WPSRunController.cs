﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;
using static Welding.DAL.CRUD;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the WPS_Run class
    /// </summary>
    public class WPS_RunController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a WPS_Run by ID
        /// </summary>
        /// <group>WPS_Run Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPS_Run/1</url>
        /// <param name="id" cref="long" in="header">WPS_Run ID</param>
        /// <response code="200"><see cref="WPS_Run"/>WPS_Run Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(WPS_Run))]
        public IHttpActionResult GetWPS_Run(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetWPS_Run <- (id: {id})");

            WPSRunActionResponse response = CRUD.ReadWPSRun(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPS_Run);
        }

        /// <summary>
        /// Get all WPS_Runs
        /// </summary>
        /// <group>WPS_Run Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPS_Run</url>
        /// <response code="200"><see cref="List&lt;Consumable&gt;"/>WPS_Run List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<WPS_Run>))]
        public IHttpActionResult GetWPS_Runs()
        {
            Console.WriteLine($">HTTP Web Request : GetWPS_Runs");

            WPSRunsActionResponse response = CRUD.ReadWPSRuns(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPS_Runs);
        }

        /// <summary>
        /// Update a WPS_Run
        /// </summary>
        /// <group>WPS_Run Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPS_Run/1</url>
        /// <param name="wpsRunId" cref="long" in="header">WPS_Run ID</param>
        /// <param name="dto" in="body"><see cref="WPS_Run"/>WPS_Run Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWPS_Run(long wpsRunId, [FromBody] WPS_Run dto)
        {
            Console.WriteLine($">HTTP Web Request : PutWPS_Run <- (wpsRunId: {wpsRunId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                WPSRunActionResponse response = CRUD.UpdateWPSRun(wpsRunId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a WPS_Run
        /// </summary>
        /// <group>WPS_Run Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPS_Run</url>
        /// <param name="wpsId" cref="long" in="header">WPS ID</param>
        /// <param name="dto" in="body"><see cref="WPS_Run"/>WPS_Run Data Transfer Object</param>
        /// <response code="200"><see cref="WPS_Run"/>WPS_Run Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(WPS_Run))]
        public IHttpActionResult PostWPS_Run(long wpsId, [FromBody] WPS_Run dto)
        {
            Console.WriteLine($">HTTP Web Request : PostWPS_Run <- (wpsId: {wpsId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            WPS_Run wpsRun = CRUD.CreateWPSRun(wpsId, dto, db).WPS_Run;

            return CreatedAtRoute("DefaultApi", new { id = wpsRun.WPS_RunId }, wpsRun);
        }

        /// <summary>
        /// Delete a WPS_Run by ID
        /// </summary>
        /// <group>WPS_Run Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPS_Run/1</url>
        /// <param name="id" cref="long" in="header">WPS_Run ID</param>
        [HttpDelete]
        [ResponseType(typeof(WPS_Run))]
        public IHttpActionResult DeleteWPS_Run(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteWPS_Run <- (id: {id})");

            WPSRunActionResponse response = CRUD.DeleteWPSRun(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPS_Run);
        }
    }
}
