﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using static Welding.DAL.CRUD;
using System.Web.Http.Description;
using Welding.DAL;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the WPQRNumberList class
    /// </summary>
    public class WPQRNumberListController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a WPQRNumberList by ID
        /// </summary>
        /// <group>WPQRNumberList Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQRNumberList/{id}</url>
        /// <param name="id" cref="long" in="header">WPQRNumberList ID</param>
        /// <response code="200"><see cref="WPQRNumberList"/>WPQRNumberList Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(WPQRNumberList))]
        public IHttpActionResult GetWPQRNumberList(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetWPQRNumberList <- (id: {id})");

            WPQRNumberListActionResponse response = CRUD.ReadWPQRNumberList(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPQRNumberList);
        }

        /// <summary>
        /// Get all WPQRNumberLists
        /// </summary>
        /// <group>WPQRNumberList Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQRNumberList</url>
        /// <response code="200"><see cref="List&lt;WPQRNumberList&gt;"/>WPQRNumberList List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<WPQRNumberList>))]
        public IHttpActionResult GetWPQRNumberLists()
        {
            Console.WriteLine($">HTTP Web Request : GetWPQRNumberLists");

            WPQRNumberListsActionResponse response = CRUD.ReadWPQRNumberLists(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPQRNumberLists);
        }

        /// <summary>
        /// Update a WPQRNumberList
        /// </summary>
        /// <group>WPQRNumberList Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQRNumberList/1</url>
        /// <param name="id" cref="long" in="header">WPQRNumberList ID</param>
        /// <param name="dto" in="body"><see cref="WPQRNumberList"/>WPQRNumberList Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWPQRNumberList(long id, [FromBody] WPQRNumberList dto)
        {
            Console.WriteLine($">HTTP Web Request : PutWPQRNumberList <- (id: {id}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                WPQRNumberListActionResponse response = CRUD.UpdateWPQRNumberList(id, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a WPQRNumberList
        /// </summary>
        /// <group>WPQRNumberList Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQRNumberList</url>
        /// <param name="operationalReviewId" cref="long" in="header">OperationalReview ID</param>
        /// <param name="dto" in="body"><see cref="WPQRNumberList"/>WPQRNumberList Data Transfer Object</param>
        /// <response code="200"><see cref="WPQRNumberList"/>WPQRNumberList Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(WPQRNumberList))]
        public IHttpActionResult PostWPQRNumberList(long operationalReviewId, [FromBody] WPQRNumberList dto)
        {
            Console.WriteLine($">HTTP Web Request : PostWPQRNumberList <- (operationalReviewId: {operationalReviewId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            WPQRNumberList employeeNumber = CRUD.CreateWPQRNumberList(operationalReviewId, dto, db).WPQRNumberList;

            return CreatedAtRoute("DefaultApi", new { id = employeeNumber.Id }, employeeNumber);
        }

        /// <summary>
        /// Delete a WPQRNumberList by ID
        /// </summary>
        /// <group>WPQRNumberList Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQRNumberList/1</url>
        /// <param name="id" cref="long" in="header">WPQRNumberList ID</param>
        [HttpDelete]
        [ResponseType(typeof(WPQRNumberList))]
        public IHttpActionResult DeleteWPQRNumberList(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteWPQRNumberList <- (id: {id})");

            WPQRNumberListActionResponse response = CRUD.DeleteWPQRNumberList(id, db);
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPQRNumberList);
        }

        /// <summary>
        /// Delete all WPQRNumberLists
        /// </summary>
        /// <group>WPQRNumberList Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPQRNumberList</url>
        /// <param name="operationalReviewId" cref="long" in="header">Operational Review ID</param>
        [HttpDelete]
        [ResponseType(typeof(void))]
        public IHttpActionResult DeleteWPQRNumberLists(long operationalReviewId)
        {
            Console.WriteLine($">HTTP Web Request : DeleteWPQRNumberLists <- (employeeNumberId: {operationalReviewId})");

            WPQRNumberListActionResponse response = CRUD.DeleteWPQRNumberLists(operationalReviewId, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }
    }
}
