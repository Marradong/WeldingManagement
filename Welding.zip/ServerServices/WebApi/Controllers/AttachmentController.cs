﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;
using static Welding.DAL.CRUD;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the Attachment class
    /// </summary>
    public class AttachmentController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get an Attachment by ID
        /// </summary>
        /// <group>Attachment Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Attachment/1</url>
        /// <param name="id" cref="long" in="header">Attachment ID</param>
        /// <response code="200"><see cref="Attachment"/>Attachment Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(Attachment))]
        public IHttpActionResult GetAttachment(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetAttachment <- (id: {id}) ");
            
            AttachmentActionResponse response = CRUD.ReadAttachment(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Attachment);
        }

        /// <summary>
        /// Get all Attachments
        /// </summary>
        /// <group>Attachment Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Attachment</url>
        /// <response code="200"><see cref="List&lt;Attachment&gt;"/>Attachment List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<Attachment>))]
        public IHttpActionResult GetAttachments()
        {
            Console.WriteLine($">HTTP Web Request : GetAttachments");

            AttachmentsActionResponse response = CRUD.ReadAttachments(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Attachments);
        }

        /// <summary>
        /// Update an Attachment
        /// </summary>
        /// <group>Attachment Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Attachment/1</url>
        /// <param name="attachmentId" cref="long" in="header">Attachment ID</param>
        /// <param name="dto" in="body"><see cref="Attachment"/>Attachment Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutAttachment(long attachmentId, [FromBody] Attachment dto)
        {
            Console.WriteLine($">HTTP Web Request : PutAttachment <- (attachmentId: {attachmentId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                AttachmentActionResponse response = CRUD.UpdateAttachment(attachmentId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }


        /// <summary>
        /// Create an Attachment
        /// </summary>
        /// <group>Attachment Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Attachment</url>
        /// <param name="linkObjId" cref="long" in="header">Link Object ID</param>
        /// <param name="linkObjType" cref="Type" in="header">Link Object Type</param>
        /// <param name="dto" in="body"><see cref="Attachment"/>Attachment Data Transfer Object</param>
        /// <response code="200"><see cref="Attachment"/>Attachment Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(Attachment))]
        public IHttpActionResult PostAttachment([FromUri(Name = "linkObjId")] long linkObjId, [FromUri(Name = "linkObjType")] string linkObjType, [FromBody] Attachment dto)
        {
            Console.WriteLine($">HTTP Web Request : PostAttachment <- (dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Attachment attachment = CRUD.CreateAttachment(dto, linkObjType, linkObjId, db).Attachment;

            return CreatedAtRoute("DefaultApi", new { id = attachment.AttachmentId }, attachment);
        }

        /// <summary>
        /// Get an Attachment by ID
        /// </summary>
        /// <group>Attachment Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Attachment/1</url>
        /// <param name="id" cref="long" in="header">Attachment ID</param>
        [HttpDelete]
        [ResponseType(typeof(Attachment))]
        public IHttpActionResult DeleteAttachment(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteAttachment <- (id: {id})");

            AttachmentActionResponse response = CRUD.DeleteAttachment(id, db);
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Attachment);
        }
    }
}
