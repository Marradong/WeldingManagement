﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using static Welding.DAL.CRUD;
using System.Web.Http.Description;
using Welding.DAL;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the ENumberList class
    /// </summary>
    public class ENumberListController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a ENumberList by ID
        /// </summary>
        /// <group>ENumberList Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/ENumberList/{id}</url>
        /// <param name="id" cref="long" in="header">ENumberList ID</param>
        /// <response code="200"><see cref="ENumberList"/>ENumberList Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(ENumberList))]
        public IHttpActionResult GetENumberList(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetENumberList <- (id: {id})");

            ENumberListActionResponse response = CRUD.ReadENumberList(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.ENumberList);
        }

        /// <summary>
        /// Get all ENumberLists
        /// </summary>
        /// <group>ENumberList Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/ENumberList</url>
        /// <response code="200"><see cref="List&lt;ENumberList&gt;"/>ENumberList List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<ENumberList>))]
        public IHttpActionResult GetENumberLists()
        {
            Console.WriteLine($">HTTP Web Request : GetENumberLists");

            ENumberListsActionResponse response = CRUD.ReadENumberLists(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.ENumberLists);
        }

        /// <summary>
        /// Update a ENumberList
        /// </summary>
        /// <group>ENumberList Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/ENumberList/1</url>
        /// <param name="employeeNumberId" cref="long" in="header">ENumberList ID</param>
        /// <param name="dto" in="body"><see cref="ENumberList"/>ENumberList Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutENumberList(long employeeNumberId, [FromBody] ENumberList dto)
        {
            Console.WriteLine($">HTTP Web Request : PutENumberList <- (employeeNumberId: {employeeNumberId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                ENumberListActionResponse response = CRUD.UpdateENumberList(employeeNumberId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a ENumberList
        /// </summary>
        /// <group>ENumberList Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/ENumberList</url>
        /// <param name="operationalReviewId" cref="long" in="header">OperationalReview ID</param>
        /// <param name="dto" in="body"><see cref="ENumberList"/>ENumberList Data Transfer Object</param>
        /// <response code="200"><see cref="ENumberList"/>ENumberList Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(ENumberList))]
        public IHttpActionResult PostENumberList(long operationalReviewId, [FromBody] ENumberList dto)
        {
            Console.WriteLine($">HTTP Web Request : PosttENumberList <- (operationalReviewId: {operationalReviewId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            ENumberList employeeNumber = CRUD.CreateENumberList(operationalReviewId, dto, db).ENumberList;

            return CreatedAtRoute("DefaultApi", new { id = employeeNumber.Id }, employeeNumber);
        }

        /// <summary>
        /// Delete a ENumberList by ID
        /// </summary>
        /// <group>ENumberList Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/ENumberList/1</url>
        /// <param name="id" cref="long" in="header">ENumberList ID</param>
        [HttpDelete]
        [ResponseType(typeof(ENumberList))]
        public IHttpActionResult DeleteENumberList(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteENumberList <- (id: {id})");

            ENumberListActionResponse response = CRUD.DeleteENumberList(id, db);
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.ENumberList);
        }

        /// <summary>
        /// Delete all ENumberLists
        /// </summary>
        /// <group>ENumberList Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/ENumberList</url>
        /// <param name="operationalReviewId" cref="long" in="header">Operational Review ID</param>
        [HttpDelete]
        [ResponseType(typeof(void))]
        public IHttpActionResult DeleteENumberLists(long operationalReviewId)
        {
            Console.WriteLine($">HTTP Web Request : DeleteENumberLists <- (operationalReviewId: {operationalReviewId})");

            ENumberListActionResponse response = CRUD.DeleteENumberLists(operationalReviewId, db);
            if (!response.Success)
            {
                return NotFound();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }
    }
}
