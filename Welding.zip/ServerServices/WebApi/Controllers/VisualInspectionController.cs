﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.CRUD;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the Consumable class
    /// </summary>
    public class VisualInspectionController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a Visual_Inspection by ID
        /// </summary>
        /// <group>Visual_Inspection Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Visual_Inspection/1</url>
        /// <param name="id" cref="long" in="header">Visual_Inspection ID</param>
        /// <response code="200"><see cref="Visual_Inspection"/>Visual_Inspection Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(Visual_Inspection))]
        public IHttpActionResult GetVisualInspection(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetVisualInspection <- (id: {id})");

            VisualInspectionActionResponse response = CRUD.ReadVisualInspection(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Visual_Inspection);
        }

        /// <summary>
        /// Get all Visual_Inspections
        /// </summary>
        /// <group>Visual_Inspection Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Visual_Inspection</url>
        /// <response code="200"><see cref="List&lt;Visual_Inspection&gt;"/>Visual_Inspection List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<Visual_Inspection>))]
        public IHttpActionResult GetVisualInspections()
        {
            Console.WriteLine($">HTTP Web Request : GetVisualInspections");

            VisualInspectionsActionResponse response = CRUD.ReadVisualInspections(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Visual_Inspections);
        }

        /// <summary>
        /// Update a Visual_Inspection
        /// </summary>
        /// <group>Visual_Inspection Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Consumables/1</url>
        /// <param name="visualInspectionId" cref="long" in="header">Visual_Inspection ID</param>
        /// <param name="dto" in="body"><see cref="Visual_Inspection"/>Visual_Inspection Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutVisualInspection(long visualInspectionId, [FromBody] Visual_Inspection dto)
        {
            Console.WriteLine($">HTTP Web Request : PutVisualInspection <- (visualInspectionId: {visualInspectionId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                VisualInspectionActionResponse response = CRUD.UpdateVisualInspection(visualInspectionId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a Visual_Inspection
        /// </summary>
        /// <group>Visual_Inspection Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Visual_Inspection</url>
        /// <param name="welderQualId" cref="long" in="header">Welder_Qualification ID</param>
        /// <param name="dto" in="body"><see cref="Visual_Inspection"/>Visual_Inspection Data Transfer Object</param>
        /// <response code="200"><see cref="Visual_Inspection"/>Visual_Inspection Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(Visual_Inspection))]
        public IHttpActionResult PostVisualInspection(long welderQualId, [FromBody] Visual_Inspection dto)
        {
            Console.WriteLine($">HTTP Web Request : PostVisualInspection <- (welderQualId: {welderQualId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Visual_Inspection visualInspection = CRUD.CreateVisualInspection(welderQualId, dto, db).Visual_Inspection;

            return CreatedAtRoute("DefaultApi", new { id = visualInspection.Visual_InspectionId }, visualInspection);
        }

        /// <summary>
        /// Delete a Visual_Inspection by ID
        /// </summary>
        /// <group>Visual_Inspection Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Visual_Inspection/1</url>
        /// <param name="id" cref="long" in="header">Visual_Inspection ID</param>
        [HttpDelete]
        [ResponseType(typeof(Visual_Inspection))]
        public IHttpActionResult DeleteVisualInspection(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteVisualInspection <- (id: {id})");

            VisualInspectionActionResponse response = CRUD.DeleteVisualInspection(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Visual_Inspection);
        }
    }
}
