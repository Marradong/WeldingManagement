﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.CRUD;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the Consumable class
    /// </summary>
    public class OperationalReviewsController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a OperationalReview by ID
        /// </summary>
        /// <group>OperationalReview Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/OperationalReviews/1</url>
        /// <param name="id" cref="long" in="header">OperationalReview ID</param>
        /// <response code="200"><see cref="OperationalReview"/>OperationalReview Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(OperationalReview))]
        public IHttpActionResult GetOperationalReview(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetOperationalReview <- (id: {id})");

            OperationalReviewActionResponse response = CRUD.ReadOperationalReview(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.OperationalReview);
        }

        /// <summary>
        /// Get all OperationalReviews
        /// </summary>
        /// <group>OperationalReview Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/OperationalReviews</url>
        /// <response code="200"><see cref="List&lt;OperationalReview&gt;"/>OperationalReview List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<OperationalReview>))]
        public IHttpActionResult GetOperationalReviews()
        {
            Console.WriteLine($">HTTP Web Request : GetOperationalReviews");

            OperationalReviewsActionResponse response = CRUD.ReadOperationalReviews(db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.OperationalReviews);
        }

        /// <summary>
        /// Update a OperationalReview
        /// </summary>
        /// <group>OperationalReview Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/OperationalReviews/1</url>
        /// <param name="operationalReviewId" cref="long" in="header">OperationalReview ID</param>
        /// <param name="dto" in="body"><see cref="OperationalReview"/>OperationalReview Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutOperationalReview(long operationalReviewId, [FromBody] OperationalReview dto)
        {
            Console.WriteLine($">HTTP Web Request : PutOperationalReview <- (operationalReviewId: {operationalReviewId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                OperationalReviewActionResponse response = CRUD.UpdateOperationalReview(operationalReviewId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a OperationalReview
        /// </summary>
        /// <group>OperationalReview Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/OperationalReviews</url>
        /// <param name="nwfId" cref="long" in="header">NewWeldingForm ID</param>
        /// <param name="dto" in="body"><see cref="OperationalReview"/>OperationalReview Data Transfer Object</param>
        /// <response code="200"><see cref="OperationalReview"/>OperationalReview Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(OperationalReview))]
        public IHttpActionResult PostOperationalReview(long nwfId, [FromBody] OperationalReview dto)
        {
            Console.WriteLine($">HTTP Web Request : PostOperationalReview <- (nwfId: {nwfId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            OperationalReview operationalReview = CRUD.CreateOperationalReview(nwfId, dto, db).OperationalReview;

            return CreatedAtRoute("DefaultApi", new { id = operationalReview.OperationalReviewId }, operationalReview);
        }

        /// <summary>
        /// Delete a OperationalReview by ID
        /// </summary>
        /// <group>OperationalReview Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/OperationalReviews/1</url>
        /// <param name="id" cref="long" in="header">OperationalReview ID</param>
        [HttpDelete]
        [ResponseType(typeof(OperationalReview))]
        public IHttpActionResult DeleteOperationalReview(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteOperationalReview <- (id: {id})");

            OperationalReviewActionResponse response = CRUD.DeleteOperationalReview(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.OperationalReview);
        }
    }
}
