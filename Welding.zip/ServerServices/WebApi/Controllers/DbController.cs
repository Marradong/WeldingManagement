﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using static Welding.DAL.CRUD;
using Welding.DAL;
using System.Web.Http.Description;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the Consumable class
    /// </summary>
    public class DatabaseController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Initialise the Welding Database
        /// </summary>
        /// <group>Database Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Database</url>
        /// <param name="ENumber" cref="string" in="header">User ENumber</param>
        [HttpGet]
        [ResponseType(typeof(void))]
        public IHttpActionResult InitializeDatabase(string ENumber)
        {
            Console.WriteLine($">HTTP Web Request : InitializeDatabase <- (ENumber: {ENumber})");

            List<string> adminUsers = new List<string> { "2596", "3215", "1541", "2930" };

            if (adminUsers.Contains(ENumber))
            {
                InitaliseDb(ENumber, db);

                return Ok("Database initialized successfully.");
            }
            else
            {
                return Unauthorized();
            }
        }
    }
}
