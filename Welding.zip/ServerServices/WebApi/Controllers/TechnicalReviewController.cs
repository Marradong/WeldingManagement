﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.CRUD;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the Consumable class
    /// </summary>
    public class TechnicalReviewsController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a TechnicalReview by ID
        /// </summary>
        /// <group>TechnicalReview Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/TechnicalReviews/1</url>
        /// <param name="id" cref="long" in="header">TechnicalReview ID</param>
        /// <response code="200"><see cref="TechnicalReview"/>TechnicalReview Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(TechnicalReview))]
        public IHttpActionResult GetTechnicalReview(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetTechnicalReview <- (id: {id})");

            TechnicalReviewActionResponse response = CRUD.ReadTechnicalReview(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.TechnicalReview);
        }

        /// <summary>
        /// Get all TechnicalReviews
        /// </summary>
        /// <group>TechnicalReview Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/TechnicalReviews</url>
        /// <response code="200"><see cref="List&lt;TechnicalReview&gt;"/>TechnicalReview List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<TechnicalReview>))]
        public IHttpActionResult GetTechnicalReviews()
        {
            Console.WriteLine($">HTTP Web Request : GetTechnicalReviews");

            TechnicalReviewsActionResponse response = CRUD.ReadTechnicalReviews(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.TechnicalReviews);
        }

        /// <summary>
        /// Update a TechnicalReview
        /// </summary>
        /// <group>TechnicalReview Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/TechnicalReviews/1</url>
        /// <param name="technicalReviewId" cref="long" in="header">TechnicalReview ID</param>
        /// <param name="dto" in="body"><see cref="TechnicalReview"/>TechnicalReview Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTechnicalReview(long technicalReviewId, [FromBody] TechnicalReview dto)
        {
            Console.WriteLine($">HTTP Web Request : PutTechnicalReview <- (technicalReviewId: {technicalReviewId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                TechnicalReviewActionResponse response = CRUD.UpdateTechnicalReview(technicalReviewId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a TechnicalReview
        /// </summary>
        /// <group>TechnicalReview Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/TechnicalReviews</url>
        /// <param name="nwfId" cref="long" in="header">NewWeldingForm ID</param>
        /// <param name="dto" in="body"><see cref="TechnicalReview"/>TechnicalReview Data Transfer Object</param>
        /// <response code="200"><see cref="TechnicalReview"/>TechnicalReview Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(TechnicalReview))]
        public IHttpActionResult PostTechnicalReview(long nwfId, [FromBody] TechnicalReview dto)
        {
            Console.WriteLine($">HTTP Web Request : PostTechnicalReview <- (nwfId: {nwfId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            TechnicalReview technicalReview = CRUD.CreateTechnicalReview(nwfId, dto, db).TechnicalReview;

            return CreatedAtRoute("DefaultApi", new { id = technicalReview.TechnicalReviewId }, technicalReview);
        }

        /// <summary>
        /// Delete a TechnicalReview by ID
        /// </summary>
        /// <group>TechnicalReview Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/TechnicalReviews/1</url>
        /// <param name="id" cref="long" in="header">TechnicalReview ID</param>
        [HttpDelete]
        [ResponseType(typeof(TechnicalReview))]
        public IHttpActionResult DeleteTechnicalReview(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteTechnicalReview <- (id: {id})");

            TechnicalReviewActionResponse response = CRUD.DeleteTechnicalReview(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.TechnicalReview);
        }
    }
}
