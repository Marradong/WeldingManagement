﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;
using static Welding.DAL.CRUD;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the Datasheet class
    /// </summary>
    public class DatasheetController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a Datasheet by ID
        /// </summary>
        /// <group>Datasheet Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Datasheet/1</url>
        /// <param name="id" cref="long" in="header">Datasheet ID</param>
        /// <response code="200"><see cref="Datasheet"/>Datasheet Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(Datasheet))]
        public IHttpActionResult GetDatasheet(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetDatasheet <- (id: {id})");

            DatasheetActionResponse response = CRUD.ReadDatasheet(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Datasheet);
        }

        /// <summary>
        /// Get all Datasheets
        /// </summary>
        /// <group>Datasheet Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Datasheet</url>
        /// <response code="200"><see cref="List&lt;Datasheet&gt;"/>Datasheet List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<Datasheet>))]
        public IHttpActionResult GetDatasheets()
        {
            Console.WriteLine($">HTTP Web Request : GetDatasheets");

            DatasheetsActionResponse response = CRUD.ReadDatasheets(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Datasheets);
        }

        /// <summary>
        /// Update a Datasheet
        /// </summary>
        /// <group>Datasheet Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Datasheet/1</url>
        /// <param name="datasheetId" cref="long" in="header">Datasheet ID</param>
        /// <param name="dto" in="body"><see cref="Datasheet"/>Datasheet Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDatasheet(long datasheetId, [FromBody] Datasheet dto)
        {
            Console.WriteLine($">HTTP Web Request : PutDatasheet <- (datasheetId: {datasheetId}, dto)");


            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try 
            { 
                DatasheetActionResponse response = CRUD.UpdateDatasheet(datasheetId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException) 
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a Datasheet
        /// </summary>
        /// <group>Datasheet Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Datasheet</url>
        /// <param name="welderQualId" cref="long" in="header">Welder_Qualification ID</param>
        /// <param name="dto" in="body"><see cref="Datasheet"/>Datasheet Data Transfer Object</param>
        /// <response code="200"><see cref="Datasheet"/>Datasheet Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(Datasheet))]
        public IHttpActionResult PostDatasheet(long welderQualId, [FromBody] Datasheet dto)
        {
            Console.WriteLine($">HTTP Web Request : PostDatasheet <- (welderQualId: {welderQualId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Datasheet datasheet = CRUD.CreateDatasheet(welderQualId, dto, db).Datasheet;

            return CreatedAtRoute("DefaultApi", new { id = datasheet.DatasheetId }, datasheet);
        }

        /// <summary>
        /// Delete a Datasheet by ID
        /// </summary>
        /// <group>Datasheet Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Datasheet/1</url>
        /// <param name="id" cref="long" in="header">Datasheet ID</param>
        [HttpDelete]
        [ResponseType(typeof(Datasheet))]
        public IHttpActionResult DeleteDatasheet(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteDatasheet <- (id: {id})");

            DatasheetActionResponse response = CRUD.DeleteDatasheet(id, db);
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Datasheet);
        }
    }
}
