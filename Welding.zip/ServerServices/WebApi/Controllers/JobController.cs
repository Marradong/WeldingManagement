﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;
using static Welding.DAL.CRUD;
using Newtonsoft.Json.Linq;
using System.Security.Cryptography;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the Job class
    /// </summary>
    public class JobsController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a Job by ID
        /// </summary>
        /// <group>Job Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Jobs/1</url>
        /// <param name="id" cref="long" in="header">Job ID</param>
        /// <response code="200"><see cref="Job"/>Job Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(Job))]
        public IHttpActionResult GetJob(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetJob <- (id: {id})");

            JobActionResponse response = CRUD.ReadJob(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Job);
        }

        /// <summary>
        /// Get all Jobs
        /// </summary>
        /// <group>Job Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Jobs</url>
        /// <response code="200"><see cref="List&lt;Job&gt;"/>Job List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<Job>))]
        public IHttpActionResult GetJobs()
        {
            Console.WriteLine($">HTTP Web Request : GetJobs");

            JobsActionResponse response = CRUD.ReadJobs(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Jobs);
        }

        /// <summary>
        /// Update a Job
        /// </summary>
        /// <group>Job Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Jobs/1</url>
        /// <param name="jobId" cref="long" in="header">Job ID</param>
        /// <param name="dto" in="body"><see cref="Job"/>Job Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutJob(long jobId, [FromBody] Job dto)
        {
            Console.WriteLine($">HTTP Web Request : PutJob <- (jobId: {jobId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                JobActionResponse response = CRUD.UpdateJob(jobId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a Job
        /// </summary>
        /// <group>Job Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Jobs</url>
        /// <param name="dto" in="body"><see cref="Job"/>Job Data Transfer Object</param>
        /// <response code="200"><see cref="Job"/>Job Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(Job))]
        public IHttpActionResult PostJob(Job dto)
        {
            Console.WriteLine($">HTTP Web Request : PostJob <- (dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Job job = CRUD.CreateJob(dto, db).Job;

            return CreatedAtRoute("DefaultApi", new { id = job.JobId }, job);
        }

        /// <summary>
        /// Create a Job and a Default Welding Action
        /// </summary>
        /// <group>Job Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Jobs</url>
        /// <param name="quoteNumber" cref="string" in="header">Job Data Transfer Object</param>
        /// <param name="managerEID" cref="string" in="header">Job Data Transfer Object</param>
        /// <response code="200"><see cref="Job"/>Job Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(Job))]
        public IHttpActionResult PostJobDefault(string quoteNumber, string managerEID)
        {
            Console.WriteLine($">HTTP Web Request : PostJobDefault <- (quoteNumber: {quoteNumber}, managerEID: {managerEID})");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Job job = CRUD.CreateJobDefault(quoteNumber, managerEID, db).Job;

            return CreatedAtRoute("DefaultApi", new { id = job.JobId }, job);
        }

        /// <summary>
        /// Delete a Job by ID
        /// </summary>
        /// <group>Job Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/Jobs/1</url>
        /// <param name="id" cref="long" in="header">Job ID</param>
        [HttpDelete]
        [ResponseType(typeof(Job))]
        public IHttpActionResult DeleteJob(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteJob <- (id: {id})");

            JobActionResponse response = CRUD.DeleteJob(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.Job);
        }
    }
}
