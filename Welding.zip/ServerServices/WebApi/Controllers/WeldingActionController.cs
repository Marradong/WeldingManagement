﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.CRUD;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the WeldingAction class
    /// </summary>
    public class WeldingActionsController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a WeldingAction by ID
        /// </summary>
        /// <group>WeldingAction Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WeldingActions/1</url>
        /// <param name="id" cref="long" in="header">WeldingAction ID</param>
        /// <response code="200"><see cref="WeldingAction"/>WeldingAction Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(WeldingAction))]
        public IHttpActionResult GetWeldingAction(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetWeldingAction <- (id: {id})");

            WeldingActionActionResponse response = CRUD.ReadWeldingAction(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WeldingAction);
        }

        /// <summary>
        /// Get all WeldingActions
        /// </summary>
        /// <group>WeldingAction Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WeldingActions</url>
        /// <response code="200"><see cref="List&lt;WeldingAction&gt;"/>WeldingAction List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<WeldingAction>))]
        public IHttpActionResult GetWeldingActions()
        {
            Console.WriteLine($">HTTP Web Request : GetWeldingActions");

            WeldingActionsActionResponse response = CRUD.ReadWeldingActions(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WeldingActions);
        }

        /// <summary>
        /// Update a WeldingAction
        /// </summary>
        /// <group>WeldingAction Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WeldingActions/1</url>
        /// <param name="weldingActionId" cref="long" in="header">WeldingAction ID</param>
        /// <param name="dto" in="body"><see cref="WeldingAction"/>WeldingAction Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWeldingAction(long weldingActionId, [FromBody] WeldingAction dto)
        {
            Console.WriteLine($">HTTP Web Request : PutWeldingAction <- (weldingActionId: {weldingActionId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                WeldingActionActionResponse response = CRUD.UpdateWeldingAction(weldingActionId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a WeldingAction
        /// </summary>
        /// <group>WeldingAction Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WeldingActions</url>
        /// <param name="jobId" cref="long" in="header">Job ID</param>
        /// <param name="dto" in="body"><see cref="WeldingAction"/>WeldingAction Data Transfer Object</param>
        /// <response code="200"><see cref="WeldingAction"/>WeldingAction Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(WeldingAction))]
        public IHttpActionResult PostWeldingAction(long jobId, [FromBody] WeldingAction dto)
        {
            Console.WriteLine($">HTTP Web Request : PostWeldingAction <- (jobId: {jobId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            WeldingAction weldingAction = CRUD.CreateWeldingAction(jobId, dto, db).WeldingAction;

            return CreatedAtRoute("DefaultApi", new { id = weldingAction.WeldingActionId }, weldingAction);
        }

        /// <summary>
        /// Delete a WeldingAction by ID
        /// </summary>
        /// <group>WeldingAction Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WeldingActions/1</url>
        /// <param name="id" cref="long" in="header">WeldingAction ID</param>
        [HttpDelete]
        [ResponseType(typeof(WeldingAction))]
        public IHttpActionResult DeleteWeldingAction(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteWeldingAction <- (id: {id})");

            WeldingActionActionResponse response = CRUD.DeleteWeldingAction(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WeldingAction);
        }
    }
}
