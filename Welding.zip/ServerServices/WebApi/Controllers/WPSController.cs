﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.CRUD;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using System.Web.Http;
using Welding.DAL;

namespace WebApi
{
    /// <summary>
    /// Api Controller for the WPS class
    /// </summary>
    public class WPSController : ApiController
    {
        private readonly EFWeldingManagement db = GlobalDbContext.Instance;

        /// <summary>
        /// Get a WPS by ID
        /// </summary>
        /// <group>WPS Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPS/1</url>
        /// <param name="id" cref="long" in="header">WPS ID</param>
        /// <response code="200"><see cref="WPS"/>WPS Object Recieved</response>
        [HttpGet]
        [ResponseType(typeof(WPS))]
        public IHttpActionResult GetWPS(long id)
        {
            Console.WriteLine($">HTTP Web Request : GetWPS <- (id: {id})");

            WPSActionResponse response = CRUD.ReadWPS(id, db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPS);
        }

        /// <summary>
        /// Get all WPS
        /// </summary>
        /// <group>WPS Requests</group>
        /// <verb>GET</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPS</url>
        /// <response code="200"><see cref="List&lt;WPS&gt;"/>WPS List Recieved</response>
        [HttpGet]
        [ResponseType(typeof(List<WPS>))]
        public IHttpActionResult GetWPSs()
        {
            Console.WriteLine($">HTTP Web Request : GetWPSs");

            WPSsActionResponse response = CRUD.ReadWPSs(db);

            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPSs);
        }

        /// <summary>
        /// Update a WPS
        /// </summary>
        /// <group>WPS Requests</group>
        /// <verb>PUT</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPS/1</url>
        /// <param name="wpsId" cref="long" in="header">WPS ID</param>
        /// <param name="dto" in="body"><see cref="WPS"/>WPS Data Transfer Object</param>
        [HttpPut]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWPS(long wpsId, [FromBody] WPS dto)
        {
            Console.WriteLine($">HTTP Web Request : PutWPS <- (wpsId: {wpsId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                WPSActionResponse response = CRUD.UpdateWPS(wpsId, dto, db);

                if (!response.Success)
                {
                    return NotFound();
                }
            }
            catch (ArgumentNullException)
            {
                return BadRequest();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a WPS
        /// </summary>
        /// <group>WPS Requests</group>
        /// <verb>POST</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPS</url>
        /// <param name="wpqrId" cref="long" in="header">WPQR ID</param>
        /// <param name="dto" in="body"><see cref="WPS"/>WPS Data Transfer Object</param>
        /// <response code="200"><see cref="WPS"/>WPS Object Posted</response>
        [HttpPost]
        [ResponseType(typeof(WPS))]
        public IHttpActionResult PostWPS(long wpqrId, [FromBody] WPS dto)
        {
            Console.WriteLine($">HTTP Web Request : PostWPS <- (wpqrId: {wpqrId}, dto)");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            
            WPS wps = CRUD.CreateWPS(wpqrId, dto, db).WPS;
            
            return CreatedAtRoute("DefaultApi", new { id = wps.WPSId }, wps);
        }

        /// <summary>
        /// Delete a WPS by ID
        /// </summary>
        /// <group>WPS Requests</group>
        /// <verb>DELETE</verb>
        /// <url>http://{localIPAddress}:{InternalPort}/api/WPS/1</url>
        /// <param name="id" cref="long" in="header">WPS ID</param>
        [HttpDelete]
        [ResponseType(typeof(WPS))]
        public IHttpActionResult DeleteWPS(long id)
        {
            Console.WriteLine($">HTTP Web Request : DeleteWPS <- (id: {id})");

            WPSActionResponse response = CRUD.DeleteWPS(id, db);
            
            if (!response.Success)
            {
                return NotFound();
            }

            return Ok(response.WPS);
        }
    }
}
