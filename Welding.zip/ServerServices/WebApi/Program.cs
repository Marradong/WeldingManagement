﻿using Microsoft.Owin.Hosting;
using Owin;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using static WebApi.ApiSetup;
using static System.Net.Mime.MediaTypeNames;
using System.Reflection;
using System.Security.Principal;

namespace WebApi
{
    class Program
    {
        private static bool IsRunAsAdministrator()
        {
            var wi = WindowsIdentity.GetCurrent();
            var wp = new WindowsPrincipal(wi);

            return wp.IsInRole(WindowsBuiltInRole.Administrator);
        }
        static void Main(string[] args)
        {
            if (!IsRunAsAdministrator())
            {
                var processInfo = new ProcessStartInfo(Assembly.GetExecutingAssembly().CodeBase);

                // The following properties run the new process as administrator
                processInfo.UseShellExecute = true;
                processInfo.Verb = "runas";

                // Start the new process
                try
                {
                    Process.Start(processInfo);
                }
                catch (Exception)
                {
                    // The user did not allow the application to run as administrator
                    Console.WriteLine("Sorry, this application must be run as Administrator.");
                }

                // Shut down the current process
                return;
            }


            if (Debugger.IsAttached)
            {
                localIPAddress = GetLocalIPAddress();
            }

            if (!IsPortAvailable(InternalPort))
            {
                Console.WriteLine($"Web Api Server {localIPAddress} : Port {InternalPort} is not available. Please close any applications that may be using this port and try again!!!.");
                Console.ReadKey();
                return;

            }

            string baseAddress = $"http://{localIPAddress}:{InternalPort}/"; // You can change the port number

            // baseAddress = "http://localhost:9000/";
            // Start OWIN host

            Version ver;

            try
            {
                ver = System.Deployment.Application.ApplicationDeployment.CurrentDeployment.UpdatedVersion;
            }
            catch (Exception)
            {
                ver = Assembly.GetExecutingAssembly().GetName().Version;
            }


            string heading = $"<< WMS WEB API SERVER Version: {ver.Major}.{ver.Minor}.{ver.Build}.{ver.Revision} >>";
            string subheading = $"Started : {DateTime.Now.ToString("hh:mm ddd, dd MMM").ToUpper()}";
            string border = new string('-', heading.Length > subheading.Length ? heading.Length : subheading.Length);

            using (WebApp.Start<Startup>(url: baseAddress))
            {
                Console.WriteLine($"\r\n{border}\r\n{heading}\r\n{subheading}\r\n{border}\r\n");
                Console.WriteLine($"Web API started at {baseAddress}");
                Console.WriteLine("Press <ENTER> to stop the server and close the app...");
                Console.ReadLine();
            }
        }
    }
}
