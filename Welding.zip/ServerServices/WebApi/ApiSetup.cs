﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace WebApi
{
    public static class ApiSetup
    {
//#if DEBUG
//        public static string localIPAddress = "localhost";

//        public const int InternalPort = 9000;
//#else
        public static IPAddress localIPAddress = new IPAddress(new byte[]{192, 168, 100, 171});

        public const int InternalPort = 54321;

        public static IPAddress GetLocalIPAddress()
        {
            Debug.WriteLine("Attempting to retrieve local IP Address.");
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    Debug.WriteLine($"Local IPv4 address found: {ip}");
                    return ip;
                }
            }
            Debug.WriteLine("No network adapters with an IPv4 address in the system. Throwing exception.");
            throw new Exception("No network adapters with an IPv4 address in the system!");
        }
        public static bool IsPortAvailable(int port)
        {
            TcpListener tcpListener = null;
            try
            {
                tcpListener = new TcpListener(localIPAddress, port); // IPAddress.Any {0.0.0.0}
                tcpListener.Start();
                Debug.WriteLine($"local {localIPAddress} : port {port} is available.");
                return true;
            }
            catch (SocketException ex)
            {
                Debug.WriteLine($"local {localIPAddress} : port {port} is not available. Exception: {ex.Message}");
                return false;
            }
            finally
            {
                tcpListener?.Stop();
            }
        }
//#endif
    }
}
