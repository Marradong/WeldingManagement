﻿using Owin;
using System.Collections.Generic;
using System;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;
using System.Linq;

[assembly: Microsoft.Owin.OwinStartup(typeof(WebApi.Startup))]
namespace WebApi
{
    public static class GlobalDbContext
    {
        private static readonly EFWeldingManagement _instance = new EFWeldingManagement();

        public static EFWeldingManagement Instance => _instance;
    }

    public class Startup
    {
        //IEndpointRouteBuilder 
        public void Configuration(IAppBuilder appBuilder)
        {
            // Configure Web API for self-host
            HttpConfiguration config = new HttpConfiguration();

            // Enable attribute routing
            config.MapHttpAttributeRoutes();

            // Enable endpoint documentation
            // config.Services.Replace(typeof(IDocumentationProvider), new XmlCommentDocumentationProvider(HttpContext.Current.Server.MapPath("~/App_Data/WebApi.XML")));

            // Additional configurations, filters, formatters, etc.
            config.Formatters.JsonFormatter.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
            config.Formatters.JsonFormatter.SerializerSettings.ConstructorHandling = Newtonsoft.Json.ConstructorHandling.AllowNonPublicDefaultConstructor;


            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            // Configuration for AttachmentController
            config.Routes.MapHttpRoute(
                name: "AttachmentApi",
                routeTemplate: "api/Attachment/{id}",
                defaults: new { controller = "Attachment", id = RouteParameter.Optional }
            );

            // Configuration for ConsumablesController
            config.Routes.MapHttpRoute(
                name: "ConsumableApi",
                routeTemplate: "api/Consumables/{id}",
                defaults: new { controller = "Consumables", id = RouteParameter.Optional }
            );

            // Configuration for DatabaseController
            config.Routes.MapHttpRoute(
                name: "DatabaseApi",
                routeTemplate: "api/Database/{id}",
                defaults: new { controller = "Database", id = RouteParameter.Optional }
            );

            // Configuration for DatasheetController
            config.Routes.MapHttpRoute(
                name: "DatasheetApi",
                routeTemplate: "api/Datasheet/{id}",
                defaults: new { controller = "Datasheet", id = RouteParameter.Optional }
            );

            // Configuration for Datasheet_RunController
            config.Routes.MapHttpRoute(
                name: "DatasheetRunApi",
                routeTemplate: "api/Datasheet_Run/{id}",
                defaults: new { controller = "Datasheet_Run", id = RouteParameter.Optional }
            );

            // Configuration for EmployeeNumberController
            config.Routes.MapHttpRoute(
                name: "ENumberListApi",
                routeTemplate: "api/ENumberList/{id}",
                defaults: new { controller = "ENumberList", id = RouteParameter.Optional }
            );

            // Configuration for JobsController
            config.Routes.MapHttpRoute(
                name: "JobApi",
                routeTemplate: "api/Jobs/{id}",
                defaults: new { controller = "Jobs", id = RouteParameter.Optional }
            );

            // Configuration for NDT_RecordController
            config.Routes.MapHttpRoute(
                name: "NDTRecordApi",
                routeTemplate: "api/NDTRecord/{id}",
                defaults: new { controller = "NDTRecord", id = RouteParameter.Optional }
            );

            // Configuration for NewWeldingFormsController
            config.Routes.MapHttpRoute(
                name: "NewWeldingFormApi",
                routeTemplate: "api/NewWeldingForms/{id}",
                defaults: new { controller = "NewWeldingForms", id = RouteParameter.Optional }
            );

            // Configuration for OperationalReviewsController
            config.Routes.MapHttpRoute(
                name: "OperationalReviewApi",
                routeTemplate: "api/OperationalReviews/{id}",
                defaults: new { controller = "OperationalReviews", id = RouteParameter.Optional }
            );

            // Configuration for PeopleController
            config.Routes.MapHttpRoute(
                name: "PersonApi",
                routeTemplate: "api/People/{id}",
                defaults: new { controller = "People", id = RouteParameter.Optional }
            );

            // Configuration for TechnicalReviewsController
            config.Routes.MapHttpRoute(
                name: "TechnicalReviewApi",
                routeTemplate: "api/TechnicalReviews/{id}",
                defaults: new { controller = "TechnicalReviews", id = RouteParameter.Optional }
            );

            // Configuration for VisualInspectionController
            config.Routes.MapHttpRoute(
                name: "VisualInspectionApi",
                routeTemplate: "api/VisualInspection/{id}",
                defaults: new { controller = "VisualInspection", id = RouteParameter.Optional }
            );

            // Configuration for WelderQualificationController
            config.Routes.MapHttpRoute(
                name: "WelderQualificationApi",
                routeTemplate: "api/WelderQualification/{id}",
                defaults: new { controller = "WelderQualification", id = RouteParameter.Optional }
            );

            // Configuration for WeldingActionsController
            config.Routes.MapHttpRoute(
                name: "WeldingActionApi",
                routeTemplate: "api/WeldingActions/{id}",
                defaults: new { controller = "WeldingActions", id = RouteParameter.Optional }
            );

            // Configuration for WPQRsController
            config.Routes.MapHttpRoute(
                name: "WPQRApi",
                routeTemplate: "api/WPQRs/{id}",
                defaults: new { controller = "WPQRs", id = RouteParameter.Optional }
            );

            // Configuration for EmployeeNumberController
            config.Routes.MapHttpRoute(
                name: "WPQRNumberListApi",
                routeTemplate: "api/WPQRNumberList/{id}",
                defaults: new { controller = "WPQRNumberList", id = RouteParameter.Optional }
            );

            // Configuration for WPQR_RunController
            config.Routes.MapHttpRoute(
                name: "WPQRRunApi",
                routeTemplate: "api/WPQR_Run/{id}",
                defaults: new { controller = "WPQR_Run", id = RouteParameter.Optional }
            );

            // Configuration for WPSController
            config.Routes.MapHttpRoute(
                name: "WPSApi",
                routeTemplate: "api/WPS/{id}",
                defaults: new { controller = "WPS", id = RouteParameter.Optional }
            );

            // Configuration for EmployeeNumberController
            config.Routes.MapHttpRoute(
                name: "WPSNumberListApi",
                routeTemplate: "api/WPSNumberList/{id}",
                defaults: new { controller = "WPSNumberList", id = RouteParameter.Optional }
            );

            // Configuration for WPS_RunController
            config.Routes.MapHttpRoute(
                name: "WPSRunApi",
                routeTemplate: "api/WPS_Run/{id}",
                defaults: new { controller = "WPS_Run", id = RouteParameter.Optional }
            );

            // Additional configurations, filters, formatters, etc.
            config.Formatters.JsonFormatter.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;

            // Use Web API with OWIN
            appBuilder.UseWebApi(config);
        }
    }
}
