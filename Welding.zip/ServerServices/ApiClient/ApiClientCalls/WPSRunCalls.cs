﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient
{
    public partial class ApiCalls
    {
        //
        // CREATE
        //
        public static WPS_Run CreateWPSRun(long wpsId, WPS_Run dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/WPS_Run?wpsId={wpsId}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            WPS_Run wpsRun = JsonConvert.DeserializeObject<WPS_Run>(response.Content.ReadAsStringAsync().Result, settings);
            return wpsRun;
        }

        //
        // READ
        //
        public static WPS_Run ReadWPSRun(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/WPS_Run/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            WPS_Run wpsRun = JsonConvert.DeserializeObject<WPS_Run>(response.Content.ReadAsStringAsync().Result, settings);
            return wpsRun;
        }

        //
        // READS
        //
        public static List<WPS_Run> ReadWPSRuns()
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/WPS_Run");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            List<WPS_Run> wpsRun = JsonConvert.DeserializeObject<List<WPS_Run>>(response.Content.ReadAsStringAsync().Result, settings);
            return wpsRun;
        }

        //
        // UPDATE
        //
        public static void UpdateWPSRun(long id, WPS_Run dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/WPS_Run/{id}?wpsRunId={id}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE
        //
        public static void DeleteWPSRun(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/WPS_Run/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
