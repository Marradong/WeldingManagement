﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient
{
    public partial class ApiCalls
    {
        //
        // CREATE - POST
        //
        public static WPSNumberList CreateWPSNumberList(long operationalReviewId, WPSNumberList dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/WPSNumberList?operationalReviewId={operationalReviewId}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            WPSNumberList datasheet = JsonConvert.DeserializeObject<WPSNumberList>(response.Content.ReadAsStringAsync().Result, settings);
            return datasheet;
        }

        //
        // READ - GET
        //
        public static WPSNumberList ReadWPSNumberList(long id)
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/WPSNumberList/{id}");

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            WPSNumberList datasheet = JsonConvert.DeserializeObject<WPSNumberList>(response.Content.ReadAsStringAsync().Result, settings);
            return datasheet;
        }

        //
        // READS - GET
        //
        public static List<WPSNumberList> ReadWPSNumberLists()
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/WPSNumberList");

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            List<WPSNumberList> datasheet = JsonConvert.DeserializeObject<List<WPSNumberList>>(response.Content.ReadAsStringAsync().Result, settings);
            return datasheet;
        }

        //
        // UPDATE - PUT
        //
        public static void UpdateWPSNumberList(long id, WPSNumberList dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/WPSNumberList/{id}?id={id}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeleteWPSNumberList(long id)
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/WPSNumberList/{id}");

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeleteWPSNumberLists(long operationalReviewId)
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/WPSNumberList?operationalReviewId={operationalReviewId}");

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}