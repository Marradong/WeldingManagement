﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;
//using System.Text.Json;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient.ApiClientCalls
{
    public partial class ApiCalls
    {
        //
        // CREATE - POST
        //
        public static Person CreatePerson(Person dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/People")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            // Person person = response.Content.ReadAsAsync<Person>().Result;
            // Person person = JsonConvert.DeserializeObject<Person>(response.Content.ReadAsStringAsync().Result, settings);
            Person person = JsonConvert.DeserializeObject<Person>(response.Content.ReadAsStringAsync().Result, settings);
            return person;
        }

        //
        // READ - GET
        //
        public static Person ReadPerson(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/People/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            // Person person = JsonConvert.DeserializeObject<Person>(response.Content.ReadAsStringAsync().Result, settings);
            Person person = JsonConvert.DeserializeObject<Person>(response.Content.ReadAsStringAsync().Result, settings);
            return person;
        }

        //
        // READ - GET
        //
        public static Person ReadPerson(string ENumber)
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/People?ENumber={ENumber}");

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            // Person person = JsonConvert.DeserializeObject<Person>(response.Content.ReadAsStringAsync().Result, settings);
            Person person = JsonConvert.DeserializeObject<Person>(response.Content.ReadAsStringAsync().Result, settings);
            return person;
        }

        //
        // READS - GET
        //
        public static List<Person> ReadPeople()
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/People");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            // List<Person> person = JsonConvert.DeserializeObject<List<Person>>(response.Content.ReadAsStringAsync().Result, settings);
            List<Person> person = JsonConvert.DeserializeObject<List<Person>>(response.Content.ReadAsStringAsync().Result, settings);
            return person;
        }

        //
        // UPDATE - PUT
        //
        public static void UpdatePerson(long id, Person dto)
        {
            HttpClient client = new HttpClient();

            //string jsonContent = JsonConvert.SerializeObject(dto, settings);
            string jsonContent = JsonConvert.SerializeObject(dto);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/People/{id}?personId={id}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeletePerson(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/People/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
