﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient
{
    public partial class ApiCalls
    {
        //
        // CREATE - POST
        //
        public static NDT_Record CreateNDTRecord(long wpsId, NDT_Record dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/NDTRecord?wpsId={wpsId}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            NDT_Record ndtRecord = JsonConvert.DeserializeObject<NDT_Record>(response.Content.ReadAsStringAsync().Result, settings);
            return ndtRecord;
        }

        //
        // READ - GET
        //
        public static NDT_Record ReadNDTRecord(long id)
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/NDTRecord/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            NDT_Record ndtRecord = JsonConvert.DeserializeObject<NDT_Record>(response.Content.ReadAsStringAsync().Result, settings);
            return ndtRecord;
        }

        //
        // READS - GET
        //
        public static List<NDT_Record> ReadNDTRecords()
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/NDTRecord");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            List<NDT_Record> ndtRecord = JsonConvert.DeserializeObject<List<NDT_Record>>(response.Content.ReadAsStringAsync().Result, settings);
            return ndtRecord;
        }

        //
        // UPDATE - PUT
        //
        public static void UpdateNDTRecord(long ndtRecordId, NDT_Record dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/NDTRecord/{ndtRecordId}?ndtRecordId={ndtRecordId}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeleteNDTRecord(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/NDTRecord/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
