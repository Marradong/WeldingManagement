﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;


namespace ApiClient
{
    public partial class ApiCalls
    {
        //
        // CREATE - POST
        //
        public static Attachment CreateAttachment(Attachment dto, string linkObjType, long linkObjId) 
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/Attachment?linkObjId={linkObjId}&linkObjType={linkObjType}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            Attachment attachment = JsonConvert.DeserializeObject<Attachment>(response.Content.ReadAsStringAsync().Result, settings);
            return attachment;
        }

        //
        // READ - GET
        //
        public static Attachment ReadAttachment(long id)
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/Attachment/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            Attachment attachment = JsonConvert.DeserializeObject<Attachment>(response.Content.ReadAsStringAsync().Result, settings);
            return attachment;
        }

        //
        // READS - GET
        //
        public static List<Attachment> ReadAttachments() 
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/Attachment");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            List<Attachment> attachment = JsonConvert.DeserializeObject<List<Attachment>>(response.Content.ReadAsStringAsync().Result, settings);
            return attachment;
        }

        //
        // UPDATE - PUT
        //
        public static void UpdateAttachment(long id, Attachment dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/Attachment/{id}?attachmentId={id}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeleteAttachment(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/Attachment/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
