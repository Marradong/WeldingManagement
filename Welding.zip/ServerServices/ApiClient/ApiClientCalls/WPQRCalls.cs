﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient
{
    public partial class ApiCalls
    {
        //
        // CREATE - POST
        //
        public static WPQR CreateWPQR(long welderQualId, WPQR dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/WPQRs?welderQualId={welderQualId}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            WPQR wpqr = JsonConvert.DeserializeObject<WPQR>(response.Content.ReadAsStringAsync().Result, settings);
            return wpqr;
        }

        //
        // READ - GET
        //
        public static WPQR ReadWPQR(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/WPQRs/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            WPQR wpqr = JsonConvert.DeserializeObject<WPQR>(response.Content.ReadAsStringAsync().Result, settings);
            return wpqr;
        }

        //
        // READS - GET
        //
        public static List<WPQR> ReadWPQRs()
        {
            HttpClient client = new HttpClient();
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/WPQRs");
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            List<WPQR> wpqr = JsonConvert.DeserializeObject<List<WPQR>>(response.Content.ReadAsStringAsync().Result, settings);
            return wpqr;
        }

        //
        // UPDATE - PUT
        //
        public static void UpdateWPQR(long id, WPQR dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/WPQRs/{id}?wpqrId={id}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeleteWPQR(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/WPQRs/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
