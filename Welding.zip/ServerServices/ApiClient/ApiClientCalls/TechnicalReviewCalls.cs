﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient
{
    public partial class ApiCalls
    {
        //
        // CREATE - POST
        //
        public static TechnicalReview CreateTechnicalReview(long nwfId, TechnicalReview dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/TechnicalReviews?nwfId={nwfId}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            TechnicalReview technicalReview = JsonConvert.DeserializeObject<TechnicalReview>(response.Content.ReadAsStringAsync().Result, settings);
            return technicalReview;
        }

        //
        // READ - GET
        //
        public static TechnicalReview ReadTechnicalReview(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/TechnicalReviews/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            TechnicalReview technicalReview = JsonConvert.DeserializeObject<TechnicalReview>(response.Content.ReadAsStringAsync().Result, settings);
            return technicalReview;
        }

        //
        // READS - GET
        //
        public static List<TechnicalReview> ReadTechnicalReviews()
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/TechnicalReviews");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            List<TechnicalReview> technicalReview = JsonConvert.DeserializeObject<List<TechnicalReview>>(response.Content.ReadAsStringAsync().Result, settings);
            return technicalReview;
        }

        //
        // UPDATE - PUT
        //
        public static void UpdateTechnicalReview(long id, TechnicalReview dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/TechnicalReviews/{id}?technicalReviewId={id}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeleteTechnicalReview(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/TechnicalReviews/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
