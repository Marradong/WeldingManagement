﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient
{
    public partial class ApiCalls
    {
        //
        // CREATE - POST
        //
        public static Visual_Inspection CreateVisualInspection(long welderQualId, Visual_Inspection dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/VisualInspection?welderQualId={welderQualId}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            Visual_Inspection visual_Inspection = JsonConvert.DeserializeObject<Visual_Inspection>(response.Content.ReadAsStringAsync().Result, settings);
            return visual_Inspection;
        }

        //
        // READ - GET
        //
        public static Visual_Inspection ReadVisualInspection(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/VisualInspection/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            Visual_Inspection visual_Inspection = JsonConvert.DeserializeObject<Visual_Inspection>(response.Content.ReadAsStringAsync().Result, settings);
            return visual_Inspection;
        }

        //
        // READS - GET
        //
        public static List<Visual_Inspection> ReadVisualInspections()
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/VisualInspection");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
            
            List<Visual_Inspection> visual_Inspection = JsonConvert.DeserializeObject<List<Visual_Inspection>>(response.Content.ReadAsStringAsync().Result, settings);
            return visual_Inspection;
        }

        //
        // UPDATE - PUT
        //
        public static void UpdateVisualInspection(long id, Visual_Inspection dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/VisualInspection/{id}?visualInspectionId={id}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeleteVisualInspection(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/VisualInspection/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
