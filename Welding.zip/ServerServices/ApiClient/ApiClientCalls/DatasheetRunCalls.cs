﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient
{
    public partial class ApiCalls
    {
        //
        // CREATE - POST
        //
        public static Datasheet_Run CreateDatasheetRun(long datasheetId, Datasheet_Run dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/Datasheet_Run?datasheetId={datasheetId}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            Datasheet_Run datasheetRun = JsonConvert.DeserializeObject<Datasheet_Run>(response.Content.ReadAsStringAsync().Result, settings);
            return datasheetRun;
        }

        //
        // READ - GET
        //
        public static Datasheet_Run ReadDatasheetRun(long id)
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/Datasheet_Run/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            Datasheet_Run datasheetRun = JsonConvert.DeserializeObject<Datasheet_Run>(response.Content.ReadAsStringAsync().Result, settings);
            return datasheetRun;
        }

        //
        // READS - GET
        //
        public static List<Datasheet_Run> ReadDatasheetRuns()
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/Datasheet_Run");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            List<Datasheet_Run> datasheetRun = JsonConvert.DeserializeObject<List<Datasheet_Run>>(response.Content.ReadAsStringAsync().Result, settings);
            return datasheetRun;
        }

        //
        // UPDATE - PUT
        //
        public static void UpdateDatasheetRun(long id, Datasheet_Run dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/Datasheet_Run/{id}?datasheetRunId={id}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeleteDatasheetRun(long id)
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/Datasheet_Run/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
