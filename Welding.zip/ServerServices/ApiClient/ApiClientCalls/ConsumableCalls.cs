﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient
{
    public partial class ApiCalls
    {
        //
        // CREATE - POST
        //
        public static Consumable CreateConsumable(long datasheetId, Consumable dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/Consumables?datasheetId={datasheetId}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            Consumable consumable = JsonConvert.DeserializeObject<Consumable>(response.Content.ReadAsStringAsync().Result, settings);
            return consumable;
        }

        //
        // READ - GET
        //
        public static Consumable ReadConsumable(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/Consumables/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            Consumable consumable = JsonConvert.DeserializeObject<Consumable>(response.Content.ReadAsStringAsync().Result, settings);
            return consumable;
        }

        //
        // READS - GET
        //
        public static List<Consumable> ReadConsumables()
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/Consumables");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            List<Consumable> consumable = JsonConvert.DeserializeObject<List<Consumable>>(response.Content.ReadAsStringAsync().Result, settings);
            return consumable;
        }

        //
        // UPDATE - PUT
        //
        public static void UpdateConsumable(long id, Consumable dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/Consumables/{id}?consumableId={id}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeleteConsumable(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/Consumables/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
