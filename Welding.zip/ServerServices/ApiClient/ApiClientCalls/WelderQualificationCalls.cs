﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient
{
    public partial class ApiCalls
    {
        //
        // CREATE - POST
        //
        public static Welder_Qualification CreateWelderQualification(long weldingActionId, Welder_Qualification dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/WelderQualification?weldingActionId={weldingActionId}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            Welder_Qualification welderQual = JsonConvert.DeserializeObject<Welder_Qualification>(response.Content.ReadAsStringAsync().Result, settings);
            return welderQual;
        }

        //
        // READ - GET
        //
        public static Welder_Qualification ReadWelderQualification(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/WelderQualification/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            Welder_Qualification welderQual = JsonConvert.DeserializeObject<Welder_Qualification>(response.Content.ReadAsStringAsync().Result, settings);
            return welderQual;
        }

        //
        // READS - GET
        //
        public static List<Welder_Qualification> ReadWelderQualifications()
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/WelderQualification");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            List<Welder_Qualification> welderQual = JsonConvert.DeserializeObject<List<Welder_Qualification>>(response.Content.ReadAsStringAsync().Result, settings);
            return welderQual;
        }

        //
        // UPDATE - PUT
        //
        public static void UpdateWelderQualification(long id, Welder_Qualification dto)
        {
            HttpClient client = new HttpClient();
            
            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/WelderQualification/{id}?welderQualificationId={id}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeleteWelderQualification(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/WelderQualification/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
