﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient
{
    public partial class ApiCalls
    {
        //
        // CREATE - POST
        //
        public static NewWeldingForm CreateNewWeldingForm(long weldingActionId, NewWeldingForm dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/NewWeldingForms?weldingActionId={weldingActionId}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            NewWeldingForm nwf = JsonConvert.DeserializeObject<NewWeldingForm>(response.Content.ReadAsStringAsync().Result, settings);
            return nwf;
        }

        //
        // READ - GET
        //
        public static NewWeldingForm ReadNewWeldingForm(long id)
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/NewWeldingForms/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            NewWeldingForm nwf = JsonConvert.DeserializeObject<NewWeldingForm>(response.Content.ReadAsStringAsync().Result, settings);
            return nwf;
        }

        //
        // READS - GET
        //
        public static List<NewWeldingForm> ReadNewWeldingForms()
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/NewWeldingForms");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            List<NewWeldingForm> nwf = JsonConvert.DeserializeObject<List<NewWeldingForm>>(response.Content.ReadAsStringAsync().Result, settings);
            return nwf;
        }

        //
        // UPDATE - PUT
        //
        public static void UpdateNewWeldingForm(long id, NewWeldingForm dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/NewWeldingForms/{id}?nwfId={id}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };


            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeleteNewWeldingForm(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/NewWeldingForms/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
