﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient
{
    public partial class ApiCalls
    {
        //
        // CREATE - POST
        //
        public static WPQR_Run CreateWPQRRun(long wpqrId, WPQR_Run dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/WPQR_Run?wpqrId={wpqrId}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            WPQR_Run wpqrRun = JsonConvert.DeserializeObject<WPQR_Run>(response.Content.ReadAsStringAsync().Result, settings);
            return wpqrRun;
        }

        //
        // READ - GET
        //
        public static WPQR_Run ReadWPQRRun(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/WPQR_Run/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            WPQR_Run wpqrRun = JsonConvert.DeserializeObject<WPQR_Run>(response.Content.ReadAsStringAsync().Result, settings);
            return wpqrRun;
        }

        //
        // READS - GET
        //
        public static List<WPQR_Run> ReadWPQRRuns()
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/WPQR_Run");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            List<WPQR_Run> wpqrRun = JsonConvert.DeserializeObject<List<WPQR_Run>>(response.Content.ReadAsStringAsync().Result, settings);
            return wpqrRun;
        }

        //
        // UPDATE - PUT
        //
        public static void UpdateWPQRRun(long id, WPQR_Run dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/WPQR_Run/{id}?wpqrRunId={id}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeleteWPQRRun(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/WPQR_Run/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
