﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient
{
    public partial class ApiCalls
    {
        public static void InitialiseDb(string ENumber)
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/Database?ENumber={ENumber}");

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
