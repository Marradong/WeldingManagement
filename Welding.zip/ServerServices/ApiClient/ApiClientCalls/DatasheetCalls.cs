﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Welding.DAL;
using static WebApi.ApiSetup;

namespace ApiClient
{
    public partial class ApiCalls
    {
        //
        // CREATE - POST
        //
        public static Datasheet CreateDatasheet(long welderQualId, Datasheet dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, $"http://{localIPAddress}:{InternalPort}/api/Datasheet?welderQualId={welderQualId}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            Datasheet datasheet = JsonConvert.DeserializeObject<Datasheet>(response.Content.ReadAsStringAsync().Result, settings);
            return datasheet;
        }

        //
        // READ - GET
        //
        public static Datasheet ReadDatasheet(long id)
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/Datasheet/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            Datasheet datasheet = JsonConvert.DeserializeObject<Datasheet>(response.Content.ReadAsStringAsync().Result, settings);
            return datasheet;
        }

        //
        // READS - GET
        //
        public static List<Datasheet> ReadDatasheets()
        {
            HttpClient client = new HttpClient();
            
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{localIPAddress}:{InternalPort}/api/Datasheet");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();

            List<Datasheet> datasheet = JsonConvert.DeserializeObject<List<Datasheet>>(response.Content.ReadAsStringAsync().Result, settings);
            return datasheet;
        }

        //
        // UPDATE - PUT
        //
        public static void UpdateDatasheet(long id, Datasheet dto)
        {
            HttpClient client = new HttpClient();

            string jsonContent = JsonConvert.SerializeObject(dto, settings);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, $"http://{localIPAddress}:{InternalPort}/api/Datasheet/{id}?datasheetId={id}")
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }

        //
        // DELETE - DELETE
        //
        public static void DeleteDatasheet(long id)
        {
            HttpClient client = new HttpClient();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Delete, $"http://{localIPAddress}:{InternalPort}/api/Datasheet/{id}");
            
            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
        }
    }
}
