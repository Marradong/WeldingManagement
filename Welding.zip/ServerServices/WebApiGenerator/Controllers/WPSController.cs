﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class WPSController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/WPS
        public IQueryable<WPS> GetWPS()
        {
            return db.WPS;
        }

        // GET: api/WPS/5
        [ResponseType(typeof(WPS))]
        public IHttpActionResult GetWPS(long id)
        {
            WPS wPS = db.WPS.Find(id);
            if (wPS == null)
            {
                return NotFound();
            }

            return Ok(wPS);
        }

        // PUT: api/WPS/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWPS(long id, WPS wPS)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != wPS.WPSId)
            {
                return BadRequest();
            }

            db.Entry(wPS).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!WPSExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/WPS
        [ResponseType(typeof(WPS))]
        public IHttpActionResult PostWPS(WPS wPS)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.WPS.Add(wPS);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = wPS.WPSId }, wPS);
        }

        // DELETE: api/WPS/5
        [ResponseType(typeof(WPS))]
        public IHttpActionResult DeleteWPS(long id)
        {
            WPS wPS = db.WPS.Find(id);
            if (wPS == null)
            {
                return NotFound();
            }

            db.WPS.Remove(wPS);
            db.SaveChanges();

            return Ok(wPS);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool WPSExists(long id)
        {
            return db.WPS.Count(e => e.WPSId == id) > 0;
        }
    }
}