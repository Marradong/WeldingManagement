﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class Visual_InspectionController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/Visual_Inspection
        public IQueryable<Visual_Inspection> GetVisual_Inspection()
        {
            return db.Visual_Inspection;
        }

        // GET: api/Visual_Inspection/5
        [ResponseType(typeof(Visual_Inspection))]
        public IHttpActionResult GetVisual_Inspection(long id)
        {
            Visual_Inspection visual_Inspection = db.Visual_Inspection.Find(id);
            if (visual_Inspection == null)
            {
                return NotFound();
            }

            return Ok(visual_Inspection);
        }

        // PUT: api/Visual_Inspection/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutVisual_Inspection(long id, Visual_Inspection visual_Inspection)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != visual_Inspection.Visual_InspectionId)
            {
                return BadRequest();
            }

            db.Entry(visual_Inspection).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Visual_InspectionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Visual_Inspection
        [ResponseType(typeof(Visual_Inspection))]
        public IHttpActionResult PostVisual_Inspection(Visual_Inspection visual_Inspection)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Visual_Inspection.Add(visual_Inspection);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = visual_Inspection.Visual_InspectionId }, visual_Inspection);
        }

        // DELETE: api/Visual_Inspection/5
        [ResponseType(typeof(Visual_Inspection))]
        public IHttpActionResult DeleteVisual_Inspection(long id)
        {
            Visual_Inspection visual_Inspection = db.Visual_Inspection.Find(id);
            if (visual_Inspection == null)
            {
                return NotFound();
            }

            db.Visual_Inspection.Remove(visual_Inspection);
            db.SaveChanges();

            return Ok(visual_Inspection);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool Visual_InspectionExists(long id)
        {
            return db.Visual_Inspection.Count(e => e.Visual_InspectionId == id) > 0;
        }
    }
}