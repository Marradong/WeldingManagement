﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class WeldingActionsController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/WeldingActions
        public IQueryable<WeldingAction> GetWeldingActions()
        {
            return db.WeldingActions;
        }

        // GET: api/WeldingActions/5
        [ResponseType(typeof(WeldingAction))]
        public IHttpActionResult GetWeldingAction(long id)
        {
            WeldingAction weldingAction = db.WeldingActions.Find(id);
            if (weldingAction == null)
            {
                return NotFound();
            }

            return Ok(weldingAction);
        }

        // PUT: api/WeldingActions/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWeldingAction(long id, WeldingAction weldingAction)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != weldingAction.WeldingActionId)
            {
                return BadRequest();
            }

            db.Entry(weldingAction).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!WeldingActionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/WeldingActions
        [ResponseType(typeof(WeldingAction))]
        public IHttpActionResult PostWeldingAction(WeldingAction weldingAction)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.WeldingActions.Add(weldingAction);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = weldingAction.WeldingActionId }, weldingAction);
        }

        // DELETE: api/WeldingActions/5
        [ResponseType(typeof(WeldingAction))]
        public IHttpActionResult DeleteWeldingAction(long id)
        {
            WeldingAction weldingAction = db.WeldingActions.Find(id);
            if (weldingAction == null)
            {
                return NotFound();
            }

            db.WeldingActions.Remove(weldingAction);
            db.SaveChanges();

            return Ok(weldingAction);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool WeldingActionExists(long id)
        {
            return db.WeldingActions.Count(e => e.WeldingActionId == id) > 0;
        }
    }
}