﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class Welder_QualificationController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/Welder_Qualification
        public IQueryable<Welder_Qualification> GetWelder_Qualification()
        {
            return db.Welder_Qualification;
        }

        // GET: api/Welder_Qualification/5
        [ResponseType(typeof(Welder_Qualification))]
        public IHttpActionResult GetWelder_Qualification(long id)
        {
            Welder_Qualification welder_Qualification = db.Welder_Qualification.Find(id);
            if (welder_Qualification == null)
            {
                return NotFound();
            }

            return Ok(welder_Qualification);
        }

        // PUT: api/Welder_Qualification/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWelder_Qualification(long id, Welder_Qualification welder_Qualification)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != welder_Qualification.Welder_QualificationId)
            {
                return BadRequest();
            }

            db.Entry(welder_Qualification).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Welder_QualificationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Welder_Qualification
        [ResponseType(typeof(Welder_Qualification))]
        public IHttpActionResult PostWelder_Qualification(Welder_Qualification welder_Qualification)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Welder_Qualification.Add(welder_Qualification);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = welder_Qualification.Welder_QualificationId }, welder_Qualification);
        }

        // DELETE: api/Welder_Qualification/5
        [ResponseType(typeof(Welder_Qualification))]
        public IHttpActionResult DeleteWelder_Qualification(long id)
        {
            Welder_Qualification welder_Qualification = db.Welder_Qualification.Find(id);
            if (welder_Qualification == null)
            {
                return NotFound();
            }

            db.Welder_Qualification.Remove(welder_Qualification);
            db.SaveChanges();

            return Ok(welder_Qualification);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool Welder_QualificationExists(long id)
        {
            return db.Welder_Qualification.Count(e => e.Welder_QualificationId == id) > 0;
        }
    }
}