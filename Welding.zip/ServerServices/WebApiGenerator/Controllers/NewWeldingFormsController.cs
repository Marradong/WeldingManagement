﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class NewWeldingFormsController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/NewWeldingForms
        public IQueryable<NewWeldingForm> GetNewWeldingForms()
        {
            return db.NewWeldingForms;
        }

        // GET: api/NewWeldingForms/5
        [ResponseType(typeof(NewWeldingForm))]
        public IHttpActionResult GetNewWeldingForm(long id)
        {
            NewWeldingForm newWeldingForm = db.NewWeldingForms.Find(id);
            if (newWeldingForm == null)
            {
                return NotFound();
            }

            return Ok(newWeldingForm);
        }

        // PUT: api/NewWeldingForms/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutNewWeldingForm(long id, NewWeldingForm newWeldingForm)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != newWeldingForm.NewWeldingFormId)
            {
                return BadRequest();
            }

            db.Entry(newWeldingForm).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!NewWeldingFormExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/NewWeldingForms
        [ResponseType(typeof(NewWeldingForm))]
        public IHttpActionResult PostNewWeldingForm(NewWeldingForm newWeldingForm)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.NewWeldingForms.Add(newWeldingForm);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = newWeldingForm.NewWeldingFormId }, newWeldingForm);
        }

        // DELETE: api/NewWeldingForms/5
        [ResponseType(typeof(NewWeldingForm))]
        public IHttpActionResult DeleteNewWeldingForm(long id)
        {
            NewWeldingForm newWeldingForm = db.NewWeldingForms.Find(id);
            if (newWeldingForm == null)
            {
                return NotFound();
            }

            db.NewWeldingForms.Remove(newWeldingForm);
            db.SaveChanges();

            return Ok(newWeldingForm);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool NewWeldingFormExists(long id)
        {
            return db.NewWeldingForms.Count(e => e.NewWeldingFormId == id) > 0;
        }
    }
}