﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class TechnicalReviewsController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/TechnicalReviews
        public IQueryable<TechnicalReview> GetTechnicalReviews()
        {
            return db.TechnicalReviews;
        }

        // GET: api/TechnicalReviews/5
        [ResponseType(typeof(TechnicalReview))]
        public IHttpActionResult GetTechnicalReview(long id)
        {
            TechnicalReview technicalReview = db.TechnicalReviews.Find(id);
            if (technicalReview == null)
            {
                return NotFound();
            }

            return Ok(technicalReview);
        }

        // PUT: api/TechnicalReviews/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTechnicalReview(long id, TechnicalReview technicalReview)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != technicalReview.TechnicalReviewId)
            {
                return BadRequest();
            }

            db.Entry(technicalReview).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TechnicalReviewExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/TechnicalReviews
        [ResponseType(typeof(TechnicalReview))]
        public IHttpActionResult PostTechnicalReview(TechnicalReview technicalReview)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.TechnicalReviews.Add(technicalReview);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = technicalReview.TechnicalReviewId }, technicalReview);
        }

        // DELETE: api/TechnicalReviews/5
        [ResponseType(typeof(TechnicalReview))]
        public IHttpActionResult DeleteTechnicalReview(long id)
        {
            TechnicalReview technicalReview = db.TechnicalReviews.Find(id);
            if (technicalReview == null)
            {
                return NotFound();
            }

            db.TechnicalReviews.Remove(technicalReview);
            db.SaveChanges();

            return Ok(technicalReview);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TechnicalReviewExists(long id)
        {
            return db.TechnicalReviews.Count(e => e.TechnicalReviewId == id) > 0;
        }
    }
}