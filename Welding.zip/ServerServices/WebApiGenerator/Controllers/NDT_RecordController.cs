﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class NDT_RecordController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/NDT_Record
        public IQueryable<NDT_Record> GetNDT_Record()
        {
            return db.NDT_Record;
        }

        // GET: api/NDT_Record/5
        [ResponseType(typeof(NDT_Record))]
        public IHttpActionResult GetNDT_Record(long id)
        {
            NDT_Record nDT_Record = db.NDT_Record.Find(id);
            if (nDT_Record == null)
            {
                return NotFound();
            }

            return Ok(nDT_Record);
        }

        // PUT: api/NDT_Record/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutNDT_Record(long id, NDT_Record nDT_Record)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != nDT_Record.NDT_RecordId)
            {
                return BadRequest();
            }

            db.Entry(nDT_Record).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!NDT_RecordExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/NDT_Record
        [ResponseType(typeof(NDT_Record))]
        public IHttpActionResult PostNDT_Record(NDT_Record nDT_Record)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.NDT_Record.Add(nDT_Record);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = nDT_Record.NDT_RecordId}, nDT_Record);
        }

        // DELETE: api/NDT_Record/5
        [ResponseType(typeof(NDT_Record))]
        public IHttpActionResult DeleteNDT_Record(long id)
        {
            NDT_Record nDT_Record = db.NDT_Record.Find(id);
            if (nDT_Record == null)
            {
                return NotFound();
            }

            db.NDT_Record.Remove(nDT_Record);
            db.SaveChanges();

            return Ok(nDT_Record);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool NDT_RecordExists(long id)
        {
            return db.NDT_Record.Count(e => e.NDT_RecordId == id) > 0;
        }
    }
}