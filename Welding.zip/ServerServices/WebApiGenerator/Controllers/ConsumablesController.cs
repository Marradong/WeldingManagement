﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class ConsumablesController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/Consumables
        public IQueryable<Consumable> GetConsumables()
        {
            return db.Consumables;
        }

        // GET: api/Consumables/5
        [ResponseType(typeof(Consumable))]
        public IHttpActionResult GetConsumable(long id)
        {
            Consumable consumable = db.Consumables.Find(id);
            if (consumable == null)
            {
                return NotFound();
            }

            return Ok(consumable);
        }

        // PUT: api/Consumables/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutConsumable(long id, Consumable consumable)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != consumable.ConsumableId)
            {
                return BadRequest();
            }

            db.Entry(consumable).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ConsumableExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Consumables
        [ResponseType(typeof(Consumable))]
        public IHttpActionResult PostConsumable(Consumable consumable)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Consumables.Add(consumable);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = consumable.ConsumableId }, consumable);
        }

        // DELETE: api/Consumables/5
        [ResponseType(typeof(Consumable))]
        public IHttpActionResult DeleteConsumable(long id)
        {
            Consumable consumable = db.Consumables.Find(id);
            if (consumable == null)
            {
                return NotFound();
            }

            db.Consumables.Remove(consumable);
            db.SaveChanges();

            return Ok(consumable);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ConsumableExists(long id)
        {
            return db.Consumables.Count(e => e.ConsumableId == id) > 0;
        }
    }
}