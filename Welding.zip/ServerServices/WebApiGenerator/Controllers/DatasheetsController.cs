﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class DatasheetsController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/Datasheets
        public IQueryable<Datasheet> GetDatasheets()
        {
            return db.Datasheets;
        }

        // GET: api/Datasheets/5
        [ResponseType(typeof(Datasheet))]
        public IHttpActionResult GetDatasheet(long id)
        {
            Datasheet datasheet = db.Datasheets.Find(id);
            if (datasheet == null)
            {
                return NotFound();
            }

            return Ok(datasheet);
        }

        // PUT: api/Datasheets/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDatasheet(long id, Datasheet datasheet)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != datasheet.DatasheetId)
            {
                return BadRequest();
            }

            db.Entry(datasheet).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DatasheetExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Datasheets
        [ResponseType(typeof(Datasheet))]
        public IHttpActionResult PostDatasheet(Datasheet datasheet)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Datasheets.Add(datasheet);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = datasheet.DatasheetId }, datasheet);
        }

        // DELETE: api/Datasheets/5
        [ResponseType(typeof(Datasheet))]
        public IHttpActionResult DeleteDatasheet(long id)
        {
            Datasheet datasheet = db.Datasheets.Find(id);
            if (datasheet == null)
            {
                return NotFound();
            }

            db.Datasheets.Remove(datasheet);
            db.SaveChanges();

            return Ok(datasheet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool DatasheetExists(long id)
        {
            return db.Datasheets.Count(e => e.DatasheetId == id) > 0;
        }
    }
}