﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class OperationalReviewsController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/OperationalReviews
        public IQueryable<OperationalReview> GetOperationalReviews()
        {
            return db.OperationalReviews;
        }

        // GET: api/OperationalReviews/5
        [ResponseType(typeof(OperationalReview))]
        public IHttpActionResult GetOperationalReview(long id)
        {
            OperationalReview operationalReview = db.OperationalReviews.Find(id);
            if (operationalReview == null)
            {
                return NotFound();
            }

            return Ok(operationalReview);
        }

        // PUT: api/OperationalReviews/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutOperationalReview(long id, OperationalReview operationalReview)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != operationalReview.OperationalReviewId)
            {
                return BadRequest();
            }

            db.Entry(operationalReview).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OperationalReviewExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/OperationalReviews
        [ResponseType(typeof(OperationalReview))]
        public IHttpActionResult PostOperationalReview(OperationalReview operationalReview)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.OperationalReviews.Add(operationalReview);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = operationalReview.OperationalReviewId }, operationalReview);
        }

        // DELETE: api/OperationalReviews/5
        [ResponseType(typeof(OperationalReview))]
        public IHttpActionResult DeleteOperationalReview(long id)
        {
            OperationalReview operationalReview = db.OperationalReviews.Find(id);
            if (operationalReview == null)
            {
                return NotFound();
            }

            db.OperationalReviews.Remove(operationalReview);
            db.SaveChanges();

            return Ok(operationalReview);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool OperationalReviewExists(long id)
        {
            return db.OperationalReviews.Count(e => e.OperationalReviewId == id) > 0;
        }
    }
}