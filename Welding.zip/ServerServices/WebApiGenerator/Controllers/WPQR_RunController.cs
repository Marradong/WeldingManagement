﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class WPQR_RunController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/WPQR_Run
        public IQueryable<WPQR_Run> GetWPQR_Run()
        {
            return db.WPQR_Run;
        }

        // GET: api/WPQR_Run/5
        [ResponseType(typeof(WPQR_Run))]
        public IHttpActionResult GetWPQR_Run(long id)
        {
            WPQR_Run wPQR_Run = db.WPQR_Run.Find(id);
            if (wPQR_Run == null)
            {
                return NotFound();
            }

            return Ok(wPQR_Run);
        }

        // PUT: api/WPQR_Run/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWPQR_Run(long id, WPQR_Run wPQR_Run)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != wPQR_Run.WPQR_RunId)
            {
                return BadRequest();
            }

            db.Entry(wPQR_Run).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!WPQR_RunExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/WPQR_Run
        [ResponseType(typeof(WPQR_Run))]
        public IHttpActionResult PostWPQR_Run(WPQR_Run wPQR_Run)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.WPQR_Run.Add(wPQR_Run);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = wPQR_Run.WPQR_RunId }, wPQR_Run);
        }

        // DELETE: api/WPQR_Run/5
        [ResponseType(typeof(WPQR_Run))]
        public IHttpActionResult DeleteWPQR_Run(long id)
        {
            WPQR_Run wPQR_Run = db.WPQR_Run.Find(id);
            if (wPQR_Run == null)
            {
                return NotFound();
            }

            db.WPQR_Run.Remove(wPQR_Run);
            db.SaveChanges();

            return Ok(wPQR_Run);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool WPQR_RunExists(long id)
        {
            return db.WPQR_Run.Count(e => e.WPQR_RunId == id) > 0;
        }
    }
}