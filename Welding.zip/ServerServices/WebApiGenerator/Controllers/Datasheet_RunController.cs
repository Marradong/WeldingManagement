﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class Datasheet_RunController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/Datasheet_Run
        public IQueryable<Datasheet_Run> GetDatasheet_Run()
        {
            return db.Datasheet_Run;
        }

        // GET: api/Datasheet_Run/5
        [ResponseType(typeof(Datasheet_Run))]
        public IHttpActionResult GetDatasheet_Run(long id)
        {
            Datasheet_Run datasheet_Run = db.Datasheet_Run.Find(id);
            if (datasheet_Run == null)
            {
                return NotFound();
            }

            return Ok(datasheet_Run);
        }

        // PUT: api/Datasheet_Run/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDatasheet_Run(long id, Datasheet_Run datasheet_Run)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != datasheet_Run.Datasheet_RunId)
            {
                return BadRequest();
            }

            db.Entry(datasheet_Run).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Datasheet_RunExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Datasheet_Run
        [ResponseType(typeof(Datasheet_Run))]
        public IHttpActionResult PostDatasheet_Run(Datasheet_Run datasheet_Run)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Datasheet_Run.Add(datasheet_Run);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = datasheet_Run.Datasheet_RunId }, datasheet_Run);
        }

        // DELETE: api/Datasheet_Run/5
        [ResponseType(typeof(Datasheet_Run))]
        public IHttpActionResult DeleteDatasheet_Run(long id)
        {
            Datasheet_Run datasheet_Run = db.Datasheet_Run.Find(id);
            if (datasheet_Run == null)
            {
                return NotFound();
            }

            db.Datasheet_Run.Remove(datasheet_Run);
            db.SaveChanges();

            return Ok(datasheet_Run);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool Datasheet_RunExists(long id)
        {
            return db.Datasheet_Run.Count(e => e.Datasheet_RunId == id) > 0;
        }
    }
}