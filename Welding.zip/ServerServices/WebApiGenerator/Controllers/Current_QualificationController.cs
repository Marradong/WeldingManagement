﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class Current_QualificationController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/Current_Qualification
        public IQueryable<Current_Qualification> GetCurrent_Qualification()
        {
            return db.Current_Qualification;
        }

        // GET: api/Current_Qualification/5
        [ResponseType(typeof(Current_Qualification))]
        public IHttpActionResult GetCurrent_Qualification(long id)
        {
            Current_Qualification current_Qualification = db.Current_Qualification.Find(id);
            if (current_Qualification == null)
            {
                return NotFound();
            }

            return Ok(current_Qualification);
        }

        // PUT: api/Current_Qualification/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutCurrent_Qualification(long id, Current_Qualification current_Qualification)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != current_Qualification.Id)
            {
                return BadRequest();
            }

            db.Entry(current_Qualification).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Current_QualificationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Current_Qualification
        [ResponseType(typeof(Current_Qualification))]
        public IHttpActionResult PostCurrent_Qualification(Current_Qualification current_Qualification)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Current_Qualification.Add(current_Qualification);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = current_Qualification.Id }, current_Qualification);
        }

        // DELETE: api/Current_Qualification/5
        [ResponseType(typeof(Current_Qualification))]
        public IHttpActionResult DeleteCurrent_Qualification(long id)
        {
            Current_Qualification current_Qualification = db.Current_Qualification.Find(id);
            if (current_Qualification == null)
            {
                return NotFound();
            }

            db.Current_Qualification.Remove(current_Qualification);
            db.SaveChanges();

            return Ok(current_Qualification);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool Current_QualificationExists(long id)
        {
            return db.Current_Qualification.Count(e => e.Id == id) > 0;
        }
    }
}