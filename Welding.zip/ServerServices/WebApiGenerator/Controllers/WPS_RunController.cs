﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class WPS_RunController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/WPS_Run
        public IQueryable<WPS_Run> GetWPS_Run()
        {
            return db.WPS_Run;
        }

        // GET: api/WPS_Run/5
        [ResponseType(typeof(WPS_Run))]
        public IHttpActionResult GetWPS_Run(long id)
        {
            WPS_Run wPS_Run = db.WPS_Run.Find(id);
            if (wPS_Run == null)
            {
                return NotFound();
            }

            return Ok(wPS_Run);
        }

        // PUT: api/WPS_Run/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWPS_Run(long id, WPS_Run wPS_Run)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != wPS_Run.WPS_RunId)
            {
                return BadRequest();
            }

            db.Entry(wPS_Run).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!WPS_RunExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/WPS_Run
        [ResponseType(typeof(WPS_Run))]
        public IHttpActionResult PostWPS_Run(WPS_Run wPS_Run)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.WPS_Run.Add(wPS_Run);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = wPS_Run.WPS_RunId }, wPS_Run);
        }

        // DELETE: api/WPS_Run/5
        [ResponseType(typeof(WPS_Run))]
        public IHttpActionResult DeleteWPS_Run(long id)
        {
            WPS_Run wPS_Run = db.WPS_Run.Find(id);
            if (wPS_Run == null)
            {
                return NotFound();
            }

            db.WPS_Run.Remove(wPS_Run);
            db.SaveChanges();

            return Ok(wPS_Run);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool WPS_RunExists(long id)
        {
            return db.WPS_Run.Count(e => e.WPS_RunId == id) > 0;
        }
    }
}