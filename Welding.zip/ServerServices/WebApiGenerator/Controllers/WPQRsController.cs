﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Welding.DAL;

namespace WeldingWebApi.Controllers
{
    public class WPQRsController : ApiController
    {
        private EFWeldingManagement db = new EFWeldingManagement();

        // GET: api/WPQRs
        public IQueryable<WPQR> GetWPQRs()
        {
            return db.WPQRs;
        }

        // GET: api/WPQRs/5
        [ResponseType(typeof(WPQR))]
        public IHttpActionResult GetWPQR(long id)
        {
            WPQR wPQR = db.WPQRs.Find(id);
            if (wPQR == null)
            {
                return NotFound();
            }

            return Ok(wPQR);
        }

        // PUT: api/WPQRs/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWPQR(long id, WPQR wPQR)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != wPQR.WPQRId)
            {
                return BadRequest();
            }

            db.Entry(wPQR).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!WPQRExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/WPQRs
        [ResponseType(typeof(WPQR))]
        public IHttpActionResult PostWPQR(WPQR wPQR)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.WPQRs.Add(wPQR);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = wPQR.WPQRId }, wPQR);
        }

        // DELETE: api/WPQRs/5
        [ResponseType(typeof(WPQR))]
        public IHttpActionResult DeleteWPQR(long id)
        {
            WPQR wPQR = db.WPQRs.Find(id);
            if (wPQR == null)
            {
                return NotFound();
            }

            db.WPQRs.Remove(wPQR);
            db.SaveChanges();

            return Ok(wPQR);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool WPQRExists(long id)
        {
            return db.WPQRs.Count(e => e.WPQRId == id) > 0;
        }
    }
}