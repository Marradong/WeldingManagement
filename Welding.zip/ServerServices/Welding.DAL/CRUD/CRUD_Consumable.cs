﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static ConsumableActionResponse CreateConsumable(long datasheetId, Consumable dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new ConsumableActionResponse(success, null, "Consumable (dto) was null.");
            }

            Datasheet datasheet = _db.Datasheets.FirstOrDefault(wq => wq.DatasheetId == datasheetId);

            if (datasheet == null)
            {
                return new ConsumableActionResponse(success, null, "Datasheet not found.");
            }

            Consumable consumable = _db.Consumables.Create();
            consumable = DbDeepCopy.DeepCopy(dto, consumable);

            datasheet.Consumables.Add(consumable);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Consumables.Add(consumable);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new ConsumableActionResponse(success, consumable);
        }

        //
        // CRUD - READ
        //
        public static ConsumableActionResponse ReadConsumable(long consumableId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            Consumable consumable = _db.Consumables.FirstOrDefault(c => c.ConsumableId == consumableId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new ConsumableActionResponse(consumable != null, consumable);
        }

        //
        // CRUD - READS
        //
        public static ConsumablesActionResponse ReadConsumables(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<Consumable> consumables = _db.Consumables.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new ConsumablesActionResponse(consumables != null, consumables);
        }

        //
        // CRUD - UPDATE
        //
        public static ConsumableActionResponse UpdateConsumable(long consumableId, Consumable dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new ConsumableActionResponse(success, null, "Consumable (dto) was null.");
            }

            Consumable existingConsumable = _db.Consumables.FirstOrDefault(c => c.ConsumableId == consumableId);

            if (existingConsumable == null)
            {
                return new ConsumableActionResponse(success, null, "Consumable not found.");
            }

            existingConsumable = DbDeepCopy.DeepCopy(dto, existingConsumable);
            
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingConsumable).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new ConsumableActionResponse(success, existingConsumable);
        }

        //
        // CRUD - DELETE
        //
        public static ConsumableActionResponse DeleteConsumable(long consumableId, EFWeldingManagement _db)
        {
            bool success = false;

            Consumable deleteConsumable = _db.Consumables.Find(consumableId);

            if (deleteConsumable == null)
            {
                return new ConsumableActionResponse(success, null, "Consumable not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Consumables.Remove(deleteConsumable);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new ConsumableActionResponse(success, null);
        }

        public class ConsumableActionResponse : ActionResponse
        {
            public Consumable Consumable { get; }

            public ConsumableActionResponse(bool success, Consumable consumable, string errorMessage = null) : base(success, errorMessage)
            {
                Consumable = consumable;
            }
        }

        public class ConsumablesActionResponse : ActionResponse
        {
            public List<Consumable> Consumables { get; }

            public ConsumablesActionResponse(bool success, List<Consumable> consumables, string errorMessage = null) : base(success, errorMessage)
            {
                Consumables = consumables;
            }
        }
    }


    //TESTS
    // Run Console - Automated via Units tests

    // 1. CREATE = READ

    // POCO - Plain old C Objects Db <-> Ui
    // Manual bind to Poco for Winform

    // ----------- NOT THIS
    // Modern Databinding  (XAML/WPF/WinUi etc) Db <-> Ui
    //Winform does not support INotify or IPublish 

    // MvvM
    // Mvp

}
