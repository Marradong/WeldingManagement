﻿using Bogus;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static AttachmentActionResponse CreateAttachment(Attachment dto, string linkObjType, long linkObjId, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new AttachmentActionResponse(success, null, "Attachment (dto) was null.");
            }

            Attachment attachment = _db.Attachments.Create();
            attachment = DbDeepCopy.DeepCopy(dto, attachment);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            if (linkObjType == typeof(NewWeldingForm).Name)
            {
                NewWeldingForm nwf = _db.NewWeldingForms.FirstOrDefault(nw => nw.NewWeldingFormId == linkObjId);

                if (nwf != null)
                {
                    nwf.Attachments.Add(attachment);
                }
                else
                {
                    return new AttachmentActionResponse(success, null, "NewWeldingForm not found.");
                }
            }
            else if (linkObjType == typeof(Datasheet).Name)
            {
                Datasheet datasheet = _db.Datasheets.FirstOrDefault(d => d.DatasheetId == linkObjId);

                if (datasheet != null)
                {
                    datasheet.Attachments.Add(attachment);
                }
                else
                {
                    return new AttachmentActionResponse(success, null, "Datasheet not found.");
                }
            }
            else if (linkObjType == typeof(Welder_Qualification).Name)
            {
                Welder_Qualification welderQual = _db.Welder_Qualification.FirstOrDefault(wq => wq.Welder_QualificationId == linkObjId);

                if (welderQual != null)
                {
                    welderQual.Attachments.Add(attachment);
                }
                else
                {
                    return new AttachmentActionResponse(success, null, "Welder_Qualification not found.");
                }
            }
            else if (linkObjType == typeof(WPQR).Name)
            {
                WPQR wpqr = _db.WPQRs.FirstOrDefault(w => w.WPQRId == linkObjId);

                if (wpqr != null)
                {
                    wpqr.Attachments.Add(attachment);
                }
                else
                {
                    return new AttachmentActionResponse(success, null, "WPQR not found.");
                }
            }
            else if (linkObjType == typeof(WPS).Name)
            {
                WPS wps = _db.WPS.FirstOrDefault(w => w.WPSId == linkObjId);

                if (wps != null)
                {
                    wps.Attachments.Add(attachment);
                }
                else
                {
                    return new AttachmentActionResponse(success, null, "WPS not found.");
                }
            }

            _db.Attachments.Add(attachment);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new AttachmentActionResponse(success, attachment);
        }

        //
        // CRUD - READ
        //
        public static AttachmentActionResponse ReadAttachment(long attachmentId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            Attachment attachment = _db.Attachments.FirstOrDefault(c => c.AttachmentId == attachmentId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new AttachmentActionResponse(attachment != null, attachment);
        }

        //
        // CRUD - READS
        //
        public static AttachmentsActionResponse ReadAttachments(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<Attachment> attachments = _db.Attachments.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new AttachmentsActionResponse(attachments != null, attachments);
        }

        //
        // CRUD - UPDATE
        //
        public static AttachmentActionResponse UpdateAttachment(long attachmentId, Attachment dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            Attachment existingAttachment = _db.Attachments.FirstOrDefault(c => c.AttachmentId == attachmentId);

            if (existingAttachment == null)
            {
                return new AttachmentActionResponse(success, null, "Attachment not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            existingAttachment = DbDeepCopy.DeepCopy(dto, existingAttachment);

            _db.Entry(existingAttachment).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new AttachmentActionResponse(success, existingAttachment);
        }

        //
        // CRUD - DELETE
        //
        public static AttachmentActionResponse DeleteAttachment(long attachmentId, EFWeldingManagement _db)
        {
            bool success = false;

            Attachment deleteAttachment = _db.Attachments.Find(attachmentId);

            if (deleteAttachment == null)
            {
                return new AttachmentActionResponse(success, null, "Attachment not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Attachments.Remove(deleteAttachment);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new AttachmentActionResponse(success, null);
        }

        public class AttachmentActionResponse : ActionResponse
        {
            public Attachment Attachment { get; }

            public AttachmentActionResponse(bool success, Attachment attachment, string errorMessage = null) : base(success, errorMessage)
            {
                Attachment = attachment;
            }
        }

        public class AttachmentsActionResponse : ActionResponse
        {
            public List<Attachment> Attachments { get; }

            public AttachmentsActionResponse(bool success, List<Attachment> attachments, string errorMessage = null) : base(success, errorMessage)
            {
                Attachments = attachments;
            }
        }
    }
}
