﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static WPQRNumberListActionResponse CreateWPQRNumberList(long operationReviewId, WPQRNumberList dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WPQRNumberListActionResponse(success, null, "WPQRNumberList (dto) was null.");
            }

            OperationalReview operationalReview = _db.OperationalReviews.FirstOrDefault(wq => wq.OperationalReviewId == operationReviewId);

            if (operationalReview == null)
            {
                return new WPQRNumberListActionResponse(success, null, "OperationalReview not found.");
            }

            WPQRNumberList wpqrNumber = _db.WPQRNumberLists.Create();
            wpqrNumber = DbDeepCopy.DeepCopy(dto, wpqrNumber);

            operationalReview.WPQRNumberLists.Add(wpqrNumber);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WPQRNumberLists.Add(wpqrNumber);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPQRNumberListActionResponse(success, wpqrNumber);
        }

        //
        // CRUD - READ
        //
        public static WPQRNumberListActionResponse ReadWPQRNumberList(long wpqrNumberId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            WPQRNumberList wpqrNumber = _db.WPQRNumberLists.FirstOrDefault(d => d.Id == wpqrNumberId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WPQRNumberListActionResponse(wpqrNumber != null, wpqrNumber);
        }

        //
        // CRUD - READS
        //
        public static WPQRNumberListsActionResponse ReadWPQRNumberLists(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<WPQRNumberList> wpqrNumbers = _db.WPQRNumberLists.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WPQRNumberListsActionResponse(wpqrNumbers != null, wpqrNumbers);
        }

        //
        // CRUD - UPDATE
        //
        public static WPQRNumberListActionResponse UpdateWPQRNumberList(long wpqrNumberId, WPQRNumberList dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WPQRNumberListActionResponse(success, null, "WPQRNumberList (dto) was null.");
            }

            WPQRNumberList existingWPQRNumberList = _db.WPQRNumberLists.FirstOrDefault(d => d.Id == wpqrNumberId);

            if (existingWPQRNumberList == null)
            {
                return new WPQRNumberListActionResponse(success, null, "WPQRNumberList not found.");
            }

            existingWPQRNumberList = DbDeepCopy.DeepCopy(dto, existingWPQRNumberList);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingWPQRNumberList).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPQRNumberListActionResponse(true, existingWPQRNumberList);
        }

        //
        // CRUD - DELETE
        //
        public static WPQRNumberListActionResponse DeleteWPQRNumberList(long wpqrNumberId, EFWeldingManagement _db)
        {
            bool success = false;

            WPQRNumberList deleteWPQRNumberList = _db.WPQRNumberLists.Find(wpqrNumberId);

            if (deleteWPQRNumberList == null)
            {
                return new WPQRNumberListActionResponse(success, null, "WPQRNumberList not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WPQRNumberLists.Remove(deleteWPQRNumberList);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPQRNumberListActionResponse(success, null);
        }

        //
        // CRUD - DELETE
        //
        public static WPQRNumberListActionResponse DeleteWPQRNumberLists(long operationalReviewId, EFWeldingManagement _db)
        {
            bool success = false;

            OperationalReview operationalReview = _db.OperationalReviews.Find(operationalReviewId);

            if (operationalReview == null)
            {
                return new WPQRNumberListActionResponse(success, null, "OperationalReview not found.");
            }

            foreach (WPQRNumberList wpqrNumber in operationalReview.WPQRNumberLists)
            {
                _db.WPQRNumberLists.Remove(wpqrNumber);
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPQRNumberListActionResponse(success, null);
        }

        public class WPQRNumberListActionResponse : ActionResponse
        {
            public WPQRNumberList WPQRNumberList { get; }

            public WPQRNumberListActionResponse(bool success, WPQRNumberList wpqrNumber, string errorMessage = null) : base(success, errorMessage)
            {
                WPQRNumberList = wpqrNumber;
            }
        }

        public class WPQRNumberListsActionResponse : ActionResponse
        {
            public List<WPQRNumberList> WPQRNumberLists { get; }

            public WPQRNumberListsActionResponse(bool success, List<WPQRNumberList> wpqrNumbers, string errorMessage = null) : base(success, errorMessage)
            {
                WPQRNumberLists = wpqrNumbers;
            }
        }
    }
}
