﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static NDTRecordActionResponse CreateNDTRecord(long wpsId, NDT_Record dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new NDTRecordActionResponse(success, null, "NDT_Record (dto) was null.");
            }

            WPS wps = _db.WPS.FirstOrDefault(wq => wq.WPSId == wpsId);

            if (wps == null)
            {
                return new NDTRecordActionResponse(success, null, "WPS not found.");
            }

            NDT_Record ndtRecord = _db.NDT_Record.Create();
            ndtRecord = DbDeepCopy.DeepCopy(dto, ndtRecord);

            wps.NDT_Record.Add(ndtRecord);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.NDT_Record.Add(ndtRecord);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new NDTRecordActionResponse(success, ndtRecord);
        }

        //
        // CRUD - READ
        //
        public static NDTRecordActionResponse ReadNDTRecord(long ndtRecordId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            NDT_Record ndtRecord = _db.NDT_Record.FirstOrDefault(nr => nr.NDT_RecordId == ndtRecordId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new NDTRecordActionResponse(ndtRecord != null, ndtRecord);
        }

        //
        // CRUD - READS
        //
        public static NDTRecordsActionResponse ReadNDTRecords(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<NDT_Record> ndtRecords = _db.NDT_Record.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new NDTRecordsActionResponse(ndtRecords != null, ndtRecords);
        }

        //
        // CRUD - UPDATE
        //
        public static NDTRecordActionResponse UpdateNDTRecord(long ndtRecordId, NDT_Record dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new NDTRecordActionResponse(success, null, "NDT_Record (dto) was null.");
            }

            NDT_Record existingNDT_Record = _db.NDT_Record.FirstOrDefault(nr => nr.NDT_RecordId == ndtRecordId);

            if (existingNDT_Record == null)
            {
                return new NDTRecordActionResponse(success, null, "NDT Record not found.");
            }

            existingNDT_Record = DbDeepCopy.DeepCopy(dto, existingNDT_Record);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingNDT_Record).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new NDTRecordActionResponse(success, existingNDT_Record);
        }

        //
        // CRUD - DELETE
        //
        public static NDTRecordActionResponse DeleteNDTRecord(long ndtRecordId, EFWeldingManagement _db)
        {
            bool success = false;

            NDT_Record deleteNDT_Record = _db.NDT_Record.Find(ndtRecordId);

            if (deleteNDT_Record == null)
            {
                return new NDTRecordActionResponse(success, null, "NDT Record not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.NDT_Record.Remove(deleteNDT_Record);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new NDTRecordActionResponse(success, null);
        }

        public class NDTRecordActionResponse : ActionResponse
        {
            public NDT_Record NDT_Record { get; }

            public NDTRecordActionResponse(bool success, NDT_Record NDTRecord, string errorMessage = null) : base(success, errorMessage)
            {
                NDT_Record = NDTRecord;
            }
        }

        public class NDTRecordsActionResponse : ActionResponse
        {
            public List<NDT_Record> NDT_Records { get; }

            public NDTRecordsActionResponse(bool success, List<NDT_Record> NDTRecords, string errorMessage = null) : base(success, errorMessage)
            {
                NDT_Records = NDTRecords;
            }
        }
    }
}
