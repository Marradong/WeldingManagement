﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.CRUD;

namespace Welding.DAL
{
    public partial class CRUD
    {
        ////
        //// CRUD - CREATE
        ////
        //public static CurrentQualificationActionResponse CreateCurrentQualification(Current_Qualification currentQual)
        //{
        //    if (currentQual == null)
        //    {
        //        throw new ArgumentNullException(nameof(currentQual));
        //    }

        //    using (EFWeldingManagement db = new EFWeldingManagement())
        //    {  
        //        db.Current_Qualification.Add(currentQual);
        //        db.SaveChanges();
        //    }
        //    return new CurrentQualificationActionResponse(true, currentQual);
        //}

        ////
        //// CRUD - READ 
        ////
        //static public CurrentQualificationActionResponse ReadCurrentQualification(long currentQualId)
        //{
        //    Current_Qualification currentQual = null;
        //    using (EFWeldingManagement db = new EFWeldingManagement())
        //    {
        //        currentQual = db.Current_Qualification.AsNoTracking().FirstOrDefault(cq => cq.Id == currentQualId);
        //    }
        //    return new CurrentQualificationActionResponse(currentQual != null, currentQual);
        //}

        ////
        //// CRUD - UPDATE
        ////
        //public static CurrentQualificationActionResponse UpdateCurrentQualification(Current_Qualification currentQual)
        //{
        //    if (currentQual == null)
        //    {
        //        throw new ArgumentNullException(nameof(currentQual));
        //    }

        //    using (EFWeldingManagement db = new EFWeldingManagement())
        //    {
        //        Current_Qualification existingCurrentQual = db.Current_Qualification.Find(currentQual.Id);
        //        if (existingCurrentQual == null)
        //        {
        //            return new CurrentQualificationActionResponse(false, null, "Current Qualification not found.");
        //        }

        //        db.Entry(currentQual).State = EntityState.Modified;
        //        db.SaveChanges();
        //    }
        //    return new CurrentQualificationActionResponse(true, currentQual);
        //}

        ////
        //// CRUD - DELETE
        ////
        //public static CurrentQualificationActionResponse DeleteCurrentQualification(long currentQualId)
        //{
        //    using (EFWeldingManagement db = new EFWeldingManagement())
        //    {
        //        Current_Qualification deleteCurrentQual = db.Current_Qualification.Find(currentQualId);
        //        if (deleteCurrentQual == null)
        //        {
        //            return new CurrentQualificationActionResponse(false, null, "Current Qualification not found.");
        //        }

        //        db.Current_Qualification.Remove(deleteCurrentQual);
        //        db.SaveChanges();
        //    }
        //    return new CurrentQualificationActionResponse(true, null);
        //}

        //public class CurrentQualificationActionResponse : ActionResponse
        //{
        //    public Current_Qualification Current_Qualification { get; }

        //    public CurrentQualificationActionResponse(bool success, Current_Qualification currentQual, string errorMessage = null) : base(success, errorMessage)
        //    {
        //        Current_Qualification = currentQual;
        //    }
        //}
    }
}
