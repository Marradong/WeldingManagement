﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static WPSRunActionResponse CreateWPSRun(long wpsId, WPS_Run dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WPSRunActionResponse(success, null, "WPS_Run (dto) was null.");
            }

            WPS wps = _db.WPS.FirstOrDefault(wq => wq.WPSId == wpsId);

            if (wps == null)
            {
                return new WPSRunActionResponse(success, null, "WPS not found.");
            }

            WPS_Run wpsRun = _db.WPS_Run.Create();
            wpsRun = DbDeepCopy.DeepCopy(dto, wpsRun);

            wps.WPS_Run.Add(wpsRun);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WPS_Run.Add(wpsRun);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPSRunActionResponse(success, wpsRun);
        }

        //
        // CRUD - READ
        //
        public static WPSRunActionResponse ReadWPSRun(long wpsRunId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            WPS_Run wpsRun = _db.WPS_Run.FirstOrDefault(wr => wr.WPS_RunId == wpsRunId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WPSRunActionResponse(wpsRun != null, wpsRun);
        }

        //
        // CRUD - READS
        //
        public static WPSRunsActionResponse ReadWPSRuns(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<WPS_Run> wpsRuns = _db.WPS_Run.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WPSRunsActionResponse(wpsRuns != null, wpsRuns);
        }

        //
        // CRUD - UPDATE
        //
        public static WPSRunActionResponse UpdateWPSRun(long wpsRunId, WPS_Run dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WPSRunActionResponse(success, null, "WPS_Run (dto) was null.");
            }

            WPS_Run existingWPSRun = _db.WPS_Run.FirstOrDefault(wr => wr.WPS_RunId == wpsRunId);

            if (existingWPSRun == null)
            {
                return new WPSRunActionResponse(success, null, "WPS_Run not found.");
            }

            existingWPSRun = DbDeepCopy.DeepCopy(dto, existingWPSRun);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingWPSRun).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPSRunActionResponse(true, existingWPSRun);
        }

        //
        // CRUD - DELETE
        //
        public static WPSRunActionResponse DeleteWPSRun(long wpsRunId, EFWeldingManagement _db)
        {
            bool success = false;

            WPS_Run deleteWPSRun = _db.WPS_Run.Find(wpsRunId);
            
            if (deleteWPSRun == null)
            {
                return new WPSRunActionResponse(success, null, "WPSRun not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WPS_Run.Remove(deleteWPSRun);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPSRunActionResponse(success, null);
        }

        public class WPSRunActionResponse : ActionResponse
        {
            public WPS_Run WPS_Run { get; }

            public WPSRunActionResponse(bool success, WPS_Run wpsRun, string errorMessage = null) : base(success, errorMessage)
            {
                WPS_Run = wpsRun;
            }
        }

        public class WPSRunsActionResponse : ActionResponse
        {
            public List<WPS_Run> WPS_Runs { get; }

            public WPSRunsActionResponse(bool success, List<WPS_Run> wpsRuns, string errorMessage = null) : base(success, errorMessage)
            {
                WPS_Runs = wpsRuns;
            }
        }
    }
}
