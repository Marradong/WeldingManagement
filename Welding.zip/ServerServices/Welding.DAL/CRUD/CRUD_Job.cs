﻿using Bogus;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static JobActionResponse CreateJob(Job dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new JobActionResponse(success, null, "Job (dto) was null.");
            }

            Job job = _db.Jobs.Create();
            job = DbDeepCopy.DeepCopy(dto, job);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Jobs.Add(job);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new JobActionResponse(success, job);
        }

        //
        // CRUD - CREATE
        //
        public static JobActionResponse CreateJobDefault(string quoteNumber, string managerEID, EFWeldingManagement _db)
        {
            bool success = false;

            // Create Job (root)
            Job newJob = _db.Jobs.Create();
            newJob.QuoteNumber = quoteNumber;
            newJob.ClientManagerEID = managerEID;

            _db.Jobs.Add(newJob);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);
            dbOperationStopwatch.Reset();

            // Create Default Welding Action
            WeldingAction defaultAction = _db.WeldingActions.Create();
            defaultAction.Status = Actions.Open;

            // Add Welding Action to job
            newJob.WeldingActions.Add(defaultAction);

            _db.WeldingActions.Add(defaultAction);

            dbOperationStopwatch.Start();
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);
            dbOperationStopwatch.Reset();

            NewWeldingForm nwf = new NewWeldingForm(defaultAction.WeldingActionId, defaultAction);
            nwf.Status = Actions.WeldingMatrix;

            _db.NewWeldingForms.Add(nwf);

            dbOperationStopwatch.Start();
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);
            dbOperationStopwatch.Reset();

            return new JobActionResponse(success, newJob);
        }

        //
        // CRUD - READ
        //
        public static JobActionResponse ReadJob(long jobId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            Job job = _db.Jobs.FirstOrDefault(c => c.JobId == jobId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");
            
            return new JobActionResponse(job != null, job);
        }

        //
        // CRUD - READS
        //
        public static JobsActionResponse ReadJobs(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<Job> jobs = _db.Jobs.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new JobsActionResponse(jobs != null, jobs);
        }

        //
        // CRUD - UPDATE
        //
        public static JobActionResponse UpdateJob(long jobId, Job dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new JobActionResponse(success, null, "Job (dto) was null.");
            }

            Job existingJob = _db.Jobs.FirstOrDefault(c => c.JobId == jobId);

            if (existingJob == null)
            {
                return new JobActionResponse(success, null, "Job not found.");
            }

            existingJob = DbDeepCopy.DeepCopy(dto, existingJob);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingJob).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new JobActionResponse(success, existingJob);
        }

        //
        // CRUD - DELETE
        //
        public static JobActionResponse DeleteJob(long jobId, EFWeldingManagement _db)
        {
            bool success = false;

            Job deleteJob = _db.Jobs.Find(jobId);

            if (deleteJob == null)
            {
                return new JobActionResponse(success, null, "Job not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Jobs.Remove(deleteJob);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new JobActionResponse(success, null);
        }

        public class JobActionResponse : ActionResponse
        {
            public Job Job { get; }

            public JobActionResponse(bool success, Job job, string errorMessage = null) : base(success, errorMessage)
            {
                Job = job;
            }
        }

        public class JobsActionResponse : ActionResponse
        {
            public List<Job> Jobs { get; }

            public JobsActionResponse(bool success, List<Job> jobs, string errorMessage = null) : base(success, errorMessage)
            {
                Jobs = jobs;
            }
        }
    }
}
