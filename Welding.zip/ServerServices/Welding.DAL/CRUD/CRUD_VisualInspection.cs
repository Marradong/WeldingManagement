﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static VisualInspectionActionResponse CreateVisualInspection(long welderQualId, Visual_Inspection dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new VisualInspectionActionResponse(success, null, "Visual_Inspection (dto) was null.");
            }

            Welder_Qualification welderQual = _db.Welder_Qualification.FirstOrDefault(wq => wq.Welder_QualificationId == welderQualId);

            if (welderQual == null)
            {
                return new VisualInspectionActionResponse(success, null, "Welder_Qualification not found.");
            }

            Visual_Inspection visualInspection = _db.Visual_Inspection.Create();
            visualInspection = DbDeepCopy.DeepCopy(dto, visualInspection);

            visualInspection.Visual_InspectionId = welderQual.Welder_QualificationId;
            welderQual.Visual_Inspection = visualInspection;

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Visual_Inspection.Add(visualInspection);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new VisualInspectionActionResponse(success, visualInspection);
        }

        //
        // CRUD - READ
        //
        public static VisualInspectionActionResponse ReadVisualInspection(long visualInspectionId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            Visual_Inspection visualInspection = _db.Visual_Inspection.FirstOrDefault(vi => vi.Visual_InspectionId == visualInspectionId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new VisualInspectionActionResponse(visualInspection != null, visualInspection);
        }

        //
        // CRUD - READS
        //
        public static VisualInspectionsActionResponse ReadVisualInspections(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<Visual_Inspection> visualInspections = _db.Visual_Inspection.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new VisualInspectionsActionResponse(visualInspections != null, visualInspections);
        }

        //
        // CRUD - UPDATE
        //
        public static VisualInspectionActionResponse UpdateVisualInspection(long visualInspectionId, Visual_Inspection dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new VisualInspectionActionResponse(success, null, "Visual_Inspection (dto) was null.");
            }

            Visual_Inspection existingVisualInspection = _db.Visual_Inspection.FirstOrDefault(vi => vi.Visual_InspectionId == visualInspectionId);

            if (existingVisualInspection == null)
            {
                return new VisualInspectionActionResponse(success, null, "Visual Inspection not found.");
            }

            existingVisualInspection = DbDeepCopy.DeepCopy(dto, existingVisualInspection);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingVisualInspection).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new VisualInspectionActionResponse(true, existingVisualInspection);
        }

        //
        // CRUD - DELETE
        //
        public static VisualInspectionActionResponse DeleteVisualInspection(long visualInspectionId, EFWeldingManagement _db)
        {
            bool success = false;

            Visual_Inspection deleteVisualInspection = _db.Visual_Inspection.Find(visualInspectionId);
            
            if (deleteVisualInspection == null)
            {
                return new VisualInspectionActionResponse(success, null, "Visual Inspection not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Visual_Inspection.Remove(deleteVisualInspection);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new VisualInspectionActionResponse(success, null);
        }

        public class VisualInspectionActionResponse : ActionResponse
        {
            public Visual_Inspection Visual_Inspection { get; }

            public VisualInspectionActionResponse(bool success, Visual_Inspection visualInspection, string errorMessage = null) : base(success, errorMessage)
            {
                Visual_Inspection = visualInspection;
            }
        }

        public class VisualInspectionsActionResponse : ActionResponse
        {
            public List<Visual_Inspection> Visual_Inspections { get; }

            public VisualInspectionsActionResponse(bool success, List<Visual_Inspection> visualInspections, string errorMessage = null) : base(success, errorMessage)
            {
                Visual_Inspections = visualInspections;
            }
        }
    }
}
