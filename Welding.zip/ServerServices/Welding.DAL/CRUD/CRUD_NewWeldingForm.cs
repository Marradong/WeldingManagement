﻿using Bogus;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static NewWeldingFormActionResponse CreateNewWeldingForm(long weldingActionId, NewWeldingForm dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new NewWeldingFormActionResponse(success, null, "NewWeldingForm (dto) was null.");
            }

            WeldingAction linkedAction = _db.WeldingActions.FirstOrDefault(c => c.WeldingActionId == weldingActionId);

            if (linkedAction == null)
            {
                return new NewWeldingFormActionResponse(success, null, "WeldingAction not found.");
            }

            NewWeldingForm newWeldingForm = _db.NewWeldingForms.Create();
            newWeldingForm = DbDeepCopy.DeepCopy(dto, newWeldingForm);
            
            newWeldingForm.NewWeldingFormId = linkedAction.WeldingActionId;
            linkedAction.NewWeldingForm = newWeldingForm;

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.NewWeldingForms.Add(newWeldingForm);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new NewWeldingFormActionResponse(success, newWeldingForm);
        }

        //
        // CRUD - READ
        //
        public static NewWeldingFormActionResponse ReadNewWeldingForm(long newWeldingFormId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            NewWeldingForm newWeldingForm = _db.NewWeldingForms.FirstOrDefault(nwf => nwf.NewWeldingFormId == newWeldingFormId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new NewWeldingFormActionResponse(newWeldingForm != null, newWeldingForm);
        }

        //
        // CRUD - READS
        //
        public static NewWeldingFormsActionResponse ReadNewWeldingForms(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<NewWeldingForm> newWeldingForms = _db.NewWeldingForms.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new NewWeldingFormsActionResponse(newWeldingForms != null, newWeldingForms);
        }

        //
        // CRUD - UPDATE
        //
        public static NewWeldingFormActionResponse UpdateNewWeldingForm(long newWeldingFormId, NewWeldingForm dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new NewWeldingFormActionResponse(success, null, "NewWeldingForm (dto) was null.");
            }

            NewWeldingForm existingNewWeldingForm = _db.NewWeldingForms.FirstOrDefault(nwf => nwf.NewWeldingFormId == newWeldingFormId);

            if (existingNewWeldingForm == null)
            {
                return new NewWeldingFormActionResponse(success, null, "New Welding Form not found.");
            }

            existingNewWeldingForm = DbDeepCopy.DeepCopy(dto, existingNewWeldingForm);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingNewWeldingForm).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new NewWeldingFormActionResponse(success, existingNewWeldingForm);
        }

        //
        // CRUD - DELETE
        //
        public static NewWeldingFormActionResponse DeleteNewWeldingForm(long newWeldingFormId, EFWeldingManagement _db)
        {
            bool success = false;

            NewWeldingForm deleteNewWeldingForm = _db.NewWeldingForms.Find(newWeldingFormId);
            
            if (deleteNewWeldingForm == null)
            {
                return new NewWeldingFormActionResponse(success, null, "New Welding Form not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.NewWeldingForms.Remove(deleteNewWeldingForm);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new NewWeldingFormActionResponse(success, null);
        }

        public class NewWeldingFormActionResponse : ActionResponse
        {
            public NewWeldingForm NewWeldingForm { get; }

            public NewWeldingFormActionResponse(bool success, NewWeldingForm newWeldingForm, string errorMessage = null) : base(success, errorMessage)
            {
                NewWeldingForm = newWeldingForm;
            }
        }

        public class NewWeldingFormsActionResponse : ActionResponse
        {
            public List<NewWeldingForm> NewWeldingForms { get; }

            public NewWeldingFormsActionResponse(bool success, List<NewWeldingForm> newWeldingForms, string errorMessage = null) : base(success, errorMessage)
            {
                NewWeldingForms = newWeldingForms;
            }
        }
    }
}
