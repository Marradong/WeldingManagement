﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static ENumberListActionResponse CreateENumberList(long operationReviewId, ENumberList dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new ENumberListActionResponse(success, null, "ENumberList (dto) was null.");
            }

            OperationalReview operationalReview = _db.OperationalReviews.FirstOrDefault(wq => wq.OperationalReviewId == operationReviewId);

            if (operationalReview == null)
            {
                return new ENumberListActionResponse(success, null, "OperationalReview not found.");
            }

            ENumberList employeeNumber = _db.ENumberLists.Create();
            employeeNumber = DbDeepCopy.DeepCopy(dto, employeeNumber);

            operationalReview.ENumberLists.Add(employeeNumber);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.ENumberLists.Add(employeeNumber);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new ENumberListActionResponse(success, employeeNumber);
        }

        //
        // CRUD - READ
        //
        public static ENumberListActionResponse ReadENumberList(long employeeNumberId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            ENumberList employeeNumber = _db.ENumberLists.FirstOrDefault(d => d.Id == employeeNumberId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new ENumberListActionResponse(employeeNumber != null, employeeNumber);
        }

        //
        // CRUD - READS
        //
        public static ENumberListsActionResponse ReadENumberLists(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<ENumberList> employeeNumbers = _db.ENumberLists.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new ENumberListsActionResponse(employeeNumbers != null, employeeNumbers);
        }

        //
        // CRUD - UPDATE
        //
        public static ENumberListActionResponse UpdateENumberList(long employeeNumberId, ENumberList dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new ENumberListActionResponse(success, null, "ENumberList (dto) was null.");
            }

            ENumberList existingENumberList = _db.ENumberLists.FirstOrDefault(d => d.Id == employeeNumberId);

            if (existingENumberList == null)
            {
                return new ENumberListActionResponse(success, null, "ENumberList not found.");
            }

            existingENumberList = DbDeepCopy.DeepCopy(dto, existingENumberList);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingENumberList).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new ENumberListActionResponse(true, existingENumberList);
        }

        //
        // CRUD - DELETE
        //
        public static ENumberListActionResponse DeleteENumberList(long employeeNumberId, EFWeldingManagement _db)
        {
            bool success = false;

            ENumberList deleteENumberList = _db.ENumberLists.Find(employeeNumberId);

            if (deleteENumberList == null)
            {
                return new ENumberListActionResponse(success, null, "ENumberList not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.ENumberLists.Remove(deleteENumberList);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new ENumberListActionResponse(success, null);
        }

        //
        // CRUD - DELETE
        //
        public static ENumberListActionResponse DeleteENumberLists(long operationalReviewId, EFWeldingManagement _db)
        {
            bool success = false;

            OperationalReview operationalReview = _db.OperationalReviews.Find(operationalReviewId);

            if (operationalReview == null)
            {
                return new ENumberListActionResponse(success, null, "OperationalReview not found.");
            }

            foreach (ENumberList employeeNumber in operationalReview.ENumberLists)
            {
                _db.ENumberLists.Remove(employeeNumber);
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new ENumberListActionResponse(success, null);
        }

        public class ENumberListActionResponse : ActionResponse
        {
            public ENumberList ENumberList { get; }

            public ENumberListActionResponse(bool success, ENumberList employeeNumber, string errorMessage = null) : base(success, errorMessage)
            {
                ENumberList = employeeNumber;
            }
        }

        public class ENumberListsActionResponse : ActionResponse
        {
            public List<ENumberList> ENumberLists { get; }

            public ENumberListsActionResponse(bool success, List<ENumberList> employeeNumbers, string errorMessage = null) : base(success, errorMessage)
            {
                ENumberLists = employeeNumbers;
            }
        }
    }
}
