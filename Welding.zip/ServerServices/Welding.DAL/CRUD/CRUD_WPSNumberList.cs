﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static WPSNumberListActionResponse CreateWPSNumberList(long operationReviewId, WPSNumberList dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WPSNumberListActionResponse(success, null, "WPSNumberList (dto) was null.");
            }

            OperationalReview operationalReview = _db.OperationalReviews.FirstOrDefault(wq => wq.OperationalReviewId == operationReviewId);

            if (operationalReview == null)
            {
                return new WPSNumberListActionResponse(success, null, "OperationalReview not found.");
            }

            WPSNumberList wpsNumber = _db.WPSNumberLists.Create();
            wpsNumber = DbDeepCopy.DeepCopy(dto, wpsNumber);

            operationalReview.WPSNumberLists.Add(wpsNumber);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WPSNumberLists.Add(wpsNumber);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPSNumberListActionResponse(success, wpsNumber);
        }

        //
        // CRUD - READ
        //
        public static WPSNumberListActionResponse ReadWPSNumberList(long wpsNumberId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            WPSNumberList wpsNumber = _db.WPSNumberLists.FirstOrDefault(d => d.Id == wpsNumberId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WPSNumberListActionResponse(wpsNumber != null, wpsNumber);
        }

        //
        // CRUD - READS
        //
        public static WPSNumberListsActionResponse ReadWPSNumberLists(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<WPSNumberList> wpsNumbers = _db.WPSNumberLists.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WPSNumberListsActionResponse(wpsNumbers != null, wpsNumbers);
        }

        //
        // CRUD - UPDATE
        //
        public static WPSNumberListActionResponse UpdateWPSNumberList(long wpsNumberId, WPSNumberList dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WPSNumberListActionResponse(success, null, "WPSNumberList (dto) was null.");
            }

            WPSNumberList existingWPSNumberList = _db.WPSNumberLists.FirstOrDefault(d => d.Id == wpsNumberId);

            if (existingWPSNumberList == null)
            {
                return new WPSNumberListActionResponse(success, null, "WPSNumberList not found.");
            }

            existingWPSNumberList = DbDeepCopy.DeepCopy(dto, existingWPSNumberList);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingWPSNumberList).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPSNumberListActionResponse(true, existingWPSNumberList);
        }

        //
        // CRUD - DELETE
        //
        public static WPSNumberListActionResponse DeleteWPSNumberList(long wpsNumberId, EFWeldingManagement _db)
        {
            bool success = false;

            WPSNumberList deleteWPSNumberList = _db.WPSNumberLists.Find(wpsNumberId);

            if (deleteWPSNumberList == null)
            {
                return new WPSNumberListActionResponse(success, null, "WPSNumberList not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WPSNumberLists.Remove(deleteWPSNumberList);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPSNumberListActionResponse(success, null);
        }

        //
        // CRUD - DELETE
        //
        public static WPSNumberListActionResponse DeleteWPSNumberLists(long operationalReviewId, EFWeldingManagement _db)
        {
            bool success = false;

            OperationalReview operationalReview = _db.OperationalReviews.Find(operationalReviewId);

            if (operationalReview == null)
            {
                return new WPSNumberListActionResponse(success, null, "OperationalReview not found.");
            }

            foreach (WPSNumberList wpsNumber in operationalReview.WPSNumberLists)
            {
                _db.WPSNumberLists.Remove(wpsNumber);
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPSNumberListActionResponse(success, null);
        }

        public class WPSNumberListActionResponse : ActionResponse
        {
            public WPSNumberList WPSNumberList { get; }

            public WPSNumberListActionResponse(bool success, WPSNumberList wpsNumber, string errorMessage = null) : base(success, errorMessage)
            {
                WPSNumberList = wpsNumber;
            }
        }

        public class WPSNumberListsActionResponse : ActionResponse
        {
            public List<WPSNumberList> WPSNumberLists { get; }

            public WPSNumberListsActionResponse(bool success, List<WPSNumberList> wpsNumbers, string errorMessage = null) : base(success, errorMessage)
            {
                WPSNumberLists = wpsNumbers;
            }
        }
    }
}
