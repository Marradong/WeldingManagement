﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static WelderQualificationActionResponse CreateWelderQualification(long weldingActionId, Welder_Qualification dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WelderQualificationActionResponse(success, null, "Welder_Qualification (dto) was null.");
            }

            WeldingAction weldingAction = _db.WeldingActions.FirstOrDefault(wq => wq.WeldingActionId == weldingActionId);

            if (weldingAction == null)
            {
                return new WelderQualificationActionResponse(success, null, "WeldingAction not found.");
            }

            Welder_Qualification welderQual = _db.Welder_Qualification.Create();
            welderQual = DbDeepCopy.DeepCopy(dto, welderQual);

            weldingAction.Welder_Qualification.Add(welderQual);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Welder_Qualification.Add(welderQual);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WelderQualificationActionResponse(success, welderQual);
        }

        //
        // CRUD - READ
        //
        public static WelderQualificationActionResponse ReadWelderQualification(long welderQualId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            Welder_Qualification welderQual = _db.Welder_Qualification.FirstOrDefault(wq => wq.Welder_QualificationId == welderQualId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WelderQualificationActionResponse(welderQual != null, welderQual);
        }

        //
        // CRUD - READS
        //
        public static WelderQualificationsActionResponse ReadWelderQualifications(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<Welder_Qualification> welderQuals = _db.Welder_Qualification.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WelderQualificationsActionResponse(welderQuals != null, welderQuals);
        }

        //
        // CRUD - UPDATE
        //
        public static WelderQualificationActionResponse UpdateWelderQualification(long welderQualId, Welder_Qualification dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WelderQualificationActionResponse(success, null, "Welder_Qualification (dto) was null.");
            }

            Welder_Qualification existingWelderQualification = _db.Welder_Qualification.FirstOrDefault(wq => wq.Welder_QualificationId == welderQualId);

            if (existingWelderQualification == null)
            {
                return new WelderQualificationActionResponse(success, null, "Welder Qualification not found.");
            }

            existingWelderQualification = DbDeepCopy.DeepCopy(dto, existingWelderQualification);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingWelderQualification).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WelderQualificationActionResponse(success, existingWelderQualification);
        }

        //
        // CRUD - DELETE
        //
        public static WelderQualificationActionResponse DeleteWelderQualification(long welderQualId, EFWeldingManagement _db)
        {
            bool success = false;

            Welder_Qualification deleteWelderQualification = _db.Welder_Qualification.Find(welderQualId);
            
            if (deleteWelderQualification == null)
            {
                return new WelderQualificationActionResponse(success, null, "Welder Qualification not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Welder_Qualification.Remove(deleteWelderQualification);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WelderQualificationActionResponse(success, null);
        }

        public class WelderQualificationActionResponse : ActionResponse
        {
            public Welder_Qualification Welder_Qualification { get; }

            public WelderQualificationActionResponse(bool success, Welder_Qualification welderQual, string errorMessage = null) : base(success, errorMessage)
            {
                Welder_Qualification = welderQual;
            }
        }

        public class WelderQualificationsActionResponse : ActionResponse
        {
            public List<Welder_Qualification> Welder_Qualifications { get; }

            public WelderQualificationsActionResponse(bool success, List<Welder_Qualification> welderQuals, string errorMessage = null) : base(success, errorMessage)
            {
                Welder_Qualifications = welderQuals;
            }
        }
    }
}
