﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static OperationalReviewActionResponse CreateOperationalReview(long nwfId, OperationalReview dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new OperationalReviewActionResponse(success, null, "OperationalReview (dto) was null.");
            }

            NewWeldingForm newWeldingForm = _db.NewWeldingForms.FirstOrDefault(c => c.NewWeldingFormId == nwfId);

            if (newWeldingForm == null)
            {
                return new OperationalReviewActionResponse(success, null, "NewWeldingForm not found.");
            }

            OperationalReview operationalReview = _db.OperationalReviews.Create();
            operationalReview = DbDeepCopy.DeepCopy(dto, operationalReview);

            operationalReview.OperationalReviewId = newWeldingForm.NewWeldingFormId;

            newWeldingForm.OperationalReview = operationalReview;

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.OperationalReviews.Add(operationalReview);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new OperationalReviewActionResponse(success, operationalReview);
        }

        //
        // CRUD - READ
        //
        public static OperationalReviewActionResponse ReadOperationalReview(long operationalReviewId,EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            OperationalReview operationalReview = _db.OperationalReviews.FirstOrDefault(or => or.OperationalReviewId == operationalReviewId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new OperationalReviewActionResponse(operationalReview != null, operationalReview);
        }

        //
        // CRUD - READS
        //
        public static OperationalReviewsActionResponse ReadOperationalReviews(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<OperationalReview> operationalReviews = _db.OperationalReviews.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new OperationalReviewsActionResponse(operationalReviews != null, operationalReviews);
        }

        //
        // CRUD - UPDATE
        //
        public static OperationalReviewActionResponse UpdateOperationalReview(long operationalReviewId, OperationalReview dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new OperationalReviewActionResponse(success, null, "OperationalReview (dto) was null.");
            }

            OperationalReview existingOperationalReview = _db.OperationalReviews.FirstOrDefault(or => or.OperationalReviewId == operationalReviewId);

            if (existingOperationalReview == null)
            {
                return new OperationalReviewActionResponse(success, null, "Operational Review not found.");
            }

            existingOperationalReview = DbDeepCopy.DeepCopy(dto, existingOperationalReview);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingOperationalReview).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new OperationalReviewActionResponse(true, existingOperationalReview);
        }

        //
        // CRUD - DELETE
        //
        public static OperationalReviewActionResponse DeleteOperationalReview(long operationalReviewId, EFWeldingManagement _db)
        {
            bool success = false;

            OperationalReview deleteOperationalReview = _db.OperationalReviews.Find(operationalReviewId);
            
            if (deleteOperationalReview == null)
            {
                return new OperationalReviewActionResponse(success, null, "Operational Review not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.OperationalReviews.Remove(deleteOperationalReview);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new OperationalReviewActionResponse(success, null);
        }

        public class OperationalReviewActionResponse : ActionResponse
        {
            public OperationalReview OperationalReview { get; }

            public OperationalReviewActionResponse(bool success, OperationalReview operationalReview, string errorMessage = null) : base(success, errorMessage)
            {
                OperationalReview = operationalReview;
            }
        }

        public class OperationalReviewsActionResponse : ActionResponse
        {
            public List<OperationalReview> OperationalReviews { get; }

            public OperationalReviewsActionResponse(bool success, List<OperationalReview> operationalReviews, string errorMessage = null) : base(success, errorMessage)
            {
                OperationalReviews = operationalReviews;
            }
        }
    }
}
