﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static DatasheetActionResponse CreateDatasheet(long welderQualId, Datasheet dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new DatasheetActionResponse(success, null, "Datasheet (dto) was null.");
            }

            Welder_Qualification welderQual = _db.Welder_Qualification.FirstOrDefault(wq => wq.Welder_QualificationId == welderQualId);

            if (welderQual == null)
            {
                return new DatasheetActionResponse(success, null, "Welder_Qualification not found.");
            }

            Datasheet datasheet = _db.Datasheets.Create();
            datasheet = DbDeepCopy.DeepCopy(dto, datasheet);
            
            datasheet.DatasheetId = welderQual.Welder_QualificationId;
            welderQual.Datasheet = datasheet;

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Datasheets.Add(datasheet);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new DatasheetActionResponse(success, datasheet);
        }

        //
        // CRUD - READ
        //
        public static DatasheetActionResponse ReadDatasheet(long datasheetId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            Datasheet datasheet = _db.Datasheets.FirstOrDefault(d => d.DatasheetId == datasheetId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new DatasheetActionResponse(datasheet != null, datasheet);
        }

        //
        // CRUD - READS
        //
        public static DatasheetsActionResponse ReadDatasheets(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<Datasheet> datasheets = _db.Datasheets.ToList();
            
            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new DatasheetsActionResponse(datasheets != null, datasheets);
        }

        //
        // CRUD - UPDATE
        //
        public static DatasheetActionResponse UpdateDatasheet(long datasheetId, Datasheet dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new DatasheetActionResponse(success, null, "Datasheet (dto) was null.");
            }

            Datasheet existingDatasheet = _db.Datasheets.FirstOrDefault(d => d.DatasheetId == datasheetId);

            if (existingDatasheet == null)
            {
                return new DatasheetActionResponse(success, null, "Datasheet not found.");
            }

            existingDatasheet = DbDeepCopy.DeepCopy(dto, existingDatasheet);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingDatasheet).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new DatasheetActionResponse(true, existingDatasheet);
        }

        //
        // CRUD - DELETE
        //
        public static DatasheetActionResponse DeleteDatasheet(long datasheetId, EFWeldingManagement _db)
        {
            bool success = false;

            Datasheet deleteDatasheet = _db.Datasheets.Find(datasheetId);

            if (deleteDatasheet == null)
            {
                return new DatasheetActionResponse(success, null, "Datasheet not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Datasheets.Remove(deleteDatasheet);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new DatasheetActionResponse(success, null);
        }

        public class DatasheetActionResponse : ActionResponse
        {
            public Datasheet Datasheet { get; }

            public DatasheetActionResponse(bool success, Datasheet datasheet, string errorMessage = null) : base(success, errorMessage)
            {
                Datasheet = datasheet;
            }
        }

        public class DatasheetsActionResponse : ActionResponse
        {
            public List<Datasheet> Datasheets { get; }

            public DatasheetsActionResponse(bool success, List<Datasheet> datasheets, string errorMessage = null) : base(success, errorMessage)
            {
                Datasheets = datasheets;
            }
        }
    }
}
