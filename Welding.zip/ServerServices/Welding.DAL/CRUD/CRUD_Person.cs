﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static PersonActionResponse CreatePerson(Person dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new PersonActionResponse(success, null, "Person (dto) was null.");
            }

            Person person = _db.People.Create();
            person = DbDeepCopy.DeepCopy(dto, person);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.People.Add(person);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new PersonActionResponse(success, person);
        }

        //
        // CRUD - READ
        //
        public static PersonActionResponse ReadPerson(long personId, EFWeldingManagement _db)
        {
            Person person = _db.People.AsNoTracking().FirstOrDefault(c => c.PersonId == personId);
            return new PersonActionResponse(person != null, person);
        }

        //
        // CRUD - READ
        //
        public static PersonActionResponse ReadPerson(string ENumber, EFWeldingManagement _db)
        {
            Person person = _db.People.AsNoTracking().FirstOrDefault(c => c.EmployeeNumber == ENumber);
            return new PersonActionResponse(person != null, person);
        }

        //
        // CRUD - READS
        //
        public static PersonsActionResponse ReadPersons(EFWeldingManagement _db)
        {
            List<Person> persons = _db.People.ToList();
            return new PersonsActionResponse(persons != null, persons);
        }

        //
        // CRUD - UPDATE
        //
        public static PersonActionResponse UpdatePerson(long personId, Person dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new PersonActionResponse(success, null, "Person (dto) was null.");
            }

            Person existingPerson = _db.People.FirstOrDefault(c => c.PersonId == personId);

            if (existingPerson == null)
            {
                return new PersonActionResponse(success, null, "Person not found.");
            }

            existingPerson = DbDeepCopy.DeepCopy(dto, existingPerson);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingPerson).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new PersonActionResponse(success, existingPerson);
        }

        //
        // CRUD - DELETE
        //
        public static PersonActionResponse DeletePerson(long personId, EFWeldingManagement _db)
        {
            bool success = false;

            Person deletePerson = _db.People.Find(personId);
            
            if (deletePerson == null)
            {
                return new PersonActionResponse(success, null, "Person not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.People.Remove(deletePerson);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new PersonActionResponse(success, null);
        }

        public class PersonActionResponse : ActionResponse
        {
            public Person Person { get; }

            public PersonActionResponse(bool success, Person person, string errorMessage = null) : base(success, errorMessage)
            {
                Person = person;
            }
        }

        public class PersonsActionResponse : ActionResponse
        {
            public List<Person> Persons { get; }

            public PersonsActionResponse(bool success, List<Person> persons, string errorMessage = null) : base(success, errorMessage)
            {
                Persons = persons;
            }
        }
    }
}
