﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static WPQRActionResponse CreateWPQR(long welderQualId, WPQR dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WPQRActionResponse(success, null, "WPQR (dto) was null.");
            }

            Welder_Qualification welderQual = _db.Welder_Qualification.FirstOrDefault(wq => wq.Welder_QualificationId == welderQualId);

            if (welderQual == null)
            {
                return new WPQRActionResponse(success, null, "Welder_Qualification not found.");
            }

            WPQR wpqr = _db.WPQRs.Create();
            wpqr = DbDeepCopy.DeepCopy(dto, wpqr);

            wpqr.WPQRId = welderQual.Welder_QualificationId;
            welderQual.WPQR = wpqr;
            welderQual.WeldingAction.WPQRs.Add(wpqr);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WPQRs.Add(wpqr);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPQRActionResponse(success, wpqr);
        }

        //
        // CRUD - READ
        //
        public static WPQRActionResponse ReadWPQR(long wpqrId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            WPQR wpqr = _db.WPQRs.FirstOrDefault(w => w.WPQRId == wpqrId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WPQRActionResponse(wpqr != null, wpqr);
        }

        //
        // CRUD - READS
        //
        public static WPQRActionsResponse ReadWPQRs(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<WPQR> wpqrs = _db.WPQRs.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WPQRActionsResponse(wpqrs != null, wpqrs);
        }

        //
        // CRUD - UPDATE
        //
        public static WPQRActionResponse UpdateWPQR(long wpqrId, WPQR dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WPQRActionResponse(success, null, "WPQR (dto) was null.");
            }

            WPQR existingWPQR = _db.WPQRs.FirstOrDefault(w => w.WPQRId == wpqrId);

            if (existingWPQR == null)
            {
                return new WPQRActionResponse(success, null, "WPQR not found.");
            }

            existingWPQR = DbDeepCopy.DeepCopy(dto, existingWPQR);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingWPQR).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPQRActionResponse(success, existingWPQR);
        }

        //
        // CRUD - DELETE
        //
        public static WPQRActionResponse DeleteWPQR(long wpqrId, EFWeldingManagement _db)
        {
            bool success = false;

            WPQR deleteWPQR = _db.WPQRs.Find(wpqrId);
            
            if (deleteWPQR == null)
            {
                return new WPQRActionResponse(success, null, "WPQR not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WPQRs.Remove(deleteWPQR);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPQRActionResponse(success, null);
        }

        public class WPQRActionResponse : ActionResponse
        {
            public WPQR WPQR { get; }

            public WPQRActionResponse(bool success, WPQR wpqr, string errorMessage = null) : base(success, errorMessage)
            {
                WPQR = wpqr;
            }
        }

        public class WPQRActionsResponse : ActionResponse
        {
            public List<WPQR> WPQRs { get; }

            public WPQRActionsResponse(bool success, List<WPQR> wpqrs, string errorMessage = null) : base(success, errorMessage)
            {
                WPQRs = wpqrs;
            }
        }
    }
}
