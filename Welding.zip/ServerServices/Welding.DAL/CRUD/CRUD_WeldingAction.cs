﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static WeldingActionActionResponse CreateWeldingAction(long jobId, WeldingAction dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WeldingActionActionResponse(success, null, "WeldingAction (dto) was null.");
            }

            Job linkedJob = _db.Jobs.FirstOrDefault(c => c.JobId == jobId);

            if (linkedJob == null)
            {
                throw new ArgumentNullException(nameof(linkedJob));
            }

            WeldingAction weldingAction = _db.WeldingActions.Create();
            weldingAction = DbDeepCopy.DeepCopy(dto, weldingAction);

            linkedJob.WeldingActions.Add(weldingAction);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WeldingActions.Add(weldingAction);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WeldingActionActionResponse(success, weldingAction);
        }

        //
        // CRUD - READ
        //
        public static WeldingActionActionResponse ReadWeldingAction(long weldingActionId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            WeldingAction weldingAction = _db.WeldingActions.FirstOrDefault(c => c.WeldingActionId == weldingActionId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WeldingActionActionResponse(weldingAction != null, weldingAction);
        }

        //
        // CRUD - READS
        //
        public static WeldingActionsActionResponse ReadWeldingActions(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<WeldingAction> weldingActions = _db.WeldingActions.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WeldingActionsActionResponse(weldingActions != null, weldingActions);
        }

        //
        // CRUD - UPDATE
        //
        public static WeldingActionActionResponse UpdateWeldingAction(long weldingActionId, WeldingAction dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WeldingActionActionResponse(success, null, "WeldingAction (dto) was null.");
            }

            WeldingAction existingWeldingAction = _db.WeldingActions.FirstOrDefault(c => c.WeldingActionId == weldingActionId);

            if (existingWeldingAction == null)
            {
                return new WeldingActionActionResponse(success, null, "WeldingAction not found.");
            }

            existingWeldingAction = DbDeepCopy.DeepCopy(dto, existingWeldingAction);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingWeldingAction).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WeldingActionActionResponse(success, existingWeldingAction);
        }

        //
        // CRUD - DELETE
        //
        public static WeldingActionActionResponse DeleteWeldingAction(long weldingActionId, EFWeldingManagement _db)
        {
            bool success = false;
            
            WeldingAction deleteWeldingAction = _db.WeldingActions.Find(weldingActionId);
            
            if (deleteWeldingAction == null)
            {
                return new WeldingActionActionResponse(success, null, "Welding Action not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WeldingActions.Remove(deleteWeldingAction);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WeldingActionActionResponse(success, null);
        }

        public class WeldingActionActionResponse : ActionResponse
        {
            public WeldingAction WeldingAction { get; }

            public WeldingActionActionResponse(bool success, WeldingAction weldingAction, string errorMessage = null) : base(success, errorMessage)
            {
                WeldingAction = weldingAction;
            }
        }
        public class WeldingActionsActionResponse : ActionResponse
        {
            public List<WeldingAction> WeldingActions { get; }

            public WeldingActionsActionResponse(bool success, List<WeldingAction> weldingActions, string errorMessage = null) : base(success, errorMessage)
            {
                WeldingActions = weldingActions;
            }
        }
    }
}
