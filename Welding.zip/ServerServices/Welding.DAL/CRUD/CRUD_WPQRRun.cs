﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static WPQRRunActionResponse CreateWPQRRun(long wpqrId, WPQR_Run dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WPQRRunActionResponse(success, null, "WPQR_Run (dto) was null.");
            }

            WPQR wpqr = _db.WPQRs.FirstOrDefault(wq => wq.WPQRId == wpqrId);

            if (wpqr == null)
            {
                return new WPQRRunActionResponse(success, null, "WPQR not found.");
            }

            WPQR_Run wpqrRun = _db.WPQR_Run.Create();
            wpqrRun = DbDeepCopy.DeepCopy(dto, wpqrRun);

            wpqr.WPQR_Run.Add(wpqrRun);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WPQR_Run.Add(wpqrRun);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPQRRunActionResponse(success, wpqrRun);
        }

        //
        // CRUD - READ
        //
        public static WPQRRunActionResponse ReadWPQRRun(long wpqrRunId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            WPQR_Run wpqrRun = _db.WPQR_Run.FirstOrDefault(wr => wr.WPQR_RunId == wpqrRunId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WPQRRunActionResponse(wpqrRun != null, wpqrRun);
        }

        //
        // CRUD - READS
        //
        public static WPQRRunsActionResponse ReadWPQRRuns(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<WPQR_Run> wpqrRuns = _db.WPQR_Run.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WPQRRunsActionResponse(wpqrRuns != null, wpqrRuns);
        }

        //
        // CRUD - UPDATE
        //
        public static WPQRRunActionResponse UpdateWPQRRun(long wpqrRunId, WPQR_Run dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WPQRRunActionResponse(success, null, "WPQR_Run (dto) was null.");
            }

            WPQR_Run existingWPQRRun = _db.WPQR_Run.FirstOrDefault(wr => wr.WPQR_RunId == wpqrRunId);

            if (existingWPQRRun == null)
            {
                return new WPQRRunActionResponse(success, null, "WPQR Run not found.");
            }

            existingWPQRRun = DbDeepCopy.DeepCopy(dto, existingWPQRRun);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingWPQRRun).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPQRRunActionResponse(success, existingWPQRRun);
        }

        //
        // CRUD - DELETE
        //
        public static WPQRRunActionResponse DeleteWPQRRun(long wpqrRunId, EFWeldingManagement _db)
        {
            bool success = false;

            WPQR_Run deleteWPQRRun = _db.WPQR_Run.Find(wpqrRunId);
            
            if (deleteWPQRRun == null)
            {
                return new WPQRRunActionResponse(success, null, "WPQR Run not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WPQR_Run.Remove(deleteWPQRRun);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPQRRunActionResponse(true, null);
        }

        public class WPQRRunActionResponse : ActionResponse
        {
            public WPQR_Run WPQR_Run { get; }

            public WPQRRunActionResponse(bool success, WPQR_Run wpqrRun, string errorMessage = null) : base(success, errorMessage)
            {
                WPQR_Run = wpqrRun;
            }
        }

        public class WPQRRunsActionResponse : ActionResponse
        {
            public List<WPQR_Run> WPQR_Runs { get; }

            public WPQRRunsActionResponse(bool success, List<WPQR_Run> wpqrRuns, string errorMessage = null) : base(success, errorMessage)
            {
                WPQR_Runs = wpqrRuns;
            }
        }
    }
}
