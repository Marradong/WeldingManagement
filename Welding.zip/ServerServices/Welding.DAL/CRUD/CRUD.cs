﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        public class ActionResponse
        {
            public bool Success { get; }

            public string ErrorMessage { get; }

            public ActionResponse(bool success, string errorMessage = null)
            {
                Success = success;
                ErrorMessage = errorMessage;
            }
        }

        public class Logger
        {
            public static void Log(string message)
            {
                Console.WriteLine("EF Message: {0} ", message);
            }
        }

        public static void InitaliseDb(string Enumber, EFWeldingManagement db)
        {
                db.Database.Log = Logger.Log;

                db.Database.Delete();
                Console.WriteLine("Deleted DB\r\n");

                db.Database.CreateIfNotExists();
                Console.WriteLine("Created DB\r\n");

                string connectionString = ConfigurationManager.ConnectionStrings["WeldingManagementSystemDb"].ConnectionString;
                SqlConnectionStringBuilder connectionStringBuilder = new SqlConnectionStringBuilder(connectionString);

                string DbName = connectionStringBuilder.InitialCatalog;
                Console.WriteLine($"Db: {DbName}");
        }
            

        public static bool SavetoDb(EFWeldingManagement db, Stopwatch dbOperationStopwatch)
        {
            bool success = false;

            try
            {
                // Starting the stopwatch just before the database operation begins
                dbOperationStopwatch.Start();

                db.SaveChanges(); // Attempting to save changes to the database

                // Stopping the stopwatch after the operation completes successfully
                dbOperationStopwatch.Stop();

                Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");
                success = true;
            }
            catch (Exception ex)
            {
                // Stopping the stopwatch upon encountering an exception
                dbOperationStopwatch.Stop();

                // Building an error message with detailed exception information
                StringBuilder errorMessage = new StringBuilder();
                errorMessage.Append($"\n\t<Error>:");

                while (ex != null)
                {
                    // Ensuring error messages are wrapped properly
                    errorMessage.AppendLine($" {ex.Message.Replace(".", ".\n\t\t")}");

                    if (ex is DbEntityValidationException dbEx)
                    {
                        foreach (DbEntityValidationResult validationErrors in dbEx.EntityValidationErrors)
                        {
                            foreach (DbValidationError validationError in validationErrors.ValidationErrors)
                            {
                                // Adding entity and validation error details
                                errorMessage.AppendLine($"{validationErrors.Entry.Entity.GetType().Name}: {validationError.ErrorMessage.Replace(".", ".\n\t\t")}");
                            }
                        }
                    }

                    ex = ex.InnerException;
                    if (ex != null)
                        errorMessage.Append($"\t<InnerException>:");
                }

                Console.WriteLine($"\tDatabase operation FAILED after {dbOperationStopwatch.ElapsedMilliseconds} ms. Error: {errorMessage}");
            }
            finally
            {
                // Restarting the stopwatch for the next operation
                dbOperationStopwatch.Restart();
            }

            return success;
        }
    }
}
