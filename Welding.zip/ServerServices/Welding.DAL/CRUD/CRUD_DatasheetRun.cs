﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static DatasheetRunActionResponse CreateDatasheetRun(long datasheetId, Datasheet_Run dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new DatasheetRunActionResponse(success, null, "Datasheet_Run (dto) was null.");
            }

            Datasheet datasheet = _db.Datasheets.FirstOrDefault(wq => wq.DatasheetId == datasheetId);

            if (datasheet == null)
            {
                return new DatasheetRunActionResponse(success, null, "Datasheet not found.");
            }

            Datasheet_Run datasheetRun = _db.Datasheet_Run.Create();
            datasheetRun = DbDeepCopy.DeepCopy(dto, datasheetRun);

            datasheet.Datasheet_Run.Add(datasheetRun);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Datasheet_Run.Add(datasheetRun);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new DatasheetRunActionResponse(success, datasheetRun);
        }

        //
        // CRUD - READ
        //
        public static DatasheetRunActionResponse ReadDatasheetRun(long datasheetRunId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            Datasheet_Run datasheetRun = _db.Datasheet_Run.FirstOrDefault(dr => dr.Datasheet_RunId == datasheetRunId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new DatasheetRunActionResponse(datasheetRun != null, datasheetRun);
        }

        //
        // CRUD - READS
        //
        public static DatasheetRunsActionResponse ReadDatasheetRuns(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<Datasheet_Run> datasheetRuns = _db.Datasheet_Run.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new DatasheetRunsActionResponse(datasheetRuns != null, datasheetRuns);
        }

        //
        // CRUD - UPDATE
        //
        public static DatasheetRunActionResponse UpdateDatasheetRun(long datasheetRunId, Datasheet_Run dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new DatasheetRunActionResponse(success, null, "Datasheet_Run (dto) was null.");
            }

            Datasheet_Run existingDatasheetRun = _db.Datasheet_Run.FirstOrDefault(dr => dr.Datasheet_RunId == datasheetRunId);

            if (existingDatasheetRun == null)
            {
                return new DatasheetRunActionResponse(success, null, "Datasheet Run not found.");
            }

            existingDatasheetRun = DbDeepCopy.DeepCopy(dto, existingDatasheetRun);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingDatasheetRun).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new DatasheetRunActionResponse(success, existingDatasheetRun);
        }

        //
        // CRUD - DELETE
        //
        public static DatasheetRunActionResponse DeleteDatasheetRun(long datasheetRunId, EFWeldingManagement _db)
        {
            bool success = false;

            Datasheet_Run deleteDatasheetRun = _db.Datasheet_Run.Find(datasheetRunId);
            
            if (deleteDatasheetRun == null)
            {
                return new DatasheetRunActionResponse(success, null, "Datasheet Run not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Datasheet_Run.Remove(deleteDatasheetRun);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new DatasheetRunActionResponse(success, null);
        }

        public class DatasheetRunActionResponse : ActionResponse
        {
            public Datasheet_Run Datasheet_Run { get; }

            public DatasheetRunActionResponse(bool success, Datasheet_Run datasheetRun, string errorMessage = null) : base(success, errorMessage)
            {
                Datasheet_Run = datasheetRun;
            }
        }

        public class DatasheetRunsActionResponse : ActionResponse
        {
            public List<Datasheet_Run> Datasheet_Runs { get; }

            public DatasheetRunsActionResponse(bool success, List<Datasheet_Run> datasheetRuns, string errorMessage = null) : base(success, errorMessage)
            {
                Datasheet_Runs = datasheetRuns;
            }
        }
    }
}
