﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static WPSActionResponse CreateWPS(long wpqrId, WPS dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WPSActionResponse(success, null, "WPS (dto) was null.");
            }

            WPQR wpqr = _db.WPQRs.FirstOrDefault(wq => wq.WPQRId == wpqrId);

            if (wpqr == null)
            {
                return new WPSActionResponse(success, null, "WPQR not found.");
            }

            WPS wps = _db.WPS.Create();
            wps = DbDeepCopy.DeepCopy(dto, wps);

            wpqr.WPS.Add(wps);
            wpqr.Welder_Qualification.WeldingAction.WPS.Add(wps);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WPS.Add(wps);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPSActionResponse(success, wps);
        }

        //
        // CRUD - READ
        //
        public static WPSActionResponse ReadWPS(long wpsId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            WPS wps = _db.WPS.FirstOrDefault(w => w.WPSId == wpsId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WPSActionResponse(wps != null, wps);
        }

        //
        // CRUD - READS
        //
        public static WPSsActionResponse ReadWPSs(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<WPS> wpss = _db.WPS.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new WPSsActionResponse(wpss != null, wpss);
        }

        //
        // CRUD - UPDATE
        //
        public static WPSActionResponse UpdateWPS(long wpsId, WPS dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new WPSActionResponse(success, null, "WPS (dto) was null.");
            }

            WPS existingWPS = _db.WPS.FirstOrDefault(w => w.WPSId == wpsId);

            if (existingWPS == null)
            {
                return new WPSActionResponse(success, null, "WPS not found.");
            }

            existingWPS = DbDeepCopy.DeepCopy(dto, existingWPS);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingWPS).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPSActionResponse(success, existingWPS);
        }

        //
        // CRUD - DELETE
        //
        public static WPSActionResponse DeleteWPS(long wpsId, EFWeldingManagement _db)
        {
            bool success = false;

            WPS deleteWPS = _db.WPS.Find(wpsId);
            
            if (deleteWPS == null)
            {
                return new WPSActionResponse(success, null, "WPS not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.WPS.Remove(deleteWPS);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new WPSActionResponse(success, null);
        }

        public class WPSActionResponse : ActionResponse
        {
            public WPS WPS { get; }

            public WPSActionResponse(bool success, WPS wps, string errorMessage = null) : base(success, errorMessage)
            {
                WPS = wps;
            }
        }

        public class WPSsActionResponse : ActionResponse
        {
            public List<WPS> WPSs { get; }

            public WPSsActionResponse(bool success, List<WPS> wpss, string errorMessage = null) : base(success, errorMessage)
            {
                WPSs = wpss;
            }
        }
    }
}
