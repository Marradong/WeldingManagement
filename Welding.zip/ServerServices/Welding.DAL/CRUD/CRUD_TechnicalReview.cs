﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class CRUD
    {
        //
        // CRUD - CREATE
        //
        public static TechnicalReviewActionResponse CreateTechnicalReview(long nwfId, TechnicalReview dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new TechnicalReviewActionResponse(success, null, "TechnicalReview (dto) was null.");
            }

            NewWeldingForm newWeldingForm = _db.NewWeldingForms.FirstOrDefault(c => c.NewWeldingFormId == nwfId);

            if (newWeldingForm == null)
            {
                return new TechnicalReviewActionResponse(success, null, "NewWeldingForm was null.");
            }

            TechnicalReview technicalReview = _db.TechnicalReviews.Create();
            technicalReview = DbDeepCopy.DeepCopy(dto, technicalReview);

            technicalReview.TechnicalReviewId = newWeldingForm.NewWeldingFormId;
            newWeldingForm.TechnicalReview = technicalReview;

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.TechnicalReviews.Add(technicalReview);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new TechnicalReviewActionResponse(success, technicalReview);
        }

        //
        // CRUD - READ
        //
        public static TechnicalReviewActionResponse ReadTechnicalReview(long technicalReviewId, EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            TechnicalReview technicalReview = _db.TechnicalReviews.FirstOrDefault(tr => tr.TechnicalReviewId == technicalReviewId);

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new TechnicalReviewActionResponse(technicalReview != null, technicalReview);
        }

        //
        // CRUD - READS
        //
        public static TechnicalReviewsActionResponse ReadTechnicalReviews(EFWeldingManagement _db)
        {
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            List<TechnicalReview> technicalReviews = _db.TechnicalReviews.ToList();

            dbOperationStopwatch.Stop();
            Console.WriteLine($"\tDatabase operation SUCCESS in {dbOperationStopwatch.ElapsedMilliseconds} ms.");

            return new TechnicalReviewsActionResponse(technicalReviews != null, technicalReviews);
        }

        //
        // CRUD - UPDATE
        //
        public static TechnicalReviewActionResponse UpdateTechnicalReview(long technicalReviewId, TechnicalReview dto, EFWeldingManagement _db)
        {
            bool success = false;

            if (dto == null)
            {
                return new TechnicalReviewActionResponse(success, null, "TechnicalReview (dto) was null.");
            }

            TechnicalReview existingTechnicalReview = _db.TechnicalReviews.FirstOrDefault(tr => tr.TechnicalReviewId == technicalReviewId);

            if (existingTechnicalReview == null)
            {
                return new TechnicalReviewActionResponse(success, null, "TechnicalReview not found.");
            }

            existingTechnicalReview = DbDeepCopy.DeepCopy(dto, existingTechnicalReview);

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.Entry(existingTechnicalReview).State = EntityState.Modified;
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new TechnicalReviewActionResponse(success, existingTechnicalReview);
        }

        //
        // CRUD - DELETE
        //
        public static TechnicalReviewActionResponse DeleteTechnicalReview(long technicalReviewId, EFWeldingManagement _db)
        {
            bool success = false;

            TechnicalReview deleteTechnicalReview = _db.TechnicalReviews.Find(technicalReviewId);
            
            if (deleteTechnicalReview == null)
            {
                return new TechnicalReviewActionResponse(success, null, "Technical Review not found.");
            }

            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            _db.TechnicalReviews.Remove(deleteTechnicalReview);
            success = CRUD.SavetoDb(_db, dbOperationStopwatch);

            return new TechnicalReviewActionResponse(success, null);
        }

        public class TechnicalReviewActionResponse : ActionResponse
        {
            public TechnicalReview TechnicalReview { get; }

            public TechnicalReviewActionResponse(bool success, TechnicalReview technicalReview, string errorMessage = null) : base(success, errorMessage)
            {
                TechnicalReview = technicalReview;
            }
        }

        public class TechnicalReviewsActionResponse : ActionResponse
        {
            public List<TechnicalReview> TechnicalReviews { get; }

            public TechnicalReviewsActionResponse(bool success, List<TechnicalReview> technicalReviews, string errorMessage = null) : base(success, errorMessage)
            {
                TechnicalReviews = technicalReviews;
            }
        }
    }
}
