﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class DTO
    {
        public class AttachmentDTO
        {
            /*************************************************************************
             * Navigation properties                                                 *
             *************************************************************************/

            public long? newWeldingFormId { get; set; }
            public long? datasheetId { get; set; }
            public long? welderQualificationId { get; set; }
            public long? wpqrId { get; set; }
            public long? wpsId { get; set; }
        }

        public static Attachment Transfer(AttachmentDTO dto, Attachment attachment) 
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (attachment == null) 
            {
                throw new ArgumentNullException(nameof(attachment), "Attachment object cannot be null");
            }

            // Transfer Fields
            
            return attachment;
        }
    }
}
