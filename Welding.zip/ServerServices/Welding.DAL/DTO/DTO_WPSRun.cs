﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class DTO
    {
        public partial class WPS_RunDTO
        {
            public double? Amps { get; set; }

            public short? AmpsTolerance { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Classification { get; set; }

            public double? FillerDia { get; set; }

            public double? HeatInput { get; set; }

            public short? HeatInputTolerance { get; set; }

            public short? Pass { get; set; }

            public double? ShieldGas { get; set; }

            public short? Side { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Specification { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Supply { get; set; }

            public double? Volts { get; set; }

            public short? VoltsTolerance { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldingPosition { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldingProcess { get; set; }

            public double? WeldSpeed { get; set; }

            public short? WeldSpeedTolerance { get; set; }
        }

        public static WPS_Run Transfer(WPS_RunDTO dto, WPS_Run wpsRun)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (wpsRun==null)
            {
                throw new ArgumentNullException(nameof(wpsRun), "WPS_Run object cannot be null");
            }

            // Transfer Fields
            wpsRun.Amps = dto.Amps;
            wpsRun.AmpsTolerance = dto.AmpsTolerance;
            wpsRun.Classification = dto.Classification;
            wpsRun.FillerDia = dto.FillerDia;
            wpsRun.HeatInput = dto.HeatInput;
            wpsRun.HeatInputTolerance = dto.HeatInputTolerance;
            wpsRun.Pass = dto.Pass;
            wpsRun.ShieldGas = dto.ShieldGas;
            wpsRun.Side = dto.Side;
            wpsRun.Specification = dto.Specification;
            wpsRun.Supply = dto.Supply;
            wpsRun.Volts = dto.Volts;
            wpsRun.VoltsTolerance = dto.VoltsTolerance;
            wpsRun.WeldingPosition = dto.WeldingPosition;
            wpsRun.WeldingProcess = dto.WeldingProcess;
            wpsRun.WeldSpeed = dto.WeldSpeed;
            wpsRun.WeldSpeedTolerance = dto.WeldSpeedTolerance;

            return wpsRun;
        }
    }
}
