﻿using Bogus.DataSets;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.DTO;

namespace Welding.DAL
{
    public partial class DTO
    {
        public partial class TechnicalReviewDTO
        {
            [MaxLength(1000)]
            [StringLength(1000)]
            public string Considerations { get; set; }

            public DateTime? Date { get; set; }

            [MaxLength(1000)]
            [StringLength(1000)]
            public string ExtraCosts { get; set; }
        }

        public static TechnicalReview Transfer(TechnicalReviewDTO dto, TechnicalReview technicalReview)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (technicalReview==null)
            {
                throw new ArgumentNullException(nameof(technicalReview), "TechnicalReview object cannot be null");
            }

            // Transfer Fields
            technicalReview.Considerations = dto.Considerations;
            technicalReview.Date = dto.Date;
            technicalReview.ExtraCosts = dto.ExtraCosts;

            return technicalReview;
        }
    }
}
