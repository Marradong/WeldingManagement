﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class DTO
    {
        public class NewWeldingFormDTO
        {
            [MaxLength(255)]
            [StringLength(255)]
            public string ClientReqs { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string ComponentDescription { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string DrawingNumber { get; set; }

            public bool? DrawingProvided { get; set; }

            public bool? HistoryProvided { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string JointConfiguration { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string MaterialGrd { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string MaterialStd { get; set; }

            public WeldingComplexityMatrix? MatrixOutput { get; set; }

            public bool? NDTProvided { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string NominalStrength { get; set; }

            public bool? ParentProvided { get; set; }

            public bool? PhotosProvided { get; set; }

            public bool? ProceduresProvided { get; set; }

            public bool? PWHTProvided { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string QualityReqs { get; set; }

            public bool? RepairProvided { get; set; }

            public bool? SpecificationsProvided { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string SuggestedProcess { get; set; }

            public bool? SymbolsProvided { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldingCategory { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldingStandard { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldPosition { get; set; }

            [MaxLength(20)]
            [StringLength(20)]
            public string WPSReference { get; set; }
        }

        public static NewWeldingForm Transfer(NewWeldingFormDTO dto, NewWeldingForm nwf)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (nwf == null)
            {
                throw new ArgumentNullException(nameof(nwf), "NewWeldingForm object cannot be null");
            }

            // Transfer Fields
            nwf.ClientReqs = dto.ClientReqs;
            nwf.ComponentDescription = dto.ComponentDescription;
            nwf.DrawingNumber = dto.DrawingNumber;
            nwf.DrawingProvided = dto.DrawingProvided;
            nwf.HistoryProvided = dto.HistoryProvided;
            nwf.JointConfiguration = dto.JointConfiguration;
            nwf.MaterialGrd = dto.MaterialGrd;
            nwf.MaterialStd = dto.MaterialStd;
            nwf.MatrixOutput = dto.MatrixOutput;
            nwf.NDTProvided = dto.NDTProvided;
            nwf.NominalStrength = dto.NominalStrength;
            nwf.ParentProvided = dto.ParentProvided;
            nwf.PhotosProvided = dto.PhotosProvided;
            nwf.ProceduresProvided = dto.ProceduresProvided;
            nwf.PWHTProvided = dto.PWHTProvided;
            nwf.QualityReqs = dto.QualityReqs;
            nwf.RepairProvided = dto.RepairProvided;
            nwf.SpecificationsProvided = dto.SpecificationsProvided;
            nwf.SuggestedProcess = dto.SuggestedProcess;
            nwf.SymbolsProvided = dto.SymbolsProvided;
            nwf.WeldingCategory = dto.WeldingCategory;
            nwf.WeldingStandard = dto.WeldingStandard;
            nwf.WeldPosition = dto.WeldPosition;
            nwf.WPSReference = dto.WPSReference;

            return nwf;
        }
    }
}
