﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.DTO;

namespace Welding.DAL
{
    public partial class DTO
    {
        public class JobDTO
        {
            [MaxLength(255)]
            [StringLength(255)]
            public string Client { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string ClientManager { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Division { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string ItemDescription { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string JobNo { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string PurchaseOrderNo { get; set; }
        }

        public static Job Transfer(JobDTO dto, Job job)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (job == null)
            {
                throw new ArgumentNullException(nameof(dto), "Job object cannot be null");
            }

            // Transfer Fields
            job.Client = dto.Client;
            job.ClientManager = dto.ClientManager;
            job.Division = dto.Division;
            job.ItemDescription = dto.ItemDescription;
            job.JobNo = dto.JobNo;
            job.PurchaseOrderNo = dto.PurchaseOrderNo;

            return job;
        }
    }
}
