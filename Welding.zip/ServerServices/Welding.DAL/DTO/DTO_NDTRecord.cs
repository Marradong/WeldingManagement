﻿using Bogus.DataSets;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.DTO;

namespace Welding.DAL
{
    public partial class DTO
    {
        public class NDTRecordDTO
        {
            public DateTime? Date { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string PNumber { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string ReportNumber { get; set; }

            public NDTTestType? TestType { get; set; }
        }

        public static NDT_Record Transfer(NDTRecordDTO dto, NDT_Record ndtRecord)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (ndtRecord == null)
            {
                throw new ArgumentNullException(nameof(ndtRecord), "NDT_Record object cannot be null");
            }

            // Transfer Fields
            ndtRecord.Date = dto.Date;
            ndtRecord.PNumber = dto.PNumber;
            ndtRecord.ReportNumber = dto.ReportNumber;
            ndtRecord.TestType = dto.TestType;

            return ndtRecord;
        }
    }
}
