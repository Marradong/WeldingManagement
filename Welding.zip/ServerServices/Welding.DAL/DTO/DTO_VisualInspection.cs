﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class DTO
    {
        public partial class Visual_InspectionDTO
        {
            public bool? ArcStrike { get; set; }

            public bool? BurnThrough { get; set; }

            public bool? Control { get; set; }

            public bool? Cracks { get; set; }

            public bool? Crater { get; set; }

            public DateTime? Date { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string DrawingNumber { get; set; }

            public bool? Final { get; set; }

            public bool? Fusion { get; set; }

            public bool? Initial { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Location { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string MaterialGrd { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string MaterialStd { get; set; }

            [MaxLength(1000)]
            [StringLength(1000)]
            public string Notes { get; set; }

            public bool? Penetration { get; set; }

            public bool? Porosity { get; set; }

            public bool? Procedure { get; set; }

            public bool? Profile { get; set; }

            public bool? Qualification { get; set; }

            public bool? Reinforcement { get; set; }

            public bool? Repair { get; set; }

            public bool? Satisfactory { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string SerialNumbers { get; set; }

            public bool? SuckBack { get; set; }

            public bool? Undercut { get; set; }

            public bool? Weld_Id { get; set; }

            public bool? Welder_Id { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldingStandard { get; set; }

            public bool? WeldLocation { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldMap { get; set; }
        }

        public static Visual_Inspection Transfer(Visual_InspectionDTO dto, Visual_Inspection visualInspection)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (visualInspection == null) 
            {
                throw new ArgumentNullException(nameof(visualInspection), "Visual_Inspection object cannot be null");
            }

            // Transfer Fields
            visualInspection.ArcStrike = dto.ArcStrike;
            visualInspection.BurnThrough = dto.BurnThrough;
            visualInspection.Control = dto.Control;
            visualInspection.Cracks = dto.Cracks;
            visualInspection.Crater = dto.Crater;
            visualInspection.Date = dto.Date;
            visualInspection.DrawingNumber = dto.DrawingNumber;
            visualInspection.Final = dto.Final;
            visualInspection.Fusion = dto.Fusion;
            visualInspection.Initial = dto.Initial;
            visualInspection.Location = dto.Location;
            visualInspection.MaterialGrd = dto.MaterialGrd;
            visualInspection.MaterialStd = dto.MaterialStd;
            visualInspection.Notes = dto.Notes;
            visualInspection.Penetration = dto.Penetration;
            visualInspection.Porosity = dto.Porosity;
            visualInspection.Procedure = dto.Procedure;
            visualInspection.Profile = dto.Profile;
            visualInspection.Qualification = dto.Qualification;
            visualInspection.Reinforcement = dto.Reinforcement;
            visualInspection.Repair = dto.Repair;
            visualInspection.Satisfactory = dto.Satisfactory;
            visualInspection.SerialNumbers = dto.SerialNumbers;
            visualInspection.SuckBack = dto.SuckBack;
            visualInspection.Undercut = dto.Undercut;
            visualInspection.Weld_Id = dto.Weld_Id;
            visualInspection.Welder_Id = dto.Welder_Id;
            visualInspection.WeldingStandard = dto.WeldingStandard;
            visualInspection.WeldLocation = dto.WeldLocation;
            visualInspection.WeldMap = dto.WeldMap;

            return visualInspection;
        }
    }
}
