﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class DTO
    {
        public partial class WPQR_RunDTO
        {
            public double? Amps { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Classification { get; set; }

            public double? FillerDia { get; set; }

            public double? HeatInput { get; set; }

            public short? Pass { get; set; }

            public double? ShieldGas { get; set; }

            public short? Side { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Specification { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Supply { get; set; }

            public double? Volts { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldingPosition { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldingProcess { get; set; }

            public double? WeldSpeed { get; set; }
        }

        public static WPQR_Run Transfer(WPQR_RunDTO dto, WPQR_Run wpqrRun)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (wpqrRun==null)
            {
                throw new ArgumentNullException(nameof(wpqrRun), "WPQR_Run object cannot be null");
            }

            // Transfer Fields
            wpqrRun.Amps = dto.Amps;
            wpqrRun.Classification = dto.Classification;
            wpqrRun.FillerDia = dto.FillerDia;
            wpqrRun.HeatInput = dto.HeatInput;
            wpqrRun.Pass = dto.Pass;
            wpqrRun.ShieldGas = dto.ShieldGas;
            wpqrRun.Side = dto.Side;
            wpqrRun.Specification = dto.Specification;
            wpqrRun.Supply = dto.Supply;
            wpqrRun.Volts = dto.Volts;
            wpqrRun.WeldingPosition = dto.WeldingPosition;
            wpqrRun.WeldingProcess = dto.WeldingProcess;
            wpqrRun.WeldSpeed = dto.WeldSpeed;

            return wpqrRun;
        }
    }
}
