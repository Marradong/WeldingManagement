﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class DTO
    {
        public partial class WeldingActionDTO
        {
            public Actions? Status { get; set; }
        }

        public static WeldingAction Transfer(WeldingActionDTO dto, WeldingAction weldingAction)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (weldingAction == null)
            {
                throw new ArgumentNullException(nameof(weldingAction), "WeldingAction object cannot be null");
            }

            // Transfer Fields
            weldingAction.Status = dto.Status;

            return weldingAction;
        }
    }
}
