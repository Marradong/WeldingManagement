﻿using Bogus.DataSets;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class DTO
    {
        public class OperationalReviewDTO
        {
            public DateTime? Date { get; set; }

            public bool? Equipment { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string EquipmentComments { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string ExtraCosts { get; set; }

            public bool? Facilities { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string FacilitiesComments { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string GeneralComments { get; set; }

            public bool? PWHT { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string PWHTComments { get; set; }

            public bool? Storage { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string StorageComments { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string SubComments { get; set; }

            public bool? SubContractors { get; set; }

            public bool? ThirdParty { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string ThirdPartyComments { get; set; }

            public bool? TrainedStaff { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string TrainedStaffComments { get; set; }

            public bool? Welders { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldersComments { get; set; }

            public bool? WPS { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WPSComments { get; set; }
        }

        public static OperationalReview Transfer(OperationalReviewDTO dto, OperationalReview operationalReview)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (operationalReview == null) 
            {
                throw new ArgumentNullException(nameof(operationalReview), "OperationalReview object cannot be null");
            }

            // Transfer Fields
            operationalReview.Date = dto.Date;
            operationalReview.Equipment = dto.Equipment;
            operationalReview.EquipmentComments = dto.EquipmentComments;
            operationalReview.ExtraCosts = dto.ExtraCosts;
            operationalReview.Facilities = dto.Facilities;
            operationalReview.FacilitiesComments = dto.FacilitiesComments;
            operationalReview.GeneralComments = dto.GeneralComments;
            operationalReview.PWHT = dto.PWHT;
            operationalReview.PWHTComments = dto.PWHTComments;
            operationalReview.Storage = dto.Storage;
            operationalReview.StorageComments = dto.StorageComments;
            operationalReview.SubComments = dto.SubComments;
            operationalReview.SubContractors = dto.SubContractors;
            operationalReview.ThirdParty = dto.ThirdParty;
            operationalReview.ThirdPartyComments = dto.ThirdPartyComments;
            operationalReview.TrainedStaff = dto.TrainedStaff;
            operationalReview.TrainedStaffComments = dto.TrainedStaffComments;
            operationalReview.Welders = dto.Welders;
            operationalReview.WeldersComments = dto.WeldersComments;
            operationalReview.WPS = dto.WPS;
            operationalReview.WPSComments = dto.WPSComments;

            return operationalReview;
        }
    }
}
