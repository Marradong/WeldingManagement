﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class DTO
    {
        public partial class WPQRDTO
        {
            public double? Amps { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string BackingComposition { get; set; }

            public double? BackingFlowRate { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string BeadType { get; set; }

            public bool? BendReq { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string BMGrade { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string BMGroupPNumber { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string BMSpecfication { get; set; }

            public double? CoolingRate { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Current { get; set; }

            public DateTime? Date { get; set; }

            public double? Diameter { get; set; }

            public bool? DPIReq { get; set; }

            public bool? DTReq { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string EFluxClassification { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string ElectricalNotes { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string ElectrodeType { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string FillerANumber { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string FillerClassification { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string FillerFNumber { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string FillerForm { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string FillerNotes { get; set; }

            public double? FillerSize { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string FillerSpecification { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string FluxTradeName { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string FluxType { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string GasNotes { get; set; }

            public bool? HardnessReq { get; set; }

            public double? HeatingRate { get; set; }

            public double? HeatInput { get; set; }

            public bool? ImpactReq { get; set; }

            public double? InterpassTemp { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string JointType { get; set; }

            public bool? MacroReq { get; set; }

            public double? MaxThickness { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string MetalTransfer { get; set; }

            public bool? MPIReq { get; set; }

            public bool? NDTReq { get; set; }

            [MaxLength(1000)]
            [StringLength(1000)]
            public string Notes { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Oscillation { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Other { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string PassType { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Polarity { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string PositionNotes { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Positon { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string PreheatNotes { get; set; }

            public double? PreheatTemp { get; set; }

            public double? PWHTTemp { get; set; }

            public double? PWHTTime { get; set; }

            public bool? RTReq { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string ShieldComposition { get; set; }

            public double? ShieldFlowRate { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string TechniqueNotes { get; set; }

            public bool? TensilReq { get; set; }

            public double? TESize { get; set; }

            public double? Thickness { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string TrailingComposition { get; set; }

            public double? TrailingFlowRate { get; set; }

            public double? TravelSpeed { get; set; }

            public bool? UTReq { get; set; }

            public bool? VIReq { get; set; }

            public double? Volts { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldingStandard { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldingType { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldProgression { get; set; }

            public double? WMThickness { get; set; }

            public int? WPQRNumber { get; set; }
        }

        public static WPQR Transfer(WPQRDTO dto, WPQR wpqr)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (wpqr == null)
            {
                throw new ArgumentNullException(nameof(wpqr), "WPQR object cannot be null");
            }

            // Transfer Fields
            wpqr.Amps = dto.Amps;
            wpqr.BackingComposition = dto.BackingComposition;
            wpqr.BackingFlowRate = dto.BackingFlowRate;
            wpqr.BeadType = dto.BeadType;
            wpqr.BendReq = dto.BendReq;
            wpqr.BMGrade = dto.BMGrade;
            wpqr.BMGroupPNumber = dto.BMGroupPNumber;
            wpqr.BMSpecfication = dto.BMSpecfication;
            wpqr.CoolingRate = dto.CoolingRate;
            wpqr.Current = dto.Current;
            wpqr.Date = dto.Date;
            wpqr.Diameter = dto.Diameter;
            wpqr.DPIReq = dto.DPIReq;
            wpqr.DTReq = dto.DTReq;
            wpqr.EFluxClassification = dto.EFluxClassification;
            wpqr.ElectricalNotes = dto.ElectricalNotes;
            wpqr.ElectrodeType = dto.ElectrodeType;
            wpqr.FillerANumber = dto.FillerANumber;
            wpqr.FillerClassification = dto.FillerClassification;
            wpqr.FillerFNumber = dto.FillerFNumber;
            wpqr.FillerForm = dto.FillerForm;
            wpqr.FillerNotes = dto.FillerNotes;
            wpqr.FillerSize = dto.FillerSize;
            wpqr.FillerSpecification = dto.FillerSpecification;
            wpqr.FluxTradeName = dto.FluxTradeName;
            wpqr.FluxType = dto.FluxType;
            wpqr.GasNotes = dto.GasNotes;
            wpqr.HardnessReq = dto.HardnessReq;
            wpqr.HeatingRate = dto.HeatingRate;
            wpqr.HeatInput = dto.HeatInput;
            wpqr.ImpactReq = dto.ImpactReq;
            wpqr.InterpassTemp = dto.InterpassTemp;
            wpqr.JointType = dto.JointType;
            wpqr.MacroReq = dto.MacroReq;
            wpqr.MaxThickness = dto.MaxThickness;
            wpqr.MetalTransfer = dto.MetalTransfer;
            wpqr.MPIReq = dto.MPIReq;
            wpqr.NDTReq = dto.NDTReq;
            wpqr.Notes = dto.Notes;
            wpqr.Oscillation = dto.Oscillation;
            wpqr.Other = dto.Other;
            wpqr.PassType = dto.PassType;
            wpqr.Polarity = dto.Polarity;
            wpqr.PositionNotes = dto.PositionNotes;
            wpqr.Positon = dto.Positon;
            wpqr.PreheatNotes = dto.PreheatNotes;
            wpqr.PreheatTemp = dto.PreheatTemp;
            wpqr.PWHTTemp = dto.PWHTTemp;
            wpqr.PWHTTime = dto.PWHTTime;
            wpqr.RTReq = dto.RTReq;
            wpqr.ShieldComposition = dto.ShieldComposition;
            wpqr.ShieldFlowRate = dto.ShieldFlowRate;
            wpqr.TechniqueNotes = dto.TechniqueNotes;
            wpqr.TensilReq = dto.TensilReq;
            wpqr.TESize = dto.TESize;
            wpqr.Thickness = dto.Thickness;
            wpqr.TrailingComposition = dto.TrailingComposition;
            wpqr.TrailingFlowRate = dto.TrailingFlowRate;
            wpqr.TravelSpeed = dto.TravelSpeed;
            wpqr.UTReq = dto.UTReq;
            wpqr.VIReq = dto.VIReq;
            wpqr.Volts = dto.Volts;
            wpqr.WeldingStandard = dto.WeldingStandard;
            wpqr.WeldingType = dto.WeldingType;
            wpqr.WeldProgression = dto.WeldProgression;
            wpqr.WMThickness = dto.WMThickness;
            wpqr.WPQRNumber = dto.WPQRNumber;

            return wpqr;
        }
    }
}
