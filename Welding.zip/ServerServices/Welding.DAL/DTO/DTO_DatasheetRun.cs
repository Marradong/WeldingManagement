﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class DTO
    {
        public class DatasheetRunDTO
        {
            public double? ActualLength { get; set; }

            public double? Amps { get; set; }

            public double? CalculatedLength { get; set; }

            public double? EnergyInput { get; set; }

            public double? FillerDia { get; set; }

            public double? Interpass { get; set; }

            public short? Pass { get; set; }

            public double? PurgeGas { get; set; }

            public double? ShieldGas { get; set; }

            public short? Side { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Supply { get; set; }

            public double? Volts { get; set; }

            public double? WeldSpeed { get; set; }

            public double? WeldTime { get; set; }
        }

        public static Datasheet_Run Transfer(DatasheetRunDTO dto, Datasheet_Run datasheetRun)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (datasheetRun == null)
            {
                throw new ArgumentNullException(nameof(datasheetRun), "Datasheet_Run object cannot be null");
            }

            // Transfer Fields
            datasheetRun.ActualLength = dto.ActualLength;
            datasheetRun.Amps = dto.Amps;
            datasheetRun.CalculatedLength = dto.CalculatedLength;
            datasheetRun.EnergyInput = dto.EnergyInput;
            datasheetRun.FillerDia = dto.FillerDia;
            datasheetRun.Interpass = dto.Interpass;
            datasheetRun.Pass = dto.Pass;
            datasheetRun.PurgeGas = dto.PurgeGas;
            datasheetRun.ShieldGas = dto.ShieldGas;
            datasheetRun.Side = dto.Side;
            datasheetRun.Supply = dto.Supply;
            datasheetRun.Volts = dto.Volts;
            datasheetRun.WeldSpeed = dto.WeldSpeed;
            datasheetRun.WeldTime = dto.WeldTime;

            return datasheetRun;
        }
    }
}
