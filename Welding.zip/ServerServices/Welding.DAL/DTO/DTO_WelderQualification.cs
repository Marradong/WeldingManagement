﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class DTO
    {
        public partial class Welder_QualificationDTO
        {

        }

        public static Welder_Qualification Transfer(Welder_QualificationDTO dto, Welder_Qualification welderQual) 
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (welderQual == null)
            {
                throw new ArgumentNullException(nameof(welderQual), "Welder_Qualification object cannot be null");
            }
            
            // Transfer Fields

            return welderQual;
        }
    }
}
