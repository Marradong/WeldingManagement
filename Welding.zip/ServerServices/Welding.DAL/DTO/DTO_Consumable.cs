﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class DTO
    {
        public class ConsumableDTO
        {
            [MaxLength(255)]
            [StringLength(255)]
            public string BatchNumber { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Classification { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Manufacturer { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string ProductName { get; set; }
        }

        public static Consumable Transfer(ConsumableDTO dto, Consumable consumable)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (consumable == null) 
            {
                throw new ArgumentNullException(nameof(consumable), "Consumable object cannot be null");
            }

            // Transfer Fields
            consumable.BatchNumber = dto.BatchNumber;
            consumable.Classification = dto.Classification;
            consumable.Manufacturer = dto.Manufacturer;
            consumable.ProductName = dto.ProductName;

            return consumable;
        }
    }
}
