﻿using Bogus.DataSets;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Welding.DAL
{
    public partial class DTO
    {
        public class PersonDTO
        {
            [MaxLength(255)]
            [StringLength(255)]
            public string Department { get; set; }

            [StringLength(255)]
            public string Division { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Email { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string EmployeeName { get; set; }

            [MaxLength(6)]
            [StringLength(6)]
            public string EmployeeNumber { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string Ext { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string FirstName { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string LastName { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string PhoneNumber { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string PreferredName { get; set; }

            public PersonRole? Role { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string SpeedDial { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WorkRole { get; set; }

            /*************************************************************************
             * Navigation properties                                                 *
             *************************************************************************/

            public long? weldingActionId { get; set; }
        }

        public static Person Transfer(PersonDTO dto, Person person)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (person==null)
            {
                throw new ArgumentNullException(nameof(person), "Person object cannot be null");
            }

            // Transfer Fields
            person.Department = dto.Department;
            person.Division = dto.Division;
            person.Email = dto.Email;
            person.EmployeeName = dto.EmployeeName;
            person.EmployeeNumber = dto.EmployeeNumber;
            person.Ext = dto.Ext;
            person.FirstName = dto.FirstName;
            person.LastName = dto.LastName;
            person.PhoneNumber = dto.PhoneNumber;
            person.PreferredName = dto.PreferredName;
            person.Role = dto.Role;
            person.SpeedDial = dto.SpeedDial;
            person.WorkRole = dto.WorkRole;


            return person;
        }
    }
}
