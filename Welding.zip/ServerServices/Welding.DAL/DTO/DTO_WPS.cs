﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Welding.DAL.DTO;

namespace Welding.DAL
{
    public partial class DTO
    {
        public partial class WPSDTO
        {
            public DateTime? Date { get; set; }

            public double? Diameter { get; set; }

            public bool? DPIReq { get; set; }

            public double? Interpass { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string JointType { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string MaterialGrd { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string MaterialStd { get; set; }

            public bool? MPIReq { get; set; }

            public bool? NDTReq { get; set; }

            [MaxLength(1000)]
            [StringLength(1000)]
            public string Notes { get; set; }

            public double? Preheat { get; set; }

            public double? PWHT { get; set; }

            public bool? RTReq { get; set; }

            public double? Thickness { get; set; }

            public bool? UTReq { get; set; }

            public bool? VIReq { get; set; }

            [MaxLength(10)]
            [StringLength(10)]
            public string WPSNumber { get; set; }
        }

        public static WPS Transfer(WPSDTO dto, WPS wps)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (wps==null)
            {
                throw new ArgumentNullException(nameof(wps), "WPS object cannot be null");
            }

            // Transfer Fields
            wps.Date = dto.Date;
            wps.Diameter = dto.Diameter;
            wps.DPIReq = dto.DPIReq;
            wps.Interpass = dto.Interpass;
            wps.JointType = dto.JointType;
            wps.MaterialGrd = dto.MaterialGrd;
            wps.MaterialStd = dto.MaterialStd;
            wps.MPIReq = dto.MPIReq;
            wps.NDTReq = dto.NDTReq;
            wps.Notes = dto.Notes;
            wps.Preheat = dto.Preheat;
            wps.PWHT = dto.PWHT;
            wps.RTReq = dto.RTReq;
            wps.Thickness = dto.Thickness;
            wps.UTReq = dto.UTReq;
            wps.VIReq = dto.VIReq;
            wps.WPSNumber = dto.WPSNumber;


            return wps;
        }
    }
}
