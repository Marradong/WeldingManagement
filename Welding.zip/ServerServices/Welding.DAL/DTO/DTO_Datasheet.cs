﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class DTO
    {
        public class DatasheetDTO
        {
            [MaxLength(255)]
            [StringLength(255)]
            public string HeatNumber { get; set; }

            public double? IncludedAngle { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string JointDesign { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string JointType { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string MaterialGrd { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string MaterialStd { get; set; }

            public double? MaterialThickness { get; set; }

            [MaxLength(1000)]
            [StringLength(255)]
            public string Notes { get; set; }

            public double? PreheatTemp { get; set; }

            public double? RootFace { get; set; }

            public double? RootGap { get; set; }

            public DateTime? TestDate { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldingPosition { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldingProcess { get; set; }

            [MaxLength(255)]
            [StringLength(255)]
            public string WeldingStandard { get; set; }

            public short? WPQRNumber { get; set; }
        }

        public static Datasheet Transfer(DatasheetDTO dto, Datasheet datasheet)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto), "DTO object cannot be null");
            }

            if (datasheet == null) 
            {
                throw new ArgumentNullException(nameof(datasheet), "Datasheet object cannot be null");
            }

            // Transfer Fields
            datasheet.HeatNumber = dto.HeatNumber;
            datasheet.IncludedAngle = dto.IncludedAngle;
            datasheet.JointDesign = dto.JointDesign;
            datasheet.JointType = dto.JointType;
            datasheet.MaterialGrd = dto.MaterialGrd;
            datasheet.MaterialStd = dto.MaterialStd;
            datasheet.MaterialThickness = dto.MaterialThickness;
            datasheet.Notes = dto.Notes;
            datasheet.PreheatTemp = dto.PreheatTemp;
            datasheet.RootFace = dto.RootFace;
            datasheet.RootGap = dto.RootGap;
            datasheet.TestDate = dto.TestDate;
            datasheet.WeldingPosition = dto.WeldingPosition;
            datasheet.WeldingProcess = dto.WeldingProcess;
            datasheet.WeldingStandard = dto.WeldingStandard;
            datasheet.WPQRNumber = dto.WPQRNumber;

            return datasheet;
        }
    }
}
