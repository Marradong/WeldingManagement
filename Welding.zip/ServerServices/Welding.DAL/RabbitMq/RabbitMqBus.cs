﻿using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public partial class EFWeldingManagement : DbContext
    {
        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            var changes = ChangeTracker.Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified || e.State == EntityState.Deleted)
                .ToList();
            var result = await base.SaveChangesAsync(cancellationToken);
            if (changes.Any()) {
                using (var publisher = new RabbitMqPublisher()) {
                    publisher.PublishChanges(changes);
                }
            }
            return result;
        }

        public override int SaveChanges()
        {
            // Debug.Print($">SaveChanges db");
            var changes = ChangeTracker.Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified || e.State == EntityState.Deleted || e.State == EntityState.Detached)
                .ToList();

            var result = base.SaveChanges();

            if (changes.Any()) {
                var publisher = new RabbitMqPublisher();
                publisher.PublishChanges(changes);
            }

            return result;
        }
    }
}
