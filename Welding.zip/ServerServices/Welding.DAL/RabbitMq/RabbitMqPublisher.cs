﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Diagnostics;
using System.Text;
using RabbitMQ.Client;

public class RabbitMqPublisher : IDisposable
{
    private readonly string _applicationName = "Welding";
    private IConnection _connection;
    private IModel _channel;

    public RabbitMqPublisher()
    {
        var factory = new ConnectionFactory()
        {
            HostName = "192.168.100.171",
            Port = 5672,
            UserName = "camco",
            Password = "camco1820"
        };
        _connection = factory.CreateConnection();
        _channel = _connection.CreateModel();
        Debug.WriteLine(">New RabbitMq publisher registered and channel connection made.  [RabbitMqPublisher]");
    }

    public void PublishChanges(IEnumerable<DbEntityEntry> changes)
    {
        Debug.WriteLine(">Attempting to publish changes...   [RabbitMqPublisher - PublishChanges]");
        foreach (var entry in changes) {
            string msg = $"Entity {entry.Entity.GetType().Name} state {entry.State}";
            string tableName = entry.Entity.GetType().Name;
            string exchangeName = $"{_applicationName}:{tableName}";
            try {
                _channel.ExchangeDeclare(exchange: exchangeName, type: "topic", durable: true);
                var body = Encoding.UTF8.GetBytes(msg);
                _channel.BasicPublish(exchange: exchangeName, routingKey: "", basicProperties: null, body: body);
                Debug.WriteLine(">Published changes to: <" + tableName + "> | With message: " + msg + "   [RabbitMqPublisher - PublishChanges]");
            }
            catch (Exception ex) {
                Debug.WriteLine($">Failed to publish changes for {tableName}: {ex.Message}   [RabbitMqPublisher - PublishChanges]");
            }
        }
    }

    public void PublishCustomMessage(string message)
    {
        string exchangeName = $"{_applicationName}:CustomMessages";
        try {
            _channel.ExchangeDeclare(exchange: exchangeName, type: "topic", durable: true);
            var body = Encoding.UTF8.GetBytes(message);
            _channel.BasicPublish(exchange: exchangeName, routingKey: "", basicProperties: null, body: body);
            Debug.WriteLine($">Published custom message to: {exchangeName} | Message: {message}");
        }
        catch (Exception ex) {
            Debug.WriteLine($">Failed to publish custom message: {ex.Message}");
        }
    }


    public void Close()
    {
        Debug.Write(">Closing publish channel..");
        if (_channel.IsOpen) {
            _channel.Close();
        }
        _channel.Dispose();
        if (_connection.IsOpen) {
            _connection.Close();
        }
        _connection.Dispose();
        Debug.WriteLine("...Closed. [RabbitMqPublisher - Close]");
    }

    public void Dispose()
    {
        Close();
    }
}
