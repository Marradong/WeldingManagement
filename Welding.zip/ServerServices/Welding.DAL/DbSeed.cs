﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

using Bogus;

namespace Welding.DAL
{

    //Create a DTO - to Fill Db with test data
    public static class DbSeed
    {
        public static bool Seed()
        {
            bool success = false;
            Stopwatch dbOperationStopwatch = new Stopwatch();
            dbOperationStopwatch.Start();

            Console.WriteLine("Starting database operation...");
            using (EFWeldingManagement db = new EFWeldingManagement())
            {


                // ---------- Create Job (Root) ---------- //


                Job job = new Job()
                {
                    JobNo = "42-42",
                    PurchaseOrderNo = "42",
                    Client = "Marvel",
                    ItemDescription = "Camco Ironman Suit",
                    ClientManagerEID = "E2596",
                    Division = "Defense",
                };
                db.Jobs.Add(job);

                Console.WriteLine("\n\t> Db Save : job.");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation


                // ---------- Create Welding Action ---------- //


                WeldingAction weldingaction = new WeldingAction(job)
                {
                    Status = Actions.WeldingMatrix,
                };
                db.WeldingActions.Add(weldingaction);

                job.WeldingActions.Add(weldingaction);
                weldingaction.Job = job;

                Console.WriteLine("\n\t> Db Save : weldingaction.");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation


                // ---------- Create New Welding Form ---------- //


                NewWeldingForm nwf = new NewWeldingForm(weldingaction.WeldingActionId, weldingaction)
                {
                    MatrixOutput = WeldingComplexityMatrix.Complex,

                    // Change status

                    DrawingNumber = "42",
                    ComponentDescription = "Mech Suit",
                    WeldingStandard = "AS42.*",
                    WeldingCategory = "A",
                    MaterialStd = "Titanium Alloy",
                    MaterialGrd = "X",
                    NominalStrength = "42kN",
                    WeldPosition = "1G",
                    SuggestedProcess = "SAW",
                    JointConfiguration = "Double Bevel",
                    QualityReqs = "N/A",
                    ClientReqs = "'Must look gnarly'",
                    DrawingProvided = true,
                    SymbolsProvided = true,
                    RepairProvided = true,
                    PWHTProvided = true,
                    SpecificationsProvided = true,
                    ProceduresProvided = true,
                    PhotosProvided = false,
                    ParentProvided = false,
                    NDTProvided = false,
                    HistoryProvided = false,
                    WPSReference = "",
                    ClientManagerEID = "E2596"
                };
                db.NewWeldingForms.Add(nwf);

                Console.WriteLine("\n\t> Db Save : nwf.");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation


                // ---------- Create Technical Review ---------- //


                TechnicalReview tcReview = new TechnicalReview(nwf.NewWeldingFormId, nwf)
                {
                    Considerations = "Consider air travel regulations",
                    ExtraCosts = "Lunch",
                    Date = DateTime.Today,
                    TechnicalReviewerEID = "E2596"
                };
                db.TechnicalReviews.Add(tcReview);
                // nwf.TechnicalReview = tcReview;


                Console.WriteLine("\n\t> Db Save : tcReview.");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation


                // ---------- Create Operational Review ---------- //


                OperationalReview opReview = new OperationalReview(nwf.NewWeldingFormId, nwf)
                {
                    Date = DateTime.Today,
                    TrainedStaff = false,
                    Facilities = false,
                    Equipment = false,
                    ThirdParty = false,
                    WPS = false,
                    Welders = false,
                    SubContractors = true,
                    Storage = true,
                    PWHT = true,
                    TrainedStaffComments = "TrainedStaffComments",
                    FacilitiesComments = "",
                    EquipmentComments = "",
                    ThirdPartyComments = "",
                    SubComments = "",
                    StorageComments = "",
                    PWHTComments = "",
                    GeneralComments = "Not Bad",
                    ExtraCosts = "Beveraginos",
                };
                db.OperationalReviews.Add(opReview);
                // nwf.OperationalReview = opReview;

                Console.WriteLine("\n\t> Db Save : opReview.");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation


                // ---------- Create Welder Qualification and Welder ---------- //


                Welder_Qualification wq = new Welder_Qualification(weldingaction);
                db.Welder_Qualification.Add(wq);

                Console.WriteLine("\n\t> Db Save : wq.");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation


                // ---------- Create Datasheet ---------- //


                Datasheet datasheet = new Datasheet(wq.Welder_QualificationId, wq)
                {
                    WPQRNumber = 42,
                    TestDate = DateTime.Today,
                    WeldingStandard = "AS42.*",
                    WeldingProcess = "SAW",
                    JointDesign = "Bendy",
                    JointType = "Elbow",
                    WeldingPosition = "1G",
                    RootFace = 4,
                    RootGap = 2,
                    IncludedAngle = 138,
                    PreheatTemp = -274.15,
                    MaterialStd = "Titanium Alloy",
                    MaterialGrd = "X",
                    MaterialThickness = 42.0001,
                    HeatNumber = "*",
                    Notes = "Worth it", // yes
                    WelderEID = "E2596"
                };
                db.Datasheets.Add(datasheet);

                Console.WriteLine("\n\t> Db Save : datasheet.");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation


                Datasheet_Run datasheet_Run = new Datasheet_Run()
                {
                    Side = 42,
                    Pass = 42,
                    FillerDia = 4.2,
                    Supply = "DCEP",
                    Amps = 84,
                    Volts = 126,
                    Interpass = 3,
                    CalculatedLength = 45,
                    ActualLength = 42,
                    WeldTime = 2520,

                    ShieldGas = 21,
                    PurgeGas = 10.5,
                };
                datasheet_Run.WeldSpeed = datasheet_Run.ActualLength / datasheet_Run.WeldTime * 60;          // Calculated
                datasheet_Run.HeatInput = (60 * datasheet_Run.Amps * datasheet_Run.Volts) / (1000 * datasheet_Run.WeldSpeed);
                db.Datasheet_Run.Add(datasheet_Run);
                datasheet.Datasheet_Run.Add(datasheet_Run);

                Console.WriteLine("\n\t> Db Save : datasheet_Run.");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation


                // ---------- Create Weld Consumable ---------- //


                Consumable consumable = new Consumable(datasheet)
                {
                    Manufacturer = "Stark Industries",
                    ProductName = "Camco 801",
                    Classification = "Top Secret",
                    BatchNumber = "... 42",
                };
                db.Consumables.Add(consumable);

                Console.WriteLine("\n\t> Db Save : consumable");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation


                // ---------- Create Visual Inspection ---------- //


                Visual_Inspection vi = new Visual_Inspection(wq.Welder_QualificationId, wq)
                {
                    Date = DateTime.Today,
                    WeldingStandard = wq.Datasheet.WeldingStandard,
                    Location = "Malibu",
                    MaterialStd = wq.Datasheet.MaterialStd,
                    MaterialGrd = wq.Datasheet.MaterialGrd,
                    WeldMap = "Google",
                    DrawingNumber = "42",
                    SerialNumbers = "42",
                    Notes = "A-Okay",
                    Weld_Id = true,
                    Welder_Id = true,
                    Initial = true,
                    Repair = true,
                    Final = true,
                    Procedure = true,
                    Qualification = true,
                    Control = true,
                    Profile = false,
                    WeldLocation = true,
                    Cracks = true,
                    Penetration = true,
                    Fusion = true,
                    Porosity = false,
                    BurnThrough = false,
                    Undercut = false,
                    ArcStrike = false,
                    Reinforcement = true,
                    SuckBack = true,
                    Crater = true,
                    Satisfactory = true,
                };
                db.Visual_Inspection.Add(vi);

                Console.WriteLine("\n\t> Db Save : vi");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation


                // ---------- Create WPQR ---------- //


                WPQR wPQR = new WPQR(wq.Welder_QualificationId, wq, wq.WeldingAction)
                {
                    MinAmps = 20,
                    BackingComposition = "BackingComp123",
                    BackingFlowRate = 10.5,
                    BeadType = "BeadType456",
                    BendReq = true,
                    BMGrade = "BMGrade789",
                    BMGroupPNumber = "BMGroup123",
                    BMSpecfication = "BMSpec123",
                    CoolingRate = 5.2,
                    Current = "200A",
                    Date = DateTime.Now,
                    Diameter = 8.0,
                    DPIReq = false,
                    DTReq = true,
                    EFluxClassification = "FluxClass123",
                    ElectricalNotes = "ElectricalNotes456",
                    ElectrodeType = "Electrode456",
                    FillerANumber = "FillerANum123",
                    FillerClassification = "FillerClass123",
                    FillerFNumber = "FillerFNum456",
                    FillerForm = "FillerForm789",
                    FillerNotes = "FillerNotes123",
                    FillerSize = 2.5,
                    FillerSpecification = "FillerSpec123",
                    FluxTradeName = "FluxTrade456",
                    FluxType = "FluxType789",
                    GasNotes = "GasNotes123",
                    HardnessReq = true,
                    HeatingRate = 15.3,
                    MinHeatInput = 200.0,
                    ImpactReq = false,
                    InterpassTemp = 150.0,
                    JointType = "ButtJoint",
                    MacroReq = true,
                    MaxThickness = 10.0,
                    MetalTransfer = "MetalTransfer123",
                    MPIReq = true,
                    NDTReq = false,
                    Notes = "Some random notes here.",
                    Oscillation = "Oscillation456",
                    Other = "Other789",
                    PassType = "SinglePass",
                    Polarity = "DC",
                    PositionNotes = "PositionNotes123",
                    Position = "2G",
                    PreheatNotes = "PreheatNotes456",
                    PreheatTemp = 100.0,
                    PWHTTemp = 600.0,
                    PWHTTime = 2.0,
                    RTReq = true,
                    ShieldComposition = "ShieldComp123",
                    ShieldFlowRate = 8.5,
                    TechniqueNotes = "TechniqueNotes456",
                    TensilReq = false,
                    TESize = 3.0,
                    Thickness = 6.0,
                    TrailingComposition = "TrailingComp123",
                    TrailingFlowRate = 7.0,
                    MinTravelSpeed = 50.0,
                    UTReq = false,
                    VIReq = true,
                    MinVolts = 25.5,
                    WeldingStandard = "AWS D1.1",
                    WeldingType = "GTAW",
                    WeldProgression = "Stringer",
                    WMThickness = 8.0,
                    WPQRNumber = "12345",
                    WPQRPreparerEID = "E2596"
                };
                db.WPQRs.Add(wPQR);

                Console.WriteLine("\n\t> Db Save : wPQR");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation

                WPQR_Run wPQR_Run = new WPQR_Run(wPQR)
                {
                    Amps = 180.0,
                    Classification = "ClassA",
                    FillerDia = 2.0,
                    HeatInput = 220.0,
                    Pass = 1,
                    ShieldGas = 15.0,
                    Side = 2,
                    Specification = "Spec123",
                    Supply = "Supply456",
                    Volts = 28.0,
                    WeldingPosition = "3G",
                    WeldingProcess = "SMAW",
                    WeldSpeed = 50.0,
                };
                db.WPQR_Run.Add(wPQR_Run);

                Console.WriteLine("\n\t> Db Save : wPQR_Run");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation


                // ---------- Create WPS ---------- //


                WPS wPS = new WPS(wPQR, wq.WeldingAction)
                {
                    WPSNumber = "123-1",
                    Date = DateTime.Now,
                    MinDiameter = 10.5,
                    DPIReq = true,
                    Interpass = 5.0,
                    JointType = "ButtJoint",
                    MaterialGrd = "MaterialGrade123",
                    MaterialStd = "MaterialStandard456",
                    MPIReq = false,
                    NDTReq = true,
                    Notes = "Some notes for ",
                    Preheat = 100.0,
                    PWHT = 600.0,
                    RTReq = true,
                    MinThickness = 8.0,
                    UTReq = false,
                    VIReq = true,
                    WPSPreparerEID = "E2596"
                };
                db.WPS.Add(wPS);

                Console.WriteLine("\n\t> Db Save : wPS");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation

                WPS_Run wPS_Run = new WPS_Run(wPS)
                {
                    Amps = "200.0",
                    Classification = "ClassB",
                    FillerDia = 2.5,
                    HeatInput = "240.0",
                    Pass = "2",
                    ShieldGas = "18.0",
                    Side = 1,
                    Specification = "Spec456",
                    Supply = "Supply789",
                    Volts = "30.0",
                    WeldingPosition = "6G",
                    WeldingProcess = "GTAW",
                    WeldSpeed = "60.0",
                };
                db.WPS_Run.Add(wPS_Run);

                Console.WriteLine("\n\t> Db Save : wPS_Run");
                success = CRUD.SavetoDb(db, dbOperationStopwatch); // Database operation


                // ---------- Create NDT Record ---------- //


                NDT_Record nDT_Record = new NDT_Record(wPS)
                {
                    TestDate = DateTime.Now,
                    PNumber = "P123",
                    ReportNumber = "R456",
                    TestType = NDTTestType.RT,
                    WelderEID = "E2596"
                };
                db.NDT_Record.Add(nDT_Record);

                Console.WriteLine("\n\t> Db Save : nDT_Record");
                success = CRUD.SavetoDb(db, dbOperationStopwatch);
            }
            return success;
        }
    }
}

