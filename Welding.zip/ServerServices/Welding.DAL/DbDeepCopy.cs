﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Welding.DAL
{
    public static class DbDeepCopy
    {
        public static Attachment DeepCopy(Attachment from, Attachment to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "Attachment (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "Attachment (to) object cannot be null");
            }

            // Transfer Fields
            to.ServerPath = from.ServerPath;
            to.AttachmentType = from.AttachmentType;

            return to;
        }

        public static Consumable DeepCopy(Consumable from, Consumable to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "Consumable (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "Consumable (to) object cannot be null");
            }

            // Transfer Fields
            to.BatchNumber = from.BatchNumber;
            to.Classification = from.Classification;
            to.Manufacturer = from.Manufacturer;
            to.ProductName = from.ProductName;
            to.Specification = from.Specification;

            return to;
        }

        public static Datasheet DeepCopy(Datasheet from, Datasheet to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "Datasheet (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "Datasheet (to) object cannot be null");
            }

            // Transfer Fields
            to.HeatNumber = from.HeatNumber;
            to.IncludedAngle = from.IncludedAngle;
            to.JointDesign = from.JointDesign;
            to.JointType = from.JointType;
            to.MaterialGrd = from.MaterialGrd;
            to.MaterialStd = from.MaterialStd;
            to.MaterialThickness = from.MaterialThickness;
            to.Notes = from.Notes;
            to.PreheatTemp = from.PreheatTemp;
            to.RootFace = from.RootFace;
            to.RootGap = from.RootGap;
            to.TestDate = from.TestDate;
            to.WeldingPosition = from.WeldingPosition;
            to.WeldingProcess = from.WeldingProcess;
            to.WeldingStandard = from.WeldingStandard;
            to.WPQRNumber = from.WPQRNumber;
            to.WelderEID = from.WelderEID;
            to.WeldersName = from.WeldersName;
            to.ExpiryDate = from.ExpiryDate;

            return to;
        }

        public static Datasheet_Run DeepCopy(Datasheet_Run from, Datasheet_Run to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "Datasheet_Run (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "Datasheet_Run (to) object cannot be null");
            }

            // Transfer Fields
            to.ActualLength = from.ActualLength;
            to.Amps = from.Amps;
            to.CalculatedLength = from.CalculatedLength;
            to.HeatInput = from.HeatInput;
            to.FillerDia = from.FillerDia;
            to.Interpass = from.Interpass;
            to.Pass = from.Pass;
            to.PurgeGas = from.PurgeGas;
            to.ShieldGas = from.ShieldGas;
            to.Side = from.Side;
            to.Supply = from.Supply;
            to.Volts = from.Volts;
            to.WeldSpeed = from.WeldSpeed;
            to.WeldTime = from.WeldTime;

            return to;
        }

        public static ENumberList DeepCopy(ENumberList from, ENumberList to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "ENumberList (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "ENumberList (to) object cannot be null");
            }

            // Transfer Fields
            to.ENumber = from.ENumber;

            return to;
        }

        public static Job DeepCopy(Job from, Job to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "Job (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(from), "Job (to) object cannot be null");
            }

            // Transfer Fields
            to.Client = from.Client;
            to.ClientManagerEID = from.ClientManagerEID;
            to.Division = from.Division;
            to.ItemDescription = from.ItemDescription;
            to.JobNo = from.JobNo;
            to.PurchaseOrderNo = from.PurchaseOrderNo;
            to.QuoteNumber = from.QuoteNumber;

            return to;
        }

        public static NDT_Record DeepCopy(NDT_Record from, NDT_Record to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "NDT_Record (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "NDT_Record (to) object cannot be null");
            }

            // Transfer Fields
            to.TestDate = from.TestDate;
            to.PNumber = from.PNumber;
            to.ReportNumber = from.ReportNumber;
            to.TestType = from.TestType;
            to.WelderEID = from.WelderEID;
            to.WeldersName = from.WeldersName;
            to.ExpiryDate = from.ExpiryDate;
            to.WPSNumber = from.WPSNumber;

            return to;
        }

        public static NewWeldingForm DeepCopy(NewWeldingForm from, NewWeldingForm to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "NewWeldingForm (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "NewWeldingForm (to) object cannot be null");
            }

            // Transfer Fields
            to.ClientReqs = from.ClientReqs;
            to.ComponentDescription = from.ComponentDescription;
            to.DrawingNumber = from.DrawingNumber;
            to.DrawingProvided = from.DrawingProvided;
            to.HistoryProvided = from.HistoryProvided;
            to.JointConfiguration = from.JointConfiguration;
            to.MaterialGrd = from.MaterialGrd;
            to.MaterialStd = from.MaterialStd;
            to.MatrixOutput = from.MatrixOutput;
            to.NDTProvided = from.NDTProvided;
            to.NominalStrength = from.NominalStrength;
            to.ParentProvided = from.ParentProvided;
            to.PhotosProvided = from.PhotosProvided;
            to.ProceduresProvided = from.ProceduresProvided;
            to.PWHTProvided = from.PWHTProvided;
            to.QualityReqs = from.QualityReqs;
            to.RepairProvided = from.RepairProvided;
            to.SpecificationsProvided = from.SpecificationsProvided;
            to.SuggestedProcess = from.SuggestedProcess;
            to.SymbolsProvided = from.SymbolsProvided;
            to.WeldingCategory = from.WeldingCategory;
            to.WeldingStandard = from.WeldingStandard;
            to.WeldPosition = from.WeldPosition;
            to.WPSReference = from.WPSReference;
            to.Date = from.Date;
            to.ManagerReviewDate = from.ManagerReviewDate;
            to.CoverCosts = from.CoverCosts;
            to.ClientManagerEID = from.ClientManagerEID;
            to.Status = from.Status;

            return to;
        }
        public static OperationalReview DeepCopy(OperationalReview from, OperationalReview to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "OperationalReview (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "OperationalReview (to) object cannot be null");
            }

            // Transfer Fields
            to.Date = from.Date;
            to.Equipment = from.Equipment;
            to.EquipmentComments = from.EquipmentComments;
            to.ExtraCosts = from.ExtraCosts;
            to.Facilities = from.Facilities;
            to.FacilitiesComments = from.FacilitiesComments;
            to.GeneralComments = from.GeneralComments;
            to.PWHT = from.PWHT;
            to.PWHTComments = from.PWHTComments;
            to.Storage = from.Storage;
            to.StorageComments = from.StorageComments;
            to.SubComments = from.SubComments;
            to.SubContractors = from.SubContractors;
            to.ThirdParty = from.ThirdParty;
            to.ThirdPartyComments = from.ThirdPartyComments;
            to.TrainedStaff = from.TrainedStaff;
            to.TrainedStaffComments = from.TrainedStaffComments;
            to.Welders = from.Welders;
            to.WeldersAmount = from.WeldersAmount;
            to.WPS = from.WPS;
            to.WPSAmount = from.WPSAmount;
            to.WPQR = from.WPQR;
            to.WPQRAmount = from.WPQRAmount;
            to.OperationalReviewerEID = from.OperationalReviewerEID;

            return to;
        }

        public static TechnicalReview DeepCopy(TechnicalReview from, TechnicalReview to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "TechnicalReview (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "TechnicalReview (to) object cannot be null");
            }

            // Transfer Fields
            to.Considerations = from.Considerations;
            to.Date = from.Date;
            to.ExtraCosts = from.ExtraCosts;
            to.TechnicalReviewerEID = from.TechnicalReviewerEID;

            return to;
        }

        public static Visual_Inspection DeepCopy(Visual_Inspection from, Visual_Inspection to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "Visual_Inspection (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "Visual_Inspection (to) object cannot be null");
            }

            // Transfer Fields
            to.ArcStrike = from.ArcStrike;
            to.BurnThrough = from.BurnThrough;
            to.Control = from.Control;
            to.Cracks = from.Cracks;
            to.Crater = from.Crater;
            to.Date = from.Date;
            to.DrawingNumber = from.DrawingNumber;
            to.Final = from.Final;
            to.Fusion = from.Fusion;
            to.Initial = from.Initial;
            to.Location = from.Location;
            to.MaterialGrd = from.MaterialGrd;
            to.MaterialStd = from.MaterialStd;
            to.Notes = from.Notes;
            to.Penetration = from.Penetration;
            to.Porosity = from.Porosity;
            to.Procedure = from.Procedure;
            to.Profile = from.Profile;
            to.Qualification = from.Qualification;
            to.Reinforcement = from.Reinforcement;
            to.Repair = from.Repair;
            to.Satisfactory = from.Satisfactory;
            to.SerialNumbers = from.SerialNumbers;
            to.SuckBack = from.SuckBack;
            to.Undercut = from.Undercut;
            to.Weld_Id = from.Weld_Id;
            to.Welder_Id = from.Welder_Id;
            to.WeldingStandard = from.WeldingStandard;
            to.WeldLocation = from.WeldLocation;
            to.WeldMap = from.WeldMap;

            return to;
        }

        public static Welder_Qualification DeepCopy(Welder_Qualification from, Welder_Qualification to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "Welder_Qualification (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "Welder_Qualification (to) object cannot be null");
            }

            // Transfer Fields
            to.Status = from.Status;
            to.Pass = from.Pass;
            to.ForWPQR = from.ForWPQR;

            return to;
        }

        public static WeldingAction DeepCopy(WeldingAction from, WeldingAction to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "WeldingAction (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "WeldingAction (to) object cannot be null");
            }

            // Transfer Fields
            to.Status = from.Status;

            return to;
        }

        public static WPQR DeepCopy(WPQR from, WPQR to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "WPQR (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "WPQR (to) object cannot be null");
            }

            // Transfer Fields
            to.MinAmps = from.MinAmps;
            to.MaxAmps = from.MaxAmps;
            to.BackingComposition = from.BackingComposition;
            to.BackingFlowRate = from.BackingFlowRate;
            to.BeadType = from.BeadType;
            to.BendReq = from.BendReq;
            to.BMGrade = from.BMGrade;
            to.BMGroupPNumber = from.BMGroupPNumber;
            to.BMSpecfication = from.BMSpecfication;
            to.CoolingRate = from.CoolingRate;
            to.Current = from.Current;
            to.Date = from.Date;
            to.Diameter = from.Diameter;
            to.DPIReq = from.DPIReq;
            to.DTReq = from.DTReq;
            to.EFluxClassification = from.EFluxClassification;
            to.ElectricalNotes = from.ElectricalNotes;
            to.ElectrodeType = from.ElectrodeType;
            to.FillerANumber = from.FillerANumber;
            to.FillerClassification = from.FillerClassification;
            to.FillerFNumber = from.FillerFNumber;
            to.FillerForm = from.FillerForm;
            to.FillerNotes = from.FillerNotes;
            to.FillerSize = from.FillerSize;
            to.FillerSpecification = from.FillerSpecification;
            to.FluxTradeName = from.FluxTradeName;
            to.FluxType = from.FluxType;
            to.GasNotes = from.GasNotes;
            to.HardnessReq = from.HardnessReq;
            to.HeatingRate = from.HeatingRate;
            to.MinHeatInput = from.MinHeatInput;
            to.MaxTravelSpeed = from.MaxTravelSpeed;
            to.ImpactReq = from.ImpactReq;
            to.InterpassTemp = from.InterpassTemp;
            to.JointType = from.JointType;
            to.MacroReq = from.MacroReq;
            to.MaxThickness = from.MaxThickness;
            to.MetalTransfer = from.MetalTransfer;
            to.MPIReq = from.MPIReq;
            to.NDTReq = from.NDTReq;
            to.Notes = from.Notes;
            to.Oscillation = from.Oscillation;
            to.Other = from.Other;
            to.PassType = from.PassType;
            to.Polarity = from.Polarity;
            to.PositionNotes = from.PositionNotes;
            to.Position = from.Position;
            to.PreheatNotes = from.PreheatNotes;
            to.PreheatTemp = from.PreheatTemp;
            to.PWHTTemp = from.PWHTTemp;
            to.PWHTTime = from.PWHTTime;
            to.RTReq = from.RTReq;
            to.ShieldComposition = from.ShieldComposition;
            to.ShieldFlowRate = from.ShieldFlowRate;
            to.TechniqueNotes = from.TechniqueNotes;
            to.TensilReq = from.TensilReq;
            to.TESize = from.TESize;
            to.Thickness = from.Thickness;
            to.TrailingComposition = from.TrailingComposition;
            to.TrailingFlowRate = from.TrailingFlowRate;
            to.MinTravelSpeed = from.MinTravelSpeed;
            to.MaxTravelSpeed = from.MaxTravelSpeed;
            to.UTReq = from.UTReq;
            to.VIReq = from.VIReq;
            to.MinVolts = from.MinVolts;
            to.MaxVolts = from.MaxVolts;
            to.WeldingStandard = from.WeldingStandard;
            to.WeldingType = from.WeldingType;
            to.WeldProgression = from.WeldProgression;
            to.WMThickness = from.WMThickness;
            to.WPQRNumber = from.WPQRNumber;
            to.PWHTNotes = from.PWHTNotes;
            to.WPQRPreparerEID = from.WPQRPreparerEID;
            to.Status = from.Status;

            return to;
        }

        public static WPQRNumberList DeepCopy(WPQRNumberList from, WPQRNumberList to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "WPQRNumberList (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "WPQRNumberList (to) object cannot be null");
            }

            // Transfer Fields
            to.WPQRNumber = from.WPQRNumber;

            return to;
        }

        public static WPQR_Run DeepCopy(WPQR_Run from, WPQR_Run to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "WPQR_Run (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "WPQR_Run (to) object cannot be null");
            }

            // Transfer Fields
            to.Amps = from.Amps;
            to.Classification = from.Classification;
            to.FillerDia = from.FillerDia;
            to.HeatInput = from.HeatInput;
            to.Pass = from.Pass;
            to.ShieldGas = from.ShieldGas;
            to.Side = from.Side;
            to.Specification = from.Specification;
            to.Supply = from.Supply;
            to.Volts = from.Volts;
            to.WeldingPosition = from.WeldingPosition;
            to.WeldingProcess = from.WeldingProcess;
            to.WeldSpeed = from.WeldSpeed;

            return to;
        }

        public static WPS DeepCopy(WPS from, WPS to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "WPS (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "WPS (to) object cannot be null");
            }

            // Transfer Fields
            to.Date = from.Date;
            to.MinDiameter = from.MinDiameter;
            to.MaxDiameter = from.MaxDiameter;
            to.DPIReq = from.DPIReq;
            to.Interpass = from.Interpass;
            to.JointType = from.JointType;
            to.MaterialGrd = from.MaterialGrd;
            to.MaterialStd = from.MaterialStd;
            to.MaterialPNo = from.MaterialPNo;
            to.MPIReq = from.MPIReq;
            to.NDTReq = from.NDTReq;
            to.Notes = from.Notes;
            to.Preheat = from.Preheat;
            to.PWHT = from.PWHT;
            to.RTReq = from.RTReq;
            to.MinThickness = from.MinThickness;
            to.MaxThickness = from.MaxThickness;
            to.UTReq = from.UTReq;
            to.VIReq = from.VIReq;
            to.WPSNumber = from.WPSNumber;
            to.WPSPreparerEID = from.WPSPreparerEID;
            to.Status = from.Status;
            to.PrepMethod = from.PrepMethod;
            to.GougingMethod = from.GougingMethod;
            to.VoltTol = from.VoltTol;
            to.AmpTol = from.AmpTol;
            to.SpeedTol = from.SpeedTol;
            to.ShieldTol = from.ShieldTol;

            return to;
        }

        public static WPSNumberList DeepCopy(WPSNumberList from, WPSNumberList to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "WPSNumberList (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "WPSNumberList (to) object cannot be null");
            }

            // Transfer Fields
            to.WPSNumber = from.WPSNumber;

            return to;
        }
        public static WPS_Run DeepCopy(WPS_Run from, WPS_Run to)
        {
            if (from == null)
            {
                throw new ArgumentNullException(nameof(from), "WPS_Run (from) object cannot be null");
            }

            if (to == null)
            {
                throw new ArgumentNullException(nameof(to), "WPS_Run (to) object cannot be null");
            }

            // Transfer Fields
            to.Amps = from.Amps;
            to.Classification = from.Classification;
            to.FillerDia = from.FillerDia;
            to.HeatInput = from.HeatInput;
            to.Pass = from.Pass;
            to.ShieldGas = from.ShieldGas;
            to.Side = from.Side;
            to.Specification = from.Specification;
            to.Supply = from.Supply;
            to.Volts = from.Volts;
            to.WeldingPosition = from.WeldingPosition;
            to.WeldingProcess = from.WeldingProcess;
            to.WeldSpeed = from.WeldSpeed;
            to.AmpsExact = from.AmpsExact;
            to.VoltsExact = from.VoltsExact;
            to.WeldSpeedExact = from.WeldSpeedExact;
            to.HeatInputExact = from.HeatInputExact;
            to.ShieldGasExact = from.ShieldGasExact;

            return to;
        }
    }
}
