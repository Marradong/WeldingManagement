﻿using ApiClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Welding.DAL;

namespace DbTester
{
    public class Logger
    {
        public static void Log(string message)
        {
            Console.WriteLine("EF Message: {0} ", message);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {

            ConsoleMenu();

        }

        static void ConsoleMenu()
        {


            // Define some colors for use in the menu
            ConsoleColor menuColor = ConsoleColor.Cyan;
            ConsoleColor errorColor = ConsoleColor.Red;
            ConsoleColor successColor = ConsoleColor.Green;

            while (true)
            {
                Console.Clear();
                PrintColored("Main Menu", menuColor);
                PrintColored("1. Initialize Db", menuColor);
                PrintColored("2. Variable Test Function", menuColor);
                PrintColored("3. Seed Data", menuColor);
                PrintColored("4. Seed Data Via API", menuColor);
                PrintColored("5. Display Job Hierarchy", menuColor);
                PrintColored("6. Exit", menuColor);
                Console.Write("Select an option: ");

                var choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                    InitaliseDb();
                    PrintColored("Database initialized successfully.", successColor);
                    break;
                    case "2":

                        Type typeStart = typeof(NewWeldingForm);
                        Console.WriteLine($"Type: {typeStart}");

                        string typeString = typeStart.FullName;
                        Console.WriteLine($"Type as string: {typeString}");

                        string typeAssembly = typeStart.Assembly.FullName;
                        Console.WriteLine($"Assembly full name: {typeAssembly}");

                        Type typeEnd = Type.GetType(typeString);
                        Console.WriteLine($"Type: {typeEnd}");


                        PrintColored("Database initialized successfully.", successColor);
                    break;
                    case "3":
                    SeedData();
                    PrintColored("Data seeded successfully.", successColor);
                    break;
                    case "4":
                    SeedDataAPI();
                    PrintColored("Data seeded successfully.", successColor);
                    break;
                    case "5":
                    DisplayJobHierarchy();
                    break;
                    case "6":
                    return; // Exit application
                    default:
                    PrintColored("Invalid option, please try again.", errorColor);
                    break;
                }
                PrintColored("Press <any key> to continue...", menuColor);
                Console.ReadKey();
            }
        }

        static void PrintColored(string message, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(message);
            Console.ResetColor();
        }


        static void InitaliseDb()
        {
            using (var db = new EFWeldingManagement())
            {
                db.Database.Log = Logger.Log;

                db.Database.Delete();
                Console.WriteLine("Deleted DB\r\n");

                db.Database.CreateIfNotExists();
                Console.WriteLine("Created DB\r\n");

               
                string connectionString = ConfigurationManager.ConnectionStrings["WeldingManagementSystemDb"].ConnectionString;
                SqlConnectionStringBuilder connectionStringBuilder = new SqlConnectionStringBuilder(connectionString);

                string DbName = connectionStringBuilder.InitialCatalog;
                Console.WriteLine($"Db: {DbName}");
            }
        }

        static void MigrateDb()
        {
            using (var db = new EFWeldingManagement())
            {
                db.Database.Log = Logger.Log;

                db.Database.CreateIfNotExists();
                Console.WriteLine("Created DB\r\n");

                db.Database.


                string connectionString = ConfigurationManager.ConnectionStrings["WeldingManagementSystemDb"].ConnectionString;
                SqlConnectionStringBuilder connectionStringBuilder = new SqlConnectionStringBuilder(connectionString);

                string DbName = connectionStringBuilder.InitialCatalog;
                Console.WriteLine($"Db: {DbName}");
            }
        }


        static void SeedData()
        {
            Console.WriteLine(Welding.DAL.DbSeed.Seed()? "Database seed successfully.": " Database Seeed <ERROR>", Color.GreenYellow);
        }

        static void SeedDataAPI()
        {
            ClientDbSeed.Seed();
            Console.WriteLine("Database seed successfully.");
        }

        static void DisplayJobHierarchy()
        {
            using (var db = new EFWeldingManagement())
            {
                var jobs = CRUD.ReadJobs(db).Jobs;

                Console.WriteLine("Displaying Job Hierarcy", Color.White);
                Console.WriteLine($"\tJob Qty : {jobs.Count}", Color.AntiqueWhite);

                foreach (var job in jobs)
                {
                    PrintProperties(job, 0);
                }
            }
        }

        private static readonly Dictionary<Type, ConsoleColor> TypeColors = new Dictionary<Type, ConsoleColor>
        {
            { typeof(Job), ConsoleColor.Yellow },
            { typeof(WeldingAction), ConsoleColor.Green },
            { typeof(Welder_Qualification), ConsoleColor.Blue },
            { typeof(WPQR), ConsoleColor.Cyan },
            { typeof(NewWeldingForm), ConsoleColor.DarkYellow },
        };

        static void PrintProperties(object obj, int indent)
        {
            if (obj == null) return;

            string indentString = new string(' ', indent);
            Type objType = obj.GetType();

            // Set color for the current object type
            Console.ForegroundColor = TypeColors.TryGetValue(objType, out ConsoleColor color) ? color : ConsoleColor.White;
            Console.WriteLine($"{indentString}{objType.Name}:");
            Console.ResetColor();

            PropertyInfo[] properties = objType.GetProperties();
            foreach (PropertyInfo property in properties)
            {
                object propValue = property.GetValue(obj, null);
                var elems = propValue as IList<object> ?? new List<object>();

                if (property.PropertyType == typeof(string) || !property.PropertyType.IsClass || property.PropertyType == typeof(DateTime))
                {
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine($"{indentString}  {property.Name}: {propValue}");
                    Console.ResetColor();
                }
                else if (elems.Count > 0) // The property is a list
                {
                    foreach (var item in elems)
                    {
                        PrintProperties(item, indent + 2);
                    }
                }
                else if (propValue != null) // The property is a class but not a string
                {
                    PrintProperties(propValue, indent + 2);
                }
            }
        }

    }
}

