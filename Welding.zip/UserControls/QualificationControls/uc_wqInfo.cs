﻿using ApiClient;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.DatasheetControls
{
    public partial class uc_wqInfo : Wisej.Web.UserControl
    {
        private up_hmSave up_hmSave1;
        private Panel overlayPanel;

        public uc_wqInfo()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks next button on info screen")]
        public event EventHandler btnInfoNextClick;
        private void btnInfoNext_Click(object sender, EventArgs e)
        {
            if (cboInfoWelder.SelectedItem == null ||
                (cbInfoWPQR.Checked && string.IsNullOrEmpty(txtInfoWPQR.Text)) ||
                (!cbInfoWPQR.Checked && cboInfoWPQR.SelectedItem == null))
            {
                return;
            }

            Save_Action();
            Update_Status();

            btnInfoNextClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on info screen")]
        public event EventHandler btnInfoHomeClick;
        protected void btnInfoHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnInfoHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on info screen")]
        public event EventHandler btnInfoBackClick;
        private void btnInfoBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnInfoBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnInfoBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            wq.Status = Actions.WelderTestParameters;

            ApiCalls.UpdateWelderQualification(wq.Welder_QualificationId, wq);

            this.Tag = new Tag(ApiCalls.ReadWelderQualification(wq.Welder_QualificationId), TagType.Welder_Qualification);
        }

        private void Save_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            if (thisTag.getTagObject() is WeldingAction)
            {
                WeldingAction wa = ApiCalls.ReadWeldingAction(((WeldingAction)thisTag.getTagObject()).WeldingActionId);

                Welder_Qualification newWQ = ApiCalls.CreateWelderQualification(wa.WeldingActionId, new Welder_Qualification() { Status = Actions.WelderTestInformation });

                this.Tag = new Tag(ApiCalls.ReadWelderQualification(newWQ.Welder_QualificationId), TagType.Welder_Qualification);

                thisTag = (Tag)this.Tag;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            wq.ForWPQR = cbInfoWPQR.Checked;

            ApiCalls.UpdateWelderQualification(wq.Welder_QualificationId, wq);

            Datasheet datasheet = FillDatasheet();

            if (wq.Datasheet == null)
            {
                ApiCalls.CreateDatasheet(wq.Welder_QualificationId, datasheet);
            }
            else
            {
                ApiCalls.UpdateDatasheet(wq.Datasheet.DatasheetId, datasheet);
            }
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            string[] eNumbers = QAWebApiClient.ApiCalls.GetPeople().Select(ppl => ppl.EmployeeNumber).ToArray();
            string[] wpqrNumbers = ApiCalls.ReadWPQRs().Select(wpqr => wpqr.WPQRNumber).ToArray();

            cboInfoWelder.Items.Clear();
            cboInfoWPQR.Items.Clear();

            cboInfoWelder.Items.AddRange(eNumbers);
            cboInfoWPQR.Items.AddRange(wpqrNumbers);

            cboInfoWelder.Refresh();
            cboInfoWPQR.Refresh();

            if (thisTag.getTagObject() is Welder_Qualification)
            {
                Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

                txtInfoJob.Text = wq.WeldingAction.Job.JobNo?.ToString() ?? "";

                if (wq.Datasheet != null)
                {
                    int idxWelder = cboInfoWelder.Items.IndexOf(wq.Datasheet.WelderEID);

                    if (idxWelder != -1)
                    {
                        cboInfoWelder.SelectedIndex = idxWelder;
                    }

                    cboInfoWelder.Refresh();

                    if (wq.ForWPQR == false)
                    {
                        cbInfoWPQR.Checked = false;

                        int idxWPQR = cboInfoWPQR.Items.IndexOf(wq.Datasheet.WPQRNumber);

                        if (idxWPQR != -1)
                        {
                            cboInfoWPQR.SelectedIndex = idxWPQR;
                        }

                        cboInfoWPQR.Refresh();
                    }
                    else
                    {
                        cbInfoWPQR.Checked = true;

                        if (wpqrNumbers.Length > 0)
                        {
                            txtInfoWPQR.Text = wq.Datasheet.WPQRNumber.ToString() ?? (wpqrNumbers.Max(w => int.TryParse(w, out int i) ? i : 0) + 1).ToString();
                        }
                        else
                        {
                            txtInfoWPQR.Text = wq.Datasheet.WPQRNumber.ToString() ?? "1000";
                        }
                    }

                    dtpInfoDate.Value = wq.Datasheet.TestDate ?? DateTime.Now;

                    txtInfoStandard.Text = wq.Datasheet.WeldingStandard?.ToString() ?? "";
                    txtInfoProcess.Text = wq.Datasheet.WeldingProcess?.ToString() ?? "";
                    txtInfoDesign.Text = wq.Datasheet.JointDesign?.ToString() ?? "";
                    txtInfoFace.Text = wq.Datasheet.RootFace?.ToString() ?? "";
                    txtInfoType.Text = wq.Datasheet.JointType?.ToString() ?? "";
                    txtInfoGap.Text = wq.Datasheet.RootGap?.ToString() ?? "";
                    txtInfoPosition.Text = wq.Datasheet.WeldingPosition?.ToString() ?? "";
                    txtInfoAngle.Text = wq.Datasheet.IncludedAngle?.ToString() ?? "";
                    txtInfoPreheat.Text = wq.Datasheet.PreheatTemp?.ToString() ?? "";
                    txtInfoNotes.Text = wq.Datasheet.Notes?.ToString() ?? "";

                    txtInfoMatStandard.Text = wq.Datasheet.MaterialStd?.ToString() ?? "";
                    txtInfoMatGrade.Text = wq.Datasheet.MaterialGrd?.ToString() ?? "";
                    txtInfoMatThickness.Text = wq.Datasheet.MaterialThickness?.ToString() ?? "";
                    txtInfoHeatNo.Text = wq.Datasheet.HeatNumber?.ToString() ?? "";
                }
            }
            else if (thisTag.getTagObject() is WeldingAction)
            {
                WeldingAction wa = ApiCalls.ReadWeldingAction(((WeldingAction)thisTag.getTagObject()).WeldingActionId);

                txtInfoJob.Text = wa.Job.JobNo?.ToString() ?? "";

                txtInfoWPQR.Text = "";
                dtpInfoDate.Value = DateTime.Now;

                txtInfoStandard.Text = "";
                txtInfoProcess.Text = "";
                txtInfoDesign.Text = "";
                txtInfoFace.Text = "";
                txtInfoType.Text = "";
                txtInfoGap.Text = "";
                txtInfoPosition.Text = "";
                txtInfoAngle.Text = "";
                txtInfoPreheat.Text = "";
                txtInfoNotes.Text = "";

                txtInfoMatStandard.Text = "";
                txtInfoMatGrade.Text = "";
                txtInfoMatThickness.Text = "";
                txtInfoHeatNo.Text = "";

                cbInfoWPQR.Checked = true;

                if (wpqrNumbers.Length > 0)
                {
                    txtInfoWPQR.Text = (wpqrNumbers.Max(w => int.TryParse(w, out int i) ? i : 0) + 1).ToString();
                }
                else
                {
                    txtInfoWPQR.Text = "1000";
                }
            }

            ChangeInputWPQR();
        }

        private void uc_dsInfo_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private void cbInfoWPQR_CheckedChanged(object sender, EventArgs e)
        {
            ChangeInputWPQR();
        }

        private void ChangeInputWPQR()
        {
            int wdt1 = 100;
            int wdt2 = 0;

            bool vbl1 = true;
            bool vbl2 = false;

            if (cbInfoWPQR.Checked)
            {
                vbl1 = false;
                vbl2 = true;

                wdt1 = 0;
                wdt2 = 100;
            }

            cboInfoWPQR.Visible = vbl1;
            txtInfoWPQR.Visible = vbl2;

            tlpInfoWPQR.ColumnStyles[tlpInfoWPQR.GetColumn(cboInfoWPQR)].SizeType = SizeType.Percent;
            tlpInfoWPQR.ColumnStyles[tlpInfoWPQR.GetColumn(cboInfoWPQR)].Width = wdt1;

            tlpInfoWPQR.ColumnStyles[tlpInfoWPQR.GetColumn(txtInfoWPQR)].SizeType = SizeType.Percent;
            tlpInfoWPQR.ColumnStyles[tlpInfoWPQR.GetColumn(txtInfoWPQR)].Width = wdt2;
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }

        private Datasheet FillDatasheet()
        {
            Datasheet datasheet = new Datasheet();

            if (!cbInfoWPQR.Checked && cboInfoWPQR.SelectedItem != null) 
            { 
                datasheet.WPQRNumber = short.TryParse(cboInfoWPQR.Text, out short wpqrNo) ? wpqrNo : (short)0;
            }
            else if (txtInfoWPQR.Text != null)
            {
                datasheet.WPQRNumber = short.TryParse(txtInfoWPQR.Text, out short wpqrNo) ? wpqrNo : (short)0;
            }

            if (dtpInfoDate.Value != null)
            {
                datasheet.TestDate = dtpInfoDate.Value;
                datasheet.ExpiryDate = dtpInfoDate.Value.AddMonths(6);
            }


            if (txtInfoStandard.Text != null)
                datasheet.WeldingStandard = txtInfoStandard.Text;

            if (txtInfoProcess.Text != null)
                datasheet.WeldingProcess = txtInfoProcess.Text;

            if (txtInfoDesign.Text != null)
                datasheet.JointDesign = txtInfoDesign.Text;

            if (txtInfoFace.Text != null)
                datasheet.RootFace = double.TryParse(txtInfoFace.Text, out double rootFace) ? rootFace : (double)0;

            if (txtInfoType.Text != null)
                datasheet.JointType = txtInfoType.Text;

            if (txtInfoGap.Text != null)
                datasheet.RootGap = double.TryParse(txtInfoGap.Text, out double rootGap) ? rootGap : (double)0;

            if (txtInfoPosition.Text != null)
                datasheet.WeldingPosition = txtInfoPosition.Text;

            if (txtInfoAngle.Text != null)
                datasheet.IncludedAngle = double.TryParse(txtInfoAngle.Text, out double angle) ? angle : (double)0;

            if (txtInfoPreheat.Text != null)
                datasheet.PreheatTemp = double.TryParse(txtInfoPreheat.Text, out double preheat) ? preheat : (double)0;

            if (txtInfoNotes.Text != null)
                datasheet.Notes = txtInfoNotes.Text;

            if (txtInfoMatStandard.Text != null)
                datasheet.MaterialStd = txtInfoMatStandard.Text;

            if (txtInfoMatGrade.Text != null)
                datasheet.MaterialGrd = txtInfoMatGrade.Text;

            if (txtInfoMatThickness.Text != null)
                datasheet.MaterialThickness = double.TryParse(txtInfoMatThickness.Text, out double matThickness) ? matThickness : (double)0;

            if (txtInfoHeatNo.Text != null)
                datasheet.HeatNumber = txtInfoHeatNo.Text;

            if (cboInfoWelder.SelectedItem != null)
            {
                datasheet.WelderEID = cboInfoWelder.SelectedItem.ToString();
                datasheet.WeldersName = QAWebApiClient.ApiCalls.GetPerson(cboInfoWelder.SelectedItem.ToString()).EmployeeName ?? "";
            }

            return datasheet;
        }

        private void label62_DoubleClick(object sender, EventArgs e)
        {
            if (UIFormatting.adminUsers.Contains(Application.Cookies["EmployeeNumber"].TrimStart('E')))
            {
                txtInfoStandard.Text = "AS 1554.1";
                txtInfoDesign.Text = "Double Bevel Butt";
                txtInfoType.Text = "Double Bevel Butt";
                txtInfoPosition.Text = "1G";
                txtInfoPreheat.Text = "0";
                txtInfoProcess.Text = "FCAW";
                txtInfoFace.Text = "5";
                txtInfoGap.Text = "3";
                txtInfoAngle.Text = "30";
                txtInfoNotes.Text = "Welding Test for Demonstration Purposes";
                txtInfoMatStandard.Text = "AS 3678";
                txtInfoMatGrade.Text = "GR 350";
                txtInfoMatThickness.Text = "15";
                txtInfoHeatNo.Text = "TEST#123";
            }
        }
    }
}
