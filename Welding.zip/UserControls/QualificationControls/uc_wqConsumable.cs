﻿using ApiClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Welding.DAL;
using Wisej.Web;

namespace WeldingManagement.UserControls.DatasheetControls
{
    public partial class uc_wqConsumable : Wisej.Web.UserControl
    {
        public uc_wqConsumable()
        {
            InitializeComponent();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks next button on consumable screen")]
        public event EventHandler btnConsumableNextClick;
        private void btnConsumableNext_Click(object sender, EventArgs e)
        {
            if (lvConsumables.Items.Count <= 0)
            {
                return;
            }

            Update_Status();

            btnConsumableNextClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on consumable screen")]
        public event EventHandler btnConsumableHomeClick;
        private void btnConsumableHome_Click(object sender, EventArgs e)
        {
            btnConsumableHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on consumable screen")]
        public event EventHandler btnConsumableBackClick;
        private void btnConsumableBack_Click(object sender, EventArgs e)
        {
            btnConsumableBackClick?.Invoke(this, e);
        }
        #endregion

        private void btnConsumableAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtConsumableManufacturer.Text) ||
                string.IsNullOrEmpty(txtConsumableProduct.Text) ||
                string.IsNullOrEmpty(txtConsumableSpecification.Text) ||
                string.IsNullOrEmpty(txtConsumableClassification.Text) ||
                string.IsNullOrEmpty(txtConsumableBatchNo.Text))
            {
                return;
            }

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || !(thisTag.getTagObject() is Welder_Qualification))
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            Consumable consumable = new Consumable(wq.Datasheet)
            {
                Manufacturer = txtConsumableManufacturer.Text,
                ProductName = txtConsumableProduct.Text,
                Specification = txtConsumableSpecification.Text,
                Classification = txtConsumableClassification.Text,
                BatchNumber = txtConsumableBatchNo.Text
            };

            ApiCalls.CreateConsumable(wq.Datasheet.DatasheetId, consumable);

            this.Tag = new Tag(ApiCalls.ReadWelderQualification(wq.Welder_QualificationId), TagType.Welder_Qualification);

            Load_Consumables();
        }

        private void btnConsumableAdd_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Consumables();
        }

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            wq.Status = Actions.WeldSequence;

            ApiCalls.UpdateWelderQualification(wq.Welder_QualificationId, wq);

            this.Tag = new Tag(ApiCalls.ReadWelderQualification(wq.Welder_QualificationId), TagType.Welder_Qualification);
        }

        private void Load_Consumables()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            lvConsumables.Items.Clear();
            Clear_Txts();

            if (wq != null)
            {
                List<Consumable> consumables = wq.Datasheet.Consumables.ToList();

                foreach (Consumable co in consumables)
                {
                    Add_lvRow(co);
                }
            }

            lvConsumables.Refresh();
        }

        private void Clear_Txts()
        {
            txtConsumableManufacturer.Text = "";
            txtConsumableProduct.Text = "";
            txtConsumableSpecification.Text = "";
            txtConsumableClassification.Text = "";
            txtConsumableBatchNo.Text = "";
        }

        private void Add_lvRow(Consumable co)
        {
            ListViewItem lvItem = new ListViewItem(new string[]
            {
                co.Manufacturer?.ToString() ?? "",
                co.ProductName?.ToString() ?? "",
                co.Specification?.ToString() ?? "",
                co.Classification?.ToString() ?? "",
                co.BatchNumber?.ToString() ?? ""
            })
            { 
                Tag = co
            };
            lvConsumables.Items.Add(lvItem);
        }

        private void btnConsumableDelete_DoubleClick(object sender, EventArgs e)
        {
            if (lvConsumables.SelectedItems.Count != 1)
            {
                return;
            }

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            Consumable cmToDelete = (Consumable)lvConsumables.Items[lvConsumables.SelectedIndex].Tag;

            if (cmToDelete == null)
            {
                return;
            }

            ApiCalls.DeleteConsumable(cmToDelete.ConsumableId);

            this.Tag = new Tag(ApiCalls.ReadWelderQualification(wq.Welder_QualificationId), TagType.Welder_Qualification);

            Load_Consumables();
        }

        private void lvConsumables_ItemDoubleClick(object sender, ItemClickEventArgs e)
        {
            Consumable cmToCopy = (Consumable)e.Item.Tag;

            if (cmToCopy == null)
            {
                return;
            }

            txtConsumableManufacturer.Text = cmToCopy.Manufacturer?.ToString() ?? "";
            txtConsumableProduct.Text = cmToCopy.ProductName?.ToString() ?? "";
            txtConsumableSpecification.Text = cmToCopy.Specification?.ToString() ?? "";
            txtConsumableClassification.Text = cmToCopy.Classification?.ToString() ?? "";
            txtConsumableBatchNo.Text = cmToCopy.BatchNumber?.ToString() ?? "";
        }

        private void lvConsumables_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnConsumableDelete.Visible = lvConsumables.SelectedItems.Count > 0;
        }

        private void lvConsumables_Resize(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            UIFormatting.ResizeColumnsFor(lvConsumables);
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }

        private void label78_DoubleClick(object sender, EventArgs e)
        {
            if (UIFormatting.adminUsers.Contains(Application.Cookies["EmployeeNumber"].TrimStart('E')))
            {
                txtConsumableManufacturer.Text = "Cigweld";
                txtConsumableProduct.Text = "Autocraft LW1-6";
                txtConsumableSpecification.Text = "AS/NZS 14341";
                txtConsumableClassification.Text = "AS/NZS 14341";
                txtConsumableBatchNo.Text = "TEST#456";
            }
        }
    }
}
