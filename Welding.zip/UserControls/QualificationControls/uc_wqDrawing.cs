﻿using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Drawing;
using Wisej.Web;
using System.ComponentModel;
using ApiClient;
using Welding.DAL;
using System.Web;
using static WeldingManagement.FileManagement;
using static WeldingManagement.DrawingFunctionality;
using System.IO;
using System.Linq;
using System.Drawing.Imaging;
using System.Diagnostics;
using System.Collections;
using Microsoft.Win32;

namespace WeldingManagement.UserControls.DatasheetControls
{
    public partial class uc_wqDrawing : Wisej.Web.UserControl
    {
        #region Drawing Functionality

        private bool mouseMoving = false;
        private bool viewMode = false;
        private Point start;
        private Point current;
        private RotatedRectangle window;
        private int weldCounter = 0;
        private List<WeldingShape> drawnShapes = new List<WeldingShape>();
        private bool resizing = false;
        private int? activeAnchorIndex = null;
        private WeldingShape activeShape = null;

        private void DrawGrid(Graphics g)
        {
            g.Clear(Color.White);

            if (!int.TryParse(txtDrawingGrid.Text, out int gridSpacing) || !cbDrawingSnap.Checked)
            {
                return;
            }

            for (int x = 0; x < pbDrawingWeldSequence.Width; x += gridSpacing)
            {
                for (int y = 0; y < pbDrawingWeldSequence.Height; y += gridSpacing)
                {
                    g.FillEllipse(Brushes.DarkGray, x - 1, y - 1, 2, 2);
                }
            }
        }

        private void DrawExisting(Graphics g)
        {
            GraphicsPath path;
            int xIdx, wdt, hgt;

            foreach (WeldingShape shape in drawnShapes)
            {
                switch (shape.ShapeType)
                {
                    case ShapeType.Rectangle:
                        DrawRectangle(g, shape.BoundingBox, shape.Rotation, shape.BoundingBox.TopLeft);
                        break;

                    case ShapeType.Ellipse:
                        DrawEllipse(g, shape.BoundingBox, shape.Rotation, shape.RunId.ToString(), shape.BoundingBox.TopLeft);
                        break;

                    case ShapeType.Bevel:
                        path = BevelPath(shape.ShapePath, shape.Double);

                        xIdx = shape.Double ? 3 : 2;

                        wdt = Math.Abs(shape.ShapePath[1].X - shape.ShapePath[xIdx].X);
                        hgt = Math.Abs(shape.ShapePath[0].Y - shape.ShapePath[1].Y);

                        DrawPath(g, path, shape.Rotation, shape.BoundingBox.TopLeft, wdt, hgt, shape.HFlip, shape.VFlip);
                        break;

                    case ShapeType.Groove:
                        float sweepAngle = 90 - (float)shape.IncludedAngle;

                        Point arcCentre2 = shape.Double ? DoubleGrooveArcCentre2(shape) : new Point();

                        path = GroovePath(shape.ShapePath, shape.ArcCentre, arcCentre2, shape.Radius, sweepAngle, shape.Rotation, shape.Double);

                        xIdx = shape.Double ? 4 : 2;

                        wdt = Math.Abs(shape.ShapePath[1].X - shape.ShapePath[xIdx].X);
                        hgt = Math.Abs(shape.ShapePath[0].Y - shape.ShapePath[1].Y);

                        DrawPath(g, path, shape.Rotation, shape.BoundingBox.TopLeft, wdt, hgt, shape.HFlip, shape.VFlip);
                        break;
                }
            }
        }

        private void DrawNew(Graphics g)
        {
            if (!int.TryParse(txtDrawingGrid.Text, out int gridSpacing) || !mouseMoving || resizing)
            {
                return;
            }

            float.TryParse(txtDrawingRotation.Text, out float rotateAng);
            double.TryParse(txtDrawingThickness.Text, out double thk);
            double.TryParse(txtDrawingRootFace.Text, out double rtFace);
            double.TryParse(txtDrawingAngle.Text, out double ang);
            double.TryParse(txtDrawingRadius.Text, out double rad);

            if (cbDrawingSnap.Checked)
            {
                int snapStartX = (int)Math.Round((double)(start.X / gridSpacing)) * gridSpacing;
                int snapStartY = (int)Math.Round((double)(start.Y / gridSpacing)) * gridSpacing;
                int snapCurrentX = (int)Math.Round((double)(current.X / gridSpacing)) * gridSpacing;
                int snapCurrentY = (int)Math.Round((double)(current.Y / gridSpacing)) * gridSpacing;

                window = new RotatedRectangle(snapStartX, snapStartY, snapCurrentX, snapCurrentY, rotateAng);
            }
            else
            {
                window = new RotatedRectangle(start.X, start.Y, current.X, current.Y, rotateAng);
            }

            double rfHgt = rtFace / thk * window.Height;

            if (rbDrawingRectangle.Checked)
            {
                DrawRectangle(g, window, rotateAng, window.TopLeft);
            }
            else if (rbDrawingWeld.Checked)
            {
                DrawEllipse(g, window, rotateAng, (weldCounter + 1).ToString(), window.TopLeft);
            }
            else if (rbDrawingBevel.Checked && txtDrawingRootFace.Text != "" && txtDrawingAngle.Text != "" && txtDrawingThickness.Text != "")
            {
                List<Point> shapePath;

                if (cbDrawingDouble.Checked)
                {
                    shapePath = DoubleBevelPoints(window, rfHgt, ang);
                }
                else
                {
                    shapePath = BevelPoints(window, rfHgt, ang);
                }

                GraphicsPath path = BevelPath(shapePath, cbDrawingDouble.Checked);

                DrawPath(g, path, rotateAng, window.TopLeft, window.Width, window.Height, cbDrawingFlipH.Checked, cbDrawingFlipV.Checked);
            }
            else if (rbDrawingGroove.Checked && txtDrawingRootFace.Text != "" && txtDrawingAngle.Text != "" && txtDrawingThickness.Text != "" && txtDrawingRadius.Text != "")
            {
                Tuple<List<Point>, Point> grooveTpl;

                float sweepAngle = 90 - (float)ang;

                double scaledRad = rad / thk * window.Height;

                double rx = scaledRad * Math.Cos(ang * Math.PI / 180);
                double r_ry = scaledRad - scaledRad * Math.Sin(ang * Math.PI / 180);

                if (cbDrawingDouble.Checked)
                {
                    grooveTpl = DoubleGroovePoints(window, rfHgt, ang, scaledRad, rx, r_ry);
                }
                else
                {
                    grooveTpl = GroovePoints(window, rfHgt, ang, scaledRad, rx, r_ry);
                }

                Point arcCentre2 = cbDrawingDouble.Checked ? DoubleGrooveArcCentre2(grooveTpl.Item2, window) : new Point();

                GraphicsPath path = GroovePath(grooveTpl.Item1, grooveTpl.Item2, arcCentre2, scaledRad, sweepAngle, rotateAng, cbDrawingDouble.Checked);

                DrawPath(g, path, rotateAng, window.TopLeft, window.Width, window.Height, cbDrawingFlipH.Checked, cbDrawingFlipV.Checked);
            }
        }

        private void DrawAnchors(Graphics g)
        {
            if (!rbDrawingEdit.Checked)
            {
                return;
            }

            foreach (var shape in drawnShapes)
            {
                Brush thickBrush = new SolidBrush(Color.Red);
                int dotSize = 5;

                foreach (var anchor in shape.AnchorPoints)
                {
                    g.FillEllipse(thickBrush, anchor.X - dotSize / 2, anchor.Y - dotSize / 2, dotSize, dotSize);
                }

                thickBrush.Dispose();
            }
        }

        private void DrawWeldDiagram(Graphics g)
        {
            DrawGrid(g);

            DrawExisting(g);

            DrawNew(g);

            DrawAnchors(g);
        }

        private void AddShape()
        {
            List<Point> shapePath;

            mouseMoving = false;

            if (window == null)
            {
                return;
            }

            float.TryParse(txtDrawingRotation.Text, out float rotateAng);
            int.TryParse(txtDrawingGrid.Text, out int gridSpacing);
            double.TryParse(txtDrawingThickness.Text, out double thk);
            double.TryParse(txtDrawingRootFace.Text, out double rtFace);
            double.TryParse(txtDrawingAngle.Text, out double ang);
            double.TryParse(txtDrawingRadius.Text, out double rad);

            double rfHgt = rtFace / thk * window.Height;

            #region Record New Shape
            if (rbDrawingRectangle.Checked || rbDrawingWeld.Checked)
            {
                shapePath = new List<Point>{window.TopLeft, window.TopRight, window.BottomRight, window.BottomLeft};

                if (rbDrawingRectangle.Checked)
                {
                    WeldingShape newRect = new WeldingShape(ShapeType.Rectangle, shapePath, rotateAng, window);
                    drawnShapes.Add(newRect);
                }
                else if (rbDrawingWeld.Checked)
                {
                    weldCounter++;
                    WeldingShape newEllipse = new WeldingShape(ShapeType.Ellipse, shapePath, rotateAng, weldCounter, window);
                    drawnShapes.Add(newEllipse);
                }
            }
            else if (rbDrawingBevel.Checked && txtDrawingRootFace.Text != "" && txtDrawingAngle.Text != "" && txtDrawingThickness.Text != "")
            {
                if (cbDrawingDouble.Checked)
                {
                    shapePath = DoubleBevelPoints(window, rfHgt, ang);
                }
                else
                {
                    shapePath = BevelPoints(window, rfHgt, ang);
                }

                WeldingShape newBevel = new WeldingShape(ShapeType.Bevel, shapePath, rotateAng, rtFace, ang, thk, cbDrawingFlipH.Checked, cbDrawingFlipV.Checked, cbDrawingDouble.Checked, window);
                drawnShapes.Add(newBevel);
            }
            else if (rbDrawingGroove.Checked && txtDrawingRootFace.Text != "" && txtDrawingAngle.Text != "" && txtDrawingThickness.Text != "" && txtDrawingRadius.Text != "")
            {
                Tuple<List<Point>, Point> grooveTpl;

                double scaledRad = rad / thk * window.Height;

                double rx = scaledRad * Math.Cos(ang * Math.PI / 180);
                double r_ry = scaledRad - scaledRad * Math.Sin(ang * Math.PI / 180); // actually r-ry

                if (cbDrawingDouble.Checked)
                {
                    grooveTpl = DoubleGroovePoints(window, rfHgt, ang, scaledRad, rx, r_ry);
                }
                else
                {
                    grooveTpl = GroovePoints(window, rfHgt, ang, scaledRad, rx, r_ry);
                }

                WeldingShape newGroove = new WeldingShape(ShapeType.Groove, grooveTpl.Item1, rotateAng, rtFace, ang, thk, scaledRad, grooveTpl.Item2, cbDrawingFlipH.Checked, cbDrawingFlipV.Checked, cbDrawingDouble.Checked, window);
                drawnShapes.Add(newGroove);
            }
            #endregion

            window = new RotatedRectangle();
        }

        private void DrawPreview(Graphics g)
        {
            Pen pen = new Pen(Color.Black);

            int margin = 10;
            int height = pDrawingShapePreview.Height - 2 * margin;
            int width = pDrawingShapePreview.Width - 2 * margin;

            float scaleX, scaleY, scale;
            float.TryParse(txtDrawingRotation.Text, out float rotateAng);
            double.TryParse(txtDrawingThickness.Text, out double thk);
            double.TryParse(txtDrawingRootFace.Text, out double rtFace);
            double.TryParse(txtDrawingAngle.Text, out double ang);
            double.TryParse(txtDrawingRadius.Text, out double rad);

            #region Scaling
            float scaleAng = Math.Abs(rotateAng);

            if (scaleAng < 40 || scaleAng > 50)
            {
                scaleY = (float)(((height * Math.Cos(scaleAng * Math.PI / 180)) - (width * Math.Sin(scaleAng * Math.PI / 180))) / (height * Math.Cos(2 * scaleAng * Math.PI / 180)));
                scaleX = (float)(((height * Math.Sin(scaleAng * Math.PI / 180)) - (width * Math.Cos(scaleAng * Math.PI / 180))) / (width * Math.Cos(2 * scaleAng * Math.PI / 180)));
            }
            else
            {
                scaleX = scaleY = (float)0.5;
            }

            scale = Math.Min(Math.Abs(scaleY), Math.Abs(scaleX));
            #endregion

            #region Draw Preview
            if (rbDrawingRectangle.Checked)
            {
                RotateGraphic(g, rotateAng, new Point(margin + (width / 2), margin + (height / 2)));
                ScaleGraphic(g, scale, scale, new Point(margin + (width / 2), margin + (height / 2)), 0, 0);

                g.DrawRectangle(pen, margin, margin, width, height);
            }
            else if (rbDrawingWeld.Checked)
            {
                height = (pDrawingShapePreview.Height / 2);

                RotateGraphic(g, rotateAng, new Point(margin + (width / 2), height));

                g.DrawEllipse(pen, margin, height / 2, width, height);

                DrawScaledString(g, "#", new Rectangle(margin, margin, width, height));
            }
            else if (rbDrawingBevel.Checked)
            {
                if(thk == 0)
                {
                    return;
                }

                if (txtDrawingRootFace.Text != "" && txtDrawingAngle.Text != "" && txtDrawingThickness.Text != "")
                {
                    List<Point> shapePath;
                    GraphicsPath path;
                    float maxWdt, maxHgt;

                    double rfHgt = rtFace / thk * height;

                    int xIdx = cbDrawingDouble.Checked ? 3 : 2;

                    if (cbDrawingDouble.Checked)
                    {
                        shapePath = DoubleBevelPoints(new RotatedRectangle(margin, margin, margin+width, margin+height, 0), rfHgt, ang);
                    }
                    else
                    {
                        shapePath = BevelPoints(new RotatedRectangle(margin, margin, margin + width, margin + height, 0), rfHgt, ang);
                    }

                    maxWdt = shapePath[xIdx].X;
                    maxHgt = shapePath[1].Y;

                    path = BevelPath(shapePath, cbDrawingDouble.Checked);

                    ScaleGraphic(g, cbDrawingFlipH.Checked ? -1 : 1, cbDrawingFlipV.Checked ? -1 : 1, new Point(margin, margin), cbDrawingFlipH.Checked ? width : 0, cbDrawingFlipV.Checked ? height : 0);
                    RotateGraphic(g, rotateAng, new Point(margin + (int)(maxWdt / 2), margin + (int)(maxHgt / 2)));
                    ScaleGraphic(g, scale, scale, new Point(margin + (int)(maxWdt / 2), margin + (int)(maxHgt / 2)), 0, 0);

                    g.DrawPath(pen, path);
                }
            }
            else if (rbDrawingGroove.Checked)
            {
                if (thk == 0)
                {
                    return;
                }

                if (txtDrawingRootFace.Text != "" && txtDrawingAngle.Text != "" && txtDrawingThickness.Text != "" && txtDrawingRadius.Text != "")
                {
                    Tuple<List<Point>, Point> grooveTpl;
                    GraphicsPath path;
                    float maxWdt, maxHgt;

                    double rfHgt = rtFace / thk * height;
                    double scaledRad = rad / thk * width;

                    double rx = scaledRad * Math.Cos(ang * Math.PI / 180);
                    double r_ry = scaledRad - scaledRad * Math.Sin(ang * Math.PI / 180);

                    float sweepAngle = 90 - (float)ang;

                    int xIdx = cbDrawingDouble.Checked ? 4 : 2;

                    RotatedRectangle boundingBox = new RotatedRectangle(margin, margin, margin + width, margin + height, 0);

                    if (cbDrawingDouble.Checked)
                    {
                        grooveTpl = DoubleGroovePoints(boundingBox, rfHgt, ang, scaledRad, rx, r_ry);
                    }
                    else
                    {
                        grooveTpl = GroovePoints(boundingBox, rfHgt, ang, scaledRad, rx, r_ry);
                    }

                    maxWdt = grooveTpl.Item1[xIdx].X;
                    maxHgt = grooveTpl.Item1[1].Y;

                    Point arcCentre2 = cbDrawingDouble.Checked ? DoubleGrooveArcCentre2(grooveTpl.Item2, boundingBox) : new Point();

                    path = GroovePath(grooveTpl.Item1, grooveTpl.Item2, arcCentre2, scaledRad, sweepAngle, 0, cbDrawingDouble.Checked);

                    ScaleGraphic(g, cbDrawingFlipH.Checked ? -1 : 1, cbDrawingFlipV.Checked ? -1 : 1, new Point(margin, margin), cbDrawingFlipH.Checked ? width : 0, cbDrawingFlipV.Checked ? height : 0);
                    RotateGraphic(g, rotateAng, new Point(margin + (int)(maxWdt / 2), margin + (int)(maxHgt / 2)));
                    ScaleGraphic(g, scale, scale, new Point(margin + (int)(maxWdt / 2), margin + (int)(maxHgt / 2)), 0, 0);

                    g.DrawPath(pen, path);
                }
            }
            #endregion
        }


        private void ResizeShape(WeldingShape shape, int anchorIndex, Point newLocation)
        {
            RotatedRectangle newBounds = shape.BoundingBox;

            bool stopX=false, stopY=false;

            int fixedX, fixedY;
            (int newX, int newY) = shape.BoundingBox.ConvertToShapeCoords(newLocation.X, newLocation.Y);

            switch (anchorIndex)
            {
                case 0: // Top-left
                    (fixedX, fixedY) = shape.BoundingBox.ConvertToShapeCoords(shape.BoundingBox.BottomRight.X, shape.BoundingBox.BottomRight.Y);
                    
                    stopX = newX > fixedX;
                    stopY = newY > fixedY;
                    
                    newBounds = new RotatedRectangle(newLocation.X, newLocation.Y, shape.BoundingBox.BottomRight.X, shape.BoundingBox.BottomRight.Y, shape.Rotation);
                    break;
                case 1: // Top-right
                    (fixedX, fixedY) = shape.BoundingBox.ConvertToShapeCoords(shape.BoundingBox.BottomLeft.X, shape.BoundingBox.BottomLeft.Y);

                    stopX = newX < fixedX;
                    stopY = newY > fixedY;

                    newBounds = new RotatedRectangle(newLocation.X, newLocation.Y, shape.BoundingBox.BottomLeft.X, shape.BoundingBox.BottomLeft.Y, shape.Rotation);
                    break;
                case 2: // Bottom-left
                    (fixedX, fixedY) = shape.BoundingBox.ConvertToShapeCoords(shape.BoundingBox.TopRight.X, shape.BoundingBox.TopRight.Y);

                    stopX = newX > fixedX;
                    stopY = newY < fixedY;

                    newBounds = new RotatedRectangle(newLocation.X, newLocation.Y, shape.BoundingBox.TopRight.X, shape.BoundingBox.TopRight.Y, shape.Rotation);
                    break;
                case 3: // Bottom-right
                    (fixedX, fixedY) = shape.BoundingBox.ConvertToShapeCoords(shape.BoundingBox.TopLeft.X, shape.BoundingBox.TopLeft.Y);

                    stopX = newX < fixedX;
                    stopY = newY < fixedY;

                    newBounds = new RotatedRectangle(newLocation.X, newLocation.Y, shape.BoundingBox.TopLeft.X, shape.BoundingBox.TopLeft.Y, shape.Rotation);
                    break;
            }

            if (stopX || stopY)
            {
                return;
            }

            newBounds.Width = newBounds.Width <= 0 ? 0 : newBounds.Width;
            newBounds.Height = newBounds.Height <= 0 ? 0 : newBounds.Height;

            // Recalculate shape path based on the new bounds

            double rfHgt;

            switch (shape.ShapeType)
            {
                case ShapeType.Rectangle:
                case ShapeType.Ellipse:

                    shape.ShapePath = new List<Point>
                    {
                        newBounds.TopLeft, newBounds.TopRight, newBounds.BottomRight, newBounds.BottomLeft
                    };
                    break;

                case ShapeType.Bevel:

                    rfHgt = shape.RootFace / shape.Thickness * newBounds.Height;

                    double chfWdt = (newBounds.Height - rfHgt) * Math.Tan(shape.IncludedAngle * Math.PI / 180);

                    if (shape.Double)
                    {
                        shape.ShapePath = DoubleBevelPoints(newBounds, rfHgt, shape.IncludedAngle);
                    }
                    else
                    {
                        shape.ShapePath = BevelPoints(newBounds, rfHgt, shape.IncludedAngle);
                    }

                    break;

                case ShapeType.Groove:

                    double scaledRad = shape.Radius / shape.BoundingBox.Height * newBounds.Height;

                    rfHgt = shape.RootFace / shape.Thickness * newBounds.Height;

                    double rx = scaledRad * Math.Cos(shape.IncludedAngle * Math.PI / 180);
                    double r_ry = scaledRad - scaledRad * Math.Sin(shape.IncludedAngle * Math.PI / 180);

                    double chfWdt2 = (newBounds.Height - rfHgt - r_ry) * Math.Tan(shape.IncludedAngle * Math.PI / 180);

                    Tuple<List<Point>, Point> grooveTpl;

                    if (shape.Double)
                    {
                        grooveTpl = DoubleGroovePoints(newBounds, rfHgt, shape.IncludedAngle, scaledRad, rx, r_ry);
                    }
                    else
                    {
                        grooveTpl = GroovePoints(newBounds, rfHgt, shape.IncludedAngle, scaledRad, rx, r_ry);
                    }

                    shape.ShapePath = grooveTpl.Item1;
                    shape.ArcCentre = grooveTpl.Item2;

                    break;

            }

            shape.BoundingBox = newBounds;
        }

        private bool IsNearPoint(Point a, Point b, int threshold = 5)
        {
            return Math.Abs(a.X - b.X) <= threshold && Math.Abs(a.Y - b.Y) <= threshold;
        }
        #endregion

        public uc_wqDrawing()
        {
            InitializeComponent();
        }

        #region Navigation
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on attachments screen")]
        public event EventHandler btnDrawingCompleteClick;
        private void btnDrawingComplete_Click(object sender, EventArgs e)
        {
            if (btnDrawingUndoRemove.Text != "Remove Current Attachment")
            {
                return;
            }

            drawnShapes.Clear();
            pbDrawingWeldSequence.Invalidate();

            Update_Status();

            btnDrawingCompleteClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on attachments screen")]
        public event EventHandler btnDrawingHomeClick;
        private void btnDrawingHome_Click(object sender, EventArgs e)
        {
            btnDrawingHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on attachments screen")]
        public event EventHandler btnDrawingBackClick;
        private void btnDrawingBack_Click(object sender, EventArgs e)
        {
            btnDrawingBackClick?.Invoke(this, e);
        }
        #endregion

        #region Drawing Events
        private void pDrawingWeldSequence_MouseDown(object sender, MouseEventArgs e)
        {
            if (rbDrawingEdit.Checked)
            {
                foreach (var shape in drawnShapes)
                {
                    for (int i = 0; i < shape.AnchorPoints.Count; i++)
                    {
                        var anchor = shape.AnchorPoints[i];
                        if (IsNearPoint(e.Location, anchor))
                        {
                            activeAnchorIndex = i;
                            activeShape = shape;
                            resizing = true;
                            return;
                        }
                    }
                }
            }

            mouseMoving = true;
            start.X = e.X;
            start.Y = e.Y;
            current.X = e.X;
            current.Y = e.Y;
            pbDrawingWeldSequence.Invalidate();
        }

        private void pDrawingWeldSequence_MouseMove(object sender, MouseEventArgs e)
        {
            if (resizing && activeShape != null && activeAnchorIndex.HasValue)
            {
                Point currentPoint;
                if (cbDrawingSnap.Checked)
                {
                    if(!int.TryParse(txtDrawingGrid.Text, out int gridSpacing))
                    {
                        gridSpacing = 10;
                    }

                    currentPoint = new Point(
                        (int)Math.Round(e.X / (double)gridSpacing) * gridSpacing,
                        (int)Math.Round(e.Y / (double)gridSpacing) * gridSpacing
                    );
                }
                else
                {
                    currentPoint = e.Location;
                }

                ResizeShape(activeShape, activeAnchorIndex.Value, currentPoint);
                pbDrawingWeldSequence.Invalidate();
            }
            else if (mouseMoving && !resizing)
            {
                current.X = e.X;
                current.Y = e.Y;
                pbDrawingWeldSequence.Invalidate();
            }
        }

        private void btnDrawingUndo_Click(object sender, EventArgs e)
        {
            if (viewMode)
            {
                AttachmentTypes attType;
                ICollection<Attachment> attachments;

                Tag thisTag = (Tag)this.Tag;

                if (thisTag != null)
                {
                    switch (thisTag.getTagType())
                    {
                        case TagType.WPQR_Sequence:
                        case TagType.WPQR_Preparation:
                            attType = thisTag.getTagType() == TagType.WPQR_Sequence ? AttachmentTypes.WPQR_Sequence : AttachmentTypes.WPQR_Preparation;
                            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);
                            attachments = wpqr.Attachments;
                            break;
                        case TagType.WPS_Sequence:
                        case TagType.WPS_Preparation:
                            attType = thisTag.getTagType() == TagType.WPS_Sequence ? AttachmentTypes.WPS_Sequence : AttachmentTypes.WPS_Preparation;
                            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);
                            attachments = wps.Attachments;
                            break;
                        default:
                            attType = AttachmentTypes.WQ_Sequence;
                            Datasheet ds = ApiCalls.ReadDatasheet(((Welder_Qualification)thisTag.getTagObject()).Datasheet.DatasheetId);
                            attachments = ds.Attachments;
                            break;
                    }

                    if (attachments.Count(a => a.AttachmentType == attType) > 0)
                    {
                        Attachment wqSeq = attachments.FirstOrDefault(a => a.AttachmentType == attType);
                        DeleteAttachment(wqSeq, pbDrawingWeldSequence);
                    }

                    Load_Action();
                }
            }
            else
            {
                if (drawnShapes.Count > 0)
                {
                    if (drawnShapes[drawnShapes.Count - 1].ShapeType == ShapeType.Ellipse)
                    {
                        weldCounter = drawnShapes[drawnShapes.Count - 1].RunId - 1;
                    }
                    drawnShapes.RemoveAt(drawnShapes.Count - 1);
                    pbDrawingWeldSequence.Invalidate();
                }
            }
        }

        private void pDrawingWeldSequence_MouseUp(object sender, MouseEventArgs e)
        {
            if (viewMode)
            {
                return;
            }

            resizing = false;
            activeAnchorIndex = null;
            activeShape = null;

            AddShape();
        }

        private void pDrawingWeldSequence_Paint(object sender, PaintEventArgs e)
        {
            if (viewMode)
            {
                return;
            }

            Graphics g = e.Graphics;

            DrawWeldDiagram(g);
        }

        private void pDrawingShapePreview_Paint(object sender, PaintEventArgs e)
        {
            if (viewMode)
            {
                return;
            }

            Graphics g = e.Graphics;

            DrawPreview(g);
        }

        #region trigger redraw
        private void txtDrawingRotation_TextChanged(object sender, EventArgs e)
        {
            pDrawingShapePreview.Invalidate();
            pbDrawingWeldSequence.Invalidate();
        }

        private void rbDrawingWeld_CheckedChanged(object sender, EventArgs e)
        {
            pDrawingShapePreview.Invalidate();

            if (rbDrawingWeld.Checked)
            {
                cbDrawingSnap.Checked = false;
            }
        }

        private void cbDrawingFlipH_CheckedChanged(object sender, EventArgs e)
        {
            if (rbDrawingBevel.Checked || rbDrawingGroove.Checked)
            {
                float.TryParse(txtDrawingRotation.Text, out float rotateAng);
                txtDrawingRotation.Text = (-rotateAng).ToString();
            }

            pDrawingShapePreview.Invalidate();
        }

        private void cbDrawingFlipV_CheckedChanged(object sender, EventArgs e)
        {
            if (rbDrawingBevel.Checked || rbDrawingGroove.Checked)
            {
                float.TryParse(txtDrawingRotation.Text, out float rotateAng);
                txtDrawingRotation.Text = (-rotateAng).ToString();
            }

            pDrawingShapePreview.Invalidate();
        }

        private void txtDrawingGrid_TextChanged(object sender, EventArgs e)
        {
            pbDrawingWeldSequence.Invalidate();
        }
        #endregion

        #endregion

        #region Database Actions
        private void uplDrawingUpload_Uploaded(object sender, UploadedEventArgs e)
        {
            AttachmentTypes attType;
            string quoteNo;
            Type type;
            long id;

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null)
            {
                return;
            }

            (attType, quoteNo, type, id) = GetFileDetails(thisTag);

            for (int i = 0; i < e.Files.Count; i++)
            {
                StoreFile(e.Files[i], attType, quoteNo, type, id);
            }

            Load_Action();
        }

        private void btnDrawingSave_Click(object sender, EventArgs e)
        {
            AttachmentTypes attType;
            string quoteNo;
            Type type;
            long id;

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null)
            {
                return;
            }

            cbDrawingSnap.Checked = false;

            (attType, quoteNo, type, id) = GetFileDetails(thisTag);

            using (Bitmap drawing = new Bitmap(pbDrawingWeldSequence.Width, pbDrawingWeldSequence.Height, PixelFormat.Format64bppArgb))
            {
                using (Graphics g = Graphics.FromImage(drawing))
                {
                    DrawWeldDiagram(g);
                }

                StoreBitmap(drawing, $"WeldDiagram_{attType}", attType, quoteNo, type, id);
            }

            drawnShapes.Clear();
            pbDrawingWeldSequence.Invalidate();

            Load_Action();
        }

        private void Load_Action()
        {
            AttachmentTypes attType;
            ICollection<Attachment> attachments;
            string thickness;
            string rootFace;
            string incAng;
            string btnUndoTxt;
            int ctrlsWdt;
            int rbWdt;
            bool hasAtt;

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null)
            {
                return;
            }

            switch (thisTag.getTagType())
            {
                case TagType.WPQR_Sequence:
                case TagType.WPQR_Preparation:
                    attType = thisTag.getTagType() == TagType.WPQR_Sequence ? AttachmentTypes.WPQR_Sequence : AttachmentTypes.WPQR_Preparation;
                    WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);
                    attachments = wpqr.Attachments;
                    thickness = wpqr.Welder_Qualification.Datasheet.MaterialThickness.ToString() ?? "";
                    rootFace = wpqr.Welder_Qualification.Datasheet.RootFace.ToString() ?? "";
                    incAng = wpqr.Welder_Qualification.Datasheet.IncludedAngle.ToString() ?? "";
                    break;
                case TagType.WPS_Sequence:
                case TagType.WPS_Preparation:
                    attType = thisTag.getTagType() == TagType.WPS_Sequence ? AttachmentTypes.WPS_Sequence : AttachmentTypes.WPS_Preparation;
                    WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);
                    attachments = wps.Attachments;
                    thickness = wps.WPQR.Welder_Qualification.Datasheet.MaterialThickness.ToString() ?? "";
                    rootFace = wps.WPQR.Welder_Qualification.Datasheet.RootFace.ToString() ?? "";
                    incAng = wps.WPQR.Welder_Qualification.Datasheet.IncludedAngle.ToString() ?? "";
                    break;
                default:
                    attType = AttachmentTypes.WQ_Sequence;
                    Datasheet ds = ApiCalls.ReadDatasheet(((Welder_Qualification)thisTag.getTagObject()).Datasheet.DatasheetId);
                    attachments = ds.Attachments;
                    thickness = ds.MaterialThickness.ToString() ?? "";
                    rootFace = ds.RootFace.ToString() ?? "";
                    incAng = ds.IncludedAngle.ToString() ?? "";
                    break;
            }

            if (attachments.Count(a => a.AttachmentType == attType) > 0)
            {
                weldCounter = 0;
                drawnShapes = new List<WeldingShape>();

                Attachment wqSeq = attachments.FirstOrDefault(a => a.AttachmentType == attType);
                wqSeq = ApiCalls.ReadAttachment(wqSeq.AttachmentId);

                using (FileStream fStream = new FileStream(wqSeq.ServerPath, FileMode.Open, FileAccess.Read))
                {
                    Image temp = GetImageFromStream(fStream);
                    pbDrawingWeldSequence.Image = temp;
                }

                ctrlsWdt = 0;
                rbWdt = 0;
                hasAtt = true;

                btnUndoTxt = "Remove Current Attachment";
            }
            else
            {
                txtDrawingThickness.Text = thickness;
                txtDrawingRootFace.Text = rootFace;
                txtDrawingAngle.Text = incAng;
                txtDrawingGrid.Text = "20";
                txtDrawingRotation.Text = "0";
                txtDrawingRadius.Text = "0";
                cbDrawingSnap.Checked = true;

                ctrlsWdt = 20;
                rbWdt = 10;
                hasAtt = false;

                btnUndoTxt = "Undo";
            }

            tlpDrawing.ColumnStyles[tlpDrawing.GetCellPosition(tlpDrawingControls).Column].SizeType = SizeType.Percent;
            tlpDrawing.ColumnStyles[tlpDrawing.GetCellPosition(tlpDrawingControls).Column].Width = ctrlsWdt;

            rbDrawingBevel.Visible = rbDrawingGroove.Visible = rbDrawingRectangle.Visible = rbDrawingWeld.Visible = !hasAtt;
            tlpDrawingPanel.RowStyles[tlpDrawingPanel.GetCellPosition(rbDrawingRectangle).Row].SizeType = SizeType.Percent;
            tlpDrawingPanel.RowStyles[tlpDrawingPanel.GetCellPosition(rbDrawingRectangle).Row].Height = rbWdt;

            uplDrawingUpload.Visible = !hasAtt;
            btnDrawingSave.Visible = !hasAtt;
            btnDrawingUndoRemove.Text = btnUndoTxt;

            viewMode = hasAtt;
        }

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            wq.Status = Actions.VisualInspection;

            ApiCalls.UpdateWelderQualification(wq.Welder_QualificationId, wq);

            this.Tag = new Tag(ApiCalls.ReadWelderQualification(wq.Welder_QualificationId), TagType.Welder_Qualification);
        }

        private void uc_wqDrawing_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private (AttachmentTypes, string, Type, long) GetFileDetails(Tag thisTag)
        {
            AttachmentTypes attType;
            string quoteNo;
            Type type;
            long id;

            switch (thisTag.getTagType())
            {
                case TagType.WPQR_Sequence:
                case TagType.WPQR_Preparation:
                    WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);
                    attType = thisTag.getTagType() == TagType.WPQR_Sequence ? AttachmentTypes.WPQR_Sequence : AttachmentTypes.WPQR_Preparation;
                    quoteNo = wpqr.Welder_Qualification.WeldingAction.Job.QuoteNumber;
                    type = typeof(WPQR);
                    id = wpqr.WPQRId;
                    break;
                case TagType.WPS_Sequence:
                case TagType.WPS_Preparation:
                    WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);
                    attType = thisTag.getTagType() == TagType.WPS_Sequence ? AttachmentTypes.WPS_Sequence : AttachmentTypes.WPS_Preparation;
                    quoteNo = wps.WPQR.Welder_Qualification.WeldingAction.Job.QuoteNumber;
                    type = typeof(WPS);
                    id = wps.WPSId;
                    break;
                default:
                    Datasheet ds = ApiCalls.ReadDatasheet(((Welder_Qualification)thisTag.getTagObject()).Datasheet.DatasheetId);
                    attType = AttachmentTypes.WQ_Sequence;
                    quoteNo = ds.Welder_Qualification.WeldingAction.Job.QuoteNumber;
                    type = typeof(Datasheet);
                    id = ds.DatasheetId;
                    break;
            }

            return (attType, quoteNo, type, id);
        }
        #endregion

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }
    }
}
