﻿namespace WeldingManagement.UserControls.DatasheetControls
{
    partial class uc_wqRun
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_wqRun));
            this.tableLayoutPanel20 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel21 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel23 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel31 = new Wisej.Web.TableLayoutPanel();
            this.btnRunDelete = new Wisej.Web.Button();
            this.btnRunBack = new Wisej.Web.Button();
            this.btnRunAdd = new Wisej.Web.Button();
            this.btnRunHome = new Wisej.Web.Button();
            this.btnRunNext = new Wisej.Web.Button();
            this.tableLayoutPanel22 = new Wisej.Web.TableLayoutPanel();
            this.lvRunParameters = new Wisej.Web.ListView();
            this.chSide = new Wisej.Web.ColumnHeader();
            this.chPass = new Wisej.Web.ColumnHeader();
            this.chDia = new Wisej.Web.ColumnHeader();
            this.chSupply = new Wisej.Web.ColumnHeader();
            this.chAmps = new Wisej.Web.ColumnHeader();
            this.chVolts = new Wisej.Web.ColumnHeader();
            this.chInterpass = new Wisej.Web.ColumnHeader();
            this.chLength = new Wisej.Web.ColumnHeader();
            this.chActual = new Wisej.Web.ColumnHeader();
            this.chWeldTime = new Wisej.Web.ColumnHeader();
            this.chWeldSpeed = new Wisej.Web.ColumnHeader();
            this.chInput = new Wisej.Web.ColumnHeader();
            this.chShield = new Wisej.Web.ColumnHeader();
            this.chPurge = new Wisej.Web.ColumnHeader();
            this.txtRunPurge = new Wisej.Web.TextBox();
            this.txtRunShield = new Wisej.Web.TextBox();
            this.txtRunInput = new Wisej.Web.TextBox();
            this.txtRunActual = new Wisej.Web.TextBox();
            this.txtRunLength = new Wisej.Web.TextBox();
            this.txtRunInterpass = new Wisej.Web.TextBox();
            this.txtRunVolts = new Wisej.Web.TextBox();
            this.txtRunAmps = new Wisej.Web.TextBox();
            this.txtRunSupply = new Wisej.Web.TextBox();
            this.txtRunDia = new Wisej.Web.TextBox();
            this.txtRunPass = new Wisej.Web.TextBox();
            this.txtRunSide = new Wisej.Web.TextBox();
            this.label63 = new Wisej.Web.Label();
            this.label64 = new Wisej.Web.Label();
            this.label65 = new Wisej.Web.Label();
            this.label66 = new Wisej.Web.Label();
            this.label67 = new Wisej.Web.Label();
            this.label68 = new Wisej.Web.Label();
            this.label69 = new Wisej.Web.Label();
            this.label70 = new Wisej.Web.Label();
            this.label71 = new Wisej.Web.Label();
            this.label72 = new Wisej.Web.Label();
            this.label73 = new Wisej.Web.Label();
            this.label74 = new Wisej.Web.Label();
            this.label75 = new Wisej.Web.Label();
            this.label76 = new Wisej.Web.Label();
            this.txtRunSpeed = new Wisej.Web.TextBox();
            this.txtRunTime = new Wisej.Web.TextBox();
            this.tableLayoutPanel24 = new Wisej.Web.TableLayoutPanel();
            this.lblInfoNote = new Wisej.Web.LinkLabel();
            this.label78 = new Wisej.Web.Label();
            this.tableLayoutPanel20.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel20.ColumnCount = 3;
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel21, 1, 3);
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel24, 1, 1);
            this.tableLayoutPanel20.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 5;
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel20.TabIndex = 4;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel21.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel23, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel22, 0, 0);
            this.tableLayoutPanel21.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel21.TabIndex = 1;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 1;
            this.tableLayoutPanel23.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Controls.Add(this.tableLayoutPanel31, 0, 0);
            this.tableLayoutPanel23.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel23.TabIndex = 5;
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel31.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel31.ColumnCount = 1;
            this.tableLayoutPanel31.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel31.Controls.Add(this.btnRunDelete, 0, 0);
            this.tableLayoutPanel31.Controls.Add(this.btnRunBack, 0, 2);
            this.tableLayoutPanel31.Controls.Add(this.btnRunAdd, 0, 1);
            this.tableLayoutPanel31.Controls.Add(this.btnRunHome, 0, 3);
            this.tableLayoutPanel31.Controls.Add(this.btnRunNext, 0, 4);
            this.tableLayoutPanel31.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel31.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel31.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 5;
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel31.TabIndex = 4;
            // 
            // btnRunDelete
            // 
            this.btnRunDelete.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnRunDelete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunDelete.Location = new System.Drawing.Point(3, 3);
            this.btnRunDelete.Name = "btnRunDelete";
            this.btnRunDelete.Size = new System.Drawing.Size(95, 79);
            this.btnRunDelete.TabIndex = 16;
            this.btnRunDelete.Text = "Delete Run";
            this.btnRunDelete.DoubleClick += new System.EventHandler(this.btnRunDelete_DoubleClick);
            // 
            // btnRunBack
            // 
            this.btnRunBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnRunBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunBack.Location = new System.Drawing.Point(3, 173);
            this.btnRunBack.Name = "btnRunBack";
            this.btnRunBack.Size = new System.Drawing.Size(95, 79);
            this.btnRunBack.TabIndex = 15;
            this.btnRunBack.Text = "Back";
            this.btnRunBack.Click += new System.EventHandler(this.btnRunBack_Click);
            // 
            // btnRunAdd
            // 
            this.btnRunAdd.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnRunAdd.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunAdd.Location = new System.Drawing.Point(3, 88);
            this.btnRunAdd.Name = "btnRunAdd";
            this.btnRunAdd.Size = new System.Drawing.Size(95, 79);
            this.btnRunAdd.TabIndex = 12;
            this.btnRunAdd.Text = "Add Run";
            this.btnRunAdd.Click += new System.EventHandler(this.btnRunAdd_Click);
            // 
            // btnRunHome
            // 
            this.btnRunHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnRunHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunHome.Location = new System.Drawing.Point(3, 258);
            this.btnRunHome.Name = "btnRunHome";
            this.btnRunHome.Size = new System.Drawing.Size(95, 79);
            this.btnRunHome.TabIndex = 14;
            this.btnRunHome.Text = "Home";
            this.btnRunHome.Click += new System.EventHandler(this.btnRunHome_Click);
            // 
            // btnRunNext
            // 
            this.btnRunNext.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnRunNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunNext.Location = new System.Drawing.Point(3, 343);
            this.btnRunNext.Name = "btnRunNext";
            this.btnRunNext.Size = new System.Drawing.Size(95, 79);
            this.btnRunNext.TabIndex = 13;
            this.btnRunNext.Text = "Next";
            this.btnRunNext.Click += new System.EventHandler(this.btnRunNext_Click);
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 14;
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.Controls.Add(this.lvRunParameters, 0, 2);
            this.tableLayoutPanel22.Controls.Add(this.txtRunPurge, 13, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunShield, 12, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunInput, 11, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunActual, 8, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunLength, 7, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunInterpass, 6, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunVolts, 5, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunAmps, 4, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunSupply, 3, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunDia, 2, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunPass, 1, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunSide, 0, 1);
            this.tableLayoutPanel22.Controls.Add(this.label63, 13, 0);
            this.tableLayoutPanel22.Controls.Add(this.label64, 12, 0);
            this.tableLayoutPanel22.Controls.Add(this.label65, 11, 0);
            this.tableLayoutPanel22.Controls.Add(this.label66, 10, 0);
            this.tableLayoutPanel22.Controls.Add(this.label67, 9, 0);
            this.tableLayoutPanel22.Controls.Add(this.label68, 8, 0);
            this.tableLayoutPanel22.Controls.Add(this.label69, 7, 0);
            this.tableLayoutPanel22.Controls.Add(this.label70, 6, 0);
            this.tableLayoutPanel22.Controls.Add(this.label71, 5, 0);
            this.tableLayoutPanel22.Controls.Add(this.label72, 4, 0);
            this.tableLayoutPanel22.Controls.Add(this.label73, 3, 0);
            this.tableLayoutPanel22.Controls.Add(this.label74, 2, 0);
            this.tableLayoutPanel22.Controls.Add(this.label75, 1, 0);
            this.tableLayoutPanel22.Controls.Add(this.label76, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.txtRunSpeed, 10, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunTime, 9, 1);
            this.tableLayoutPanel22.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 3;
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 60F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel22.TabIndex = 4;
            // 
            // lvRunParameters
            // 
            this.lvRunParameters.Columns.AddRange(new Wisej.Web.ColumnHeader[] {
            this.chSide,
            this.chPass,
            this.chDia,
            this.chSupply,
            this.chAmps,
            this.chVolts,
            this.chInterpass,
            this.chLength,
            this.chActual,
            this.chWeldTime,
            this.chWeldSpeed,
            this.chInput,
            this.chShield,
            this.chPurge});
            this.tableLayoutPanel22.SetColumnSpan(this.lvRunParameters, 14);
            this.lvRunParameters.Dock = Wisej.Web.DockStyle.Fill;
            this.lvRunParameters.HeaderStyle = Wisej.Web.ColumnHeaderStyle.None;
            this.lvRunParameters.Location = new System.Drawing.Point(3, 175);
            this.lvRunParameters.Name = "lvRunParameters";
            this.lvRunParameters.Size = new System.Drawing.Size(1018, 255);
            this.lvRunParameters.TabIndex = 28;
            this.lvRunParameters.View = Wisej.Web.View.Details;
            this.lvRunParameters.SelectedIndexChanged += new System.EventHandler(this.lvRunParameters_SelectedIndexChanged);
            this.lvRunParameters.ItemDoubleClick += new Wisej.Web.ItemClickEventHandler(this.lvRunParameters_ItemDoubleClick);
            this.lvRunParameters.Resize += new System.EventHandler(this.lvRunParameters_Resize);
            // 
            // chSide
            // 
            this.chSide.Name = "chSide";
            this.chSide.Text = "Side";
            // 
            // chPass
            // 
            this.chPass.Name = "chPass";
            this.chPass.Text = "Pass";
            // 
            // chDia
            // 
            this.chDia.Name = "chDia";
            this.chDia.Text = "Dia";
            // 
            // chSupply
            // 
            this.chSupply.Name = "chSupply";
            this.chSupply.Text = "Supply";
            // 
            // chAmps
            // 
            this.chAmps.Name = "chAmps";
            this.chAmps.Text = "Amps";
            // 
            // chVolts
            // 
            this.chVolts.Name = "chVolts";
            this.chVolts.Text = "Volts";
            // 
            // chInterpass
            // 
            this.chInterpass.Name = "chInterpass";
            this.chInterpass.Text = "Interpass";
            // 
            // chLength
            // 
            this.chLength.Name = "chLength";
            this.chLength.Text = "Length";
            // 
            // chActual
            // 
            this.chActual.Name = "chActual";
            this.chActual.Text = "Actual";
            // 
            // chWeldTime
            // 
            this.chWeldTime.Name = "chWeldTime";
            this.chWeldTime.Text = "Weld Time";
            // 
            // chWeldSpeed
            // 
            this.chWeldSpeed.Name = "chWeldSpeed";
            this.chWeldSpeed.Text = "Weld Speed";
            // 
            // chInput
            // 
            this.chInput.Name = "chInput";
            this.chInput.Text = "Input";
            // 
            // chShield
            // 
            this.chShield.Name = "chShield";
            this.chShield.Text = "Shield Gas";
            // 
            // chPurge
            // 
            this.chPurge.Name = "chPurge";
            this.chPurge.Text = "Purge Gas";
            // 
            // txtRunPurge
            // 
            this.txtRunPurge.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunPurge.InputType.Step = 0.1D;
            this.txtRunPurge.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunPurge.Location = new System.Drawing.Point(952, 89);
            this.txtRunPurge.Name = "txtRunPurge";
            this.txtRunPurge.Size = new System.Drawing.Size(69, 80);
            this.txtRunPurge.TabIndex = 11;
            this.txtRunPurge.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunShield
            // 
            this.txtRunShield.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunShield.InputType.Step = 0.1D;
            this.txtRunShield.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunShield.Location = new System.Drawing.Point(879, 89);
            this.txtRunShield.Name = "txtRunShield";
            this.txtRunShield.Size = new System.Drawing.Size(67, 80);
            this.txtRunShield.TabIndex = 10;
            this.txtRunShield.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunInput
            // 
            this.txtRunInput.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtRunInput.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunInput.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunInput.Location = new System.Drawing.Point(806, 89);
            this.txtRunInput.Name = "txtRunInput";
            this.txtRunInput.ReadOnly = true;
            this.txtRunInput.Size = new System.Drawing.Size(67, 80);
            this.txtRunInput.TabIndex = 25;
            this.txtRunInput.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunActual
            // 
            this.txtRunActual.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunActual.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunActual.Location = new System.Drawing.Point(587, 89);
            this.txtRunActual.Name = "txtRunActual";
            this.txtRunActual.Size = new System.Drawing.Size(67, 80);
            this.txtRunActual.TabIndex = 8;
            this.txtRunActual.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            this.txtRunActual.TextChanged += new System.EventHandler(this.txtRunActual_TextChanged);
            this.txtRunActual.KeyPress += new Wisej.Web.KeyPressEventHandler(this.txtRunActual_KeyPress);
            // 
            // txtRunLength
            // 
            this.txtRunLength.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunLength.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunLength.Location = new System.Drawing.Point(514, 89);
            this.txtRunLength.Name = "txtRunLength";
            this.txtRunLength.Size = new System.Drawing.Size(67, 80);
            this.txtRunLength.TabIndex = 7;
            this.txtRunLength.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunInterpass
            // 
            this.txtRunInterpass.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunInterpass.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunInterpass.Location = new System.Drawing.Point(441, 89);
            this.txtRunInterpass.Name = "txtRunInterpass";
            this.txtRunInterpass.Size = new System.Drawing.Size(67, 80);
            this.txtRunInterpass.TabIndex = 6;
            this.txtRunInterpass.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunVolts
            // 
            this.txtRunVolts.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunVolts.InputType.Step = 0.1D;
            this.txtRunVolts.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunVolts.Location = new System.Drawing.Point(368, 89);
            this.txtRunVolts.Name = "txtRunVolts";
            this.txtRunVolts.Size = new System.Drawing.Size(67, 80);
            this.txtRunVolts.TabIndex = 5;
            this.txtRunVolts.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            this.txtRunVolts.TextChanged += new System.EventHandler(this.txtRunVolts_TextChanged);
            this.txtRunVolts.KeyPress += new Wisej.Web.KeyPressEventHandler(this.txtRunVolts_KeyPress);
            // 
            // txtRunAmps
            // 
            this.txtRunAmps.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunAmps.InputType.Step = 0.1D;
            this.txtRunAmps.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunAmps.Location = new System.Drawing.Point(295, 89);
            this.txtRunAmps.Name = "txtRunAmps";
            this.txtRunAmps.Size = new System.Drawing.Size(67, 80);
            this.txtRunAmps.TabIndex = 4;
            this.txtRunAmps.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            this.txtRunAmps.TextChanged += new System.EventHandler(this.txtRunAmps_TextChanged);
            this.txtRunAmps.KeyPress += new Wisej.Web.KeyPressEventHandler(this.txtRunAmps_KeyPress);
            // 
            // txtRunSupply
            // 
            this.txtRunSupply.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunSupply.Location = new System.Drawing.Point(222, 89);
            this.txtRunSupply.Name = "txtRunSupply";
            this.txtRunSupply.Size = new System.Drawing.Size(67, 80);
            this.txtRunSupply.TabIndex = 3;
            this.txtRunSupply.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunDia
            // 
            this.txtRunDia.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunDia.InputType.Step = 0.1D;
            this.txtRunDia.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunDia.Location = new System.Drawing.Point(149, 89);
            this.txtRunDia.Name = "txtRunDia";
            this.txtRunDia.Size = new System.Drawing.Size(67, 80);
            this.txtRunDia.TabIndex = 2;
            this.txtRunDia.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunPass
            // 
            this.txtRunPass.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunPass.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunPass.Location = new System.Drawing.Point(76, 89);
            this.txtRunPass.Name = "txtRunPass";
            this.txtRunPass.Size = new System.Drawing.Size(67, 80);
            this.txtRunPass.TabIndex = 1;
            this.txtRunPass.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunSide
            // 
            this.txtRunSide.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunSide.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunSide.Location = new System.Drawing.Point(3, 89);
            this.txtRunSide.Name = "txtRunSide";
            this.txtRunSide.Size = new System.Drawing.Size(67, 80);
            this.txtRunSide.TabIndex = 0;
            this.txtRunSide.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label63.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label63.Dock = Wisej.Web.DockStyle.Fill;
            this.label63.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label63.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label63.Location = new System.Drawing.Point(952, 3);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(69, 80);
            this.label63.TabIndex = 13;
            this.label63.Text = "Purge Gas \r\nL/min";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label64.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label64.Dock = Wisej.Web.DockStyle.Fill;
            this.label64.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label64.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label64.Location = new System.Drawing.Point(879, 3);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(67, 80);
            this.label64.TabIndex = 12;
            this.label64.Text = "Shield Gas \r\nL/min";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label65.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label65.Dock = Wisej.Web.DockStyle.Fill;
            this.label65.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label65.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label65.Location = new System.Drawing.Point(806, 3);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(67, 80);
            this.label65.TabIndex = 11;
            this.label65.Text = "Energy Input kJ/mm";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label66.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label66.Dock = Wisej.Web.DockStyle.Fill;
            this.label66.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label66.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label66.Location = new System.Drawing.Point(733, 3);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(67, 80);
            this.label66.TabIndex = 10;
            this.label66.Text = "Weld Speed mm/min";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label67.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label67.Dock = Wisej.Web.DockStyle.Fill;
            this.label67.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label67.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label67.Location = new System.Drawing.Point(660, 3);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(67, 80);
            this.label67.TabIndex = 9;
            this.label67.Text = "Weld Time \r\ns";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label68.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label68.Dock = Wisej.Web.DockStyle.Fill;
            this.label68.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label68.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label68.Location = new System.Drawing.Point(587, 3);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(67, 80);
            this.label68.TabIndex = 8;
            this.label68.Text = "Actual Length";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label69.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label69.Dock = Wisej.Web.DockStyle.Fill;
            this.label69.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label69.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label69.Location = new System.Drawing.Point(514, 3);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(67, 80);
            this.label69.TabIndex = 7;
            this.label69.Text = "Length";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label70.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label70.Dock = Wisej.Web.DockStyle.Fill;
            this.label70.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label70.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label70.Location = new System.Drawing.Point(441, 3);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(67, 80);
            this.label70.TabIndex = 6;
            this.label70.Text = "Interpass Temp\r\n°C";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label71.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label71.Dock = Wisej.Web.DockStyle.Fill;
            this.label71.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label71.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label71.Location = new System.Drawing.Point(368, 3);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(67, 80);
            this.label71.TabIndex = 5;
            this.label71.Text = "Volts";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label72.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label72.Dock = Wisej.Web.DockStyle.Fill;
            this.label72.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label72.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label72.Location = new System.Drawing.Point(295, 3);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(67, 80);
            this.label72.TabIndex = 4;
            this.label72.Text = "Amps";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label73.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label73.Dock = Wisej.Web.DockStyle.Fill;
            this.label73.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label73.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label73.Location = new System.Drawing.Point(222, 3);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(67, 80);
            this.label73.TabIndex = 3;
            this.label73.Text = "Supply";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label74.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label74.Dock = Wisej.Web.DockStyle.Fill;
            this.label74.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label74.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label74.Location = new System.Drawing.Point(149, 3);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(67, 80);
            this.label74.TabIndex = 2;
            this.label74.Text = "Filler Dia \r\nmm";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label75.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label75.Dock = Wisej.Web.DockStyle.Fill;
            this.label75.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label75.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label75.Location = new System.Drawing.Point(76, 3);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(67, 80);
            this.label75.TabIndex = 1;
            this.label75.Text = "Pass Number";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label76.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label76.Dock = Wisej.Web.DockStyle.Fill;
            this.label76.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label76.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label76.Location = new System.Drawing.Point(3, 3);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(67, 80);
            this.label76.TabIndex = 0;
            this.label76.Text = "Side";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtRunSpeed
            // 
            this.txtRunSpeed.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtRunSpeed.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunSpeed.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunSpeed.Location = new System.Drawing.Point(733, 89);
            this.txtRunSpeed.Name = "txtRunSpeed";
            this.txtRunSpeed.ReadOnly = true;
            this.txtRunSpeed.Size = new System.Drawing.Size(67, 80);
            this.txtRunSpeed.TabIndex = 24;
            this.txtRunSpeed.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunTime
            // 
            this.txtRunTime.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunTime.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunTime.Location = new System.Drawing.Point(660, 89);
            this.txtRunTime.Name = "txtRunTime";
            this.txtRunTime.Size = new System.Drawing.Size(67, 80);
            this.txtRunTime.TabIndex = 9;
            this.txtRunTime.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            this.txtRunTime.TextChanged += new System.EventHandler(this.txtRunTime_TextChanged);
            this.txtRunTime.KeyPress += new Wisej.Web.KeyPressEventHandler(this.txtRunTime_KeyPress);
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 1;
            this.tableLayoutPanel24.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel24.Controls.Add(this.lblInfoNote, 0, 1);
            this.tableLayoutPanel24.Controls.Add(this.label78, 0, 0);
            this.tableLayoutPanel24.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 2;
            this.tableLayoutPanel24.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel24.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel24.TabIndex = 0;
            // 
            // lblInfoNote
            // 
            this.lblInfoNote.AutoSize = true;
            this.lblInfoNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblInfoNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblInfoNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblInfoNote.LinkArea = new Wisej.Web.LinkArea(268, 84);
            this.lblInfoNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblInfoNote.Location = new System.Drawing.Point(6, 79);
            this.lblInfoNote.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.lblInfoNote.Name = "lblInfoNote";
            this.lblInfoNote.Size = new System.Drawing.Size(1133, 35);
            this.lblInfoNote.TabIndex = 5;
            this.lblInfoNote.Text = resources.GetString("lblInfoNote.Text");
            this.lblInfoNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfoNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblInfoNote_LinkClicked);
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label78.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label78.CssStyle = "border-radius: 4px;";
            this.label78.Dock = Wisej.Web.DockStyle.Fill;
            this.label78.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label78.Location = new System.Drawing.Point(6, 3);
            this.label78.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(1133, 70);
            this.label78.TabIndex = 0;
            this.label78.Text = "Welding Test Parameters";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label78.DoubleClick += new System.EventHandler(this.label78_DoubleClick);
            // 
            // uc_wqRun
            // 
            this.Controls.Add(this.tableLayoutPanel20);
            this.Name = "uc_wqRun";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_dsRun_VisibleChanged);
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel31.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel22.PerformLayout();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel24.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel20;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel21;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel23;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel31;
        private Wisej.Web.Button btnRunBack;
        private Wisej.Web.Button btnRunAdd;
        private Wisej.Web.Button btnRunHome;
        private Wisej.Web.Button btnRunNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel22;
        private Wisej.Web.ListView lvRunParameters;
        private Wisej.Web.ColumnHeader chSide;
        private Wisej.Web.ColumnHeader chPass;
        private Wisej.Web.ColumnHeader chDia;
        private Wisej.Web.ColumnHeader chSupply;
        private Wisej.Web.ColumnHeader chAmps;
        private Wisej.Web.ColumnHeader chVolts;
        private Wisej.Web.ColumnHeader chInterpass;
        private Wisej.Web.ColumnHeader chLength;
        private Wisej.Web.ColumnHeader chActual;
        private Wisej.Web.ColumnHeader chWeldTime;
        private Wisej.Web.ColumnHeader chWeldSpeed;
        private Wisej.Web.ColumnHeader chInput;
        private Wisej.Web.ColumnHeader chShield;
        private Wisej.Web.ColumnHeader chPurge;
        private Wisej.Web.TextBox txtRunPurge;
        private Wisej.Web.TextBox txtRunShield;
        private Wisej.Web.TextBox txtRunInput;
        private Wisej.Web.TextBox txtRunActual;
        private Wisej.Web.TextBox txtRunLength;
        private Wisej.Web.TextBox txtRunInterpass;
        private Wisej.Web.TextBox txtRunVolts;
        private Wisej.Web.TextBox txtRunAmps;
        private Wisej.Web.TextBox txtRunSupply;
        private Wisej.Web.TextBox txtRunDia;
        private Wisej.Web.TextBox txtRunPass;
        private Wisej.Web.TextBox txtRunSide;
        private Wisej.Web.Label label63;
        private Wisej.Web.Label label64;
        private Wisej.Web.Label label65;
        private Wisej.Web.Label label66;
        private Wisej.Web.Label label67;
        private Wisej.Web.Label label68;
        private Wisej.Web.Label label69;
        private Wisej.Web.Label label70;
        private Wisej.Web.Label label71;
        private Wisej.Web.Label label72;
        private Wisej.Web.Label label73;
        private Wisej.Web.Label label74;
        private Wisej.Web.Label label75;
        private Wisej.Web.Label label76;
        private Wisej.Web.TextBox txtRunSpeed;
        private Wisej.Web.TextBox txtRunTime;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel24;
        private Wisej.Web.Label label78;
        private Wisej.Web.Button btnRunDelete;
        private Wisej.Web.LinkLabel lblInfoNote;
    }
}
