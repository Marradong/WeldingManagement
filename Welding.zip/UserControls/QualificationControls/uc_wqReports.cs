﻿using ApiClient;
using GemBox.Document;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using Welding.DAL;
using WeldingManagement.UserControls.PopupControls;
using Wisej.Web;
using static WeldingManagement.FileManagement;
using static WeldingManagement.Helpers.GenericHelpers;
using static WeldingManagement.TemplateCompiler;

namespace WeldingManagement.UserControls.QualificationControls
{
    public partial class uc_wqReports : Wisej.Web.UserControl
    {
        private up_wqFileView up_wqFileView1;
        private up_hmSave up_hmSave1;
        private Panel overlayPanel;

        public uc_wqReports()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = System.Drawing.Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on upload screen")]
        public event EventHandler btnUploadBackClick;
        private void btnUploadBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnUploadBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnUploadBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on upload screen")]
        public event EventHandler btnUploadHomeClick;
        private void btnUploadHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnUploadHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on upload screen")]
        public event EventHandler btnUploadCompleteClick;
        private void btnUploadComplete_Click(object sender, EventArgs e)
        {
            UIFormatting.StartLoader(this);

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                UIFormatting.StopLoader(this);
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            if (!wq.Attachments.Any(w => w.AttachmentType == AttachmentTypes.Weld_Stamp))
            {
                UIFormatting.StopLoader(this);
                return;
            }

            if (!wq.Attachments.Any(w => w.AttachmentType == AttachmentTypes.NATA_Report))
            {
                UIFormatting.StopLoader(this);
                return;
            }

            Save_Action();
            Update_Status();

            if (up_wqFileView1 == null)
            {
                up_wqFileView1 = new up_wqFileView();
                this.Controls.Add(up_wqFileView1);
            }

            overlayPanel.Visible = true;

            wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            if (wq.Status != Actions.Complete)
            {
                UIFormatting.StopLoader(this);
                return;
            }

            Datasheet ds = ApiCalls.ReadDatasheet(wq.Datasheet.DatasheetId);
            Visual_Inspection vi = ApiCalls.ReadVisualInspection(wq.Visual_Inspection.Visual_InspectionId);

            string welderQualPath = CompleteWelderQual(wq);

            using (FileStream fStream = new FileStream(welderQualPath, FileMode.Open, FileAccess.Read))
            {
                var reader = new BinaryReader(fStream);
                var buffer = reader.ReadBytes((int)fStream.Length);
                var mem = new MemoryStream(buffer);

                up_wqFileView1.pvView_Stream = mem;
                up_wqFileView1.path = welderQualPath;
                up_wqFileView1.title = "Below is a Preview of the Completed Welder Qualification";

                UIFormatting.StopLoader(this);

                up_wqFileView1.ShowPopup(new Point(this.Width / 2 - up_wqFileView1.Width / 2, this.Height / 2 - up_wqFileView1.Height / 2), up_wqFileView1_Closed);
            }

            UIFormatting.StopLoader(this);
        }
                

        private void up_wqFileView1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            btnUploadCompleteClick?.Invoke(this, new EventArgs());
        }
        #endregion

        private void uplUploadStamp_Uploaded(object sender, UploadedEventArgs e)
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            for (int i = 0; i < e.Files.Count; i++)
            {
                StoreFile(e.Files[i], AttachmentTypes.Weld_Stamp, wq.WeldingAction.Job.QuoteNumber, typeof(Welder_Qualification), wq.Welder_QualificationId);
            }

            Load_Action(true);
        }

        private void uplUploadReports_Uploaded(object sender, UploadedEventArgs e)
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            for (int i = 0; i < e.Files.Count; i++)
            {
                StoreFile(e.Files[i], AttachmentTypes.NATA_Report, wq.WeldingAction.Job.QuoteNumber, typeof(Welder_Qualification), wq.Welder_QualificationId);
            }

            Load_Action(true);
        }

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            wq.Status = Actions.Complete;

            ApiCalls.UpdateWelderQualification(wq.Welder_QualificationId, wq);

            this.Tag = new Tag(ApiCalls.ReadWelderQualification(wq.Welder_QualificationId), TagType.Welder_Qualification);
        }

        private void Save_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            wq.Pass = btnUploadPass.BackColor == System.Drawing.Color.FromName("@switchOn");

            ApiCalls.UpdateWelderQualification(wq.Welder_QualificationId, wq);

            this.Tag = new Tag(ApiCalls.ReadWelderQualification(wq.Welder_QualificationId), TagType.Welder_Qualification);
        }

        private void Load_Action(bool filesOnly = false)
        {
            uplUploadStamp.Visible = true;

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            if (!filesOnly)
            {
                btnUploadPass.BackColor = wq.Pass == true ? System.Drawing.Color.FromName("@switchOn") : System.Drawing.Color.FromName("@controlLight");
                btnUploadFail.BackColor = wq.Pass == true ? System.Drawing.Color.FromName("@controlLight") : System.Drawing.Color.FromName("@invalid");
            }

            lvUpload.Items.Clear();

            foreach (Attachment att in wq.Attachments)
            {
                ListViewItem lvItem = new ListViewItem(new string[] { att.ServerPath.Split('\\').Last(), UIFormatting.GetEnumDisplayName(att.AttachmentType) });
                lvItem.Tag = new Tag(att, TagType.Attachment);
                lvUpload.Items.Add(lvItem);

                switch (att.AttachmentType)
                {
                    case AttachmentTypes.Weld_Stamp:
                        uplUploadStamp.Visible = false;
                        break;
                }
            }

            lvUpload.Refresh();

            UIFormatting.ResizeColumnsFor(lvUpload);

            if (pbUpload != null && pbUpload.Image != null)
            {
                pbUpload.Image.Dispose();
            }

            if (pvUpload != null && pvUpload.PdfStream != null)
            {
                pvUpload.PdfStream = null;
            }

            pvUpload.Visible = true;
            pbUpload.Visible = false;

            tlpUpload.RowStyles[tlpUpload.GetCellPosition(pvUpload).Row].SizeType = SizeType.Percent;
            tlpUpload.RowStyles[tlpUpload.GetCellPosition(pvUpload).Row].Height = 80;

            tlpUpload.RowStyles[tlpUpload.GetCellPosition(pbUpload).Row].SizeType = SizeType.Percent;
            tlpUpload.RowStyles[tlpUpload.GetCellPosition(pbUpload).Row].Height = 0;
        }

        private void btnUploadPass_Click(object sender, EventArgs e)
        {
            btnUploadPass.BackColor = System.Drawing.Color.FromName("@switchOn");
            btnUploadFail.BackColor = System.Drawing.Color.FromName("@controlLight");
        }

        private void btnUploadFail_Click(object sender, EventArgs e)
        {
            btnUploadPass.BackColor = System.Drawing.Color.FromName("@controlLight");
            btnUploadFail.BackColor = System.Drawing.Color.FromName("@invalid");
        }

        private void uc_wqReports_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private void lvUpload_Resize(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            UIFormatting.ResizeColumnsFor(lvUpload);
        }

        private void lvUpload_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvUpload.SelectedIndex < 0)
            {
                return;
            }

            Tag itemTag = (Tag)lvUpload.Items[lvUpload.SelectedIndex].Tag;

            ViewAttachment(itemTag, pbUpload, pvUpload, tlpUpload);
        }

        private void btnUploadDelete_Click(object sender, EventArgs e)
        {
            if (lvUpload.SelectedIndex < 0)
            {
                return;
            }

            Tag itemTag = (Tag)lvUpload.Items[lvUpload.SelectedIndex].Tag;

            DeleteAttachment(itemTag, pbUpload, pvUpload);

            Load_Action(true);
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }
    }
}
