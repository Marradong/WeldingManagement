﻿namespace WeldingManagement.UserControls.VisualControls
{
    partial class uc_wqInspection
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_wqInspection));
            this.tableLayoutPanel5 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel6 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel8 = new Wisej.Web.TableLayoutPanel();
            this.btnVisualBack = new Wisej.Web.Button();
            this.btnVisualHome = new Wisej.Web.Button();
            this.btnVisualComplete = new Wisej.Web.Button();
            this.tableLayoutPanel7 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel32 = new Wisej.Web.TableLayoutPanel();
            this.label7 = new Wisej.Web.Label();
            this.tableLayoutPanel14 = new Wisej.Web.TableLayoutPanel();
            this.btnVisualNSatisfactory = new Wisej.Web.Button();
            this.btnVisualYSatisfactory = new Wisej.Web.Button();
            this.btnVisualNPorosity = new Wisej.Web.Button();
            this.btnVisualYPorosity = new Wisej.Web.Button();
            this.btnVisualNQualification = new Wisej.Web.Button();
            this.btnVisualYQualification = new Wisej.Web.Button();
            this.btnVisualNCrater = new Wisej.Web.Button();
            this.btnVisualYCrater = new Wisej.Web.Button();
            this.btnVisualNFusion = new Wisej.Web.Button();
            this.btnVisualYFusion = new Wisej.Web.Button();
            this.btnVisualNProcedure = new Wisej.Web.Button();
            this.btnVisualYProcedure = new Wisej.Web.Button();
            this.btnVisualNSuckBack = new Wisej.Web.Button();
            this.btnVisualYSuckBack = new Wisej.Web.Button();
            this.btnVisualNPenetration = new Wisej.Web.Button();
            this.btnVisualYPenetration = new Wisej.Web.Button();
            this.btnVisualNFinal = new Wisej.Web.Button();
            this.btnVisualYFinal = new Wisej.Web.Button();
            this.btnVisualNReinforcement = new Wisej.Web.Button();
            this.btnVisualYReinforcement = new Wisej.Web.Button();
            this.btnVisualNCracks = new Wisej.Web.Button();
            this.btnVisualYCracks = new Wisej.Web.Button();
            this.btnVisualNRepair = new Wisej.Web.Button();
            this.btnVisualYRepair = new Wisej.Web.Button();
            this.btnVisualNArc = new Wisej.Web.Button();
            this.btnVisualYArc = new Wisej.Web.Button();
            this.btnVisualNLocation = new Wisej.Web.Button();
            this.btnVisualYLocation = new Wisej.Web.Button();
            this.btnVisualNInitial = new Wisej.Web.Button();
            this.btnVisualYInitial = new Wisej.Web.Button();
            this.btnVisualNUndercut = new Wisej.Web.Button();
            this.btnVisualYUndercut = new Wisej.Web.Button();
            this.btnVisualNSize = new Wisej.Web.Button();
            this.btnVisualYSize = new Wisej.Web.Button();
            this.btnVisualNWeldersID = new Wisej.Web.Button();
            this.btnVisualNBurn = new Wisej.Web.Button();
            this.btnVisualYBurn = new Wisej.Web.Button();
            this.btnVisualNControl = new Wisej.Web.Button();
            this.btnVisualYControl = new Wisej.Web.Button();
            this.btnVisualNWeldID = new Wisej.Web.Button();
            this.btnVisualYWeldersID = new Wisej.Web.Button();
            this.btnVisualYWeldID = new Wisej.Web.Button();
            this.label17 = new Wisej.Web.Label();
            this.label11 = new Wisej.Web.Label();
            this.label18 = new Wisej.Web.Label();
            this.label20 = new Wisej.Web.Label();
            this.label8 = new Wisej.Web.Label();
            this.label12 = new Wisej.Web.Label();
            this.label19 = new Wisej.Web.Label();
            this.label23 = new Wisej.Web.Label();
            this.label21 = new Wisej.Web.Label();
            this.label24 = new Wisej.Web.Label();
            this.label25 = new Wisej.Web.Label();
            this.label22 = new Wisej.Web.Label();
            this.label26 = new Wisej.Web.Label();
            this.label27 = new Wisej.Web.Label();
            this.label33 = new Wisej.Web.Label();
            this.label29 = new Wisej.Web.Label();
            this.label28 = new Wisej.Web.Label();
            this.label32 = new Wisej.Web.Label();
            this.label34 = new Wisej.Web.Label();
            this.label36 = new Wisej.Web.Label();
            this.label30 = new Wisej.Web.Label();
            this.tableLayoutPanel13 = new Wisej.Web.TableLayoutPanel();
            this.dtpVisualDate = new Wisej.Web.DateTimePicker();
            this.txtVisualNotes = new Wisej.Web.TextBox();
            this.txtVisualDrawing = new Wisej.Web.TextBox();
            this.txtVisualMap = new Wisej.Web.TextBox();
            this.txtVisualLocation = new Wisej.Web.TextBox();
            this.txtVisualJob = new Wisej.Web.TextBox();
            this.txtVisualMatGrade = new Wisej.Web.TextBox();
            this.txtVisualMatStandard = new Wisej.Web.TextBox();
            this.txtVisualStandard = new Wisej.Web.TextBox();
            this.txtVisualWelder = new Wisej.Web.TextBox();
            this.txtVisualWPQR = new Wisej.Web.TextBox();
            this.label100 = new Wisej.Web.Label();
            this.label14 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.label1 = new Wisej.Web.Label();
            this.txtVisualSerial = new Wisej.Web.TextBox();
            this.label40 = new Wisej.Web.Label();
            this.label10 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.label13 = new Wisej.Web.Label();
            this.label101 = new Wisej.Web.Label();
            this.label4 = new Wisej.Web.Label();
            this.label5 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.tableLayoutPanel9 = new Wisej.Web.TableLayoutPanel();
            this.lblInfoNote = new Wisej.Web.LinkLabel();
            this.label16 = new Wisej.Web.Label();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel32.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel5.ColumnCount = 3;
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel6, 1, 3);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel9, 1, 1);
            this.tableLayoutPanel5.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 5;
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel1, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel7, 0, 0);
            this.tableLayoutPanel6.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel6.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel8, 0, 0);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel8.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Controls.Add(this.btnVisualBack, 0, 2);
            this.tableLayoutPanel8.Controls.Add(this.btnVisualHome, 0, 3);
            this.tableLayoutPanel8.Controls.Add(this.btnVisualComplete, 0, 4);
            this.tableLayoutPanel8.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel8.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 6);
            this.tableLayoutPanel8.Margin = new Wisej.Web.Padding(3, 6, 3, 6);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 5;
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(103, 421);
            this.tableLayoutPanel8.TabIndex = 4;
            // 
            // btnVisualBack
            // 
            this.btnVisualBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnVisualBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualBack.Location = new System.Drawing.Point(3, 169);
            this.btnVisualBack.Name = "btnVisualBack";
            this.btnVisualBack.Size = new System.Drawing.Size(95, 77);
            this.btnVisualBack.TabIndex = 56;
            this.btnVisualBack.Text = "Back";
            this.btnVisualBack.Click += new System.EventHandler(this.btnVisualBack_Click);
            // 
            // btnVisualHome
            // 
            this.btnVisualHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnVisualHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualHome.Location = new System.Drawing.Point(3, 252);
            this.btnVisualHome.Name = "btnVisualHome";
            this.btnVisualHome.Size = new System.Drawing.Size(95, 77);
            this.btnVisualHome.TabIndex = 55;
            this.btnVisualHome.Text = "Home";
            this.btnVisualHome.Click += new System.EventHandler(this.btnVisualHome_Click);
            // 
            // btnVisualComplete
            // 
            this.btnVisualComplete.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnVisualComplete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualComplete.Location = new System.Drawing.Point(3, 335);
            this.btnVisualComplete.Name = "btnVisualComplete";
            this.btnVisualComplete.Size = new System.Drawing.Size(95, 81);
            this.btnVisualComplete.TabIndex = 54;
            this.btnVisualComplete.Text = "Complete";
            this.btnVisualComplete.Click += new System.EventHandler(this.btnVisualComplete_Click);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel32, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel14, 0, 2);
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel13, 0, 0);
            this.tableLayoutPanel7.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 3;
            this.tableLayoutPanel7.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 47F));
            this.tableLayoutPanel7.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel7.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 47F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel7.TabIndex = 4;
            // 
            // tableLayoutPanel32
            // 
            this.tableLayoutPanel32.ColumnCount = 1;
            this.tableLayoutPanel32.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel32.Controls.Add(this.label7, 0, 0);
            this.tableLayoutPanel32.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel32.Location = new System.Drawing.Point(3, 206);
            this.tableLayoutPanel32.Name = "tableLayoutPanel32";
            this.tableLayoutPanel32.RowCount = 1;
            this.tableLayoutPanel32.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel32.Size = new System.Drawing.Size(1018, 19);
            this.tableLayoutPanel32.TabIndex = 53;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label7.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label7.Dock = Wisej.Web.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(3, 0);
            this.label7.Margin = new Wisej.Web.Padding(3, 0, 3, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(1012, 19);
            this.label7.TabIndex = 52;
            this.label7.Text = "Inspection results (S: Satisfactory   U: Unsatisfactory)";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 9;
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNSatisfactory, 8, 6);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYSatisfactory, 7, 6);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNPorosity, 5, 6);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYPorosity, 4, 6);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNQualification, 2, 6);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYQualification, 1, 6);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNCrater, 8, 5);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYCrater, 7, 5);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNFusion, 5, 5);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYFusion, 4, 5);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNProcedure, 2, 5);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYProcedure, 1, 5);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNSuckBack, 8, 4);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYSuckBack, 7, 4);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNPenetration, 5, 4);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYPenetration, 4, 4);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNFinal, 2, 4);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYFinal, 1, 4);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNReinforcement, 8, 3);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYReinforcement, 7, 3);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNCracks, 5, 3);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYCracks, 4, 3);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNRepair, 2, 3);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYRepair, 1, 3);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNArc, 8, 2);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYArc, 7, 2);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNLocation, 5, 2);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYLocation, 4, 2);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNInitial, 2, 2);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYInitial, 1, 2);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNUndercut, 8, 1);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYUndercut, 7, 1);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNSize, 5, 1);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYSize, 4, 1);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNWeldersID, 2, 1);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNBurn, 8, 0);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYBurn, 7, 0);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNControl, 5, 0);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYControl, 4, 0);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualNWeldID, 2, 0);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYWeldersID, 1, 1);
            this.tableLayoutPanel14.Controls.Add(this.btnVisualYWeldID, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.label11, 0, 1);
            this.tableLayoutPanel14.Controls.Add(this.label18, 0, 2);
            this.tableLayoutPanel14.Controls.Add(this.label20, 0, 3);
            this.tableLayoutPanel14.Controls.Add(this.label8, 0, 4);
            this.tableLayoutPanel14.Controls.Add(this.label12, 0, 5);
            this.tableLayoutPanel14.Controls.Add(this.label19, 0, 6);
            this.tableLayoutPanel14.Controls.Add(this.label23, 3, 0);
            this.tableLayoutPanel14.Controls.Add(this.label21, 3, 1);
            this.tableLayoutPanel14.Controls.Add(this.label24, 3, 2);
            this.tableLayoutPanel14.Controls.Add(this.label25, 3, 3);
            this.tableLayoutPanel14.Controls.Add(this.label22, 3, 4);
            this.tableLayoutPanel14.Controls.Add(this.label26, 3, 5);
            this.tableLayoutPanel14.Controls.Add(this.label27, 3, 6);
            this.tableLayoutPanel14.Controls.Add(this.label33, 6, 5);
            this.tableLayoutPanel14.Controls.Add(this.label29, 6, 4);
            this.tableLayoutPanel14.Controls.Add(this.label28, 6, 6);
            this.tableLayoutPanel14.Controls.Add(this.label32, 6, 3);
            this.tableLayoutPanel14.Controls.Add(this.label34, 6, 2);
            this.tableLayoutPanel14.Controls.Add(this.label36, 6, 1);
            this.tableLayoutPanel14.Controls.Add(this.label30, 6, 0);
            this.tableLayoutPanel14.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(3, 231);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 7;
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(1018, 199);
            this.tableLayoutPanel14.TabIndex = 52;
            // 
            // btnVisualNSatisfactory
            // 
            this.btnVisualNSatisfactory.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNSatisfactory.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNSatisfactory.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNSatisfactory.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNSatisfactory.Location = new System.Drawing.Point(961, 171);
            this.btnVisualNSatisfactory.Name = "btnVisualNSatisfactory";
            this.btnVisualNSatisfactory.Size = new System.Drawing.Size(54, 25);
            this.btnVisualNSatisfactory.TabIndex = 53;
            this.btnVisualNSatisfactory.Text = "U";
            this.btnVisualNSatisfactory.Click += new System.EventHandler(this.btnVisualNSatisfactory_Click);
            // 
            // btnVisualYSatisfactory
            // 
            this.btnVisualYSatisfactory.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYSatisfactory.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYSatisfactory.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYSatisfactory.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYSatisfactory.Location = new System.Drawing.Point(905, 171);
            this.btnVisualYSatisfactory.Name = "btnVisualYSatisfactory";
            this.btnVisualYSatisfactory.Size = new System.Drawing.Size(50, 25);
            this.btnVisualYSatisfactory.TabIndex = 52;
            this.btnVisualYSatisfactory.Text = "S";
            this.btnVisualYSatisfactory.Click += new System.EventHandler(this.btnVisualYSatisfactory_Click);
            // 
            // btnVisualNPorosity
            // 
            this.btnVisualNPorosity.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNPorosity.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNPorosity.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNPorosity.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNPorosity.Location = new System.Drawing.Point(623, 171);
            this.btnVisualNPorosity.Name = "btnVisualNPorosity";
            this.btnVisualNPorosity.Size = new System.Drawing.Size(50, 25);
            this.btnVisualNPorosity.TabIndex = 39;
            this.btnVisualNPorosity.Text = "U";
            this.btnVisualNPorosity.Click += new System.EventHandler(this.btnVisualNPorosity_Click);
            // 
            // btnVisualYPorosity
            // 
            this.btnVisualYPorosity.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYPorosity.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYPorosity.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYPorosity.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYPorosity.Location = new System.Drawing.Point(567, 171);
            this.btnVisualYPorosity.Name = "btnVisualYPorosity";
            this.btnVisualYPorosity.Size = new System.Drawing.Size(50, 25);
            this.btnVisualYPorosity.TabIndex = 38;
            this.btnVisualYPorosity.Text = "S";
            this.btnVisualYPorosity.Click += new System.EventHandler(this.btnVisualYPorosity_Click);
            // 
            // btnVisualNQualification
            // 
            this.btnVisualNQualification.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNQualification.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNQualification.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNQualification.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNQualification.Location = new System.Drawing.Point(285, 171);
            this.btnVisualNQualification.Name = "btnVisualNQualification";
            this.btnVisualNQualification.Size = new System.Drawing.Size(50, 25);
            this.btnVisualNQualification.TabIndex = 25;
            this.btnVisualNQualification.Text = "U";
            this.btnVisualNQualification.Click += new System.EventHandler(this.btnVisualNQualification_Click);
            // 
            // btnVisualYQualification
            // 
            this.btnVisualYQualification.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYQualification.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYQualification.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYQualification.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYQualification.Location = new System.Drawing.Point(229, 171);
            this.btnVisualYQualification.Name = "btnVisualYQualification";
            this.btnVisualYQualification.Size = new System.Drawing.Size(50, 25);
            this.btnVisualYQualification.TabIndex = 24;
            this.btnVisualYQualification.Text = "S";
            this.btnVisualYQualification.Click += new System.EventHandler(this.btnVisualYQualification_Click);
            // 
            // btnVisualNCrater
            // 
            this.btnVisualNCrater.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNCrater.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNCrater.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNCrater.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNCrater.Location = new System.Drawing.Point(961, 143);
            this.btnVisualNCrater.Name = "btnVisualNCrater";
            this.btnVisualNCrater.Size = new System.Drawing.Size(54, 22);
            this.btnVisualNCrater.TabIndex = 51;
            this.btnVisualNCrater.Text = "U";
            this.btnVisualNCrater.Click += new System.EventHandler(this.btnVisualNCrater_Click);
            // 
            // btnVisualYCrater
            // 
            this.btnVisualYCrater.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYCrater.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYCrater.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYCrater.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYCrater.Location = new System.Drawing.Point(905, 143);
            this.btnVisualYCrater.Name = "btnVisualYCrater";
            this.btnVisualYCrater.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYCrater.TabIndex = 50;
            this.btnVisualYCrater.Text = "S";
            this.btnVisualYCrater.Click += new System.EventHandler(this.btnVisualYCrater_Click);
            // 
            // btnVisualNFusion
            // 
            this.btnVisualNFusion.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNFusion.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNFusion.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNFusion.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNFusion.Location = new System.Drawing.Point(623, 143);
            this.btnVisualNFusion.Name = "btnVisualNFusion";
            this.btnVisualNFusion.Size = new System.Drawing.Size(50, 22);
            this.btnVisualNFusion.TabIndex = 37;
            this.btnVisualNFusion.Text = "U";
            this.btnVisualNFusion.Click += new System.EventHandler(this.btnVisualNFusion_Click);
            // 
            // btnVisualYFusion
            // 
            this.btnVisualYFusion.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYFusion.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYFusion.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYFusion.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYFusion.Location = new System.Drawing.Point(567, 143);
            this.btnVisualYFusion.Name = "btnVisualYFusion";
            this.btnVisualYFusion.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYFusion.TabIndex = 36;
            this.btnVisualYFusion.Text = "S";
            this.btnVisualYFusion.Click += new System.EventHandler(this.btnVisualYFusion_Click);
            // 
            // btnVisualNProcedure
            // 
            this.btnVisualNProcedure.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNProcedure.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNProcedure.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNProcedure.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNProcedure.Location = new System.Drawing.Point(285, 143);
            this.btnVisualNProcedure.Name = "btnVisualNProcedure";
            this.btnVisualNProcedure.Size = new System.Drawing.Size(50, 22);
            this.btnVisualNProcedure.TabIndex = 23;
            this.btnVisualNProcedure.Text = "U";
            this.btnVisualNProcedure.Click += new System.EventHandler(this.btnVisualNProcedure_Click);
            // 
            // btnVisualYProcedure
            // 
            this.btnVisualYProcedure.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYProcedure.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYProcedure.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYProcedure.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYProcedure.Location = new System.Drawing.Point(229, 143);
            this.btnVisualYProcedure.Name = "btnVisualYProcedure";
            this.btnVisualYProcedure.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYProcedure.TabIndex = 22;
            this.btnVisualYProcedure.Text = "S";
            this.btnVisualYProcedure.Click += new System.EventHandler(this.btnVisualYProcedure_Click);
            // 
            // btnVisualNSuckBack
            // 
            this.btnVisualNSuckBack.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNSuckBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNSuckBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNSuckBack.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNSuckBack.Location = new System.Drawing.Point(961, 115);
            this.btnVisualNSuckBack.Name = "btnVisualNSuckBack";
            this.btnVisualNSuckBack.Size = new System.Drawing.Size(54, 22);
            this.btnVisualNSuckBack.TabIndex = 49;
            this.btnVisualNSuckBack.Text = "U";
            this.btnVisualNSuckBack.Click += new System.EventHandler(this.btnVisualNSuckBack_Click);
            // 
            // btnVisualYSuckBack
            // 
            this.btnVisualYSuckBack.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYSuckBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYSuckBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYSuckBack.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYSuckBack.Location = new System.Drawing.Point(905, 115);
            this.btnVisualYSuckBack.Name = "btnVisualYSuckBack";
            this.btnVisualYSuckBack.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYSuckBack.TabIndex = 48;
            this.btnVisualYSuckBack.Text = "S";
            this.btnVisualYSuckBack.Click += new System.EventHandler(this.btnVisualYSuckBack_Click);
            // 
            // btnVisualNPenetration
            // 
            this.btnVisualNPenetration.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNPenetration.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNPenetration.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNPenetration.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNPenetration.Location = new System.Drawing.Point(623, 115);
            this.btnVisualNPenetration.Name = "btnVisualNPenetration";
            this.btnVisualNPenetration.Size = new System.Drawing.Size(50, 22);
            this.btnVisualNPenetration.TabIndex = 35;
            this.btnVisualNPenetration.Text = "U";
            this.btnVisualNPenetration.Click += new System.EventHandler(this.btnVisualNPenetration_Click);
            // 
            // btnVisualYPenetration
            // 
            this.btnVisualYPenetration.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYPenetration.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYPenetration.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYPenetration.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYPenetration.Location = new System.Drawing.Point(567, 115);
            this.btnVisualYPenetration.Name = "btnVisualYPenetration";
            this.btnVisualYPenetration.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYPenetration.TabIndex = 34;
            this.btnVisualYPenetration.Text = "S";
            this.btnVisualYPenetration.Click += new System.EventHandler(this.btnVisualYPenetration_Click);
            // 
            // btnVisualNFinal
            // 
            this.btnVisualNFinal.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNFinal.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNFinal.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNFinal.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNFinal.Location = new System.Drawing.Point(285, 115);
            this.btnVisualNFinal.Name = "btnVisualNFinal";
            this.btnVisualNFinal.Size = new System.Drawing.Size(50, 22);
            this.btnVisualNFinal.TabIndex = 21;
            this.btnVisualNFinal.Text = "U";
            this.btnVisualNFinal.Click += new System.EventHandler(this.btnVisualNFinal_Click);
            // 
            // btnVisualYFinal
            // 
            this.btnVisualYFinal.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYFinal.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYFinal.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYFinal.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYFinal.Location = new System.Drawing.Point(229, 115);
            this.btnVisualYFinal.Name = "btnVisualYFinal";
            this.btnVisualYFinal.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYFinal.TabIndex = 20;
            this.btnVisualYFinal.Text = "S";
            this.btnVisualYFinal.Click += new System.EventHandler(this.btnVisualYFinal_Click);
            // 
            // btnVisualNReinforcement
            // 
            this.btnVisualNReinforcement.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNReinforcement.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNReinforcement.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNReinforcement.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNReinforcement.Location = new System.Drawing.Point(961, 87);
            this.btnVisualNReinforcement.Name = "btnVisualNReinforcement";
            this.btnVisualNReinforcement.Size = new System.Drawing.Size(54, 22);
            this.btnVisualNReinforcement.TabIndex = 47;
            this.btnVisualNReinforcement.Text = "U";
            this.btnVisualNReinforcement.Click += new System.EventHandler(this.btnVisualNReinforcement_Click);
            // 
            // btnVisualYReinforcement
            // 
            this.btnVisualYReinforcement.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYReinforcement.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYReinforcement.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYReinforcement.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYReinforcement.Location = new System.Drawing.Point(905, 87);
            this.btnVisualYReinforcement.Name = "btnVisualYReinforcement";
            this.btnVisualYReinforcement.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYReinforcement.TabIndex = 46;
            this.btnVisualYReinforcement.Text = "S";
            this.btnVisualYReinforcement.Click += new System.EventHandler(this.btnVisualYReinforcement_Click);
            // 
            // btnVisualNCracks
            // 
            this.btnVisualNCracks.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNCracks.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNCracks.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNCracks.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNCracks.Location = new System.Drawing.Point(623, 87);
            this.btnVisualNCracks.Name = "btnVisualNCracks";
            this.btnVisualNCracks.Size = new System.Drawing.Size(50, 22);
            this.btnVisualNCracks.TabIndex = 33;
            this.btnVisualNCracks.Text = "U";
            this.btnVisualNCracks.Click += new System.EventHandler(this.btnVisualNCracks_Click);
            // 
            // btnVisualYCracks
            // 
            this.btnVisualYCracks.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYCracks.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYCracks.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYCracks.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYCracks.Location = new System.Drawing.Point(567, 87);
            this.btnVisualYCracks.Name = "btnVisualYCracks";
            this.btnVisualYCracks.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYCracks.TabIndex = 32;
            this.btnVisualYCracks.Text = "S";
            this.btnVisualYCracks.Click += new System.EventHandler(this.btnVisualYCracks_Click);
            // 
            // btnVisualNRepair
            // 
            this.btnVisualNRepair.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNRepair.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNRepair.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNRepair.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNRepair.Location = new System.Drawing.Point(285, 87);
            this.btnVisualNRepair.Name = "btnVisualNRepair";
            this.btnVisualNRepair.Size = new System.Drawing.Size(50, 22);
            this.btnVisualNRepair.TabIndex = 19;
            this.btnVisualNRepair.Text = "U";
            this.btnVisualNRepair.Click += new System.EventHandler(this.btnVisualNRepair_Click);
            // 
            // btnVisualYRepair
            // 
            this.btnVisualYRepair.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYRepair.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYRepair.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYRepair.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYRepair.Location = new System.Drawing.Point(229, 87);
            this.btnVisualYRepair.Name = "btnVisualYRepair";
            this.btnVisualYRepair.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYRepair.TabIndex = 18;
            this.btnVisualYRepair.Text = "S";
            this.btnVisualYRepair.Click += new System.EventHandler(this.btnVisualYRepair_Click);
            // 
            // btnVisualNArc
            // 
            this.btnVisualNArc.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNArc.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNArc.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNArc.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNArc.Location = new System.Drawing.Point(961, 59);
            this.btnVisualNArc.Name = "btnVisualNArc";
            this.btnVisualNArc.Size = new System.Drawing.Size(54, 22);
            this.btnVisualNArc.TabIndex = 45;
            this.btnVisualNArc.Text = "U";
            this.btnVisualNArc.Click += new System.EventHandler(this.btnVisualNArc_Click);
            // 
            // btnVisualYArc
            // 
            this.btnVisualYArc.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYArc.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYArc.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYArc.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYArc.Location = new System.Drawing.Point(905, 59);
            this.btnVisualYArc.Name = "btnVisualYArc";
            this.btnVisualYArc.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYArc.TabIndex = 44;
            this.btnVisualYArc.Text = "S";
            this.btnVisualYArc.Click += new System.EventHandler(this.btnVisualYArc_Click);
            // 
            // btnVisualNLocation
            // 
            this.btnVisualNLocation.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNLocation.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNLocation.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNLocation.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNLocation.Location = new System.Drawing.Point(623, 59);
            this.btnVisualNLocation.Name = "btnVisualNLocation";
            this.btnVisualNLocation.Size = new System.Drawing.Size(50, 22);
            this.btnVisualNLocation.TabIndex = 31;
            this.btnVisualNLocation.Text = "U";
            this.btnVisualNLocation.Click += new System.EventHandler(this.btnVisualNLocation_Click);
            // 
            // btnVisualYLocation
            // 
            this.btnVisualYLocation.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYLocation.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYLocation.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYLocation.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYLocation.Location = new System.Drawing.Point(567, 59);
            this.btnVisualYLocation.Name = "btnVisualYLocation";
            this.btnVisualYLocation.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYLocation.TabIndex = 30;
            this.btnVisualYLocation.Text = "S";
            this.btnVisualYLocation.Click += new System.EventHandler(this.btnVisualYLocation_Click);
            // 
            // btnVisualNInitial
            // 
            this.btnVisualNInitial.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNInitial.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNInitial.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNInitial.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNInitial.Location = new System.Drawing.Point(285, 59);
            this.btnVisualNInitial.Name = "btnVisualNInitial";
            this.btnVisualNInitial.Size = new System.Drawing.Size(50, 22);
            this.btnVisualNInitial.TabIndex = 17;
            this.btnVisualNInitial.Text = "U";
            this.btnVisualNInitial.Click += new System.EventHandler(this.btnVisualNInitial_Click);
            // 
            // btnVisualYInitial
            // 
            this.btnVisualYInitial.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYInitial.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYInitial.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYInitial.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYInitial.Location = new System.Drawing.Point(229, 59);
            this.btnVisualYInitial.Name = "btnVisualYInitial";
            this.btnVisualYInitial.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYInitial.TabIndex = 16;
            this.btnVisualYInitial.Text = "S";
            this.btnVisualYInitial.Click += new System.EventHandler(this.btnVisualYInitial_Click);
            // 
            // btnVisualNUndercut
            // 
            this.btnVisualNUndercut.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNUndercut.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNUndercut.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNUndercut.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNUndercut.Location = new System.Drawing.Point(961, 31);
            this.btnVisualNUndercut.Name = "btnVisualNUndercut";
            this.btnVisualNUndercut.Size = new System.Drawing.Size(54, 22);
            this.btnVisualNUndercut.TabIndex = 43;
            this.btnVisualNUndercut.Text = "U";
            this.btnVisualNUndercut.Click += new System.EventHandler(this.btnVisualNUndercut_Click);
            // 
            // btnVisualYUndercut
            // 
            this.btnVisualYUndercut.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYUndercut.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYUndercut.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYUndercut.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYUndercut.Location = new System.Drawing.Point(905, 31);
            this.btnVisualYUndercut.Name = "btnVisualYUndercut";
            this.btnVisualYUndercut.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYUndercut.TabIndex = 42;
            this.btnVisualYUndercut.Text = "S";
            this.btnVisualYUndercut.Click += new System.EventHandler(this.btnVisualYUndercut_Click);
            // 
            // btnVisualNSize
            // 
            this.btnVisualNSize.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNSize.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNSize.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNSize.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNSize.Location = new System.Drawing.Point(623, 31);
            this.btnVisualNSize.Name = "btnVisualNSize";
            this.btnVisualNSize.Size = new System.Drawing.Size(50, 22);
            this.btnVisualNSize.TabIndex = 29;
            this.btnVisualNSize.Text = "U";
            this.btnVisualNSize.Click += new System.EventHandler(this.btnVisualNSize_Click);
            // 
            // btnVisualYSize
            // 
            this.btnVisualYSize.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYSize.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYSize.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYSize.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYSize.Location = new System.Drawing.Point(567, 31);
            this.btnVisualYSize.Name = "btnVisualYSize";
            this.btnVisualYSize.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYSize.TabIndex = 28;
            this.btnVisualYSize.Text = "S";
            this.btnVisualYSize.Click += new System.EventHandler(this.btnVisualYSize_Click);
            // 
            // btnVisualNWeldersID
            // 
            this.btnVisualNWeldersID.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNWeldersID.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNWeldersID.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNWeldersID.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNWeldersID.Location = new System.Drawing.Point(285, 31);
            this.btnVisualNWeldersID.Name = "btnVisualNWeldersID";
            this.btnVisualNWeldersID.Size = new System.Drawing.Size(50, 22);
            this.btnVisualNWeldersID.TabIndex = 15;
            this.btnVisualNWeldersID.Text = "U";
            this.btnVisualNWeldersID.Click += new System.EventHandler(this.btnVisualNWeldersID_Click);
            // 
            // btnVisualNBurn
            // 
            this.btnVisualNBurn.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNBurn.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNBurn.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNBurn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNBurn.Location = new System.Drawing.Point(961, 3);
            this.btnVisualNBurn.Name = "btnVisualNBurn";
            this.btnVisualNBurn.Size = new System.Drawing.Size(54, 22);
            this.btnVisualNBurn.TabIndex = 41;
            this.btnVisualNBurn.Text = "U";
            this.btnVisualNBurn.Click += new System.EventHandler(this.btnVisualNBurn_Click);
            // 
            // btnVisualYBurn
            // 
            this.btnVisualYBurn.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYBurn.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYBurn.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYBurn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYBurn.Location = new System.Drawing.Point(905, 3);
            this.btnVisualYBurn.Name = "btnVisualYBurn";
            this.btnVisualYBurn.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYBurn.TabIndex = 40;
            this.btnVisualYBurn.Text = "S";
            this.btnVisualYBurn.Click += new System.EventHandler(this.btnVisualYBurn_Click);
            // 
            // btnVisualNControl
            // 
            this.btnVisualNControl.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNControl.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNControl.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNControl.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNControl.Location = new System.Drawing.Point(623, 3);
            this.btnVisualNControl.Name = "btnVisualNControl";
            this.btnVisualNControl.Size = new System.Drawing.Size(50, 22);
            this.btnVisualNControl.TabIndex = 27;
            this.btnVisualNControl.Text = "U";
            this.btnVisualNControl.Click += new System.EventHandler(this.btnVisualNControl_Click);
            // 
            // btnVisualYControl
            // 
            this.btnVisualYControl.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYControl.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYControl.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYControl.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYControl.Location = new System.Drawing.Point(567, 3);
            this.btnVisualYControl.Name = "btnVisualYControl";
            this.btnVisualYControl.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYControl.TabIndex = 26;
            this.btnVisualYControl.Text = "S";
            this.btnVisualYControl.Click += new System.EventHandler(this.btnVisualYControl_Click);
            // 
            // btnVisualNWeldID
            // 
            this.btnVisualNWeldID.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualNWeldID.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualNWeldID.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualNWeldID.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualNWeldID.Location = new System.Drawing.Point(285, 3);
            this.btnVisualNWeldID.Name = "btnVisualNWeldID";
            this.btnVisualNWeldID.Size = new System.Drawing.Size(50, 22);
            this.btnVisualNWeldID.TabIndex = 13;
            this.btnVisualNWeldID.Text = "U";
            this.btnVisualNWeldID.Click += new System.EventHandler(this.btnVisualNWeldID_Click);
            // 
            // btnVisualYWeldersID
            // 
            this.btnVisualYWeldersID.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYWeldersID.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYWeldersID.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYWeldersID.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYWeldersID.Location = new System.Drawing.Point(229, 31);
            this.btnVisualYWeldersID.Name = "btnVisualYWeldersID";
            this.btnVisualYWeldersID.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYWeldersID.TabIndex = 14;
            this.btnVisualYWeldersID.Text = "S";
            this.btnVisualYWeldersID.Click += new System.EventHandler(this.btnVisualYWeldersID_Click);
            // 
            // btnVisualYWeldID
            // 
            this.btnVisualYWeldID.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.btnVisualYWeldID.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.btnVisualYWeldID.Dock = Wisej.Web.DockStyle.Fill;
            this.btnVisualYWeldID.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVisualYWeldID.Location = new System.Drawing.Point(229, 3);
            this.btnVisualYWeldID.Name = "btnVisualYWeldID";
            this.btnVisualYWeldID.Size = new System.Drawing.Size(50, 22);
            this.btnVisualYWeldID.TabIndex = 12;
            this.btnVisualYWeldID.Text = "S";
            this.btnVisualYWeldID.Click += new System.EventHandler(this.btnVisualYWeldID_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromName("@window");
            this.label17.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label17.Dock = Wisej.Web.DockStyle.Fill;
            this.label17.Location = new System.Drawing.Point(3, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(220, 22);
            this.label17.TabIndex = 55;
            this.label17.Text = "Weld Identification";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromName("@window");
            this.label11.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label11.Dock = Wisej.Web.DockStyle.Fill;
            this.label11.Location = new System.Drawing.Point(3, 31);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(220, 22);
            this.label11.TabIndex = 53;
            this.label11.Text = "Welders Identification";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.FromName("@window");
            this.label18.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label18.Dock = Wisej.Web.DockStyle.Fill;
            this.label18.Location = new System.Drawing.Point(3, 59);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(220, 22);
            this.label18.TabIndex = 56;
            this.label18.Text = "Initial Inspection";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.FromName("@window");
            this.label20.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label20.Dock = Wisej.Web.DockStyle.Fill;
            this.label20.Location = new System.Drawing.Point(3, 87);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(220, 22);
            this.label20.TabIndex = 58;
            this.label20.Text = "Repair Weld Inspection";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromName("@window");
            this.label8.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label8.Dock = Wisej.Web.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(3, 115);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(220, 22);
            this.label8.TabIndex = 52;
            this.label8.Text = "Final Inspection";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromName("@window");
            this.label12.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label12.Dock = Wisej.Web.DockStyle.Fill;
            this.label12.Location = new System.Drawing.Point(3, 143);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(220, 22);
            this.label12.TabIndex = 54;
            this.label12.Text = "Welding Procedure";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.FromName("@window");
            this.label19.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label19.Dock = Wisej.Web.DockStyle.Fill;
            this.label19.Location = new System.Drawing.Point(3, 171);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(220, 25);
            this.label19.TabIndex = 57;
            this.label19.Text = "Welder Qualification";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.FromName("@window");
            this.label23.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label23.Dock = Wisej.Web.DockStyle.Fill;
            this.label23.Location = new System.Drawing.Point(341, 3);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(220, 22);
            this.label23.TabIndex = 61;
            this.label23.Text = "Material Control";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.FromName("@window");
            this.label21.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label21.Dock = Wisej.Web.DockStyle.Fill;
            this.label21.Location = new System.Drawing.Point(341, 31);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(220, 22);
            this.label21.TabIndex = 59;
            this.label21.Text = "Weld Size / Profile";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FromName("@window");
            this.label24.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label24.Dock = Wisej.Web.DockStyle.Fill;
            this.label24.Location = new System.Drawing.Point(341, 59);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(220, 22);
            this.label24.TabIndex = 62;
            this.label24.Text = "Weld Location";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.FromName("@window");
            this.label25.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label25.Dock = Wisej.Web.DockStyle.Fill;
            this.label25.Location = new System.Drawing.Point(341, 87);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(220, 22);
            this.label25.TabIndex = 63;
            this.label25.Text = "Cracks";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromName("@window");
            this.label22.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label22.Dock = Wisej.Web.DockStyle.Fill;
            this.label22.Location = new System.Drawing.Point(341, 115);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(220, 22);
            this.label22.TabIndex = 60;
            this.label22.Text = "Incomplete Penetration";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.FromName("@window");
            this.label26.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label26.Dock = Wisej.Web.DockStyle.Fill;
            this.label26.Location = new System.Drawing.Point(341, 143);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(220, 22);
            this.label26.TabIndex = 64;
            this.label26.Text = "Incomplete Fusion";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.FromName("@window");
            this.label27.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label27.Dock = Wisej.Web.DockStyle.Fill;
            this.label27.Location = new System.Drawing.Point(341, 171);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(220, 25);
            this.label27.TabIndex = 65;
            this.label27.Text = "Porosity";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.FromName("@window");
            this.label33.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label33.Dock = Wisej.Web.DockStyle.Fill;
            this.label33.Location = new System.Drawing.Point(679, 143);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(220, 22);
            this.label33.TabIndex = 70;
            this.label33.Text = "Crater Cross Section";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.FromName("@window");
            this.label29.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label29.Dock = Wisej.Web.DockStyle.Fill;
            this.label29.Location = new System.Drawing.Point(679, 115);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(220, 22);
            this.label29.TabIndex = 67;
            this.label29.Text = "SuckBack";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.FromName("@window");
            this.label28.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label28.Dock = Wisej.Web.DockStyle.Fill;
            this.label28.Location = new System.Drawing.Point(679, 171);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(220, 25);
            this.label28.TabIndex = 66;
            this.label28.Text = "Satisfactory";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.FromName("@window");
            this.label32.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label32.Dock = Wisej.Web.DockStyle.Fill;
            this.label32.Location = new System.Drawing.Point(679, 87);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(220, 22);
            this.label32.TabIndex = 69;
            this.label32.Text = "Weld Reinforcement";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.FromName("@window");
            this.label34.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label34.Dock = Wisej.Web.DockStyle.Fill;
            this.label34.Location = new System.Drawing.Point(679, 59);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(220, 22);
            this.label34.TabIndex = 71;
            this.label34.Text = "Arc Strike";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.FromName("@window");
            this.label36.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label36.Dock = Wisej.Web.DockStyle.Fill;
            this.label36.Location = new System.Drawing.Point(679, 31);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(220, 22);
            this.label36.TabIndex = 72;
            this.label36.Text = "Undercut";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.FromName("@window");
            this.label30.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label30.Dock = Wisej.Web.DockStyle.Fill;
            this.label30.Location = new System.Drawing.Point(679, 3);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(220, 22);
            this.label30.TabIndex = 68;
            this.label30.Text = "Burn Through";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 4;
            this.tableLayoutPanel13.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel13.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel13.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel13.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel13.Controls.Add(this.dtpVisualDate, 3, 1);
            this.tableLayoutPanel13.Controls.Add(this.txtVisualNotes, 3, 5);
            this.tableLayoutPanel13.Controls.Add(this.txtVisualDrawing, 3, 4);
            this.tableLayoutPanel13.Controls.Add(this.txtVisualMap, 3, 3);
            this.tableLayoutPanel13.Controls.Add(this.txtVisualLocation, 3, 2);
            this.tableLayoutPanel13.Controls.Add(this.txtVisualJob, 3, 0);
            this.tableLayoutPanel13.Controls.Add(this.txtVisualMatGrade, 1, 4);
            this.tableLayoutPanel13.Controls.Add(this.txtVisualMatStandard, 1, 3);
            this.tableLayoutPanel13.Controls.Add(this.txtVisualStandard, 1, 2);
            this.tableLayoutPanel13.Controls.Add(this.txtVisualWelder, 1, 1);
            this.tableLayoutPanel13.Controls.Add(this.txtVisualWPQR, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.label100, 2, 2);
            this.tableLayoutPanel13.Controls.Add(this.label14, 2, 1);
            this.tableLayoutPanel13.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel13.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.txtVisualSerial, 1, 5);
            this.tableLayoutPanel13.Controls.Add(this.label40, 0, 3);
            this.tableLayoutPanel13.Controls.Add(this.label10, 0, 4);
            this.tableLayoutPanel13.Controls.Add(this.label2, 2, 0);
            this.tableLayoutPanel13.Controls.Add(this.label13, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.label101, 2, 3);
            this.tableLayoutPanel13.Controls.Add(this.label4, 2, 4);
            this.tableLayoutPanel13.Controls.Add(this.label5, 0, 5);
            this.tableLayoutPanel13.Controls.Add(this.label6, 2, 5);
            this.tableLayoutPanel13.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 6;
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(1018, 197);
            this.tableLayoutPanel13.TabIndex = 5;
            // 
            // dtpVisualDate
            // 
            this.dtpVisualDate.Dock = Wisej.Web.DockStyle.Fill;
            this.dtpVisualDate.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpVisualDate.Location = new System.Drawing.Point(765, 35);
            this.dtpVisualDate.Name = "dtpVisualDate";
            this.dtpVisualDate.Size = new System.Drawing.Size(250, 26);
            this.dtpVisualDate.TabIndex = 7;
            this.dtpVisualDate.Value = new System.DateTime(2024, 8, 30, 0, 0, 0, 0);
            // 
            // txtVisualNotes
            // 
            this.txtVisualNotes.Dock = Wisej.Web.DockStyle.Fill;
            this.txtVisualNotes.Location = new System.Drawing.Point(765, 163);
            this.txtVisualNotes.Name = "txtVisualNotes";
            this.txtVisualNotes.Size = new System.Drawing.Size(250, 31);
            this.txtVisualNotes.TabIndex = 11;
            // 
            // txtVisualDrawing
            // 
            this.txtVisualDrawing.Dock = Wisej.Web.DockStyle.Fill;
            this.txtVisualDrawing.Location = new System.Drawing.Point(765, 131);
            this.txtVisualDrawing.Name = "txtVisualDrawing";
            this.txtVisualDrawing.Size = new System.Drawing.Size(250, 26);
            this.txtVisualDrawing.TabIndex = 10;
            // 
            // txtVisualMap
            // 
            this.txtVisualMap.Dock = Wisej.Web.DockStyle.Fill;
            this.txtVisualMap.Location = new System.Drawing.Point(765, 99);
            this.txtVisualMap.Name = "txtVisualMap";
            this.txtVisualMap.Size = new System.Drawing.Size(250, 26);
            this.txtVisualMap.TabIndex = 9;
            // 
            // txtVisualLocation
            // 
            this.txtVisualLocation.Dock = Wisej.Web.DockStyle.Fill;
            this.txtVisualLocation.Location = new System.Drawing.Point(765, 67);
            this.txtVisualLocation.Name = "txtVisualLocation";
            this.txtVisualLocation.Size = new System.Drawing.Size(250, 26);
            this.txtVisualLocation.TabIndex = 8;
            // 
            // txtVisualJob
            // 
            this.txtVisualJob.Dock = Wisej.Web.DockStyle.Fill;
            this.txtVisualJob.Location = new System.Drawing.Point(765, 3);
            this.txtVisualJob.Name = "txtVisualJob";
            this.txtVisualJob.Size = new System.Drawing.Size(250, 26);
            this.txtVisualJob.TabIndex = 6;
            // 
            // txtVisualMatGrade
            // 
            this.txtVisualMatGrade.Dock = Wisej.Web.DockStyle.Fill;
            this.txtVisualMatGrade.Location = new System.Drawing.Point(257, 131);
            this.txtVisualMatGrade.Name = "txtVisualMatGrade";
            this.txtVisualMatGrade.Size = new System.Drawing.Size(248, 26);
            this.txtVisualMatGrade.TabIndex = 4;
            // 
            // txtVisualMatStandard
            // 
            this.txtVisualMatStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtVisualMatStandard.Location = new System.Drawing.Point(257, 99);
            this.txtVisualMatStandard.Name = "txtVisualMatStandard";
            this.txtVisualMatStandard.Size = new System.Drawing.Size(248, 26);
            this.txtVisualMatStandard.TabIndex = 3;
            // 
            // txtVisualStandard
            // 
            this.txtVisualStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtVisualStandard.Location = new System.Drawing.Point(257, 67);
            this.txtVisualStandard.Name = "txtVisualStandard";
            this.txtVisualStandard.Size = new System.Drawing.Size(248, 26);
            this.txtVisualStandard.TabIndex = 2;
            // 
            // txtVisualWelder
            // 
            this.txtVisualWelder.Dock = Wisej.Web.DockStyle.Fill;
            this.txtVisualWelder.Location = new System.Drawing.Point(257, 35);
            this.txtVisualWelder.Name = "txtVisualWelder";
            this.txtVisualWelder.Size = new System.Drawing.Size(248, 26);
            this.txtVisualWelder.TabIndex = 1;
            // 
            // txtVisualWPQR
            // 
            this.txtVisualWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.txtVisualWPQR.Location = new System.Drawing.Point(257, 3);
            this.txtVisualWPQR.Name = "txtVisualWPQR";
            this.txtVisualWPQR.Size = new System.Drawing.Size(248, 26);
            this.txtVisualWPQR.TabIndex = 0;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.BackColor = System.Drawing.Color.FromName("@window");
            this.label100.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label100.Dock = Wisej.Web.DockStyle.Fill;
            this.label100.Location = new System.Drawing.Point(511, 67);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(248, 26);
            this.label100.TabIndex = 14;
            this.label100.Text = "Location";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromName("@window");
            this.label14.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label14.Dock = Wisej.Web.DockStyle.Fill;
            this.label14.Location = new System.Drawing.Point(511, 35);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(248, 26);
            this.label14.TabIndex = 13;
            this.label14.Text = "Date";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromName("@window");
            this.label3.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label3.Dock = Wisej.Web.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(248, 26);
            this.label3.TabIndex = 2;
            this.label3.Text = "Welding Standard";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromName("@window");
            this.label1.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(248, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "WPQR Number";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtVisualSerial
            // 
            this.txtVisualSerial.Dock = Wisej.Web.DockStyle.Fill;
            this.txtVisualSerial.Location = new System.Drawing.Point(257, 163);
            this.txtVisualSerial.Name = "txtVisualSerial";
            this.txtVisualSerial.Size = new System.Drawing.Size(248, 31);
            this.txtVisualSerial.TabIndex = 5;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.FromName("@window");
            this.label40.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label40.Dock = Wisej.Web.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(3, 99);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(248, 26);
            this.label40.TabIndex = 8;
            this.label40.Text = "Material Standard";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromName("@window");
            this.label10.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label10.Dock = Wisej.Web.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(3, 131);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(248, 26);
            this.label10.TabIndex = 9;
            this.label10.Text = "Material Grade";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromName("@window");
            this.label2.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(511, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(248, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "Job Number";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromName("@window");
            this.label13.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label13.Dock = Wisej.Web.DockStyle.Fill;
            this.label13.Location = new System.Drawing.Point(3, 35);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(248, 26);
            this.label13.TabIndex = 12;
            this.label13.Text = "Welder ID";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.BackColor = System.Drawing.Color.FromName("@window");
            this.label101.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label101.Dock = Wisej.Web.DockStyle.Fill;
            this.label101.Location = new System.Drawing.Point(511, 99);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(248, 26);
            this.label101.TabIndex = 18;
            this.label101.Text = "Weld Map";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromName("@window");
            this.label4.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label4.Dock = Wisej.Web.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(511, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(248, 26);
            this.label4.TabIndex = 48;
            this.label4.Text = "Drawing Numbers";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromName("@window");
            this.label5.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label5.Dock = Wisej.Web.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(3, 163);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(248, 31);
            this.label5.TabIndex = 49;
            this.label5.Text = "Quantity / Item Serial Numbers";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromName("@window");
            this.label6.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label6.Dock = Wisej.Web.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(511, 163);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(248, 31);
            this.label6.TabIndex = 50;
            this.label6.Text = "Notes / Remarks";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.lblInfoNote, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel9.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 2;
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel9.TabIndex = 0;
            // 
            // lblInfoNote
            // 
            this.lblInfoNote.AutoSize = true;
            this.lblInfoNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblInfoNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblInfoNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblInfoNote.LinkArea = new Wisej.Web.LinkArea(280, 84);
            this.lblInfoNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblInfoNote.Location = new System.Drawing.Point(9, 79);
            this.lblInfoNote.Margin = new Wisej.Web.Padding(9, 3, 6, 3);
            this.lblInfoNote.Name = "lblInfoNote";
            this.lblInfoNote.Size = new System.Drawing.Size(1130, 35);
            this.lblInfoNote.TabIndex = 8;
            this.lblInfoNote.Text = resources.GetString("lblInfoNote.Text");
            this.lblInfoNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfoNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblInfoNote_LinkClicked);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label16.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label16.CssStyle = "border-radius: 4px;";
            this.label16.Dock = Wisej.Web.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label16.Location = new System.Drawing.Point(9, 3);
            this.label16.Margin = new Wisej.Web.Padding(9, 3, 6, 3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(1130, 70);
            this.label16.TabIndex = 0;
            this.label16.Text = "Welding Test Inspection";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label16.DoubleClick += new System.EventHandler(this.label16_DoubleClick);
            // 
            // uc_wqInspection
            // 
            this.Controls.Add(this.tableLayoutPanel5);
            this.Name = "uc_wqInspection";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_viInspection_VisibleChanged);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel32.ResumeLayout(false);
            this.tableLayoutPanel32.PerformLayout();
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel5;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel6;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel7;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel32;
        private Wisej.Web.Label label7;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel14;
        private Wisej.Web.Button btnVisualNSatisfactory;
        private Wisej.Web.Button btnVisualYSatisfactory;
        private Wisej.Web.Button btnVisualNPorosity;
        private Wisej.Web.Button btnVisualYPorosity;
        private Wisej.Web.Button btnVisualNQualification;
        private Wisej.Web.Button btnVisualYQualification;
        private Wisej.Web.Button btnVisualNCrater;
        private Wisej.Web.Button btnVisualYCrater;
        private Wisej.Web.Button btnVisualNFusion;
        private Wisej.Web.Button btnVisualYFusion;
        private Wisej.Web.Button btnVisualNProcedure;
        private Wisej.Web.Button btnVisualYProcedure;
        private Wisej.Web.Button btnVisualNSuckBack;
        private Wisej.Web.Button btnVisualYSuckBack;
        private Wisej.Web.Button btnVisualNPenetration;
        private Wisej.Web.Button btnVisualYPenetration;
        private Wisej.Web.Button btnVisualNFinal;
        private Wisej.Web.Button btnVisualYFinal;
        private Wisej.Web.Button btnVisualNReinforcement;
        private Wisej.Web.Button btnVisualYReinforcement;
        private Wisej.Web.Button btnVisualNCracks;
        private Wisej.Web.Button btnVisualYCracks;
        private Wisej.Web.Button btnVisualNRepair;
        private Wisej.Web.Button btnVisualYRepair;
        private Wisej.Web.Button btnVisualNArc;
        private Wisej.Web.Button btnVisualYArc;
        private Wisej.Web.Button btnVisualNLocation;
        private Wisej.Web.Button btnVisualYLocation;
        private Wisej.Web.Button btnVisualNInitial;
        private Wisej.Web.Button btnVisualYInitial;
        private Wisej.Web.Button btnVisualNUndercut;
        private Wisej.Web.Button btnVisualYUndercut;
        private Wisej.Web.Button btnVisualNSize;
        private Wisej.Web.Button btnVisualYSize;
        private Wisej.Web.Button btnVisualNWeldersID;
        private Wisej.Web.Button btnVisualNBurn;
        private Wisej.Web.Button btnVisualYBurn;
        private Wisej.Web.Button btnVisualNControl;
        private Wisej.Web.Button btnVisualYControl;
        private Wisej.Web.Button btnVisualNWeldID;
        private Wisej.Web.Button btnVisualYWeldersID;
        private Wisej.Web.Button btnVisualYWeldID;
        private Wisej.Web.Label label17;
        private Wisej.Web.Label label11;
        private Wisej.Web.Label label18;
        private Wisej.Web.Label label20;
        private Wisej.Web.Label label8;
        private Wisej.Web.Label label12;
        private Wisej.Web.Label label19;
        private Wisej.Web.Label label23;
        private Wisej.Web.Label label21;
        private Wisej.Web.Label label24;
        private Wisej.Web.Label label25;
        private Wisej.Web.Label label22;
        private Wisej.Web.Label label26;
        private Wisej.Web.Label label27;
        private Wisej.Web.Label label33;
        private Wisej.Web.Label label29;
        private Wisej.Web.Label label28;
        private Wisej.Web.Label label32;
        private Wisej.Web.Label label34;
        private Wisej.Web.Label label36;
        private Wisej.Web.Label label30;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel13;
        private Wisej.Web.TextBox txtVisualNotes;
        private Wisej.Web.TextBox txtVisualDrawing;
        private Wisej.Web.TextBox txtVisualMap;
        private Wisej.Web.TextBox txtVisualLocation;
        private Wisej.Web.TextBox txtVisualJob;
        private Wisej.Web.TextBox txtVisualMatGrade;
        private Wisej.Web.TextBox txtVisualMatStandard;
        private Wisej.Web.TextBox txtVisualStandard;
        private Wisej.Web.TextBox txtVisualWelder;
        private Wisej.Web.TextBox txtVisualWPQR;
        private Wisej.Web.Label label100;
        private Wisej.Web.Label label14;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label1;
        private Wisej.Web.TextBox txtVisualSerial;
        private Wisej.Web.Label label40;
        private Wisej.Web.Label label10;
        private Wisej.Web.Label label2;
        private Wisej.Web.Label label13;
        private Wisej.Web.Label label101;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label5;
        private Wisej.Web.Label label6;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel9;
        private Wisej.Web.Label label16;
        private Wisej.Web.DateTimePicker dtpVisualDate;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel8;
        private Wisej.Web.Button btnVisualBack;
        private Wisej.Web.Button btnVisualHome;
        private Wisej.Web.Button btnVisualComplete;
        private Wisej.Web.LinkLabel lblInfoNote;
    }
}
