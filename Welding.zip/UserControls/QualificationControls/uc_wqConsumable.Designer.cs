﻿namespace WeldingManagement.UserControls.DatasheetControls
{
    partial class uc_wqConsumable
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_wqConsumable));
            this.tableLayoutPanel20 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel21 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel23 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel31 = new Wisej.Web.TableLayoutPanel();
            this.btnConsumableDelete = new Wisej.Web.Button();
            this.btnConsumableBack = new Wisej.Web.Button();
            this.btnConsumableAdd = new Wisej.Web.Button();
            this.btnConsumableHome = new Wisej.Web.Button();
            this.btnConsumableNext = new Wisej.Web.Button();
            this.tableLayoutPanel22 = new Wisej.Web.TableLayoutPanel();
            this.txtConsumableSpecification = new Wisej.Web.TextBox();
            this.label1 = new Wisej.Web.Label();
            this.lvConsumables = new Wisej.Web.ListView();
            this.chManufacturer = new Wisej.Web.ColumnHeader();
            this.chProduct = new Wisej.Web.ColumnHeader();
            this.chClassification = new Wisej.Web.ColumnHeader();
            this.chBatchNo = new Wisej.Web.ColumnHeader();
            this.txtConsumableBatchNo = new Wisej.Web.TextBox();
            this.txtConsumableClassification = new Wisej.Web.TextBox();
            this.txtConsumableProduct = new Wisej.Web.TextBox();
            this.txtConsumableManufacturer = new Wisej.Web.TextBox();
            this.label73 = new Wisej.Web.Label();
            this.label74 = new Wisej.Web.Label();
            this.label75 = new Wisej.Web.Label();
            this.label76 = new Wisej.Web.Label();
            this.tableLayoutPanel24 = new Wisej.Web.TableLayoutPanel();
            this.lblInfoNote = new Wisej.Web.LinkLabel();
            this.label78 = new Wisej.Web.Label();
            this.chSpecification = new Wisej.Web.ColumnHeader();
            this.tableLayoutPanel20.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel20.ColumnCount = 3;
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel21, 1, 3);
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel24, 1, 1);
            this.tableLayoutPanel20.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 5;
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel20.TabIndex = 5;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel21.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel23, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel22, 0, 0);
            this.tableLayoutPanel21.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel21.TabIndex = 1;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 1;
            this.tableLayoutPanel23.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Controls.Add(this.tableLayoutPanel31, 0, 0);
            this.tableLayoutPanel23.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel23.TabIndex = 5;
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel31.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel31.ColumnCount = 1;
            this.tableLayoutPanel31.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel31.Controls.Add(this.btnConsumableDelete, 0, 0);
            this.tableLayoutPanel31.Controls.Add(this.btnConsumableBack, 0, 2);
            this.tableLayoutPanel31.Controls.Add(this.btnConsumableAdd, 0, 1);
            this.tableLayoutPanel31.Controls.Add(this.btnConsumableHome, 0, 3);
            this.tableLayoutPanel31.Controls.Add(this.btnConsumableNext, 0, 4);
            this.tableLayoutPanel31.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel31.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel31.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 5;
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel31.TabIndex = 4;
            // 
            // btnConsumableDelete
            // 
            this.btnConsumableDelete.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnConsumableDelete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnConsumableDelete.Location = new System.Drawing.Point(3, 3);
            this.btnConsumableDelete.Name = "btnConsumableDelete";
            this.btnConsumableDelete.Size = new System.Drawing.Size(95, 79);
            this.btnConsumableDelete.TabIndex = 8;
            this.btnConsumableDelete.Text = "Delete Consumable";
            this.btnConsumableDelete.DoubleClick += new System.EventHandler(this.btnConsumableDelete_DoubleClick);
            // 
            // btnConsumableBack
            // 
            this.btnConsumableBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnConsumableBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnConsumableBack.Location = new System.Drawing.Point(3, 173);
            this.btnConsumableBack.Name = "btnConsumableBack";
            this.btnConsumableBack.Size = new System.Drawing.Size(95, 79);
            this.btnConsumableBack.TabIndex = 7;
            this.btnConsumableBack.Text = "Back";
            this.btnConsumableBack.Click += new System.EventHandler(this.btnConsumableBack_Click);
            // 
            // btnConsumableAdd
            // 
            this.btnConsumableAdd.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnConsumableAdd.Dock = Wisej.Web.DockStyle.Fill;
            this.btnConsumableAdd.Location = new System.Drawing.Point(3, 88);
            this.btnConsumableAdd.Name = "btnConsumableAdd";
            this.btnConsumableAdd.Size = new System.Drawing.Size(95, 79);
            this.btnConsumableAdd.TabIndex = 4;
            this.btnConsumableAdd.Text = "Add Consumable";
            this.btnConsumableAdd.VisibleChanged += new System.EventHandler(this.btnConsumableAdd_VisibleChanged);
            this.btnConsumableAdd.Click += new System.EventHandler(this.btnConsumableAdd_Click);
            // 
            // btnConsumableHome
            // 
            this.btnConsumableHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnConsumableHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnConsumableHome.Location = new System.Drawing.Point(3, 258);
            this.btnConsumableHome.Name = "btnConsumableHome";
            this.btnConsumableHome.Size = new System.Drawing.Size(95, 79);
            this.btnConsumableHome.TabIndex = 6;
            this.btnConsumableHome.Text = "Home";
            this.btnConsumableHome.Click += new System.EventHandler(this.btnConsumableHome_Click);
            // 
            // btnConsumableNext
            // 
            this.btnConsumableNext.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnConsumableNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnConsumableNext.Location = new System.Drawing.Point(3, 343);
            this.btnConsumableNext.Name = "btnConsumableNext";
            this.btnConsumableNext.Size = new System.Drawing.Size(95, 79);
            this.btnConsumableNext.TabIndex = 5;
            this.btnConsumableNext.Text = "Next";
            this.btnConsumableNext.Click += new System.EventHandler(this.btnConsumableNext_Click);
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 5;
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.Controls.Add(this.txtConsumableSpecification, 2, 1);
            this.tableLayoutPanel22.Controls.Add(this.label1, 4, 0);
            this.tableLayoutPanel22.Controls.Add(this.lvConsumables, 0, 2);
            this.tableLayoutPanel22.Controls.Add(this.txtConsumableBatchNo, 4, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtConsumableClassification, 3, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtConsumableProduct, 1, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtConsumableManufacturer, 0, 1);
            this.tableLayoutPanel22.Controls.Add(this.label73, 2, 0);
            this.tableLayoutPanel22.Controls.Add(this.label74, 3, 0);
            this.tableLayoutPanel22.Controls.Add(this.label75, 1, 0);
            this.tableLayoutPanel22.Controls.Add(this.label76, 0, 0);
            this.tableLayoutPanel22.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 3;
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 60F));
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel22.TabIndex = 4;
            // 
            // txtConsumableSpecification
            // 
            this.txtConsumableSpecification.Dock = Wisej.Web.DockStyle.Fill;
            this.txtConsumableSpecification.Location = new System.Drawing.Point(411, 89);
            this.txtConsumableSpecification.Name = "txtConsumableSpecification";
            this.txtConsumableSpecification.Size = new System.Drawing.Size(198, 80);
            this.txtConsumableSpecification.TabIndex = 30;
            this.txtConsumableSpecification.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label1.Location = new System.Drawing.Point(819, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(202, 80);
            this.label1.TabIndex = 29;
            this.label1.Text = "Batch / Cast Number";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lvConsumables
            // 
            this.lvConsumables.Columns.AddRange(new Wisej.Web.ColumnHeader[] {
            this.chManufacturer,
            this.chProduct,
            this.chSpecification,
            this.chClassification,
            this.chBatchNo});
            this.tableLayoutPanel22.SetColumnSpan(this.lvConsumables, 14);
            this.lvConsumables.Dock = Wisej.Web.DockStyle.Fill;
            this.lvConsumables.HeaderStyle = Wisej.Web.ColumnHeaderStyle.None;
            this.lvConsumables.Location = new System.Drawing.Point(3, 175);
            this.lvConsumables.Name = "lvConsumables";
            this.lvConsumables.Size = new System.Drawing.Size(1018, 255);
            this.lvConsumables.TabIndex = 28;
            this.lvConsumables.View = Wisej.Web.View.Details;
            this.lvConsumables.SelectedIndexChanged += new System.EventHandler(this.lvConsumables_SelectedIndexChanged);
            this.lvConsumables.ItemDoubleClick += new Wisej.Web.ItemClickEventHandler(this.lvConsumables_ItemDoubleClick);
            this.lvConsumables.Resize += new System.EventHandler(this.lvConsumables_Resize);
            // 
            // chManufacturer
            // 
            this.chManufacturer.Name = "chManufacturer";
            this.chManufacturer.Text = "Manufacturer";
            // 
            // chProduct
            // 
            this.chProduct.Name = "chProduct";
            this.chProduct.Text = "Product Name";
            // 
            // chClassification
            // 
            this.chClassification.Name = "chClassification";
            this.chClassification.Text = "Classification";
            // 
            // chBatchNo
            // 
            this.chBatchNo.Name = "chBatchNo";
            this.chBatchNo.Text = "Batch / Cast Number";
            // 
            // txtConsumableBatchNo
            // 
            this.txtConsumableBatchNo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtConsumableBatchNo.Location = new System.Drawing.Point(819, 89);
            this.txtConsumableBatchNo.Name = "txtConsumableBatchNo";
            this.txtConsumableBatchNo.Size = new System.Drawing.Size(202, 80);
            this.txtConsumableBatchNo.TabIndex = 3;
            this.txtConsumableBatchNo.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtConsumableClassification
            // 
            this.txtConsumableClassification.Dock = Wisej.Web.DockStyle.Fill;
            this.txtConsumableClassification.Location = new System.Drawing.Point(615, 89);
            this.txtConsumableClassification.Name = "txtConsumableClassification";
            this.txtConsumableClassification.Size = new System.Drawing.Size(198, 80);
            this.txtConsumableClassification.TabIndex = 2;
            this.txtConsumableClassification.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtConsumableProduct
            // 
            this.txtConsumableProduct.Dock = Wisej.Web.DockStyle.Fill;
            this.txtConsumableProduct.Location = new System.Drawing.Point(207, 89);
            this.txtConsumableProduct.Name = "txtConsumableProduct";
            this.txtConsumableProduct.Size = new System.Drawing.Size(198, 80);
            this.txtConsumableProduct.TabIndex = 1;
            this.txtConsumableProduct.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtConsumableManufacturer
            // 
            this.txtConsumableManufacturer.Dock = Wisej.Web.DockStyle.Fill;
            this.txtConsumableManufacturer.Location = new System.Drawing.Point(3, 89);
            this.txtConsumableManufacturer.Name = "txtConsumableManufacturer";
            this.txtConsumableManufacturer.Size = new System.Drawing.Size(198, 80);
            this.txtConsumableManufacturer.TabIndex = 0;
            this.txtConsumableManufacturer.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label73.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label73.Dock = Wisej.Web.DockStyle.Fill;
            this.label73.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label73.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label73.Location = new System.Drawing.Point(411, 3);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(198, 80);
            this.label73.TabIndex = 3;
            this.label73.Text = "Specification";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label74.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label74.Dock = Wisej.Web.DockStyle.Fill;
            this.label74.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label74.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label74.Location = new System.Drawing.Point(615, 3);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(198, 80);
            this.label74.TabIndex = 2;
            this.label74.Text = "Classification";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label75.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label75.Dock = Wisej.Web.DockStyle.Fill;
            this.label75.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label75.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label75.Location = new System.Drawing.Point(207, 3);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(198, 80);
            this.label75.TabIndex = 1;
            this.label75.Text = "Product Name";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label76.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label76.Dock = Wisej.Web.DockStyle.Fill;
            this.label76.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label76.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label76.Location = new System.Drawing.Point(3, 3);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(198, 80);
            this.label76.TabIndex = 0;
            this.label76.Text = "Manufacturer";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 1;
            this.tableLayoutPanel24.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel24.Controls.Add(this.lblInfoNote, 0, 1);
            this.tableLayoutPanel24.Controls.Add(this.label78, 0, 0);
            this.tableLayoutPanel24.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 2;
            this.tableLayoutPanel24.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel24.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel24.TabIndex = 0;
            // 
            // lblInfoNote
            // 
            this.lblInfoNote.AutoSize = true;
            this.lblInfoNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblInfoNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblInfoNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblInfoNote.LinkArea = new Wisej.Web.LinkArea(258, 84);
            this.lblInfoNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblInfoNote.Location = new System.Drawing.Point(6, 79);
            this.lblInfoNote.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.lblInfoNote.Name = "lblInfoNote";
            this.lblInfoNote.Size = new System.Drawing.Size(1133, 35);
            this.lblInfoNote.TabIndex = 6;
            this.lblInfoNote.Text = resources.GetString("lblInfoNote.Text");
            this.lblInfoNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfoNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblInfoNote_LinkClicked);
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label78.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label78.CssStyle = "border-radius: 4px;";
            this.label78.Dock = Wisej.Web.DockStyle.Fill;
            this.label78.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label78.Location = new System.Drawing.Point(6, 3);
            this.label78.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(1133, 70);
            this.label78.TabIndex = 0;
            this.label78.Text = "Welding Test Consumables";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label78.DoubleClick += new System.EventHandler(this.label78_DoubleClick);
            // 
            // chSpecification
            // 
            this.chSpecification.Name = "chSpecification";
            this.chSpecification.Text = "chSpecification";
            // 
            // uc_wqConsumable
            // 
            this.Controls.Add(this.tableLayoutPanel20);
            this.Name = "uc_wqConsumable";
            this.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel31.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel22.PerformLayout();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel24.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel20;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel21;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel23;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel31;
        private Wisej.Web.Button btnConsumableBack;
        private Wisej.Web.Button btnConsumableAdd;
        private Wisej.Web.Button btnConsumableHome;
        private Wisej.Web.Button btnConsumableNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel22;
        private Wisej.Web.ListView lvConsumables;
        private Wisej.Web.ColumnHeader chManufacturer;
        private Wisej.Web.ColumnHeader chProduct;
        private Wisej.Web.ColumnHeader chClassification;
        private Wisej.Web.ColumnHeader chBatchNo;
        private Wisej.Web.TextBox txtConsumableBatchNo;
        private Wisej.Web.TextBox txtConsumableClassification;
        private Wisej.Web.TextBox txtConsumableProduct;
        private Wisej.Web.TextBox txtConsumableManufacturer;
        private Wisej.Web.Label label73;
        private Wisej.Web.Label label74;
        private Wisej.Web.Label label75;
        private Wisej.Web.Label label76;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel24;
        private Wisej.Web.Label label78;
        private Wisej.Web.Button btnConsumableDelete;
        private Wisej.Web.LinkLabel lblInfoNote;
        private Wisej.Web.TextBox txtConsumableSpecification;
        private Wisej.Web.Label label1;
        private Wisej.Web.ColumnHeader chSpecification;
    }
}
