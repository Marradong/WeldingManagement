﻿namespace WeldingManagement.UserControls.DatasheetControls
{
    partial class uc_wqInfo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_wqInfo));
            this.tableLayoutPanel15 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel16 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel18 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel30 = new Wisej.Web.TableLayoutPanel();
            this.btnInfoBack = new Wisej.Web.Button();
            this.btnInfoHome = new Wisej.Web.Button();
            this.btnInfoNext = new Wisej.Web.Button();
            this.tableLayoutPanel17 = new Wisej.Web.TableLayoutPanel();
            this.tlpInfoWPQR = new Wisej.Web.TableLayoutPanel();
            this.cboInfoWPQR = new Wisej.Web.ComboBox();
            this.txtInfoWPQR = new Wisej.Web.TextBox();
            this.cbInfoWPQR = new Wisej.Web.CheckBox();
            this.cboInfoWelder = new Wisej.Web.ComboBox();
            this.dtpInfoDate = new Wisej.Web.DateTimePicker();
            this.txtInfoNotes = new Wisej.Web.TextBox();
            this.txtInfoAngle = new Wisej.Web.TextBox();
            this.txtInfoGap = new Wisej.Web.TextBox();
            this.txtInfoFace = new Wisej.Web.TextBox();
            this.txtInfoProcess = new Wisej.Web.TextBox();
            this.txtInfoHeatNo = new Wisej.Web.TextBox();
            this.txtInfoMatThickness = new Wisej.Web.TextBox();
            this.txtInfoMatGrade = new Wisej.Web.TextBox();
            this.txtInfoMatStandard = new Wisej.Web.TextBox();
            this.txtInfoType = new Wisej.Web.TextBox();
            this.txtInfoDesign = new Wisej.Web.TextBox();
            this.txtInfoStandard = new Wisej.Web.TextBox();
            this.txtInfoJob = new Wisej.Web.TextBox();
            this.label42 = new Wisej.Web.Label();
            this.label43 = new Wisej.Web.Label();
            this.label44 = new Wisej.Web.Label();
            this.label45 = new Wisej.Web.Label();
            this.label46 = new Wisej.Web.Label();
            this.label47 = new Wisej.Web.Label();
            this.label48 = new Wisej.Web.Label();
            this.label49 = new Wisej.Web.Label();
            this.label50 = new Wisej.Web.Label();
            this.label51 = new Wisej.Web.Label();
            this.label52 = new Wisej.Web.Label();
            this.label53 = new Wisej.Web.Label();
            this.label54 = new Wisej.Web.Label();
            this.label55 = new Wisej.Web.Label();
            this.label56 = new Wisej.Web.Label();
            this.label57 = new Wisej.Web.Label();
            this.label58 = new Wisej.Web.Label();
            this.label59 = new Wisej.Web.Label();
            this.label60 = new Wisej.Web.Label();
            this.txtInfoPosition = new Wisej.Web.TextBox();
            this.txtInfoPreheat = new Wisej.Web.TextBox();
            this.label1 = new Wisej.Web.Label();
            this.tableLayoutPanel19 = new Wisej.Web.TableLayoutPanel();
            this.lblInfoNote = new Wisej.Web.LinkLabel();
            this.label62 = new Wisej.Web.Label();
            this.tableLayoutPanel15.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.tlpInfoWPQR.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel15.ColumnCount = 3;
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.Controls.Add(this.tableLayoutPanel16, 1, 3);
            this.tableLayoutPanel15.Controls.Add(this.tableLayoutPanel19, 1, 1);
            this.tableLayoutPanel15.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 5;
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel15.TabIndex = 3;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel16.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel18, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel17, 0, 0);
            this.tableLayoutPanel16.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel16.TabIndex = 1;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 1;
            this.tableLayoutPanel18.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Controls.Add(this.tableLayoutPanel30, 0, 0);
            this.tableLayoutPanel18.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel18.TabIndex = 5;
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel30.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel30.ColumnCount = 1;
            this.tableLayoutPanel30.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel30.Controls.Add(this.btnInfoBack, 0, 2);
            this.tableLayoutPanel30.Controls.Add(this.btnInfoHome, 0, 3);
            this.tableLayoutPanel30.Controls.Add(this.btnInfoNext, 0, 4);
            this.tableLayoutPanel30.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel30.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel30.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 5;
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel30.TabIndex = 4;
            // 
            // btnInfoBack
            // 
            this.btnInfoBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnInfoBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoBack.Location = new System.Drawing.Point(3, 173);
            this.btnInfoBack.Name = "btnInfoBack";
            this.btnInfoBack.Size = new System.Drawing.Size(95, 79);
            this.btnInfoBack.TabIndex = 20;
            this.btnInfoBack.Text = "Back";
            this.btnInfoBack.Click += new System.EventHandler(this.btnInfoBack_Click);
            // 
            // btnInfoHome
            // 
            this.btnInfoHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnInfoHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoHome.Location = new System.Drawing.Point(3, 258);
            this.btnInfoHome.Name = "btnInfoHome";
            this.btnInfoHome.Size = new System.Drawing.Size(95, 79);
            this.btnInfoHome.TabIndex = 19;
            this.btnInfoHome.Text = "Home";
            this.btnInfoHome.Click += new System.EventHandler(this.btnInfoHome_Click);
            // 
            // btnInfoNext
            // 
            this.btnInfoNext.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnInfoNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoNext.Location = new System.Drawing.Point(3, 343);
            this.btnInfoNext.Name = "btnInfoNext";
            this.btnInfoNext.Size = new System.Drawing.Size(95, 79);
            this.btnInfoNext.TabIndex = 18;
            this.btnInfoNext.Text = "Next";
            this.btnInfoNext.Click += new System.EventHandler(this.btnInfoNext_Click);
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 4;
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.Controls.Add(this.tlpInfoWPQR, 1, 1);
            this.tableLayoutPanel17.Controls.Add(this.cbInfoWPQR, 3, 0);
            this.tableLayoutPanel17.Controls.Add(this.cboInfoWelder, 3, 1);
            this.tableLayoutPanel17.Controls.Add(this.dtpInfoDate, 3, 2);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoNotes, 3, 7);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoAngle, 3, 6);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoGap, 3, 5);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoFace, 3, 4);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoProcess, 3, 3);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoHeatNo, 2, 12);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoMatThickness, 2, 11);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoMatGrade, 2, 10);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoMatStandard, 2, 9);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoType, 1, 5);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoDesign, 1, 4);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoStandard, 1, 3);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoJob, 1, 2);
            this.tableLayoutPanel17.Controls.Add(this.label42, 2, 7);
            this.tableLayoutPanel17.Controls.Add(this.label43, 2, 6);
            this.tableLayoutPanel17.Controls.Add(this.label44, 2, 5);
            this.tableLayoutPanel17.Controls.Add(this.label45, 2, 4);
            this.tableLayoutPanel17.Controls.Add(this.label46, 2, 3);
            this.tableLayoutPanel17.Controls.Add(this.label47, 2, 2);
            this.tableLayoutPanel17.Controls.Add(this.label48, 2, 1);
            this.tableLayoutPanel17.Controls.Add(this.label49, 0, 12);
            this.tableLayoutPanel17.Controls.Add(this.label50, 0, 11);
            this.tableLayoutPanel17.Controls.Add(this.label51, 0, 10);
            this.tableLayoutPanel17.Controls.Add(this.label52, 0, 9);
            this.tableLayoutPanel17.Controls.Add(this.label53, 0, 8);
            this.tableLayoutPanel17.Controls.Add(this.label54, 0, 7);
            this.tableLayoutPanel17.Controls.Add(this.label55, 0, 6);
            this.tableLayoutPanel17.Controls.Add(this.label56, 0, 5);
            this.tableLayoutPanel17.Controls.Add(this.label57, 0, 4);
            this.tableLayoutPanel17.Controls.Add(this.label58, 0, 3);
            this.tableLayoutPanel17.Controls.Add(this.label59, 0, 2);
            this.tableLayoutPanel17.Controls.Add(this.label60, 0, 1);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoPosition, 1, 6);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoPreheat, 1, 7);
            this.tableLayoutPanel17.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel17.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 13;
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel17.TabIndex = 4;
            // 
            // tlpInfoWPQR
            // 
            this.tlpInfoWPQR.ColumnCount = 2;
            this.tlpInfoWPQR.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpInfoWPQR.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpInfoWPQR.Controls.Add(this.cboInfoWPQR, 0, 0);
            this.tlpInfoWPQR.Controls.Add(this.txtInfoWPQR, 1, 0);
            this.tlpInfoWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpInfoWPQR.Location = new System.Drawing.Point(256, 33);
            this.tlpInfoWPQR.Margin = new Wisej.Web.Padding(0);
            this.tlpInfoWPQR.Name = "tlpInfoWPQR";
            this.tlpInfoWPQR.RowCount = 1;
            this.tlpInfoWPQR.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpInfoWPQR.Size = new System.Drawing.Size(256, 33);
            this.tlpInfoWPQR.TabIndex = 21;
            // 
            // cboInfoWPQR
            // 
            this.cboInfoWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.cboInfoWPQR.Location = new System.Drawing.Point(3, 3);
            this.cboInfoWPQR.Name = "cboInfoWPQR";
            this.cboInfoWPQR.Size = new System.Drawing.Size(122, 27);
            this.cboInfoWPQR.TabIndex = 2;
            // 
            // txtInfoWPQR
            // 
            this.txtInfoWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoWPQR.InputType.Min = "0";
            this.txtInfoWPQR.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtInfoWPQR.InputType.Step = 1D;
            this.txtInfoWPQR.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtInfoWPQR.Location = new System.Drawing.Point(131, 3);
            this.txtInfoWPQR.Name = "txtInfoWPQR";
            this.txtInfoWPQR.Size = new System.Drawing.Size(122, 27);
            this.txtInfoWPQR.TabIndex = 1;
            // 
            // cbInfoWPQR
            // 
            this.cbInfoWPQR.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoWPQR.BackColor = System.Drawing.Color.FromName("@window");
            this.cbInfoWPQR.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbInfoWPQR.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbInfoWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoWPQR.Location = new System.Drawing.Point(771, 3);
            this.cbInfoWPQR.Name = "cbInfoWPQR";
            this.cbInfoWPQR.Size = new System.Drawing.Size(250, 27);
            this.cbInfoWPQR.TabIndex = 20;
            this.cbInfoWPQR.Text = "No/Yes";
            this.cbInfoWPQR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbInfoWPQR.CheckedChanged += new System.EventHandler(this.cbInfoWPQR_CheckedChanged);
            // 
            // cboInfoWelder
            // 
            this.cboInfoWelder.AutoCompleteMode = Wisej.Web.AutoCompleteMode.Filter;
            this.cboInfoWelder.Dock = Wisej.Web.DockStyle.Fill;
            this.cboInfoWelder.Location = new System.Drawing.Point(771, 36);
            this.cboInfoWelder.Name = "cboInfoWelder";
            this.cboInfoWelder.Size = new System.Drawing.Size(250, 27);
            this.cboInfoWelder.Sorted = true;
            this.cboInfoWelder.TabIndex = 7;
            // 
            // dtpInfoDate
            // 
            this.dtpInfoDate.Dock = Wisej.Web.DockStyle.Fill;
            this.dtpInfoDate.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpInfoDate.Location = new System.Drawing.Point(771, 69);
            this.dtpInfoDate.Name = "dtpInfoDate";
            this.dtpInfoDate.Size = new System.Drawing.Size(250, 27);
            this.dtpInfoDate.TabIndex = 8;
            this.dtpInfoDate.Value = new System.DateTime(2024, 2, 19, 13, 55, 37, 653);
            // 
            // txtInfoNotes
            // 
            this.txtInfoNotes.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoNotes.Location = new System.Drawing.Point(771, 234);
            this.txtInfoNotes.Multiline = true;
            this.txtInfoNotes.Name = "txtInfoNotes";
            this.txtInfoNotes.Size = new System.Drawing.Size(250, 27);
            this.txtInfoNotes.TabIndex = 13;
            // 
            // txtInfoAngle
            // 
            this.txtInfoAngle.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoAngle.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtInfoAngle.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtInfoAngle.Location = new System.Drawing.Point(771, 201);
            this.txtInfoAngle.Name = "txtInfoAngle";
            this.txtInfoAngle.Size = new System.Drawing.Size(250, 27);
            this.txtInfoAngle.TabIndex = 12;
            // 
            // txtInfoGap
            // 
            this.txtInfoGap.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoGap.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtInfoGap.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtInfoGap.Location = new System.Drawing.Point(771, 168);
            this.txtInfoGap.Name = "txtInfoGap";
            this.txtInfoGap.Size = new System.Drawing.Size(250, 27);
            this.txtInfoGap.TabIndex = 11;
            // 
            // txtInfoFace
            // 
            this.txtInfoFace.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoFace.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtInfoFace.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtInfoFace.Location = new System.Drawing.Point(771, 135);
            this.txtInfoFace.Name = "txtInfoFace";
            this.txtInfoFace.Size = new System.Drawing.Size(250, 27);
            this.txtInfoFace.TabIndex = 10;
            // 
            // txtInfoProcess
            // 
            this.txtInfoProcess.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoProcess.Location = new System.Drawing.Point(771, 102);
            this.txtInfoProcess.Name = "txtInfoProcess";
            this.txtInfoProcess.Size = new System.Drawing.Size(250, 27);
            this.txtInfoProcess.TabIndex = 9;
            // 
            // txtInfoHeatNo
            // 
            this.tableLayoutPanel17.SetColumnSpan(this.txtInfoHeatNo, 2);
            this.txtInfoHeatNo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoHeatNo.Location = new System.Drawing.Point(515, 399);
            this.txtInfoHeatNo.Name = "txtInfoHeatNo";
            this.txtInfoHeatNo.Size = new System.Drawing.Size(506, 31);
            this.txtInfoHeatNo.TabIndex = 17;
            // 
            // txtInfoMatThickness
            // 
            this.tableLayoutPanel17.SetColumnSpan(this.txtInfoMatThickness, 2);
            this.txtInfoMatThickness.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatThickness.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtInfoMatThickness.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtInfoMatThickness.Location = new System.Drawing.Point(515, 366);
            this.txtInfoMatThickness.Name = "txtInfoMatThickness";
            this.txtInfoMatThickness.Size = new System.Drawing.Size(506, 27);
            this.txtInfoMatThickness.TabIndex = 16;
            // 
            // txtInfoMatGrade
            // 
            this.tableLayoutPanel17.SetColumnSpan(this.txtInfoMatGrade, 2);
            this.txtInfoMatGrade.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatGrade.Location = new System.Drawing.Point(515, 333);
            this.txtInfoMatGrade.Name = "txtInfoMatGrade";
            this.txtInfoMatGrade.Size = new System.Drawing.Size(506, 27);
            this.txtInfoMatGrade.TabIndex = 15;
            // 
            // txtInfoMatStandard
            // 
            this.tableLayoutPanel17.SetColumnSpan(this.txtInfoMatStandard, 2);
            this.txtInfoMatStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatStandard.Location = new System.Drawing.Point(515, 300);
            this.txtInfoMatStandard.Name = "txtInfoMatStandard";
            this.txtInfoMatStandard.Size = new System.Drawing.Size(506, 27);
            this.txtInfoMatStandard.TabIndex = 14;
            // 
            // txtInfoType
            // 
            this.txtInfoType.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoType.Location = new System.Drawing.Point(259, 168);
            this.txtInfoType.Name = "txtInfoType";
            this.txtInfoType.Size = new System.Drawing.Size(250, 27);
            this.txtInfoType.TabIndex = 4;
            // 
            // txtInfoDesign
            // 
            this.txtInfoDesign.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoDesign.Location = new System.Drawing.Point(259, 135);
            this.txtInfoDesign.Name = "txtInfoDesign";
            this.txtInfoDesign.Size = new System.Drawing.Size(250, 27);
            this.txtInfoDesign.TabIndex = 3;
            // 
            // txtInfoStandard
            // 
            this.txtInfoStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoStandard.Location = new System.Drawing.Point(259, 102);
            this.txtInfoStandard.Name = "txtInfoStandard";
            this.txtInfoStandard.Size = new System.Drawing.Size(250, 27);
            this.txtInfoStandard.TabIndex = 2;
            // 
            // txtInfoJob
            // 
            this.txtInfoJob.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoJob.Location = new System.Drawing.Point(259, 69);
            this.txtInfoJob.Name = "txtInfoJob";
            this.txtInfoJob.Size = new System.Drawing.Size(250, 27);
            this.txtInfoJob.TabIndex = 1;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.FromName("@window");
            this.label42.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label42.Dock = Wisej.Web.DockStyle.Fill;
            this.label42.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label42.Location = new System.Drawing.Point(515, 234);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(250, 27);
            this.label42.TabIndex = 18;
            this.label42.Text = "Notes";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.FromName("@window");
            this.label43.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label43.Dock = Wisej.Web.DockStyle.Fill;
            this.label43.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label43.Location = new System.Drawing.Point(515, 201);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(250, 27);
            this.label43.TabIndex = 17;
            this.label43.Text = "Included Angle (°)";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.FromName("@window");
            this.label44.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label44.Dock = Wisej.Web.DockStyle.Fill;
            this.label44.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label44.Location = new System.Drawing.Point(515, 168);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(250, 27);
            this.label44.TabIndex = 16;
            this.label44.Text = "Root Gap (mm)";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.FromName("@window");
            this.label45.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label45.Dock = Wisej.Web.DockStyle.Fill;
            this.label45.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label45.Location = new System.Drawing.Point(515, 135);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(250, 27);
            this.label45.TabIndex = 15;
            this.label45.Text = "Root Face (mm)";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.FromName("@window");
            this.label46.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label46.Dock = Wisej.Web.DockStyle.Fill;
            this.label46.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label46.Location = new System.Drawing.Point(515, 102);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(250, 27);
            this.label46.TabIndex = 14;
            this.label46.Text = "Welding Process";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.FromName("@window");
            this.label47.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label47.Dock = Wisej.Web.DockStyle.Fill;
            this.label47.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label47.Location = new System.Drawing.Point(515, 69);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(250, 27);
            this.label47.TabIndex = 13;
            this.label47.Text = "Date";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.FromName("@window");
            this.label48.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label48.Dock = Wisej.Web.DockStyle.Fill;
            this.label48.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label48.Location = new System.Drawing.Point(515, 36);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(250, 27);
            this.label48.TabIndex = 12;
            this.label48.Text = "Welder ID";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.FromName("@window");
            this.label49.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.tableLayoutPanel17.SetColumnSpan(this.label49, 2);
            this.label49.Dock = Wisej.Web.DockStyle.Fill;
            this.label49.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label49.Location = new System.Drawing.Point(3, 399);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(506, 31);
            this.label49.TabIndex = 11;
            this.label49.Text = "Platecast / Heat Number";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.FromName("@window");
            this.label50.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.tableLayoutPanel17.SetColumnSpan(this.label50, 2);
            this.label50.Dock = Wisej.Web.DockStyle.Fill;
            this.label50.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label50.Location = new System.Drawing.Point(3, 366);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(506, 27);
            this.label50.TabIndex = 10;
            this.label50.Text = "Thickness (mm)";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.FromName("@window");
            this.label51.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.tableLayoutPanel17.SetColumnSpan(this.label51, 2);
            this.label51.Dock = Wisej.Web.DockStyle.Fill;
            this.label51.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label51.Location = new System.Drawing.Point(3, 333);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(506, 27);
            this.label51.TabIndex = 9;
            this.label51.Text = "Material Grade";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.FromName("@window");
            this.label52.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.tableLayoutPanel17.SetColumnSpan(this.label52, 2);
            this.label52.Dock = Wisej.Web.DockStyle.Fill;
            this.label52.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label52.Location = new System.Drawing.Point(3, 300);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(506, 27);
            this.label52.TabIndex = 8;
            this.label52.Text = "Material Standard";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label53.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel17.SetColumnSpan(this.label53, 4);
            this.label53.Dock = Wisej.Web.DockStyle.Fill;
            this.label53.Location = new System.Drawing.Point(3, 267);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(1018, 27);
            this.label53.TabIndex = 7;
            this.label53.Text = "Material Details";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.FromName("@window");
            this.label54.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label54.Dock = Wisej.Web.DockStyle.Fill;
            this.label54.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label54.Location = new System.Drawing.Point(3, 234);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(250, 27);
            this.label54.TabIndex = 6;
            this.label54.Text = "Preheat (°)";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.FromName("@window");
            this.label55.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label55.Dock = Wisej.Web.DockStyle.Fill;
            this.label55.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label55.Location = new System.Drawing.Point(3, 201);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(250, 27);
            this.label55.TabIndex = 5;
            this.label55.Text = "Welding Position";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.FromName("@window");
            this.label56.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label56.Dock = Wisej.Web.DockStyle.Fill;
            this.label56.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label56.Location = new System.Drawing.Point(3, 168);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(250, 27);
            this.label56.TabIndex = 4;
            this.label56.Text = "Joint Type";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.FromName("@window");
            this.label57.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label57.Dock = Wisej.Web.DockStyle.Fill;
            this.label57.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label57.Location = new System.Drawing.Point(3, 135);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(250, 27);
            this.label57.TabIndex = 3;
            this.label57.Text = "Joint Design";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.Color.FromName("@window");
            this.label58.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label58.Dock = Wisej.Web.DockStyle.Fill;
            this.label58.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label58.Location = new System.Drawing.Point(3, 102);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(250, 27);
            this.label58.TabIndex = 2;
            this.label58.Text = "Welding Standard";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.Color.FromName("@window");
            this.label59.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label59.Dock = Wisej.Web.DockStyle.Fill;
            this.label59.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label59.Location = new System.Drawing.Point(3, 69);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(250, 27);
            this.label59.TabIndex = 1;
            this.label59.Text = "Job Number";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.FromName("@window");
            this.label60.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label60.Dock = Wisej.Web.DockStyle.Fill;
            this.label60.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label60.Location = new System.Drawing.Point(3, 36);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(250, 27);
            this.label60.TabIndex = 0;
            this.label60.Text = "WPQR Number";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtInfoPosition
            // 
            this.txtInfoPosition.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPosition.Location = new System.Drawing.Point(259, 201);
            this.txtInfoPosition.Name = "txtInfoPosition";
            this.txtInfoPosition.Size = new System.Drawing.Size(250, 27);
            this.txtInfoPosition.TabIndex = 5;
            // 
            // txtInfoPreheat
            // 
            this.txtInfoPreheat.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPreheat.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtInfoPreheat.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtInfoPreheat.Location = new System.Drawing.Point(259, 234);
            this.txtInfoPreheat.Name = "txtInfoPreheat";
            this.txtInfoPreheat.Size = new System.Drawing.Size(250, 27);
            this.txtInfoPreheat.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromName("@window");
            this.label1.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.tableLayoutPanel17.SetColumnSpan(this.label1, 3);
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.ForeColor = System.Drawing.Color.FromName("@controlText");
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(762, 27);
            this.label1.TabIndex = 19;
            this.label1.Text = "Is this Welding Test used for the development of a new WPQR";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 1;
            this.tableLayoutPanel19.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel19.Controls.Add(this.lblInfoNote, 0, 1);
            this.tableLayoutPanel19.Controls.Add(this.label62, 0, 0);
            this.tableLayoutPanel19.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 2;
            this.tableLayoutPanel19.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel19.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel19.TabIndex = 0;
            // 
            // lblInfoNote
            // 
            this.lblInfoNote.AutoSize = true;
            this.lblInfoNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblInfoNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblInfoNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblInfoNote.LinkArea = new Wisej.Web.LinkArea(283, 84);
            this.lblInfoNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblInfoNote.Location = new System.Drawing.Point(6, 79);
            this.lblInfoNote.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.lblInfoNote.Name = "lblInfoNote";
            this.lblInfoNote.Size = new System.Drawing.Size(1133, 35);
            this.lblInfoNote.TabIndex = 4;
            this.lblInfoNote.Text = resources.GetString("lblInfoNote.Text");
            this.lblInfoNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfoNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblInfoNote_LinkClicked);
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.Color.FromName("@window");
            this.label62.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label62.CssStyle = "border-radius: 4px;";
            this.label62.Dock = Wisej.Web.DockStyle.Fill;
            this.label62.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label62.Location = new System.Drawing.Point(6, 3);
            this.label62.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(1133, 70);
            this.label62.TabIndex = 0;
            this.label62.Text = "Welding Test Information";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label62.DoubleClick += new System.EventHandler(this.label62_DoubleClick);
            // 
            // uc_wqInfo
            // 
            this.Controls.Add(this.tableLayoutPanel15);
            this.Name = "uc_wqInfo";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_dsInfo_VisibleChanged);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel30.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.tlpInfoWPQR.ResumeLayout(false);
            this.tlpInfoWPQR.PerformLayout();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel15;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel16;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel18;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel30;
        private Wisej.Web.Button btnInfoBack;
        private Wisej.Web.Button btnInfoHome;
        private Wisej.Web.Button btnInfoNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel17;
        private Wisej.Web.TextBox txtInfoNotes;
        private Wisej.Web.TextBox txtInfoAngle;
        private Wisej.Web.TextBox txtInfoGap;
        private Wisej.Web.TextBox txtInfoFace;
        private Wisej.Web.TextBox txtInfoProcess;
        private Wisej.Web.TextBox txtInfoHeatNo;
        private Wisej.Web.TextBox txtInfoMatThickness;
        private Wisej.Web.TextBox txtInfoMatGrade;
        private Wisej.Web.TextBox txtInfoMatStandard;
        private Wisej.Web.TextBox txtInfoType;
        private Wisej.Web.TextBox txtInfoDesign;
        private Wisej.Web.TextBox txtInfoStandard;
        private Wisej.Web.TextBox txtInfoJob;
        private Wisej.Web.Label label42;
        private Wisej.Web.Label label43;
        private Wisej.Web.Label label44;
        private Wisej.Web.Label label45;
        private Wisej.Web.Label label46;
        private Wisej.Web.Label label47;
        private Wisej.Web.Label label48;
        private Wisej.Web.Label label49;
        private Wisej.Web.Label label50;
        private Wisej.Web.Label label51;
        private Wisej.Web.Label label52;
        private Wisej.Web.Label label53;
        private Wisej.Web.Label label54;
        private Wisej.Web.Label label55;
        private Wisej.Web.Label label56;
        private Wisej.Web.Label label57;
        private Wisej.Web.Label label58;
        private Wisej.Web.Label label59;
        private Wisej.Web.Label label60;
        private Wisej.Web.TextBox txtInfoPosition;
        private Wisej.Web.TextBox txtInfoPreheat;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel19;
        private Wisej.Web.Label label62;
        private Wisej.Web.DateTimePicker dtpInfoDate;
        private Wisej.Web.ComboBox cboInfoWelder;
        private Wisej.Web.Label label1;
        private Wisej.Web.CheckBox cbInfoWPQR;
        private Wisej.Web.TableLayoutPanel tlpInfoWPQR;
        private Wisej.Web.TextBox txtInfoWPQR;
        private Wisej.Web.ComboBox cboInfoWPQR;
        private Wisej.Web.LinkLabel lblInfoNote;
    }
}
