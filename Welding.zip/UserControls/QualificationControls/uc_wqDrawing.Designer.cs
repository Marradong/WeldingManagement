﻿namespace WeldingManagement.UserControls.DatasheetControls
{
    partial class uc_wqDrawing
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_wqDrawing));
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.tlpDrawing = new Wisej.Web.TableLayoutPanel();
            this.tlpDrawingControls = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel5 = new Wisej.Web.TableLayoutPanel();
            this.label100 = new Wisej.Web.Label();
            this.txtDrawingRootFace = new Wisej.Web.TextBox();
            this.txtDrawingAngle = new Wisej.Web.TextBox();
            this.txtDrawingRadius = new Wisej.Web.TextBox();
            this.cbDrawingSnap = new Wisej.Web.CheckBox();
            this.cbDrawingDouble = new Wisej.Web.CheckBox();
            this.label9 = new Wisej.Web.Label();
            this.txtDrawingGrid = new Wisej.Web.TextBox();
            this.label2 = new Wisej.Web.Label();
            this.cbDrawingFlipV = new Wisej.Web.CheckBox();
            this.txtDrawingThickness = new Wisej.Web.TextBox();
            this.cbDrawingFlipH = new Wisej.Web.CheckBox();
            this.label1 = new Wisej.Web.Label();
            this.label8 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.label4 = new Wisej.Web.Label();
            this.label7 = new Wisej.Web.Label();
            this.txtDrawingRotation = new Wisej.Web.TextBox();
            this.label5 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.pDrawingShapePreview = new Wisej.Web.Panel();
            this.tlpDrawingPanel = new Wisej.Web.TableLayoutPanel();
            this.rbDrawingEdit = new Wisej.Web.RadioButton();
            this.pbDrawingWeldSequence = new Wisej.Web.PictureBox();
            this.rbDrawingGroove = new Wisej.Web.RadioButton();
            this.rbDrawingBevel = new Wisej.Web.RadioButton();
            this.rbDrawingWeld = new Wisej.Web.RadioButton();
            this.rbDrawingRectangle = new Wisej.Web.RadioButton();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel4 = new Wisej.Web.TableLayoutPanel();
            this.btnDrawingSave = new Wisej.Web.Button();
            this.uplDrawingUpload = new Wisej.Web.Upload();
            this.btnDrawingUndoRemove = new Wisej.Web.Button();
            this.btnDrawingBack = new Wisej.Web.Button();
            this.btnDrawingHome = new Wisej.Web.Button();
            this.btnDrawingComplete = new Wisej.Web.Button();
            this.tableLayoutPanel6 = new Wisej.Web.TableLayoutPanel();
            this.lblInfoNote = new Wisej.Web.LinkLabel();
            this.label16 = new Wisej.Web.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tlpDrawing.SuspendLayout();
            this.tlpDrawingControls.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tlpDrawingPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDrawingWeldSequence)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel6, 1, 1);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel2.Controls.Add(this.tlpDrawing, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 1, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tlpDrawing
            // 
            this.tlpDrawing.ColumnCount = 2;
            this.tlpDrawing.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpDrawing.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 60F));
            this.tlpDrawing.Controls.Add(this.tlpDrawingControls, 0, 0);
            this.tlpDrawing.Controls.Add(this.tlpDrawingPanel, 1, 0);
            this.tlpDrawing.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpDrawing.Location = new System.Drawing.Point(3, 3);
            this.tlpDrawing.Name = "tlpDrawing";
            this.tlpDrawing.RowCount = 1;
            this.tlpDrawing.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpDrawing.Size = new System.Drawing.Size(1024, 433);
            this.tlpDrawing.TabIndex = 6;
            // 
            // tlpDrawingControls
            // 
            this.tlpDrawingControls.ColumnCount = 1;
            this.tlpDrawingControls.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tlpDrawingControls.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tlpDrawingControls.Controls.Add(this.pDrawingShapePreview, 0, 1);
            this.tlpDrawingControls.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpDrawingControls.Location = new System.Drawing.Point(3, 3);
            this.tlpDrawingControls.Name = "tlpDrawingControls";
            this.tlpDrawingControls.RowCount = 2;
            this.tlpDrawingControls.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpDrawingControls.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpDrawingControls.Size = new System.Drawing.Size(250, 427);
            this.tlpDrawingControls.TabIndex = 9;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel5.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel5.ColumnCount = 4;
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.label100, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.txtDrawingRootFace, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this.txtDrawingAngle, 3, 1);
            this.tableLayoutPanel5.Controls.Add(this.txtDrawingRadius, 3, 2);
            this.tableLayoutPanel5.Controls.Add(this.cbDrawingSnap, 3, 4);
            this.tableLayoutPanel5.Controls.Add(this.cbDrawingDouble, 3, 3);
            this.tableLayoutPanel5.Controls.Add(this.label9, 2, 4);
            this.tableLayoutPanel5.Controls.Add(this.txtDrawingGrid, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label2, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.cbDrawingFlipV, 1, 4);
            this.tableLayoutPanel5.Controls.Add(this.txtDrawingThickness, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.cbDrawingFlipH, 1, 3);
            this.tableLayoutPanel5.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label8, 2, 2);
            this.tableLayoutPanel5.Controls.Add(this.label6, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.label4, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.label7, 2, 3);
            this.tableLayoutPanel5.Controls.Add(this.txtDrawingRotation, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.label5, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.label3, 2, 1);
            this.tableLayoutPanel5.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 5;
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(244, 207);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.BackColor = System.Drawing.Color.FromName("@window");
            this.label100.Dock = Wisej.Web.DockStyle.Fill;
            this.label100.Location = new System.Drawing.Point(3, 3);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(54, 35);
            this.label100.TabIndex = 16;
            this.label100.Text = "Grid Size";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDrawingRootFace
            // 
            this.txtDrawingRootFace.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDrawingRootFace.InputType.Min = "0";
            this.txtDrawingRootFace.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtDrawingRootFace.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDrawingRootFace.Location = new System.Drawing.Point(183, 3);
            this.txtDrawingRootFace.Name = "txtDrawingRootFace";
            this.txtDrawingRootFace.Size = new System.Drawing.Size(56, 35);
            this.txtDrawingRootFace.TabIndex = 6;
            this.txtDrawingRootFace.TextChanged += new System.EventHandler(this.txtDrawingRotation_TextChanged);
            // 
            // txtDrawingAngle
            // 
            this.txtDrawingAngle.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDrawingAngle.InputType.Max = "89";
            this.txtDrawingAngle.InputType.Min = "0";
            this.txtDrawingAngle.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtDrawingAngle.InputType.Step = 0.5D;
            this.txtDrawingAngle.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDrawingAngle.Location = new System.Drawing.Point(183, 44);
            this.txtDrawingAngle.Name = "txtDrawingAngle";
            this.txtDrawingAngle.Size = new System.Drawing.Size(56, 35);
            this.txtDrawingAngle.TabIndex = 7;
            this.txtDrawingAngle.TextChanged += new System.EventHandler(this.txtDrawingRotation_TextChanged);
            // 
            // txtDrawingRadius
            // 
            this.txtDrawingRadius.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDrawingRadius.InputType.Min = "0";
            this.txtDrawingRadius.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtDrawingRadius.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDrawingRadius.Location = new System.Drawing.Point(183, 85);
            this.txtDrawingRadius.Name = "txtDrawingRadius";
            this.txtDrawingRadius.Size = new System.Drawing.Size(56, 35);
            this.txtDrawingRadius.TabIndex = 15;
            this.txtDrawingRadius.TextChanged += new System.EventHandler(this.txtDrawingRotation_TextChanged);
            // 
            // cbDrawingSnap
            // 
            this.cbDrawingSnap.Appearance = Wisej.Web.Appearance.Switch;
            this.cbDrawingSnap.BackColor = System.Drawing.Color.FromName("@window");
            this.cbDrawingSnap.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbDrawingSnap.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDrawingSnap.Location = new System.Drawing.Point(183, 167);
            this.cbDrawingSnap.Name = "cbDrawingSnap";
            this.cbDrawingSnap.Size = new System.Drawing.Size(56, 35);
            this.cbDrawingSnap.TabIndex = 18;
            this.cbDrawingSnap.CheckedChanged += new System.EventHandler(this.txtDrawingGrid_TextChanged);
            // 
            // cbDrawingDouble
            // 
            this.cbDrawingDouble.Appearance = Wisej.Web.Appearance.Switch;
            this.cbDrawingDouble.BackColor = System.Drawing.Color.FromName("@window");
            this.cbDrawingDouble.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbDrawingDouble.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDrawingDouble.Location = new System.Drawing.Point(183, 126);
            this.cbDrawingDouble.Name = "cbDrawingDouble";
            this.cbDrawingDouble.Size = new System.Drawing.Size(56, 35);
            this.cbDrawingDouble.TabIndex = 13;
            this.cbDrawingDouble.CheckedChanged += new System.EventHandler(this.txtDrawingRotation_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromName("@window");
            this.label9.Dock = Wisej.Web.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(123, 167);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 35);
            this.label9.TabIndex = 19;
            this.label9.Text = "Grid Snap";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDrawingGrid
            // 
            this.txtDrawingGrid.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDrawingGrid.InputType.Max = "100";
            this.txtDrawingGrid.InputType.Min = "1";
            this.txtDrawingGrid.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtDrawingGrid.InputType.Step = 1D;
            this.txtDrawingGrid.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDrawingGrid.Location = new System.Drawing.Point(63, 3);
            this.txtDrawingGrid.Name = "txtDrawingGrid";
            this.txtDrawingGrid.Size = new System.Drawing.Size(54, 35);
            this.txtDrawingGrid.TabIndex = 17;
            this.txtDrawingGrid.TextChanged += new System.EventHandler(this.txtDrawingGrid_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromName("@window");
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(123, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 35);
            this.label2.TabIndex = 2;
            this.label2.Text = "Root Face";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbDrawingFlipV
            // 
            this.cbDrawingFlipV.Appearance = Wisej.Web.Appearance.Switch;
            this.cbDrawingFlipV.BackColor = System.Drawing.Color.FromName("@window");
            this.cbDrawingFlipV.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbDrawingFlipV.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDrawingFlipV.Location = new System.Drawing.Point(63, 167);
            this.cbDrawingFlipV.Name = "cbDrawingFlipV";
            this.cbDrawingFlipV.Size = new System.Drawing.Size(54, 35);
            this.cbDrawingFlipV.TabIndex = 9;
            this.cbDrawingFlipV.CheckedChanged += new System.EventHandler(this.cbDrawingFlipV_CheckedChanged);
            // 
            // txtDrawingThickness
            // 
            this.txtDrawingThickness.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDrawingThickness.InputType.Min = "0";
            this.txtDrawingThickness.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtDrawingThickness.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDrawingThickness.Location = new System.Drawing.Point(63, 85);
            this.txtDrawingThickness.Name = "txtDrawingThickness";
            this.txtDrawingThickness.Size = new System.Drawing.Size(54, 35);
            this.txtDrawingThickness.TabIndex = 11;
            this.txtDrawingThickness.TextChanged += new System.EventHandler(this.txtDrawingRotation_TextChanged);
            // 
            // cbDrawingFlipH
            // 
            this.cbDrawingFlipH.Appearance = Wisej.Web.Appearance.Switch;
            this.cbDrawingFlipH.BackColor = System.Drawing.Color.FromName("@window");
            this.cbDrawingFlipH.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbDrawingFlipH.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDrawingFlipH.Location = new System.Drawing.Point(63, 126);
            this.cbDrawingFlipH.Name = "cbDrawingFlipH";
            this.cbDrawingFlipH.Size = new System.Drawing.Size(54, 35);
            this.cbDrawingFlipH.TabIndex = 8;
            this.cbDrawingFlipH.CheckedChanged += new System.EventHandler(this.cbDrawingFlipH_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromName("@window");
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "Rotation";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromName("@window");
            this.label8.Dock = Wisej.Web.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(123, 85);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 35);
            this.label8.TabIndex = 14;
            this.label8.Text = "Radius";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromName("@window");
            this.label6.Dock = Wisej.Web.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(3, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 35);
            this.label6.TabIndex = 10;
            this.label6.Text = "Thickness";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromName("@window");
            this.label4.Dock = Wisej.Web.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(3, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 35);
            this.label4.TabIndex = 4;
            this.label4.Text = "Flip (h)";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromName("@window");
            this.label7.Dock = Wisej.Web.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(123, 126);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 35);
            this.label7.TabIndex = 12;
            this.label7.Text = "Double";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDrawingRotation
            // 
            this.txtDrawingRotation.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDrawingRotation.InputType.Max = "45";
            this.txtDrawingRotation.InputType.Min = "-45";
            this.txtDrawingRotation.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtDrawingRotation.InputType.Step = 0.5D;
            this.txtDrawingRotation.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDrawingRotation.Location = new System.Drawing.Point(63, 44);
            this.txtDrawingRotation.Name = "txtDrawingRotation";
            this.txtDrawingRotation.Size = new System.Drawing.Size(54, 35);
            this.txtDrawingRotation.TabIndex = 1;
            this.txtDrawingRotation.TextChanged += new System.EventHandler(this.txtDrawingRotation_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromName("@window");
            this.label5.Dock = Wisej.Web.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(3, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 35);
            this.label5.TabIndex = 5;
            this.label5.Text = "Flip (v)";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromName("@window");
            this.label3.Dock = Wisej.Web.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(123, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 35);
            this.label3.TabIndex = 3;
            this.label3.Text = "Angle";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pDrawingShapePreview
            // 
            this.pDrawingShapePreview.BackColor = System.Drawing.Color.FromName("@window");
            this.pDrawingShapePreview.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pDrawingShapePreview.Dock = Wisej.Web.DockStyle.Fill;
            this.pDrawingShapePreview.Location = new System.Drawing.Point(3, 216);
            this.pDrawingShapePreview.Name = "pDrawingShapePreview";
            this.pDrawingShapePreview.Size = new System.Drawing.Size(244, 208);
            this.pDrawingShapePreview.TabIndex = 8;
            this.pDrawingShapePreview.Paint += new Wisej.Web.PaintEventHandler(this.pDrawingShapePreview_Paint);
            // 
            // tlpDrawingPanel
            // 
            this.tlpDrawingPanel.ColumnCount = 5;
            this.tlpDrawingPanel.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpDrawingPanel.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpDrawingPanel.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpDrawingPanel.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpDrawingPanel.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpDrawingPanel.Controls.Add(this.rbDrawingEdit, 4, 1);
            this.tlpDrawingPanel.Controls.Add(this.pbDrawingWeldSequence, 0, 0);
            this.tlpDrawingPanel.Controls.Add(this.rbDrawingGroove, 3, 1);
            this.tlpDrawingPanel.Controls.Add(this.rbDrawingBevel, 2, 1);
            this.tlpDrawingPanel.Controls.Add(this.rbDrawingWeld, 1, 1);
            this.tlpDrawingPanel.Controls.Add(this.rbDrawingRectangle, 0, 1);
            this.tlpDrawingPanel.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpDrawingPanel.Location = new System.Drawing.Point(259, 3);
            this.tlpDrawingPanel.Name = "tlpDrawingPanel";
            this.tlpDrawingPanel.RowCount = 2;
            this.tlpDrawingPanel.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tlpDrawingPanel.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpDrawingPanel.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tlpDrawingPanel.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tlpDrawingPanel.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tlpDrawingPanel.Size = new System.Drawing.Size(762, 427);
            this.tlpDrawingPanel.TabIndex = 7;
            // 
            // rbDrawingEdit
            // 
            this.rbDrawingEdit.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDrawingEdit.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.rbDrawingEdit.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDrawingEdit.Location = new System.Drawing.Point(611, 387);
            this.rbDrawingEdit.Name = "rbDrawingEdit";
            this.rbDrawingEdit.Size = new System.Drawing.Size(148, 37);
            this.rbDrawingEdit.TabIndex = 6;
            this.rbDrawingEdit.Text = "Edit Shape";
            this.rbDrawingEdit.CheckedChanged += new System.EventHandler(this.txtDrawingRotation_TextChanged);
            // 
            // pbDrawingWeldSequence
            // 
            this.pbDrawingWeldSequence.BackColor = System.Drawing.Color.FromName("@window");
            this.pbDrawingWeldSequence.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tlpDrawingPanel.SetColumnSpan(this.pbDrawingWeldSequence, 5);
            this.pbDrawingWeldSequence.Dock = Wisej.Web.DockStyle.Fill;
            this.pbDrawingWeldSequence.Location = new System.Drawing.Point(3, 3);
            this.pbDrawingWeldSequence.Name = "pbDrawingWeldSequence";
            this.pbDrawingWeldSequence.Size = new System.Drawing.Size(756, 378);
            this.pbDrawingWeldSequence.SizeMode = Wisej.Web.PictureBoxSizeMode.Zoom;
            this.pbDrawingWeldSequence.MouseDown += new Wisej.Web.MouseEventHandler(this.pDrawingWeldSequence_MouseDown);
            this.pbDrawingWeldSequence.MouseMove += new Wisej.Web.MouseEventHandler(this.pDrawingWeldSequence_MouseMove);
            this.pbDrawingWeldSequence.MouseUp += new Wisej.Web.MouseEventHandler(this.pDrawingWeldSequence_MouseUp);
            this.pbDrawingWeldSequence.Paint += new Wisej.Web.PaintEventHandler(this.pDrawingWeldSequence_Paint);
            // 
            // rbDrawingGroove
            // 
            this.rbDrawingGroove.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDrawingGroove.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.rbDrawingGroove.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDrawingGroove.Location = new System.Drawing.Point(459, 387);
            this.rbDrawingGroove.Name = "rbDrawingGroove";
            this.rbDrawingGroove.Size = new System.Drawing.Size(146, 37);
            this.rbDrawingGroove.TabIndex = 5;
            this.rbDrawingGroove.Text = "Groove";
            this.rbDrawingGroove.CheckedChanged += new System.EventHandler(this.txtDrawingRotation_TextChanged);
            // 
            // rbDrawingBevel
            // 
            this.rbDrawingBevel.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDrawingBevel.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.rbDrawingBevel.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDrawingBevel.Location = new System.Drawing.Point(307, 387);
            this.rbDrawingBevel.Name = "rbDrawingBevel";
            this.rbDrawingBevel.Size = new System.Drawing.Size(146, 37);
            this.rbDrawingBevel.TabIndex = 4;
            this.rbDrawingBevel.Text = "Bevel";
            this.rbDrawingBevel.CheckedChanged += new System.EventHandler(this.txtDrawingRotation_TextChanged);
            // 
            // rbDrawingWeld
            // 
            this.rbDrawingWeld.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDrawingWeld.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.rbDrawingWeld.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDrawingWeld.Location = new System.Drawing.Point(155, 387);
            this.rbDrawingWeld.Name = "rbDrawingWeld";
            this.rbDrawingWeld.Size = new System.Drawing.Size(146, 37);
            this.rbDrawingWeld.TabIndex = 3;
            this.rbDrawingWeld.Text = "Weld";
            this.rbDrawingWeld.CheckedChanged += new System.EventHandler(this.rbDrawingWeld_CheckedChanged);
            // 
            // rbDrawingRectangle
            // 
            this.rbDrawingRectangle.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDrawingRectangle.Checked = true;
            this.rbDrawingRectangle.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.rbDrawingRectangle.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDrawingRectangle.Location = new System.Drawing.Point(3, 387);
            this.rbDrawingRectangle.Name = "rbDrawingRectangle";
            this.rbDrawingRectangle.Size = new System.Drawing.Size(146, 37);
            this.rbDrawingRectangle.TabIndex = 2;
            this.rbDrawingRectangle.TabStop = true;
            this.rbDrawingRectangle.Text = "Rectangle";
            this.rbDrawingRectangle.CheckedChanged += new System.EventHandler(this.txtDrawingRotation_TextChanged);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel3.TabIndex = 5;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.btnDrawingSave, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.uplDrawingUpload, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.btnDrawingUndoRemove, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.btnDrawingBack, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.btnDrawingHome, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.btnDrawingComplete, 0, 6);
            this.tableLayoutPanel4.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel4.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 6);
            this.tableLayoutPanel4.Margin = new Wisej.Web.Padding(3, 6, 3, 6);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 7;
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(103, 421);
            this.tableLayoutPanel4.TabIndex = 4;
            // 
            // btnDrawingSave
            // 
            this.btnDrawingSave.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDrawingSave.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDrawingSave.Location = new System.Drawing.Point(3, 121);
            this.btnDrawingSave.Name = "btnDrawingSave";
            this.btnDrawingSave.Size = new System.Drawing.Size(95, 53);
            this.btnDrawingSave.TabIndex = 6;
            this.btnDrawingSave.Text = "Save Drawing";
            this.btnDrawingSave.Click += new System.EventHandler(this.btnDrawingSave_Click);
            // 
            // uplDrawingUpload
            // 
            this.uplDrawingUpload.AllowedFileTypes = ".jpg, .jpeg, .png, .bmp";
            this.uplDrawingUpload.ButtonPosition = System.Drawing.ContentAlignment.TopCenter;
            this.uplDrawingUpload.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.uplDrawingUpload.Dock = Wisej.Web.DockStyle.Fill;
            this.uplDrawingUpload.HideValue = true;
            this.uplDrawingUpload.Location = new System.Drawing.Point(3, 62);
            this.uplDrawingUpload.Name = "uplDrawingUpload";
            this.uplDrawingUpload.ResizableEdges = ((Wisej.Web.AnchorStyles)((((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left) 
            | Wisej.Web.AnchorStyles.Right)));
            this.uplDrawingUpload.Size = new System.Drawing.Size(95, 53);
            this.uplDrawingUpload.TabIndex = 5;
            this.uplDrawingUpload.Text = "Image";
            this.uplDrawingUpload.Uploaded += new Wisej.Web.UploadedEventHandler(this.uplDrawingUpload_Uploaded);
            // 
            // btnDrawingUndoRemove
            // 
            this.btnDrawingUndoRemove.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDrawingUndoRemove.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDrawingUndoRemove.Location = new System.Drawing.Point(3, 3);
            this.btnDrawingUndoRemove.Name = "btnDrawingUndoRemove";
            this.btnDrawingUndoRemove.Size = new System.Drawing.Size(95, 53);
            this.btnDrawingUndoRemove.TabIndex = 4;
            this.btnDrawingUndoRemove.Text = "Undo";
            this.btnDrawingUndoRemove.Click += new System.EventHandler(this.btnDrawingUndo_Click);
            // 
            // btnDrawingBack
            // 
            this.btnDrawingBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDrawingBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDrawingBack.Location = new System.Drawing.Point(3, 239);
            this.btnDrawingBack.Name = "btnDrawingBack";
            this.btnDrawingBack.Size = new System.Drawing.Size(95, 53);
            this.btnDrawingBack.TabIndex = 3;
            this.btnDrawingBack.Text = "Back";
            this.btnDrawingBack.Click += new System.EventHandler(this.btnDrawingBack_Click);
            // 
            // btnDrawingHome
            // 
            this.btnDrawingHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDrawingHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDrawingHome.Location = new System.Drawing.Point(3, 298);
            this.btnDrawingHome.Name = "btnDrawingHome";
            this.btnDrawingHome.Size = new System.Drawing.Size(95, 53);
            this.btnDrawingHome.TabIndex = 1;
            this.btnDrawingHome.Text = "Home";
            this.btnDrawingHome.Click += new System.EventHandler(this.btnDrawingHome_Click);
            // 
            // btnDrawingComplete
            // 
            this.btnDrawingComplete.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDrawingComplete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDrawingComplete.Location = new System.Drawing.Point(3, 357);
            this.btnDrawingComplete.Name = "btnDrawingComplete";
            this.btnDrawingComplete.Size = new System.Drawing.Size(95, 59);
            this.btnDrawingComplete.TabIndex = 0;
            this.btnDrawingComplete.Text = "Complete";
            this.btnDrawingComplete.Click += new System.EventHandler(this.btnDrawingComplete_Click);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.lblInfoNote, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel6.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // lblInfoNote
            // 
            this.lblInfoNote.AutoSize = true;
            this.lblInfoNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblInfoNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblInfoNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblInfoNote.LinkArea = new Wisej.Web.LinkArea(273, 84);
            this.lblInfoNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblInfoNote.Location = new System.Drawing.Point(9, 79);
            this.lblInfoNote.Margin = new Wisej.Web.Padding(9, 3, 6, 3);
            this.lblInfoNote.Name = "lblInfoNote";
            this.lblInfoNote.Size = new System.Drawing.Size(1130, 35);
            this.lblInfoNote.TabIndex = 7;
            this.lblInfoNote.Text = resources.GetString("lblInfoNote.Text");
            this.lblInfoNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfoNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblInfoNote_LinkClicked);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label16.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label16.CssStyle = "border-radius: 4px;";
            this.label16.Dock = Wisej.Web.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label16.Location = new System.Drawing.Point(9, 3);
            this.label16.Margin = new Wisej.Web.Padding(9, 3, 6, 3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(1130, 70);
            this.label16.TabIndex = 0;
            this.label16.Text = "Welding Test Sequence";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uc_wqDrawing
            // 
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "uc_wqDrawing";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_wqDrawing_VisibleChanged);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tlpDrawing.ResumeLayout(false);
            this.tlpDrawingControls.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tlpDrawingPanel.ResumeLayout(false);
            this.tlpDrawingPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDrawingWeldSequence)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.TableLayoutPanel tlpDrawing;
        private Wisej.Web.TableLayoutPanel tlpDrawingControls;
        private Wisej.Web.CheckBox cbDrawingFlipV;
        private Wisej.Web.CheckBox cbDrawingFlipH;
        private Wisej.Web.TextBox txtDrawingAngle;
        private Wisej.Web.TextBox txtDrawingRootFace;
        private Wisej.Web.Label label2;
        private Wisej.Web.TextBox txtDrawingRotation;
        private Wisej.Web.Label label1;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label5;
        private Wisej.Web.Panel pDrawingShapePreview;
        private Wisej.Web.TableLayoutPanel tlpDrawingPanel;
        private Wisej.Web.RadioButton rbDrawingGroove;
        private Wisej.Web.RadioButton rbDrawingBevel;
        private Wisej.Web.RadioButton rbDrawingWeld;
        private Wisej.Web.RadioButton rbDrawingRectangle;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel4;
        private Wisej.Web.Upload uplDrawingUpload;
        private Wisej.Web.Button btnDrawingUndoRemove;
        private Wisej.Web.Button btnDrawingBack;
        private Wisej.Web.Button btnDrawingHome;
        private Wisej.Web.Button btnDrawingComplete;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel6;
        private Wisej.Web.Label label16;
        private Wisej.Web.TextBox txtDrawingThickness;
        private Wisej.Web.Label label6;
        private Wisej.Web.CheckBox cbDrawingDouble;
        private Wisej.Web.Label label7;
        private Wisej.Web.TextBox txtDrawingRadius;
        private Wisej.Web.Label label8;
        private Wisej.Web.Label label100;
        private Wisej.Web.TextBox txtDrawingGrid;
        private Wisej.Web.Label label9;
        private Wisej.Web.CheckBox cbDrawingSnap;
        private Wisej.Web.Button btnDrawingSave;
        private Wisej.Web.PictureBox pbDrawingWeldSequence;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel5;
        private Wisej.Web.LinkLabel lblInfoNote;
        private Wisej.Web.RadioButton rbDrawingEdit;
    }
}
