﻿using ApiClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Welding.DAL;
using Wisej.Web;

namespace WeldingManagement.UserControls.DatasheetControls
{
    public partial class uc_wqRun : Wisej.Web.UserControl
    {
        public uc_wqRun()
        {
            InitializeComponent();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks next button on run screen")]
        public event EventHandler btnRunNextClick;
        private void btnRunNext_Click(object sender, EventArgs e)
        {
            if (lvRunParameters.Items.Count <= 0)
            {
                return;
            }

            Update_Status();

            btnRunNextClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on run screen")]
        public event EventHandler btnRunHomeClick;
        private void btnRunHome_Click(object sender, EventArgs e)
        {
            btnRunHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on run screen")]
        public event EventHandler btnRunBackClick;
        private void btnRunBack_Click(object sender, EventArgs e)
        {
            btnRunBackClick?.Invoke(this, e);
        }
        #endregion

        private void btnRunAdd_Click(object sender, EventArgs e)
        {
            UIFormatting.StartLoader(this);

            if (string.IsNullOrEmpty(txtRunSide.Text) ||
                string.IsNullOrEmpty(txtRunPass.Text) ||
                string.IsNullOrEmpty(txtRunDia.Text) ||
                string.IsNullOrEmpty(txtRunSupply.Text) ||
                string.IsNullOrEmpty(txtRunAmps.Text) ||
                string.IsNullOrEmpty(txtRunVolts.Text) ||
                string.IsNullOrEmpty(txtRunInterpass.Text) ||
                string.IsNullOrEmpty(txtRunLength.Text) ||
                string.IsNullOrEmpty(txtRunActual.Text) ||
                string.IsNullOrEmpty(txtRunTime.Text) ||
                string.IsNullOrEmpty(txtRunSpeed.Text) ||
                string.IsNullOrEmpty(txtRunInput.Text) ||
                string.IsNullOrEmpty(txtRunShield.Text) ||
                string.IsNullOrEmpty(txtRunPurge.Text))
            {
                UIFormatting.StopLoader(this);
                return;
            }

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || !(thisTag.getTagObject() is Welder_Qualification))
            {
                UIFormatting.StopLoader(this);
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            Datasheet_Run datasheet_Run = new Datasheet_Run()
            {
                Side = short.Parse(txtRunSide.Text),
                Pass = short.Parse(txtRunPass.Text),
                FillerDia = double.Parse(txtRunDia.Text),
                Supply = txtRunSupply.Text,
                Amps = double.Parse(txtRunAmps.Text),
                Volts = double.Parse(txtRunVolts.Text),
                Interpass = double.Parse(txtRunInterpass.Text),
                CalculatedLength = double.Parse(txtRunLength.Text),
                ActualLength = double.Parse(txtRunActual.Text),
                WeldTime = double.Parse(txtRunTime.Text),
                WeldSpeed = double.Parse(txtRunSpeed.Text),
                HeatInput = double.Parse(txtRunInput.Text),
                ShieldGas = double.Parse(txtRunShield.Text),
                PurgeGas = double.Parse(txtRunPurge.Text)
            };

            ApiCalls.CreateDatasheetRun(wq.Datasheet.DatasheetId, datasheet_Run);

            this.Tag = new Tag(ApiCalls.ReadWelderQualification(wq.Welder_QualificationId), TagType.Welder_Qualification);

            Load_Parameters();

            UIFormatting.StopLoader(this);
        }

        private void uc_dsRun_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Parameters();
        }

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.Welder_Qualification)
            {
                Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

                wq.Status = Actions.Consumables;

                ApiCalls.UpdateWelderQualification(wq.Welder_QualificationId, wq);

                this.Tag = new Tag(ApiCalls.ReadWelderQualification(wq.Welder_QualificationId), TagType.Welder_Qualification);
            }
        }

        private void Load_Parameters()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || !(thisTag.getTagObject() is Welder_Qualification))
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            lvRunParameters.Items.Clear();
            Clear_Txts();

            if (wq != null)
            {
                List<Datasheet_Run> datasheet_Runs = wq.Datasheet.Datasheet_Run.ToList();

                foreach (Datasheet_Run dr in datasheet_Runs)
                {
                    Add_lvRow(dr);
                }
            }

            lvRunParameters.Refresh();
        }

        private void Add_lvRow(Datasheet_Run dr)
        {
            ListViewItem lvItem = new ListViewItem(new string[]
            {
                dr.Side.ToString(),
                dr.Pass.ToString(),
                dr.FillerDia.ToString(),
                dr.Supply.ToString(),
                dr.Amps.ToString(),
                dr.Volts.ToString(),
                dr.Interpass.ToString(),
                dr.CalculatedLength.ToString(),
                dr.ActualLength.ToString(),
                dr.WeldTime.ToString(),
                dr.WeldSpeed.ToString(),
                dr.HeatInput.ToString(),
                dr.ShieldGas.ToString(),
                dr.PurgeGas.ToString()
            })
            {
                Tag = dr
            };

            lvRunParameters.Items.Add(lvItem);
        }

        private void Clear_Txts()
        {
            txtRunSide.Text = "";
            txtRunPass.Text = "";
            txtRunDia.Text = "";
            txtRunSupply.Text = "";
            txtRunAmps.Text = "";
            txtRunVolts.Text = "";
            txtRunInterpass.Text = "";
            txtRunLength.Text = "";
            txtRunActual.Text = "";
            txtRunTime.Text = "";
            txtRunSpeed.Text = "";
            txtRunInput.Text = "";
            txtRunShield.Text = "";
            txtRunPurge.Text = "";
        }

        private void CalculateRunSpeed()
        {
            try
            {
                txtRunSpeed.Text = Math.Round(double.Parse(txtRunActual.Text) / double.Parse(txtRunTime.Text) * 60, 3).ToString();

                CalculateEnergyInput();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private void CalculateEnergyInput()
        {
            try
            {
                txtRunInput.Text = Math.Round((60 * double.Parse(txtRunAmps.Text) * double.Parse(txtRunVolts.Text)) / (1000 * double.Parse(txtRunSpeed.Text)), 3).ToString();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private void txtRunActual_KeyPress(object sender, KeyPressEventArgs e)
        {
            CalculateRunSpeed();
        }

        private void txtRunTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            CalculateRunSpeed();
        }

        private void txtRunAmps_KeyPress(object sender, KeyPressEventArgs e)
        {
            CalculateEnergyInput();
        }

        private void txtRunVolts_KeyPress(object sender, KeyPressEventArgs e)
        {
            CalculateEnergyInput();
        }

        private void txtRunActual_TextChanged(object sender, EventArgs e)
        {
            CalculateRunSpeed();
        }

        private void txtRunTime_TextChanged(object sender, EventArgs e)
        {
            CalculateRunSpeed();
        }

        private void txtRunAmps_TextChanged(object sender, EventArgs e)
        {
            CalculateEnergyInput();
        }

        private void txtRunVolts_TextChanged(object sender, EventArgs e)
        {
            CalculateEnergyInput();
        }

        private void lvRunParameters_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnRunDelete.Visible = lvRunParameters.SelectedItems.Count > 0;
        }

        private void lvRunParameters_ItemDoubleClick(object sender, ItemClickEventArgs e)
        {
            Datasheet_Run drToCopy = (Datasheet_Run)e.Item.Tag;

            if (drToCopy == null)
            {
                return;
            }

            txtRunSide.Text = drToCopy.Side.Value.ToString() ?? "";
            txtRunPass.Text = (drToCopy.Pass.Value + 1).ToString() ?? "";
            txtRunDia.Text = drToCopy.FillerDia.Value.ToString() ?? "";
            txtRunSupply.Text = drToCopy.Supply?.ToString() ?? "";
            txtRunAmps.Text = drToCopy.Amps?.ToString() ?? "";
            txtRunVolts.Text = drToCopy.Volts?.ToString() ?? "";
            txtRunInterpass.Text = drToCopy.Interpass?.ToString() ?? "";
            txtRunLength.Text = drToCopy.CalculatedLength.Value.ToString() ?? "";
            txtRunActual.Text = drToCopy.ActualLength.Value.ToString() ?? "";
            txtRunTime.Text = drToCopy.WeldTime?.ToString() ?? "";
            txtRunSpeed.Text = drToCopy.WeldSpeed?.ToString() ?? "";
            txtRunInput.Text = drToCopy.HeatInput?.ToString() ?? "";
            txtRunShield.Text = drToCopy.ShieldGas.Value.ToString() ?? "";
            txtRunPurge.Text = drToCopy.PurgeGas.Value.ToString() ?? "";
        }

        private void btnRunDelete_DoubleClick(object sender, EventArgs e)
        {
            if (lvRunParameters.SelectedItems.Count != 1)
            {
                return;
            }

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            Datasheet_Run drToDelete = (Datasheet_Run)lvRunParameters.Items[lvRunParameters.SelectedIndex].Tag;

            if (drToDelete == null)
            {
                return;
            }

            ApiCalls.DeleteDatasheetRun(drToDelete.Datasheet_RunId);

            this.Tag = new Tag(ApiCalls.ReadWelderQualification(wq.Welder_QualificationId), TagType.Welder_Qualification);

            Load_Parameters();
        }

        private void lvRunParameters_Resize(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != Wisej.Web.DockStyle.Fill)
            {
                return;
            }

            UIFormatting.ResizeColumnsFor(lvRunParameters);
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }

        private void label78_DoubleClick(object sender, EventArgs e)
        {
            if (UIFormatting.adminUsers.Contains(Application.Cookies["EmployeeNumber"].TrimStart('E')))
            {
                txtRunSide.Text = "1";
                txtRunPass.Text = "1";
                txtRunDia.Text = "1.2";
                txtRunSupply.Text = "DCEP";
                txtRunAmps.Text = "100";
                txtRunVolts.Text = "50";
                txtRunInterpass.Text = "75";
                txtRunLength.Text = "250";
                txtRunActual.Text = "249";
                txtRunTime.Text = "120";
                CalculateEnergyInput();
                CalculateRunSpeed();
                txtRunShield.Text = "0";
                txtRunPurge.Text = "0";
            }
        }
    }
}
