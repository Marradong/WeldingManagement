﻿using ApiClient;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using Welding.DAL;
using Wisej.Web;
using static Google.Protobuf.Reflection.SourceCodeInfo.Types;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.VisualControls
{
    public partial class uc_wqInspection : Wisej.Web.UserControl
    {
        private up_hmSave up_hmSave1;
        private Panel overlayPanel;

        public uc_wqInspection()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on Visual Inspection screen")]
        public event EventHandler btnVisualCompleteClick;
        private void btnVisualComplete_Click(object sender, EventArgs e)
        {
            Save_Action();
            Update_Status();

            btnVisualCompleteClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on Visual Inspection screen")]
        public event EventHandler btnVisualHomeClick;
        private void btnVisualHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnVisualHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on Visual Inspection screen")]
        public event EventHandler btnVisualBackClick;
        private void btnVisualBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnVisualBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnVisualBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        #region Tick Events

        private void btnVisualYWeldID_Click(object sender, EventArgs e)
        {
            btnVisualYWeldID.BackColor = Color.FromName("@switchOn");
            btnVisualNWeldID.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYBurn_Click(object sender, EventArgs e)
        {
            btnVisualYBurn.BackColor = Color.FromName("@switchOn");
            btnVisualNBurn.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYWeldersID_Click(object sender, EventArgs e)
        {
            btnVisualYWeldersID.BackColor = Color.FromName("@switchOn");
            btnVisualNWeldersID.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYInitial_Click(object sender, EventArgs e)
        {
            btnVisualYInitial.BackColor = Color.FromName("@switchOn");
            btnVisualNInitial.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYRepair_Click(object sender, EventArgs e)
        {
            btnVisualYRepair.BackColor = Color.FromName("@switchOn");
            btnVisualNRepair.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYFinal_Click(object sender, EventArgs e)
        {
            btnVisualYFinal.BackColor = Color.FromName("@switchOn");
            btnVisualNFinal.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYProcedure_Click(object sender, EventArgs e)
        {
            btnVisualYProcedure.BackColor = Color.FromName("@switchOn");
            btnVisualNProcedure.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYQualification_Click(object sender, EventArgs e)
        {
            btnVisualYQualification.BackColor = Color.FromName("@switchOn");
            btnVisualNQualification.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYControl_Click(object sender, EventArgs e)
        {
            btnVisualYControl.BackColor = Color.FromName("@switchOn");
            btnVisualNControl.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYSize_Click(object sender, EventArgs e)
        {
            btnVisualYSize.BackColor = Color.FromName("@switchOn");
            btnVisualNSize.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYLocation_Click(object sender, EventArgs e)
        {
            btnVisualYLocation.BackColor = Color.FromName("@switchOn");
            btnVisualNLocation.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYCracks_Click(object sender, EventArgs e)
        {
            btnVisualYCracks.BackColor = Color.FromName("@switchOn");
            btnVisualNCracks.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYPenetration_Click(object sender, EventArgs e)
        {
            btnVisualYPenetration.BackColor = Color.FromName("@switchOn");
            btnVisualNPenetration.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYFusion_Click(object sender, EventArgs e)
        {
            btnVisualYFusion.BackColor = Color.FromName("@switchOn");
            btnVisualNFusion.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYPorosity_Click(object sender, EventArgs e)
        {
            btnVisualYPorosity.BackColor = Color.FromName("@switchOn");
            btnVisualNPorosity.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYSatisfactory_Click(object sender, EventArgs e)
        {
            btnVisualYSatisfactory.BackColor = Color.FromName("@switchOn");
            btnVisualNSatisfactory.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYCrater_Click(object sender, EventArgs e)
        {
            btnVisualYCrater.BackColor = Color.FromName("@switchOn");
            btnVisualNCrater.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYSuckBack_Click(object sender, EventArgs e)
        {
            btnVisualYSuckBack.BackColor = Color.FromName("@switchOn");
            btnVisualNSuckBack.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYReinforcement_Click(object sender, EventArgs e)
        {
            btnVisualYReinforcement.BackColor = Color.FromName("@switchOn");
            btnVisualNReinforcement.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYArc_Click(object sender, EventArgs e)
        {
            btnVisualYArc.BackColor = Color.FromName("@switchOn");
            btnVisualNArc.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYUndercut_Click(object sender, EventArgs e)
        {
            btnVisualYUndercut.BackColor = Color.FromName("@switchOn");
            btnVisualNUndercut.BackColor = Color.FromName("@controlLight");
        }


        #endregion

        #region Cross Events
        private void btnVisualNWeldID_Click(object sender, EventArgs e)
        {
            btnVisualYWeldID.BackColor = Color.FromName("@controlLight");
            btnVisualNWeldID.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNWeldersID_Click(object sender, EventArgs e)
        {
            btnVisualYWeldersID.BackColor = Color.FromName("@controlLight");
            btnVisualNWeldersID.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNInitial_Click(object sender, EventArgs e)
        {
            btnVisualYInitial.BackColor = Color.FromName("@controlLight");
            btnVisualNInitial.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNRepair_Click(object sender, EventArgs e)
        {
            btnVisualYRepair.BackColor = Color.FromName("@controlLight");
            btnVisualNRepair.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNFinal_Click(object sender, EventArgs e)
        {
            btnVisualYFinal.BackColor = Color.FromName("@controlLight");
            btnVisualNFinal.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNProcedure_Click(object sender, EventArgs e)
        {
            btnVisualYProcedure.BackColor = Color.FromName("@controlLight");
            btnVisualNProcedure.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNQualification_Click(object sender, EventArgs e)
        {
            btnVisualYQualification.BackColor = Color.FromName("@controlLight");
            btnVisualNQualification.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNControl_Click(object sender, EventArgs e)
        {
            btnVisualYControl.BackColor = Color.FromName("@controlLight");
            btnVisualNControl.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNSize_Click(object sender, EventArgs e)
        {
            btnVisualYSize.BackColor = Color.FromName("@controlLight");
            btnVisualNSize.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNLocation_Click(object sender, EventArgs e)
        {
            btnVisualYLocation.BackColor = Color.FromName("@controlLight");
            btnVisualNLocation.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNCracks_Click(object sender, EventArgs e)
        {
            btnVisualYCracks.BackColor = Color.FromName("@controlLight");
            btnVisualNCracks.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNPenetration_Click(object sender, EventArgs e)
        {
            btnVisualYPenetration.BackColor = Color.FromName("@controlLight");
            btnVisualNPenetration.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNFusion_Click(object sender, EventArgs e)
        {
            btnVisualYFusion.BackColor = Color.FromName("@controlLight");
            btnVisualNFusion.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNPorosity_Click(object sender, EventArgs e)
        {
            btnVisualYPorosity.BackColor = Color.FromName("@controlLight");
            btnVisualNPorosity.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNSatisfactory_Click(object sender, EventArgs e)
        {
            btnVisualYSatisfactory.BackColor = Color.FromName("@controlLight");
            btnVisualNSatisfactory.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNCrater_Click(object sender, EventArgs e)
        {
            btnVisualYCrater.BackColor = Color.FromName("@controlLight");
            btnVisualNCrater.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNSuckBack_Click(object sender, EventArgs e)
        {
            btnVisualYSuckBack.BackColor = Color.FromName("@controlLight");
            btnVisualNSuckBack.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNReinforcement_Click(object sender, EventArgs e)
        {
            btnVisualYReinforcement.BackColor = Color.FromName("@controlLight");
            btnVisualNReinforcement.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNArc_Click(object sender, EventArgs e)
        {
            btnVisualYArc.BackColor = Color.FromName("@controlLight");
            btnVisualNArc.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNUndercut_Click(object sender, EventArgs e)
        {
            btnVisualYUndercut.BackColor = Color.FromName("@controlLight");
            btnVisualNUndercut.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNBurn_Click(object sender, EventArgs e)
        {
            btnVisualYBurn.BackColor = Color.FromName("@controlLight");
            btnVisualNBurn.BackColor = Color.FromName("@invalid");
        }

        #endregion

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            wq.Status = Actions.NataReports;

            ApiCalls.UpdateWelderQualification(wq.Welder_QualificationId, wq);

            this.Tag = new Tag(ApiCalls.ReadWelderQualification(wq.Welder_QualificationId), TagType.Welder_Qualification);
        }

        private void Save_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            Visual_Inspection vi = FillInspection();

            if (wq.Visual_Inspection == null)
            {
                ApiCalls.CreateVisualInspection(wq.Welder_QualificationId, vi);
            }
            else
            {
                ApiCalls.UpdateVisualInspection(wq.Visual_Inspection.Visual_InspectionId, vi);
            }

            this.Tag = new Tag(ApiCalls.ReadWelderQualification(wq.Welder_QualificationId), TagType.Welder_Qualification);
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            if (wq == null)
            {
                return;
            }

            dtpVisualDate.Value = DateTime.Now;

            if (wq.Visual_Inspection != null)
            {
                txtVisualJob.Text = wq.WeldingAction.Job.JobNo?.ToString() ?? "";
                txtVisualWPQR.Text = wq.Datasheet.WPQRNumber?.ToString() ?? "";
                txtVisualWelder.Text = wq.Datasheet.WelderEID?.ToString() ?? "";
                txtVisualStandard.Text = wq.Visual_Inspection.WeldingStandard?.ToString() ?? "";
                txtVisualMatStandard.Text = wq.Visual_Inspection.MaterialStd?.ToString() ?? "";
                txtVisualMatGrade.Text = wq.Visual_Inspection.MaterialGrd?.ToString() ?? "";

                dtpVisualDate.Value = wq.Visual_Inspection.Date ?? DateTime.Now;
                txtVisualLocation.Text = wq.Visual_Inspection.Location?.ToString() ?? "";
                txtVisualMap.Text = wq.Visual_Inspection.WeldMap?.ToString() ?? "";
                txtVisualDrawing.Text = wq.Visual_Inspection.DrawingNumber?.ToString() ?? "";
                txtVisualSerial.Text = wq.Visual_Inspection.SerialNumbers?.ToString() ?? "";
                txtVisualNotes.Text = wq.Visual_Inspection.Notes?.ToString() ?? "";

                btnVisualYWeldID.BackColor = wq.Visual_Inspection.Weld_Id == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNWeldID.BackColor = wq.Visual_Inspection.Weld_Id == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYWeldersID.BackColor = wq.Visual_Inspection.Welder_Id == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNWeldersID.BackColor = wq.Visual_Inspection.Welder_Id == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYInitial.BackColor = wq.Visual_Inspection.Initial == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNInitial.BackColor = wq.Visual_Inspection.Initial == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYRepair.BackColor = wq.Visual_Inspection.Repair == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNRepair.BackColor = wq.Visual_Inspection.Repair == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYFinal.BackColor = wq.Visual_Inspection.Final == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNFinal.BackColor = wq.Visual_Inspection.Final == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYProcedure.BackColor = wq.Visual_Inspection.Procedure == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNProcedure.BackColor = wq.Visual_Inspection.Procedure == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYQualification.BackColor = wq.Visual_Inspection.Qualification == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNQualification.BackColor = wq.Visual_Inspection.Qualification == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYControl.BackColor = wq.Visual_Inspection.Control == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNControl.BackColor = wq.Visual_Inspection.Control == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYSize.BackColor = wq.Visual_Inspection.Profile == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNSize.BackColor = wq.Visual_Inspection.Profile == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYLocation.BackColor = wq.Visual_Inspection.WeldLocation == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNLocation.BackColor = wq.Visual_Inspection.WeldLocation == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYCracks.BackColor = wq.Visual_Inspection.Cracks == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNCracks.BackColor = wq.Visual_Inspection.Cracks == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYPenetration.BackColor = wq.Visual_Inspection.Penetration == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNPenetration.BackColor = wq.Visual_Inspection.Penetration == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYFusion.BackColor = wq.Visual_Inspection.Fusion == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNFusion.BackColor = wq.Visual_Inspection.Fusion == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYPorosity.BackColor = wq.Visual_Inspection.Porosity == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNPorosity.BackColor = wq.Visual_Inspection.Porosity == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYBurn.BackColor = wq.Visual_Inspection.BurnThrough == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNBurn.BackColor = wq.Visual_Inspection.BurnThrough == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYUndercut.BackColor = wq.Visual_Inspection.Undercut == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNUndercut.BackColor = wq.Visual_Inspection.Undercut == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYArc.BackColor = wq.Visual_Inspection.ArcStrike == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNArc.BackColor = wq.Visual_Inspection.ArcStrike == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYReinforcement.BackColor = wq.Visual_Inspection.Reinforcement == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNReinforcement.BackColor = wq.Visual_Inspection.Reinforcement == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYSuckBack.BackColor = wq.Visual_Inspection.SuckBack == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNSuckBack.BackColor = wq.Visual_Inspection.SuckBack == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYCrater.BackColor = wq.Visual_Inspection.Crater == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNCrater.BackColor = wq.Visual_Inspection.Crater == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");

                btnVisualYSatisfactory.BackColor = wq.Visual_Inspection.Satisfactory == true ? Color.FromName("@switchOn") : Color.FromName("@controlLight");
                btnVisualNSatisfactory.BackColor = wq.Visual_Inspection.Satisfactory == true ? Color.FromName("@controlLight") : Color.FromName("@invalid");
            }
            else
            {
                txtVisualJob.Text = wq.WeldingAction.Job.JobNo?.ToString() ?? "";
                txtVisualWPQR.Text = wq.Datasheet.WPQRNumber?.ToString() ?? "";
                txtVisualWelder.Text = wq.Datasheet.WelderEID?.ToString() ?? "";
                txtVisualStandard.Text = wq.Datasheet.WeldingStandard?.ToString() ?? "";
                txtVisualMatStandard.Text = wq.Datasheet.MaterialStd?.ToString() ?? "";
                txtVisualMatGrade.Text = wq.Datasheet.MaterialGrd?.ToString() ?? "";

                dtpVisualDate.Value = DateTime.Now;
                txtVisualLocation.Text = "";
                txtVisualMap.Text = "";
                txtVisualDrawing.Text = "";
                txtVisualSerial.Text = "";
                txtVisualNotes.Text = "";
            }
        }

        private void uc_viInspection_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }

        private Visual_Inspection FillInspection()
        {
            Visual_Inspection visual_Inspection = new Visual_Inspection
            {
                Date = dtpVisualDate.Value,
                Location = txtVisualLocation.Text,
                WeldMap = txtVisualMap.Text,
                DrawingNumber = txtVisualDrawing.Text,
                SerialNumbers = txtVisualSerial.Text,
                Notes = txtVisualNotes.Text,
                WeldingStandard = txtVisualStandard.Text,
                MaterialStd = txtVisualMatStandard.Text,
                MaterialGrd = txtVisualMatGrade.Text,

                Weld_Id = btnVisualYWeldID.BackColor == Color.FromName("@switchOn"),
                Welder_Id = btnVisualYWeldersID.BackColor == Color.FromName("@switchOn"),
                Initial = btnVisualYInitial.BackColor == Color.FromName("@switchOn"),
                Repair = btnVisualYRepair.BackColor == Color.FromName("@switchOn"),
                Final = btnVisualYFinal.BackColor == Color.FromName("@switchOn"),
                Procedure = btnVisualYProcedure.BackColor == Color.FromName("@switchOn"),
                Qualification = btnVisualYQualification.BackColor == Color.FromName("@switchOn"),
                Control = btnVisualYControl.BackColor == Color.FromName("@switchOn"),
                Profile = btnVisualYSize.BackColor == Color.FromName("@switchOn"),
                WeldLocation = btnVisualYLocation.BackColor == Color.FromName("@switchOn"),
                Cracks = btnVisualYCracks.BackColor == Color.FromName("@switchOn"),
                Penetration = btnVisualYPenetration.BackColor == Color.FromName("@switchOn"),
                Fusion = btnVisualYFusion.BackColor == Color.FromName("@switchOn"),
                Porosity = btnVisualYPorosity.BackColor == Color.FromName("@switchOn"),
                BurnThrough = btnVisualYBurn.BackColor == Color.FromName("@switchOn"),
                Undercut = btnVisualYUndercut.BackColor == Color.FromName("@switchOn"),
                ArcStrike = btnVisualYArc.BackColor == Color.FromName("@switchOn"),
                Reinforcement = btnVisualYReinforcement.BackColor == Color.FromName("@switchOn"),
                SuckBack = btnVisualYSuckBack.BackColor == Color.FromName("@switchOn"),
                Crater = btnVisualYCrater.BackColor == Color.FromName("@switchOn"),
                Satisfactory = btnVisualYSatisfactory.BackColor == Color.FromName("@switchOn")
            };

            return visual_Inspection;
        }

        private void label16_DoubleClick(object sender, EventArgs e)
        {
            if (UIFormatting.adminUsers.Contains(Application.Cookies["EmployeeNumber"].TrimStart('E')))
            {
                txtVisualSerial.Text = "1 off";
                txtVisualLocation.Text = "2 Bell Street";
                txtVisualMap.Text = "N/A";
                txtVisualDrawing.Text = "TEST#789";
                txtVisualNotes.Text = "Visual Inspection for Demonstration Purposes";
            }
        }
    }
}
