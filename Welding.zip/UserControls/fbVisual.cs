﻿using System;
using System.ComponentModel;
using System.Drawing;
using Wisej.Web;

namespace WeldingManagement
{
    public partial class fbVisual : Wisej.Web.UserControl
    {
        #region FlipBoard
        bool IsDesignMode = (LicenseManager.UsageMode == LicenseUsageMode.Designtime);
        bool checkCancel = true;

        [Category("Board")]
        [Description("Number to display")]

        private void Boards_Selecting(object sender, TabControlCancelEventArgs e)
        {
            e.Cancel = checkCancel;
            checkCancel = true;
        }

        private BoardId showBoard = BoardId.Visual;
        public BoardId ShowBoard
        {
            get
            {
                return showBoard;
            }
            set
            {
                showBoard = value;
                checkCancel = false;

                //Change Boards
                Boards.SelectedIndex = (int)showBoard;
                Boards.Refresh();

                //Exectute Board Show Code
                switch (ShowBoard)
                {
                    case BoardId.Visual:

                        string LoggedIn = "True";
                        if (LoggedIn == "True")
                        {
                            Boards.SelectedIndex = (int)BoardId.Visual;
                            Boards.Refresh();
                        }
                        else
                        {
                            //txtUserName.Text = txtEmpId.Text = txtPassword.Text = "";
                            //if (txtUserName.Text == "")
                            //    txtUserName.Text = Environment.UserName;

                            Boards.SelectedIndex = (int)BoardId.Visual;
                        }

                        break;
                }
            }
        }

        public enum BoardId
        {
            Visual = 0,
        }
        public fbVisual()
        {
            InitializeComponent();

            Boards.BorderStyle = Wisej.Web.BorderStyle.None;
            Boards.ItemSize = new Size(1, 1); //Hide Tabs - they are not selectable
            Boards.SizeMode = TabSizeMode.Fixed;

            foreach (TabPage tab in Boards.TabPages)
            {
                tab.Text = "";
                tab.BackColor = Color.White;
            }
        }
        #endregion

        #region Visual

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on Visual Inspection screen")]
        public event EventHandler btnVisualHomeClick;
        private void btnVisualHome_Click(object sender, EventArgs e)
        {
            btnVisualHomeClick?.Invoke(this, e);
            this.ShowBoard = BoardId.Visual;
            this.Refresh();
        }

        private void btnVisualComplete_Click(object sender, EventArgs e)
        {
            // TODO
        }

        #region Tick Buttons

        private void btnVisualYWeldID_Click(object sender, EventArgs e)
        {
            btnVisualYWeldID.BackColor = Color.FromName("@switchOn");
            btnVisualNWeldID.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYBurn_Click(object sender, EventArgs e)
        {
            btnVisualYBurn.BackColor = Color.FromName("@switchOn");
            btnVisualNBurn.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYWeldersID_Click(object sender, EventArgs e)
        {
            btnVisualYWeldersID.BackColor = Color.FromName("@switchOn");
            btnVisualNWeldersID.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYInitial_Click(object sender, EventArgs e)
        {
            btnVisualYInitial.BackColor = Color.FromName("@switchOn");
            btnVisualNInitial.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYRepair_Click(object sender, EventArgs e)
        {
            btnVisualYRepair.BackColor = Color.FromName("@switchOn");
            btnVisualNRepair.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYFinal_Click(object sender, EventArgs e)
        {
            btnVisualYFinal.BackColor = Color.FromName("@switchOn");
            btnVisualNFinal.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYProcedure_Click(object sender, EventArgs e)
        {
            btnVisualYProcedure.BackColor = Color.FromName("@switchOn");
            btnVisualNProcedure.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYQualification_Click(object sender, EventArgs e)
        {
            btnVisualYQualification.BackColor = Color.FromName("@switchOn");
            btnVisualNQualification.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYControl_Click(object sender, EventArgs e)
        {
            btnVisualYControl.BackColor = Color.FromName("@switchOn");
            btnVisualNControl.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYSize_Click(object sender, EventArgs e)
        {
            btnVisualYSize.BackColor = Color.FromName("@switchOn");
            btnVisualNSize.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYLocation_Click(object sender, EventArgs e)
        {
            btnVisualYLocation.BackColor = Color.FromName("@switchOn");
            btnVisualNLocation.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYCracks_Click(object sender, EventArgs e)
        {
            btnVisualYCracks.BackColor = Color.FromName("@switchOn");
            btnVisualNCracks.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYPenetration_Click(object sender, EventArgs e)
        {
            btnVisualYPenetration.BackColor = Color.FromName("@switchOn");
            btnVisualNPenetration.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYFusion_Click(object sender, EventArgs e)
        {
            btnVisualYFusion.BackColor = Color.FromName("@switchOn");
            btnVisualNFusion.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYPorosity_Click(object sender, EventArgs e)
        {
            btnVisualYPorosity.BackColor = Color.FromName("@switchOn");
            btnVisualNPorosity.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYSatisfactory_Click(object sender, EventArgs e)
        {
            btnVisualYSatisfactory.BackColor = Color.FromName("@switchOn");
            btnVisualNSatisfactory.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYCrater_Click(object sender, EventArgs e)
        {
            btnVisualYCrater.BackColor = Color.FromName("@switchOn");
            btnVisualNCrater.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYSuckBack_Click(object sender, EventArgs e)
        {
            btnVisualYSuckBack.BackColor = Color.FromName("@switchOn");
            btnVisualNSuckBack.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYReinforcement_Click(object sender, EventArgs e)
        {
            btnVisualYReinforcement.BackColor = Color.FromName("@switchOn");
            btnVisualNReinforcement.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYArc_Click(object sender, EventArgs e)
        {
            btnVisualYArc.BackColor = Color.FromName("@switchOn");
            btnVisualNArc.BackColor = Color.FromName("@controlLight");
        }

        private void btnVisualYUndercut_Click(object sender, EventArgs e)
        {
            btnVisualYUndercut.BackColor = Color.FromName("@switchOn");
            btnVisualNUndercut.BackColor = Color.FromName("@controlLight");
        }
        #endregion

        #region Cross Buttons
        private void btnVisualNWeldID_Click(object sender, EventArgs e)
        {
            btnVisualYWeldID.BackColor = Color.FromName("@controlLight");
            btnVisualNWeldID.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNWeldersID_Click(object sender, EventArgs e)
        {
            btnVisualYWeldersID.BackColor = Color.FromName("@controlLight");
            btnVisualNWeldersID.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNInitial_Click(object sender, EventArgs e)
        {
            btnVisualYInitial.BackColor = Color.FromName("@controlLight");
            btnVisualNInitial.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNRepair_Click(object sender, EventArgs e)
        {
            btnVisualYRepair.BackColor = Color.FromName("@controlLight");
            btnVisualNRepair.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNFinal_Click(object sender, EventArgs e)
        {
            btnVisualYFinal.BackColor = Color.FromName("@controlLight");
            btnVisualNFinal.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNProcedure_Click(object sender, EventArgs e)
        {
            btnVisualYProcedure.BackColor = Color.FromName("@controlLight");
            btnVisualNProcedure.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNQualification_Click(object sender, EventArgs e)
        {
            btnVisualYQualification.BackColor = Color.FromName("@controlLight");
            btnVisualNQualification.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNControl_Click(object sender, EventArgs e)
        {
            btnVisualYControl.BackColor = Color.FromName("@controlLight");
            btnVisualNControl.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNSize_Click(object sender, EventArgs e)
        {
            btnVisualYSize.BackColor = Color.FromName("@controlLight");
            btnVisualNSize.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNLocation_Click(object sender, EventArgs e)
        {
            btnVisualYLocation.BackColor = Color.FromName("@controlLight");
            btnVisualNLocation.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNCracks_Click(object sender, EventArgs e)
        {
            btnVisualYCracks.BackColor = Color.FromName("@controlLight");
            btnVisualNCracks.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNPenetration_Click(object sender, EventArgs e)
        {
            btnVisualYPenetration.BackColor = Color.FromName("@controlLight");
            btnVisualNPenetration.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNFusion_Click(object sender, EventArgs e)
        {
            btnVisualYFusion.BackColor = Color.FromName("@controlLight");
            btnVisualNFusion.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNPorosity_Click(object sender, EventArgs e)
        {
            btnVisualYPorosity.BackColor = Color.FromName("@controlLight");
            btnVisualNPorosity.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNSatisfactory_Click(object sender, EventArgs e)
        {
            btnVisualYSatisfactory.BackColor = Color.FromName("@controlLight");
            btnVisualNSatisfactory.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNCrater_Click(object sender, EventArgs e)
        {
            btnVisualYCrater.BackColor = Color.FromName("@controlLight");
            btnVisualNCrater.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNSuckBack_Click(object sender, EventArgs e)
        {
            btnVisualYSuckBack.BackColor = Color.FromName("@controlLight");
            btnVisualNSuckBack.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNReinforcement_Click(object sender, EventArgs e)
        {
            btnVisualYReinforcement.BackColor = Color.FromName("@controlLight");
            btnVisualNReinforcement.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNArc_Click(object sender, EventArgs e)
        {
            btnVisualYArc.BackColor = Color.FromName("@controlLight");
            btnVisualNArc.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNUndercut_Click(object sender, EventArgs e)
        {
            btnVisualYUndercut.BackColor = Color.FromName("@controlLight");
            btnVisualNUndercut.BackColor = Color.FromName("@invalid");
        }

        private void btnVisualNBurn_Click(object sender, EventArgs e)
        {
            btnVisualYBurn.BackColor = Color.FromName("@controlLight");
            btnVisualNBurn.BackColor = Color.FromName("@invalid");
        }

        #endregion

        #endregion
    }
}
