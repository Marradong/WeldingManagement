﻿namespace WeldingManagement.UserControls
{
    partial class MultiSelectComboBox
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboUserControl = new Wisej.Web.UserComboBox();
            this.clbUserControlData = new Wisej.Web.CheckedListBox();
            this.txtUserControlOutput = new Wisej.Web.TextBox();
            this.tlpUserControlContainer = new Wisej.Web.TableLayoutPanel();
            this.tlpUserControlContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // cboUserControl
            // 
            this.cboUserControl.AutoCompleteMode = Wisej.Web.AutoCompleteMode.Filter;
            this.cboUserControl.Dock = Wisej.Web.DockStyle.Fill;
            this.cboUserControl.DropDownControl = this.clbUserControlData;
            this.cboUserControl.Location = new System.Drawing.Point(0, 135);
            this.cboUserControl.Margin = new Wisej.Web.Padding(0, 3, 0, 0);
            this.cboUserControl.Name = "cboUserControl";
            this.cboUserControl.Size = new System.Drawing.Size(596, 130);
            this.cboUserControl.TabIndex = 2;
            this.cboUserControl.KeyPress += new Wisej.Web.KeyPressEventHandler(this.cboUserControl_KeyPress);
            // 
            // clbUserControlData
            // 
            this.clbUserControlData.Items.AddRange(new object[] {
            "test 1",
            "test 2"});
            this.clbUserControlData.Location = new System.Drawing.Point(3, 3);
            this.clbUserControlData.Name = "clbUserControlData";
            this.clbUserControlData.Size = new System.Drawing.Size(590, 259);
            this.clbUserControlData.TabIndex = 1;
            this.clbUserControlData.AfterItemCheck += new Wisej.Web.ItemCheckEventHandler(this.clbUserControlData_AfterItemCheck);
            // 
            // txtUserControlOutput
            // 
            this.txtUserControlOutput.Dock = Wisej.Web.DockStyle.Fill;
            this.txtUserControlOutput.Location = new System.Drawing.Point(0, 0);
            this.txtUserControlOutput.Margin = new Wisej.Web.Padding(0, 0, 0, 3);
            this.txtUserControlOutput.Multiline = true;
            this.txtUserControlOutput.Name = "txtUserControlOutput";
            this.txtUserControlOutput.ReadOnly = true;
            this.txtUserControlOutput.Size = new System.Drawing.Size(596, 129);
            this.txtUserControlOutput.TabIndex = 3;
            // 
            // tlpUserControlContainer
            // 
            this.tlpUserControlContainer.ColumnCount = 1;
            this.tlpUserControlContainer.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpUserControlContainer.Controls.Add(this.txtUserControlOutput, 0, 0);
            this.tlpUserControlContainer.Controls.Add(this.cboUserControl, 0, 1);
            this.tlpUserControlContainer.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpUserControlContainer.Location = new System.Drawing.Point(0, 0);
            this.tlpUserControlContainer.Margin = new Wisej.Web.Padding(0);
            this.tlpUserControlContainer.Name = "tlpUserControlContainer";
            this.tlpUserControlContainer.RowCount = 2;
            this.tlpUserControlContainer.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpUserControlContainer.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpUserControlContainer.Size = new System.Drawing.Size(596, 265);
            this.tlpUserControlContainer.TabIndex = 4;
            // 
            // MultiSelectComboBox
            // 
            this.Controls.Add(this.tlpUserControlContainer);
            this.Controls.Add(this.clbUserControlData);
            this.Name = "MultiSelectComboBox";
            this.Size = new System.Drawing.Size(596, 265);
            this.tlpUserControlContainer.ResumeLayout(false);
            this.tlpUserControlContainer.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Wisej.Web.CheckedListBox clbUserControlData;
        private Wisej.Web.UserComboBox cboUserControl;
        private Wisej.Web.TextBox txtUserControlOutput;
        private Wisej.Web.TableLayoutPanel tlpUserControlContainer;
    }
}
