﻿namespace WeldingManagement
{
    partial class fbWPQR
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle109 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle110 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle111 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle112 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle113 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle114 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle115 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle116 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle117 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle118 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle119 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle120 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle121 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle122 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle123 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle124 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle125 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle126 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle127 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle128 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle129 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle130 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle131 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle132 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle133 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle134 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle135 = new Wisej.Web.DataGridViewCellStyle();
            this.Boards = new Wisej.Web.TabControl();
            this.tabWPQRInfo = new Wisej.Web.TabPage();
            this.tableLayoutPanel25 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel26 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel27 = new Wisej.Web.TableLayoutPanel();
            this.label86 = new Wisej.Web.Label();
            this.label87 = new Wisej.Web.Label();
            this.label88 = new Wisej.Web.Label();
            this.label89 = new Wisej.Web.Label();
            this.label90 = new Wisej.Web.Label();
            this.label99 = new Wisej.Web.Label();
            this.label100 = new Wisej.Web.Label();
            this.label101 = new Wisej.Web.Label();
            this.label102 = new Wisej.Web.Label();
            this.label98 = new Wisej.Web.Label();
            this.label82 = new Wisej.Web.Label();
            this.label81 = new Wisej.Web.Label();
            this.label94 = new Wisej.Web.Label();
            this.label93 = new Wisej.Web.Label();
            this.label79 = new Wisej.Web.Label();
            this.txtInfoWPQR = new Wisej.Web.TextBox();
            this.txtInfoStandard = new Wisej.Web.TextBox();
            this.txtInfoType = new Wisej.Web.TextBox();
            this.txtInfoJoint = new Wisej.Web.TextBox();
            this.txtInfoMaxThickness = new Wisej.Web.TextBox();
            this.txtInfoOther = new Wisej.Web.TextBox();
            this.txtInfoDia = new Wisej.Web.TextBox();
            this.txtInfoPrepared = new Wisej.Web.TextBox();
            this.txtInfoDate = new Wisej.Web.TextBox();
            this.txtInfoWPS = new Wisej.Web.TextBox();
            this.txtInfoThickness = new Wisej.Web.TextBox();
            this.txtInfoMatStandard = new Wisej.Web.TextBox();
            this.txtInfoPNo = new Wisej.Web.TextBox();
            this.txtInfoMatGrade = new Wisej.Web.TextBox();
            this.tableLayoutPanel28 = new Wisej.Web.TableLayoutPanel();
            this.btnInfoBack = new Wisej.Web.Button();
            this.btnInfoHome = new Wisej.Web.Button();
            this.btnInfoNext = new Wisej.Web.Button();
            this.tableLayoutPanel29 = new Wisej.Web.TableLayoutPanel();
            this.label103 = new Wisej.Web.Label();
            this.label104 = new Wisej.Web.Label();
            this.tabWPQRRun = new Wisej.Web.TabPage();
            this.tableLayoutPanel33 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel34 = new Wisej.Web.TableLayoutPanel();
            this.dgvWPQRRun = new Wisej.Web.DataGridView();
            this.dgvcSide = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcPass = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcProcess = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcPosition = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcSize = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcSpecification = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcClassification = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcPolarity = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcFluxGas = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcInput = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcAmps = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcVolts = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcSpeed = new Wisej.Web.DataGridViewTextBoxColumn();
            this.tableLayoutPanel35 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel36 = new Wisej.Web.TableLayoutPanel();
            this.btnRunBack = new Wisej.Web.Button();
            this.btnRunHome = new Wisej.Web.Button();
            this.btnRunNext = new Wisej.Web.Button();
            this.tableLayoutPanel38 = new Wisej.Web.TableLayoutPanel();
            this.label110 = new Wisej.Web.Label();
            this.label111 = new Wisej.Web.Label();
            this.tabWPQRDetails = new Wisej.Web.TabPage();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.txtDetailsCooling = new Wisej.Web.TextBox();
            this.label8 = new Wisej.Web.Label();
            this.label9 = new Wisej.Web.Label();
            this.label5 = new Wisej.Web.Label();
            this.label4 = new Wisej.Web.Label();
            this.label7 = new Wisej.Web.Label();
            this.label1 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.label11 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.label10 = new Wisej.Web.Label();
            this.label13 = new Wisej.Web.Label();
            this.label24 = new Wisej.Web.Label();
            this.label21 = new Wisej.Web.Label();
            this.label18 = new Wisej.Web.Label();
            this.label22 = new Wisej.Web.Label();
            this.label19 = new Wisej.Web.Label();
            this.label12 = new Wisej.Web.Label();
            this.label20 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.label23 = new Wisej.Web.Label();
            this.label14 = new Wisej.Web.Label();
            this.label15 = new Wisej.Web.Label();
            this.label25 = new Wisej.Web.Label();
            this.label26 = new Wisej.Web.Label();
            this.label27 = new Wisej.Web.Label();
            this.label28 = new Wisej.Web.Label();
            this.txtDetailsSpecification = new Wisej.Web.TextBox();
            this.txtDetailsANo = new Wisej.Web.TextBox();
            this.txtDetailsForm = new Wisej.Web.TextBox();
            this.txtDetailsWMThickness = new Wisej.Web.TextBox();
            this.txtDetailsClassification = new Wisej.Web.TextBox();
            this.txtDetailsFluxClassification = new Wisej.Web.TextBox();
            this.txtDetailsType = new Wisej.Web.TextBox();
            this.txtDetailsFillerOther = new Wisej.Web.TextBox();
            this.txtDetailsFNo = new Wisej.Web.TextBox();
            this.txtDetailsSize = new Wisej.Web.TextBox();
            this.txtDetailsName = new Wisej.Web.TextBox();
            this.txtDetailsPosition = new Wisej.Web.TextBox();
            this.txtDetailsPreheat = new Wisej.Web.TextBox();
            this.txtDetailsPWHT = new Wisej.Web.TextBox();
            this.txtDetailsProgression = new Wisej.Web.TextBox();
            this.txtDetailsPositionOther = new Wisej.Web.TextBox();
            this.txtDetailsInterpass = new Wisej.Web.TextBox();
            this.txtDetailsPreheatOther = new Wisej.Web.TextBox();
            this.txtDetailsTime = new Wisej.Web.TextBox();
            this.txtDetailsHeating = new Wisej.Web.TextBox();
            this.txtDetailsPWHTOther = new Wisej.Web.TextBox();
            this.tableLayoutPanel4 = new Wisej.Web.TableLayoutPanel();
            this.btnDetailsBack = new Wisej.Web.Button();
            this.btnDetailsHome = new Wisej.Web.Button();
            this.btnDetailsNext = new Wisej.Web.Button();
            this.tableLayoutPanel5 = new Wisej.Web.TableLayoutPanel();
            this.label16 = new Wisej.Web.Label();
            this.label17 = new Wisej.Web.Label();
            this.tabWPQRDetailsContinued = new Wisej.Web.TabPage();
            this.tableLayoutPanel6 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel7 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel8 = new Wisej.Web.TableLayoutPanel();
            this.label50 = new Wisej.Web.Label();
            this.txtContTechniqueOther = new Wisej.Web.TextBox();
            this.txtContElectrodes = new Wisej.Web.TextBox();
            this.txtContPass = new Wisej.Web.TextBox();
            this.txtContOscillation = new Wisej.Web.TextBox();
            this.Speed = new Wisej.Web.TextBox();
            this.txtContBead = new Wisej.Web.TextBox();
            this.txtContElectricalOther = new Wisej.Web.TextBox();
            this.txtContInput = new Wisej.Web.TextBox();
            this.txtContAmps = new Wisej.Web.TextBox();
            this.txtContPolarity = new Wisej.Web.TextBox();
            this.label42 = new Wisej.Web.Label();
            this.label29 = new Wisej.Web.Label();
            this.label30 = new Wisej.Web.Label();
            this.label31 = new Wisej.Web.Label();
            this.label32 = new Wisej.Web.Label();
            this.label33 = new Wisej.Web.Label();
            this.label34 = new Wisej.Web.Label();
            this.label39 = new Wisej.Web.Label();
            this.label40 = new Wisej.Web.Label();
            this.label51 = new Wisej.Web.Label();
            this.txtContShieldComp = new Wisej.Web.TextBox();
            this.txtContShieldFlow = new Wisej.Web.TextBox();
            this.txtContTrailComp = new Wisej.Web.TextBox();
            this.txtContTrailFlow = new Wisej.Web.TextBox();
            this.txtContGasOther = new Wisej.Web.TextBox();
            this.txtContBackComp = new Wisej.Web.TextBox();
            this.txtContBackFlow = new Wisej.Web.TextBox();
            this.txtContVolts = new Wisej.Web.TextBox();
            this.txtContTungsten = new Wisej.Web.TextBox();
            this.txtContTransfer = new Wisej.Web.TextBox();
            this.label52 = new Wisej.Web.Label();
            this.label53 = new Wisej.Web.Label();
            this.label54 = new Wisej.Web.Label();
            this.label35 = new Wisej.Web.Label();
            this.label36 = new Wisej.Web.Label();
            this.label37 = new Wisej.Web.Label();
            this.label38 = new Wisej.Web.Label();
            this.label41 = new Wisej.Web.Label();
            this.label43 = new Wisej.Web.Label();
            this.label44 = new Wisej.Web.Label();
            this.label45 = new Wisej.Web.Label();
            this.label46 = new Wisej.Web.Label();
            this.label47 = new Wisej.Web.Label();
            this.label48 = new Wisej.Web.Label();
            this.label49 = new Wisej.Web.Label();
            this.cbContDT = new Wisej.Web.CheckBox();
            this.cbContMacro = new Wisej.Web.CheckBox();
            this.cbContVisual = new Wisej.Web.CheckBox();
            this.cbContNDT = new Wisej.Web.CheckBox();
            this.cbContHardness = new Wisej.Web.CheckBox();
            this.cbContDPI = new Wisej.Web.CheckBox();
            this.cbContBend = new Wisej.Web.CheckBox();
            this.cbContMPI = new Wisej.Web.CheckBox();
            this.cbContTensil = new Wisej.Web.CheckBox();
            this.cbContRT = new Wisej.Web.CheckBox();
            this.cbContImpact = new Wisej.Web.CheckBox();
            this.cbContUT = new Wisej.Web.CheckBox();
            this.txtContCurrent = new Wisej.Web.TextBox();
            this.txtContNotes = new Wisej.Web.TextBox();
            this.tableLayoutPanel9 = new Wisej.Web.TableLayoutPanel();
            this.btnContBack = new Wisej.Web.Button();
            this.btnContHome = new Wisej.Web.Button();
            this.btnContNext = new Wisej.Web.Button();
            this.tableLayoutPanel13 = new Wisej.Web.TableLayoutPanel();
            this.label55 = new Wisej.Web.Label();
            this.label56 = new Wisej.Web.Label();
            this.tabUpload = new Wisej.Web.TabPage();
            this.tableLayoutPanel14 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel22 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel10 = new Wisej.Web.TableLayoutPanel();
            this.pbUploadSequence = new Wisej.Web.PictureBox();
            this.pbUploadPreparation = new Wisej.Web.PictureBox();
            this.uplUploadSequence = new Wisej.Web.Upload();
            this.uplUploadPreparation = new Wisej.Web.Upload();
            this.tableLayoutPanel11 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel12 = new Wisej.Web.TableLayoutPanel();
            this.btnUploadBack = new Wisej.Web.Button();
            this.btnUploadHome = new Wisej.Web.Button();
            this.btnUploadComplete = new Wisej.Web.Button();
            this.tableLayoutPanel15 = new Wisej.Web.TableLayoutPanel();
            this.label76 = new Wisej.Web.Label();
            this.label57 = new Wisej.Web.Label();
            this.Boards.SuspendLayout();
            this.tabWPQRInfo.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.tabWPQRRun.SuspendLayout();
            this.tableLayoutPanel33.SuspendLayout();
            this.tableLayoutPanel34.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWPQRRun)).BeginInit();
            this.tableLayoutPanel35.SuspendLayout();
            this.tableLayoutPanel36.SuspendLayout();
            this.tableLayoutPanel38.SuspendLayout();
            this.tabWPQRDetails.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tabWPQRDetailsContinued.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tabUpload.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbUploadSequence)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUploadPreparation)).BeginInit();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.SuspendLayout();
            // 
            // Boards
            // 
            this.Boards.Alignment = Wisej.Web.TabAlignment.Top;
            this.Boards.BorderStyle = Wisej.Web.BorderStyle.None;
            this.Boards.Controls.Add(this.tabWPQRInfo);
            this.Boards.Controls.Add(this.tabWPQRRun);
            this.Boards.Controls.Add(this.tabWPQRDetails);
            this.Boards.Controls.Add(this.tabWPQRDetailsContinued);
            this.Boards.Controls.Add(this.tabUpload);
            this.Boards.Display = Wisej.Web.Display.Label;
            this.Boards.Dock = Wisej.Web.DockStyle.Fill;
            this.Boards.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Boards.Location = new System.Drawing.Point(0, 0);
            this.Boards.Name = "Boards";
            this.Boards.Orientation = Wisej.Web.Orientation.Horizontal;
            this.Boards.PageInsets = new Wisej.Web.Padding(0, 35, 0, 0);
            this.Boards.SelectedIndex = 0;
            this.Boards.Size = new System.Drawing.Size(1212, 650);
            this.Boards.TabIndex = 3;
            this.Boards.TabStop = false;
            this.Boards.Selecting += new Wisej.Web.TabControlCancelEventHandler(this.Boards_Selecting);
            // 
            // tabWPQRInfo
            // 
            this.tabWPQRInfo.Controls.Add(this.tableLayoutPanel25);
            this.tabWPQRInfo.Location = new System.Drawing.Point(0, 35);
            this.tabWPQRInfo.Name = "tabWPQRInfo";
            this.tabWPQRInfo.Size = new System.Drawing.Size(1212, 615);
            this.tabWPQRInfo.Text = "Info";
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 3;
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.Controls.Add(this.tableLayoutPanel26, 1, 3);
            this.tableLayoutPanel25.Controls.Add(this.tableLayoutPanel29, 1, 1);
            this.tableLayoutPanel25.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 5;
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel25.TabIndex = 3;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 2;
            this.tableLayoutPanel26.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel26.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel26.Controls.Add(this.tableLayoutPanel27, 0, 0);
            this.tableLayoutPanel26.Controls.Add(this.tableLayoutPanel28, 1, 0);
            this.tableLayoutPanel26.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel26.TabIndex = 1;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.ColumnCount = 4;
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel27.Controls.Add(this.label86, 2, 4);
            this.tableLayoutPanel27.Controls.Add(this.label87, 2, 3);
            this.tableLayoutPanel27.Controls.Add(this.label88, 2, 2);
            this.tableLayoutPanel27.Controls.Add(this.label89, 2, 1);
            this.tableLayoutPanel27.Controls.Add(this.label90, 2, 0);
            this.tableLayoutPanel27.Controls.Add(this.label99, 0, 3);
            this.tableLayoutPanel27.Controls.Add(this.label100, 0, 2);
            this.tableLayoutPanel27.Controls.Add(this.label101, 0, 1);
            this.tableLayoutPanel27.Controls.Add(this.label102, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.label98, 0, 5);
            this.tableLayoutPanel27.Controls.Add(this.label82, 0, 4);
            this.tableLayoutPanel27.Controls.Add(this.label81, 0, 6);
            this.tableLayoutPanel27.Controls.Add(this.label94, 0, 7);
            this.tableLayoutPanel27.Controls.Add(this.label93, 2, 7);
            this.tableLayoutPanel27.Controls.Add(this.label79, 0, 8);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoWPQR, 1, 0);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoStandard, 1, 1);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoType, 1, 2);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoJoint, 1, 3);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoMaxThickness, 1, 4);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoOther, 1, 5);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoDia, 3, 4);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoPrepared, 3, 0);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoDate, 3, 1);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoWPS, 3, 2);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoThickness, 3, 3);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoMatStandard, 1, 7);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoPNo, 1, 8);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoMatGrade, 3, 7);
            this.tableLayoutPanel27.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 9;
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel27.TabIndex = 4;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Dock = Wisej.Web.DockStyle.Fill;
            this.label86.Location = new System.Drawing.Point(515, 195);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(250, 42);
            this.label86.TabIndex = 16;
            this.label86.Text = "Diameter (mm)";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Dock = Wisej.Web.DockStyle.Fill;
            this.label87.Location = new System.Drawing.Point(515, 147);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(250, 42);
            this.label87.TabIndex = 15;
            this.label87.Text = "Thickness (mm)";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Dock = Wisej.Web.DockStyle.Fill;
            this.label88.Location = new System.Drawing.Point(515, 99);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(250, 42);
            this.label88.TabIndex = 14;
            this.label88.Text = "WPS Number";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Dock = Wisej.Web.DockStyle.Fill;
            this.label89.Location = new System.Drawing.Point(515, 51);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(250, 42);
            this.label89.TabIndex = 13;
            this.label89.Text = "Date";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Dock = Wisej.Web.DockStyle.Fill;
            this.label90.Location = new System.Drawing.Point(515, 3);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(250, 42);
            this.label90.TabIndex = 12;
            this.label90.Text = "Prepared By Emp ID";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Dock = Wisej.Web.DockStyle.Fill;
            this.label99.Location = new System.Drawing.Point(3, 147);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(250, 42);
            this.label99.TabIndex = 3;
            this.label99.Text = "Joint Type";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Dock = Wisej.Web.DockStyle.Fill;
            this.label100.Location = new System.Drawing.Point(3, 99);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(250, 42);
            this.label100.TabIndex = 2;
            this.label100.Text = "Welding Type";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Dock = Wisej.Web.DockStyle.Fill;
            this.label101.Location = new System.Drawing.Point(3, 51);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(250, 42);
            this.label101.TabIndex = 1;
            this.label101.Text = "Welding Code / Standard";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Dock = Wisej.Web.DockStyle.Fill;
            this.label102.Location = new System.Drawing.Point(3, 3);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(250, 42);
            this.label102.TabIndex = 0;
            this.label102.Text = "WPQR Number";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Dock = Wisej.Web.DockStyle.Fill;
            this.label98.Location = new System.Drawing.Point(3, 243);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(250, 42);
            this.label98.TabIndex = 4;
            this.label98.Text = "Other";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Dock = Wisej.Web.DockStyle.Fill;
            this.label82.Location = new System.Drawing.Point(3, 195);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(250, 42);
            this.label82.TabIndex = 20;
            this.label82.Text = "Maximum Pass Thickness (mm)";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label81.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel27.SetColumnSpan(this.label81, 4);
            this.label81.Dock = Wisej.Web.DockStyle.Fill;
            this.label81.Location = new System.Drawing.Point(3, 291);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(1018, 42);
            this.label81.TabIndex = 21;
            this.label81.Text = "Base Metals";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Dock = Wisej.Web.DockStyle.Fill;
            this.label94.Location = new System.Drawing.Point(3, 339);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(250, 42);
            this.label94.TabIndex = 8;
            this.label94.Text = "Material Standard";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Dock = Wisej.Web.DockStyle.Fill;
            this.label93.Location = new System.Drawing.Point(515, 339);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(250, 42);
            this.label93.TabIndex = 9;
            this.label93.Text = "Material Grade";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Dock = Wisej.Web.DockStyle.Fill;
            this.label79.Location = new System.Drawing.Point(3, 387);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(250, 43);
            this.label79.TabIndex = 22;
            this.label79.Text = "P / Group Number";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtInfoWPQR
            // 
            this.txtInfoWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoWPQR.Location = new System.Drawing.Point(259, 3);
            this.txtInfoWPQR.Name = "txtInfoWPQR";
            this.txtInfoWPQR.Size = new System.Drawing.Size(250, 42);
            this.txtInfoWPQR.TabIndex = 25;
            // 
            // txtInfoStandard
            // 
            this.txtInfoStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoStandard.Location = new System.Drawing.Point(259, 51);
            this.txtInfoStandard.Name = "txtInfoStandard";
            this.txtInfoStandard.Size = new System.Drawing.Size(250, 42);
            this.txtInfoStandard.TabIndex = 26;
            // 
            // txtInfoType
            // 
            this.txtInfoType.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoType.Location = new System.Drawing.Point(259, 99);
            this.txtInfoType.Name = "txtInfoType";
            this.txtInfoType.Size = new System.Drawing.Size(250, 42);
            this.txtInfoType.TabIndex = 27;
            // 
            // txtInfoJoint
            // 
            this.txtInfoJoint.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoJoint.Location = new System.Drawing.Point(259, 147);
            this.txtInfoJoint.Name = "txtInfoJoint";
            this.txtInfoJoint.Size = new System.Drawing.Size(250, 42);
            this.txtInfoJoint.TabIndex = 28;
            // 
            // txtInfoMaxThickness
            // 
            this.txtInfoMaxThickness.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMaxThickness.Location = new System.Drawing.Point(259, 195);
            this.txtInfoMaxThickness.Name = "txtInfoMaxThickness";
            this.txtInfoMaxThickness.Size = new System.Drawing.Size(250, 42);
            this.txtInfoMaxThickness.TabIndex = 31;
            // 
            // txtInfoOther
            // 
            this.tableLayoutPanel27.SetColumnSpan(this.txtInfoOther, 3);
            this.txtInfoOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoOther.Location = new System.Drawing.Point(259, 243);
            this.txtInfoOther.Name = "txtInfoOther";
            this.txtInfoOther.Size = new System.Drawing.Size(762, 42);
            this.txtInfoOther.TabIndex = 29;
            // 
            // txtInfoDia
            // 
            this.txtInfoDia.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoDia.Location = new System.Drawing.Point(771, 195);
            this.txtInfoDia.Name = "txtInfoDia";
            this.txtInfoDia.Size = new System.Drawing.Size(250, 42);
            this.txtInfoDia.TabIndex = 30;
            // 
            // txtInfoPrepared
            // 
            this.txtInfoPrepared.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPrepared.Location = new System.Drawing.Point(771, 3);
            this.txtInfoPrepared.Name = "txtInfoPrepared";
            this.txtInfoPrepared.Size = new System.Drawing.Size(250, 42);
            this.txtInfoPrepared.TabIndex = 32;
            // 
            // txtInfoDate
            // 
            this.txtInfoDate.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoDate.Location = new System.Drawing.Point(771, 51);
            this.txtInfoDate.Name = "txtInfoDate";
            this.txtInfoDate.Size = new System.Drawing.Size(250, 42);
            this.txtInfoDate.TabIndex = 33;
            // 
            // txtInfoWPS
            // 
            this.txtInfoWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoWPS.Location = new System.Drawing.Point(771, 99);
            this.txtInfoWPS.Name = "txtInfoWPS";
            this.txtInfoWPS.Size = new System.Drawing.Size(250, 42);
            this.txtInfoWPS.TabIndex = 34;
            // 
            // txtInfoThickness
            // 
            this.txtInfoThickness.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoThickness.Location = new System.Drawing.Point(771, 147);
            this.txtInfoThickness.Name = "txtInfoThickness";
            this.txtInfoThickness.Size = new System.Drawing.Size(250, 42);
            this.txtInfoThickness.TabIndex = 35;
            // 
            // txtInfoMatStandard
            // 
            this.txtInfoMatStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatStandard.Location = new System.Drawing.Point(259, 339);
            this.txtInfoMatStandard.Name = "txtInfoMatStandard";
            this.txtInfoMatStandard.Size = new System.Drawing.Size(250, 42);
            this.txtInfoMatStandard.TabIndex = 36;
            // 
            // txtInfoPNo
            // 
            this.tableLayoutPanel27.SetColumnSpan(this.txtInfoPNo, 3);
            this.txtInfoPNo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPNo.Location = new System.Drawing.Point(259, 387);
            this.txtInfoPNo.Name = "txtInfoPNo";
            this.txtInfoPNo.Size = new System.Drawing.Size(762, 43);
            this.txtInfoPNo.TabIndex = 37;
            // 
            // txtInfoMatGrade
            // 
            this.txtInfoMatGrade.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatGrade.Location = new System.Drawing.Point(771, 339);
            this.txtInfoMatGrade.Name = "txtInfoMatGrade";
            this.txtInfoMatGrade.Size = new System.Drawing.Size(250, 42);
            this.txtInfoMatGrade.TabIndex = 38;
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel28.ColumnCount = 1;
            this.tableLayoutPanel28.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel28.Controls.Add(this.btnInfoBack, 0, 2);
            this.tableLayoutPanel28.Controls.Add(this.btnInfoHome, 0, 3);
            this.tableLayoutPanel28.Controls.Add(this.btnInfoNext, 0, 4);
            this.tableLayoutPanel28.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 5;
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel28.TabIndex = 3;
            // 
            // btnInfoBack
            // 
            this.btnInfoBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoBack.Location = new System.Drawing.Point(3, 175);
            this.btnInfoBack.Name = "btnInfoBack";
            this.btnInfoBack.Size = new System.Drawing.Size(101, 80);
            this.btnInfoBack.TabIndex = 3;
            this.btnInfoBack.Text = "Back";
            this.btnInfoBack.Click += new System.EventHandler(this.btnInfoBack_Click);
            // 
            // btnInfoHome
            // 
            this.btnInfoHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoHome.Location = new System.Drawing.Point(3, 261);
            this.btnInfoHome.Name = "btnInfoHome";
            this.btnInfoHome.Size = new System.Drawing.Size(101, 80);
            this.btnInfoHome.TabIndex = 1;
            this.btnInfoHome.Text = "Home";
            this.btnInfoHome.Click += new System.EventHandler(this.btnInfoHome_Click);
            // 
            // btnInfoNext
            // 
            this.btnInfoNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoNext.Location = new System.Drawing.Point(3, 347);
            this.btnInfoNext.Name = "btnInfoNext";
            this.btnInfoNext.Size = new System.Drawing.Size(101, 81);
            this.btnInfoNext.TabIndex = 0;
            this.btnInfoNext.Text = "Next";
            this.btnInfoNext.Click += new System.EventHandler(this.btnInfoNext_Click);
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.ColumnCount = 1;
            this.tableLayoutPanel29.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel29.Controls.Add(this.label103, 0, 1);
            this.tableLayoutPanel29.Controls.Add(this.label104, 0, 0);
            this.tableLayoutPanel29.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel29.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 2;
            this.tableLayoutPanel29.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel29.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel29.TabIndex = 0;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label103.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label103.Dock = Wisej.Web.DockStyle.Fill;
            this.label103.Location = new System.Drawing.Point(3, 79);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(1139, 35);
            this.label103.TabIndex = 1;
            this.label103.Text = "Notes";
            this.label103.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label104.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label104.Dock = Wisej.Web.DockStyle.Fill;
            this.label104.Location = new System.Drawing.Point(3, 3);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(1139, 70);
            this.label104.TabIndex = 0;
            this.label104.Text = "WPQR Information";
            this.label104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabWPQRRun
            // 
            this.tabWPQRRun.Controls.Add(this.tableLayoutPanel33);
            this.tabWPQRRun.Location = new System.Drawing.Point(0, 35);
            this.tabWPQRRun.Name = "tabWPQRRun";
            this.tabWPQRRun.Size = new System.Drawing.Size(1212, 615);
            this.tabWPQRRun.Text = "Run";
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.ColumnCount = 3;
            this.tableLayoutPanel33.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel33.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel34, 1, 3);
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel38, 1, 1);
            this.tableLayoutPanel33.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel33.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 5;
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel33.TabIndex = 4;
            // 
            // tableLayoutPanel34
            // 
            this.tableLayoutPanel34.ColumnCount = 2;
            this.tableLayoutPanel34.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel34.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel34.Controls.Add(this.dgvWPQRRun, 0, 0);
            this.tableLayoutPanel34.Controls.Add(this.tableLayoutPanel35, 1, 0);
            this.tableLayoutPanel34.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel34.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel34.Name = "tableLayoutPanel34";
            this.tableLayoutPanel34.RowCount = 1;
            this.tableLayoutPanel34.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel34.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel34.TabIndex = 1;
            // 
            // dgvWPQRRun
            // 
            this.dgvWPQRRun.AutoGenerateColumns = false;
            this.dgvWPQRRun.AutoSizeColumnsMode = Wisej.Web.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgvWPQRRun.AutoSizeRowsMode = Wisej.Web.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle109.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle109.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvWPQRRun.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle109;
            this.dgvWPQRRun.ColumnHeadersHeight = 64;
            this.dgvWPQRRun.Columns.AddRange(new Wisej.Web.DataGridViewColumn[] {
            this.dgvcSide,
            this.dgvcPass,
            this.dgvcProcess,
            this.dgvcPosition,
            this.dgvcSize,
            this.dgvcSpecification,
            this.dgvcClassification,
            this.dgvcPolarity,
            this.dgvcFluxGas,
            this.dgvcInput,
            this.dgvcAmps,
            this.dgvcVolts,
            this.dgvcSpeed});
            this.dgvWPQRRun.Dock = Wisej.Web.DockStyle.Fill;
            this.dgvWPQRRun.Location = new System.Drawing.Point(0, 3);
            this.dgvWPQRRun.Margin = new Wisej.Web.Padding(0, 3, 0, 3);
            this.dgvWPQRRun.MultiSelect = false;
            this.dgvWPQRRun.Name = "dgvWPQRRun";
            this.dgvWPQRRun.Size = new System.Drawing.Size(1030, 433);
            this.dgvWPQRRun.TabIndex = 29;
            // 
            // dgvcSide
            // 
            dataGridViewCellStyle110.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle110.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcSide.DefaultCellStyle = dataGridViewCellStyle110;
            dataGridViewCellStyle111.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcSide.HeaderStyle = dataGridViewCellStyle111;
            this.dgvcSide.HeaderText = "Side";
            this.dgvcSide.Name = "dgvcSide";
            this.dgvcSide.ReadOnly = true;
            // 
            // dgvcPass
            // 
            dataGridViewCellStyle112.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle112.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcPass.DefaultCellStyle = dataGridViewCellStyle112;
            dataGridViewCellStyle113.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcPass.HeaderStyle = dataGridViewCellStyle113;
            this.dgvcPass.HeaderText = "Pass";
            this.dgvcPass.Name = "dgvcPass";
            this.dgvcPass.ReadOnly = true;
            // 
            // dgvcProcess
            // 
            dataGridViewCellStyle114.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle114.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcProcess.DefaultCellStyle = dataGridViewCellStyle114;
            dataGridViewCellStyle115.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcProcess.HeaderStyle = dataGridViewCellStyle115;
            this.dgvcProcess.HeaderText = "Process";
            this.dgvcProcess.Name = "dgvcProcess";
            // 
            // dgvcPosition
            // 
            dataGridViewCellStyle116.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle116.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcPosition.DefaultCellStyle = dataGridViewCellStyle116;
            dataGridViewCellStyle117.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcPosition.HeaderStyle = dataGridViewCellStyle117;
            this.dgvcPosition.HeaderText = "Position";
            this.dgvcPosition.Name = "dgvcPosition";
            // 
            // dgvcSize
            // 
            dataGridViewCellStyle118.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle118.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcSize.DefaultCellStyle = dataGridViewCellStyle118;
            dataGridViewCellStyle119.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcSize.HeaderStyle = dataGridViewCellStyle119;
            this.dgvcSize.HeaderText = "Size";
            this.dgvcSize.Name = "dgvcSize";
            this.dgvcSize.ReadOnly = true;
            // 
            // dgvcSpecification
            // 
            dataGridViewCellStyle120.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle120.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcSpecification.DefaultCellStyle = dataGridViewCellStyle120;
            dataGridViewCellStyle121.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcSpecification.HeaderStyle = dataGridViewCellStyle121;
            this.dgvcSpecification.HeaderText = "Specification";
            this.dgvcSpecification.Name = "dgvcSpecification";
            // 
            // dgvcClassification
            // 
            dataGridViewCellStyle122.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle122.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcClassification.DefaultCellStyle = dataGridViewCellStyle122;
            dataGridViewCellStyle123.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcClassification.HeaderStyle = dataGridViewCellStyle123;
            this.dgvcClassification.HeaderText = "Classification";
            this.dgvcClassification.Name = "dgvcClassification";
            // 
            // dgvcPolarity
            // 
            dataGridViewCellStyle124.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle124.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcPolarity.DefaultCellStyle = dataGridViewCellStyle124;
            dataGridViewCellStyle125.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcPolarity.HeaderStyle = dataGridViewCellStyle125;
            this.dgvcPolarity.HeaderText = "Polarity";
            this.dgvcPolarity.Name = "dgvcPolarity";
            this.dgvcPolarity.ReadOnly = true;
            // 
            // dgvcFluxGas
            // 
            dataGridViewCellStyle126.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle126.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcFluxGas.DefaultCellStyle = dataGridViewCellStyle126;
            dataGridViewCellStyle127.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcFluxGas.HeaderStyle = dataGridViewCellStyle127;
            this.dgvcFluxGas.HeaderText = "Flux or Gas";
            this.dgvcFluxGas.Name = "dgvcFluxGas";
            // 
            // dgvcInput
            // 
            dataGridViewCellStyle128.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle128.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcInput.DefaultCellStyle = dataGridViewCellStyle128;
            dataGridViewCellStyle129.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcInput.HeaderStyle = dataGridViewCellStyle129;
            this.dgvcInput.HeaderText = "Heat Input";
            this.dgvcInput.Name = "dgvcInput";
            // 
            // dgvcAmps
            // 
            dataGridViewCellStyle130.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle130.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcAmps.DefaultCellStyle = dataGridViewCellStyle130;
            dataGridViewCellStyle131.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcAmps.HeaderStyle = dataGridViewCellStyle131;
            this.dgvcAmps.HeaderText = "Amps";
            this.dgvcAmps.Name = "dgvcAmps";
            this.dgvcAmps.ReadOnly = true;
            // 
            // dgvcVolts
            // 
            dataGridViewCellStyle132.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle132.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcVolts.DefaultCellStyle = dataGridViewCellStyle132;
            dataGridViewCellStyle133.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcVolts.HeaderStyle = dataGridViewCellStyle133;
            this.dgvcVolts.HeaderText = "Volts";
            this.dgvcVolts.Name = "dgvcVolts";
            // 
            // dgvcSpeed
            // 
            dataGridViewCellStyle134.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle134.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcSpeed.DefaultCellStyle = dataGridViewCellStyle134;
            dataGridViewCellStyle135.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcSpeed.HeaderStyle = dataGridViewCellStyle135;
            this.dgvcSpeed.HeaderText = "Weld Speed";
            this.dgvcSpeed.Name = "dgvcSpeed";
            // 
            // tableLayoutPanel35
            // 
            this.tableLayoutPanel35.ColumnCount = 1;
            this.tableLayoutPanel35.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel36, 0, 0);
            this.tableLayoutPanel35.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel35.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel35.Name = "tableLayoutPanel35";
            this.tableLayoutPanel35.RowCount = 1;
            this.tableLayoutPanel35.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel35.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel35.TabIndex = 5;
            // 
            // tableLayoutPanel36
            // 
            this.tableLayoutPanel36.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel36.ColumnCount = 1;
            this.tableLayoutPanel36.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel36.Controls.Add(this.btnRunBack, 0, 2);
            this.tableLayoutPanel36.Controls.Add(this.btnRunHome, 0, 3);
            this.tableLayoutPanel36.Controls.Add(this.btnRunNext, 0, 4);
            this.tableLayoutPanel36.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel36.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel36.Name = "tableLayoutPanel36";
            this.tableLayoutPanel36.RowCount = 5;
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel36.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel36.TabIndex = 4;
            // 
            // btnRunBack
            // 
            this.btnRunBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunBack.Location = new System.Drawing.Point(3, 173);
            this.btnRunBack.Name = "btnRunBack";
            this.btnRunBack.Size = new System.Drawing.Size(95, 79);
            this.btnRunBack.TabIndex = 3;
            this.btnRunBack.Text = "Back";
            this.btnRunBack.Click += new System.EventHandler(this.btnRunBack_Click);
            // 
            // btnRunHome
            // 
            this.btnRunHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunHome.Location = new System.Drawing.Point(3, 258);
            this.btnRunHome.Name = "btnRunHome";
            this.btnRunHome.Size = new System.Drawing.Size(95, 79);
            this.btnRunHome.TabIndex = 1;
            this.btnRunHome.Text = "Home";
            this.btnRunHome.Click += new System.EventHandler(this.btnRunHome_Click);
            // 
            // btnRunNext
            // 
            this.btnRunNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunNext.Location = new System.Drawing.Point(3, 343);
            this.btnRunNext.Name = "btnRunNext";
            this.btnRunNext.Size = new System.Drawing.Size(95, 79);
            this.btnRunNext.TabIndex = 0;
            this.btnRunNext.Text = "Next";
            this.btnRunNext.Click += new System.EventHandler(this.btnRunNext_Click);
            // 
            // tableLayoutPanel38
            // 
            this.tableLayoutPanel38.ColumnCount = 1;
            this.tableLayoutPanel38.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel38.Controls.Add(this.label110, 0, 1);
            this.tableLayoutPanel38.Controls.Add(this.label111, 0, 0);
            this.tableLayoutPanel38.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel38.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel38.Name = "tableLayoutPanel38";
            this.tableLayoutPanel38.RowCount = 2;
            this.tableLayoutPanel38.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel38.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel38.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel38.TabIndex = 0;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label110.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label110.Dock = Wisej.Web.DockStyle.Fill;
            this.label110.Location = new System.Drawing.Point(3, 79);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(1139, 35);
            this.label110.TabIndex = 1;
            this.label110.Text = "Notes";
            this.label110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label111.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label111.Dock = Wisej.Web.DockStyle.Fill;
            this.label111.Location = new System.Drawing.Point(3, 3);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(1139, 70);
            this.label111.TabIndex = 0;
            this.label111.Text = "WPQR Parameters";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabWPQRDetails
            // 
            this.tabWPQRDetails.Controls.Add(this.tableLayoutPanel1);
            this.tabWPQRDetails.Location = new System.Drawing.Point(0, 35);
            this.tabWPQRDetails.Name = "tabWPQRDetails";
            this.tabWPQRDetails.Size = new System.Drawing.Size(1212, 615);
            this.tabWPQRDetails.Text = "Details";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel5, 1, 1);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 1, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 6;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 16F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 17.3F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 16F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 17.3F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 16F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 17.3F));
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsCooling, 0, 11);
            this.tableLayoutPanel3.Controls.Add(this.label8, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label9, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label5, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.label4, 4, 1);
            this.tableLayoutPanel3.Controls.Add(this.label7, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.label1, 4, 2);
            this.tableLayoutPanel3.Controls.Add(this.label6, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label11, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.label2, 4, 3);
            this.tableLayoutPanel3.Controls.Add(this.label10, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label13, 2, 4);
            this.tableLayoutPanel3.Controls.Add(this.label24, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label21, 0, 11);
            this.tableLayoutPanel3.Controls.Add(this.label18, 0, 10);
            this.tableLayoutPanel3.Controls.Add(this.label22, 2, 11);
            this.tableLayoutPanel3.Controls.Add(this.label19, 2, 10);
            this.tableLayoutPanel3.Controls.Add(this.label12, 4, 10);
            this.tableLayoutPanel3.Controls.Add(this.label20, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.label3, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.label23, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.label14, 2, 8);
            this.tableLayoutPanel3.Controls.Add(this.label15, 4, 8);
            this.tableLayoutPanel3.Controls.Add(this.label25, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label26, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label27, 2, 6);
            this.tableLayoutPanel3.Controls.Add(this.label28, 4, 6);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsSpecification, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsANo, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsForm, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsWMThickness, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsClassification, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsFluxClassification, 3, 2);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsType, 3, 3);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsFillerOther, 3, 4);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsFNo, 5, 1);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsSize, 5, 2);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsName, 5, 3);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsPosition, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsPreheat, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsPWHT, 1, 10);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsProgression, 3, 6);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsPositionOther, 5, 6);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsInterpass, 3, 8);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsPreheatOther, 5, 8);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsTime, 3, 10);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsHeating, 5, 10);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsPWHTOther, 3, 11);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 12;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel3.TabIndex = 4;
            // 
            // txtDetailsCooling
            // 
            this.txtDetailsCooling.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsCooling.Location = new System.Drawing.Point(167, 399);
            this.txtDetailsCooling.Name = "txtDetailsCooling";
            this.txtDetailsCooling.Size = new System.Drawing.Size(171, 31);
            this.txtDetailsCooling.TabIndex = 56;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = Wisej.Web.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(3, 75);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(158, 30);
            this.label8.TabIndex = 1;
            this.label8.Text = "A-Number";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = Wisej.Web.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(3, 39);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(158, 30);
            this.label9.TabIndex = 0;
            this.label9.Text = "Specification";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = Wisej.Web.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(344, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(158, 30);
            this.label5.TabIndex = 12;
            this.label5.Text = "Classification";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = Wisej.Web.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(685, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 30);
            this.label4.TabIndex = 13;
            this.label4.Text = "F-Number";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = Wisej.Web.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(344, 75);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 30);
            this.label7.TabIndex = 2;
            this.label7.Text = "Electrode Flux Classification";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(685, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 30);
            this.label1.TabIndex = 16;
            this.label1.Text = "Size (mm)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = Wisej.Web.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(3, 111);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 30);
            this.label6.TabIndex = 3;
            this.label6.Text = "Filler Form";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = Wisej.Web.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(344, 111);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(158, 30);
            this.label11.TabIndex = 20;
            this.label11.Text = "Flux Type";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(685, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(158, 30);
            this.label2.TabIndex = 15;
            this.label2.Text = "Flux Trade Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = Wisej.Web.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(3, 147);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(158, 30);
            this.label10.TabIndex = 4;
            this.label10.Text = "Weld Metal Thickness";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = Wisej.Web.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(344, 147);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(158, 30);
            this.label13.TabIndex = 8;
            this.label13.Text = "Other";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label24.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel3.SetColumnSpan(this.label24, 6);
            this.label24.Dock = Wisej.Web.DockStyle.Fill;
            this.label24.Location = new System.Drawing.Point(3, 3);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(1018, 30);
            this.label24.TabIndex = 31;
            this.label24.Text = "Filler Metals";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = Wisej.Web.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(3, 399);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(158, 31);
            this.label21.TabIndex = 27;
            this.label21.Text = "Cooling Rate";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = Wisej.Web.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(3, 363);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(158, 30);
            this.label18.TabIndex = 24;
            this.label18.Text = "Temperature";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = Wisej.Web.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label22.Location = new System.Drawing.Point(344, 399);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(158, 31);
            this.label22.TabIndex = 28;
            this.label22.Text = "Other";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = Wisej.Web.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(344, 363);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(158, 30);
            this.label19.TabIndex = 25;
            this.label19.Text = "Time";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = Wisej.Web.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(685, 363);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(158, 30);
            this.label12.TabIndex = 23;
            this.label12.Text = "Heating Rate";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label20.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel3.SetColumnSpan(this.label20, 6);
            this.label20.Dock = Wisej.Web.DockStyle.Fill;
            this.label20.Location = new System.Drawing.Point(3, 327);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(1018, 30);
            this.label20.TabIndex = 29;
            this.label20.Text = "PWHT";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = Wisej.Web.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(3, 291);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 30);
            this.label3.TabIndex = 14;
            this.label3.Text = "Temperature";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label23.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel3.SetColumnSpan(this.label23, 6);
            this.label23.Dock = Wisej.Web.DockStyle.Fill;
            this.label23.Location = new System.Drawing.Point(3, 255);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(1018, 30);
            this.label23.TabIndex = 30;
            this.label23.Text = "Preheat";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = Wisej.Web.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(344, 291);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(158, 30);
            this.label14.TabIndex = 9;
            this.label14.Text = "Interpass Temperature";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = Wisej.Web.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(685, 291);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(158, 30);
            this.label15.TabIndex = 22;
            this.label15.Text = "Other";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label25.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel3.SetColumnSpan(this.label25, 6);
            this.label25.Dock = Wisej.Web.DockStyle.Fill;
            this.label25.Location = new System.Drawing.Point(3, 183);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(1018, 30);
            this.label25.TabIndex = 32;
            this.label25.Text = "Position";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = Wisej.Web.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label26.Location = new System.Drawing.Point(3, 219);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(158, 30);
            this.label26.TabIndex = 33;
            this.label26.Text = "Position (s)";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = Wisej.Web.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label27.Location = new System.Drawing.Point(344, 219);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(158, 30);
            this.label27.TabIndex = 34;
            this.label27.Text = "Weld Progression";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = Wisej.Web.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label28.Location = new System.Drawing.Point(685, 219);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(158, 30);
            this.label28.TabIndex = 35;
            this.label28.Text = "Other";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDetailsSpecification
            // 
            this.txtDetailsSpecification.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsSpecification.Location = new System.Drawing.Point(167, 39);
            this.txtDetailsSpecification.Name = "txtDetailsSpecification";
            this.txtDetailsSpecification.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsSpecification.TabIndex = 36;
            // 
            // txtDetailsANo
            // 
            this.txtDetailsANo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsANo.Location = new System.Drawing.Point(167, 75);
            this.txtDetailsANo.Name = "txtDetailsANo";
            this.txtDetailsANo.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsANo.TabIndex = 37;
            // 
            // txtDetailsForm
            // 
            this.txtDetailsForm.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsForm.Location = new System.Drawing.Point(167, 111);
            this.txtDetailsForm.Name = "txtDetailsForm";
            this.txtDetailsForm.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsForm.TabIndex = 39;
            // 
            // txtDetailsWMThickness
            // 
            this.txtDetailsWMThickness.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsWMThickness.Location = new System.Drawing.Point(167, 147);
            this.txtDetailsWMThickness.Name = "txtDetailsWMThickness";
            this.txtDetailsWMThickness.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsWMThickness.TabIndex = 38;
            // 
            // txtDetailsClassification
            // 
            this.txtDetailsClassification.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsClassification.Location = new System.Drawing.Point(508, 39);
            this.txtDetailsClassification.Name = "txtDetailsClassification";
            this.txtDetailsClassification.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsClassification.TabIndex = 40;
            // 
            // txtDetailsFluxClassification
            // 
            this.txtDetailsFluxClassification.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsFluxClassification.Location = new System.Drawing.Point(508, 75);
            this.txtDetailsFluxClassification.Name = "txtDetailsFluxClassification";
            this.txtDetailsFluxClassification.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsFluxClassification.TabIndex = 41;
            // 
            // txtDetailsType
            // 
            this.txtDetailsType.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsType.Location = new System.Drawing.Point(508, 111);
            this.txtDetailsType.Name = "txtDetailsType";
            this.txtDetailsType.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsType.TabIndex = 42;
            // 
            // txtDetailsFillerOther
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.txtDetailsFillerOther, 3);
            this.txtDetailsFillerOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsFillerOther.Location = new System.Drawing.Point(508, 147);
            this.txtDetailsFillerOther.Name = "txtDetailsFillerOther";
            this.txtDetailsFillerOther.Size = new System.Drawing.Size(513, 30);
            this.txtDetailsFillerOther.TabIndex = 43;
            // 
            // txtDetailsFNo
            // 
            this.txtDetailsFNo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsFNo.Location = new System.Drawing.Point(849, 39);
            this.txtDetailsFNo.Name = "txtDetailsFNo";
            this.txtDetailsFNo.Size = new System.Drawing.Size(172, 30);
            this.txtDetailsFNo.TabIndex = 44;
            // 
            // txtDetailsSize
            // 
            this.txtDetailsSize.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsSize.Location = new System.Drawing.Point(849, 75);
            this.txtDetailsSize.Name = "txtDetailsSize";
            this.txtDetailsSize.Size = new System.Drawing.Size(172, 30);
            this.txtDetailsSize.TabIndex = 45;
            // 
            // txtDetailsName
            // 
            this.txtDetailsName.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsName.Location = new System.Drawing.Point(849, 111);
            this.txtDetailsName.Name = "txtDetailsName";
            this.txtDetailsName.Size = new System.Drawing.Size(172, 30);
            this.txtDetailsName.TabIndex = 46;
            // 
            // txtDetailsPosition
            // 
            this.txtDetailsPosition.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPosition.Location = new System.Drawing.Point(167, 219);
            this.txtDetailsPosition.Name = "txtDetailsPosition";
            this.txtDetailsPosition.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsPosition.TabIndex = 47;
            // 
            // txtDetailsPreheat
            // 
            this.txtDetailsPreheat.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPreheat.Location = new System.Drawing.Point(167, 291);
            this.txtDetailsPreheat.Name = "txtDetailsPreheat";
            this.txtDetailsPreheat.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsPreheat.TabIndex = 48;
            // 
            // txtDetailsPWHT
            // 
            this.txtDetailsPWHT.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPWHT.Location = new System.Drawing.Point(167, 363);
            this.txtDetailsPWHT.Name = "txtDetailsPWHT";
            this.txtDetailsPWHT.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsPWHT.TabIndex = 49;
            // 
            // txtDetailsProgression
            // 
            this.txtDetailsProgression.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsProgression.Location = new System.Drawing.Point(508, 219);
            this.txtDetailsProgression.Name = "txtDetailsProgression";
            this.txtDetailsProgression.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsProgression.TabIndex = 50;
            // 
            // txtDetailsPositionOther
            // 
            this.txtDetailsPositionOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPositionOther.Location = new System.Drawing.Point(849, 219);
            this.txtDetailsPositionOther.Name = "txtDetailsPositionOther";
            this.txtDetailsPositionOther.Size = new System.Drawing.Size(172, 30);
            this.txtDetailsPositionOther.TabIndex = 51;
            // 
            // txtDetailsInterpass
            // 
            this.txtDetailsInterpass.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsInterpass.Location = new System.Drawing.Point(508, 291);
            this.txtDetailsInterpass.Name = "txtDetailsInterpass";
            this.txtDetailsInterpass.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsInterpass.TabIndex = 52;
            // 
            // txtDetailsPreheatOther
            // 
            this.txtDetailsPreheatOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPreheatOther.Location = new System.Drawing.Point(849, 291);
            this.txtDetailsPreheatOther.Name = "txtDetailsPreheatOther";
            this.txtDetailsPreheatOther.Size = new System.Drawing.Size(172, 30);
            this.txtDetailsPreheatOther.TabIndex = 53;
            // 
            // txtDetailsTime
            // 
            this.txtDetailsTime.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsTime.Location = new System.Drawing.Point(508, 363);
            this.txtDetailsTime.Name = "txtDetailsTime";
            this.txtDetailsTime.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsTime.TabIndex = 54;
            // 
            // txtDetailsHeating
            // 
            this.txtDetailsHeating.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsHeating.Location = new System.Drawing.Point(849, 363);
            this.txtDetailsHeating.Name = "txtDetailsHeating";
            this.txtDetailsHeating.Size = new System.Drawing.Size(172, 30);
            this.txtDetailsHeating.TabIndex = 55;
            // 
            // txtDetailsPWHTOther
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.txtDetailsPWHTOther, 3);
            this.txtDetailsPWHTOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPWHTOther.Location = new System.Drawing.Point(508, 399);
            this.txtDetailsPWHTOther.Name = "txtDetailsPWHTOther";
            this.txtDetailsPWHTOther.Size = new System.Drawing.Size(513, 31);
            this.txtDetailsPWHTOther.TabIndex = 57;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.btnDetailsBack, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.btnDetailsHome, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.btnDetailsNext, 0, 4);
            this.tableLayoutPanel4.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 5;
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel4.TabIndex = 3;
            // 
            // btnDetailsBack
            // 
            this.btnDetailsBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDetailsBack.Location = new System.Drawing.Point(3, 175);
            this.btnDetailsBack.Name = "btnDetailsBack";
            this.btnDetailsBack.Size = new System.Drawing.Size(101, 80);
            this.btnDetailsBack.TabIndex = 3;
            this.btnDetailsBack.Text = "Back";
            this.btnDetailsBack.Click += new System.EventHandler(this.btnDetailsBack_Click);
            // 
            // btnDetailsHome
            // 
            this.btnDetailsHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDetailsHome.Location = new System.Drawing.Point(3, 261);
            this.btnDetailsHome.Name = "btnDetailsHome";
            this.btnDetailsHome.Size = new System.Drawing.Size(101, 80);
            this.btnDetailsHome.TabIndex = 1;
            this.btnDetailsHome.Text = "Home";
            this.btnDetailsHome.Click += new System.EventHandler(this.btnDetailsHome_Click);
            // 
            // btnDetailsNext
            // 
            this.btnDetailsNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDetailsNext.Location = new System.Drawing.Point(3, 347);
            this.btnDetailsNext.Name = "btnDetailsNext";
            this.btnDetailsNext.Size = new System.Drawing.Size(101, 81);
            this.btnDetailsNext.TabIndex = 0;
            this.btnDetailsNext.Text = "Next";
            this.btnDetailsNext.Click += new System.EventHandler(this.btnDetailsNext_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.label16, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel5.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label16.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label16.Dock = Wisej.Web.DockStyle.Fill;
            this.label16.Location = new System.Drawing.Point(3, 79);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(1139, 35);
            this.label16.TabIndex = 1;
            this.label16.Text = "Notes";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label17.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label17.Dock = Wisej.Web.DockStyle.Fill;
            this.label17.Location = new System.Drawing.Point(3, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(1139, 70);
            this.label17.TabIndex = 0;
            this.label17.Text = "WPQR Details";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabWPQRDetailsContinued
            // 
            this.tabWPQRDetailsContinued.Controls.Add(this.tableLayoutPanel6);
            this.tabWPQRDetailsContinued.Location = new System.Drawing.Point(0, 35);
            this.tabWPQRDetailsContinued.Name = "tabWPQRDetailsContinued";
            this.tabWPQRDetailsContinued.Size = new System.Drawing.Size(1212, 615);
            this.tabWPQRDetailsContinued.Text = "Details Continued";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 3;
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel7, 1, 3);
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel13, 1, 1);
            this.tableLayoutPanel6.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 5;
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 15F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 77.5F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel6.TabIndex = 5;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel7.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel8, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel9, 1, 0);
            this.tableLayoutPanel7.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(33, 125);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(1145, 470);
            this.tableLayoutPanel7.TabIndex = 1;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 6;
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 16F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 17.3F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 16F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 17.3F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 16F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 17.3F));
            this.tableLayoutPanel8.Controls.Add(this.label50, 0, 11);
            this.tableLayoutPanel8.Controls.Add(this.txtContTechniqueOther, 5, 10);
            this.tableLayoutPanel8.Controls.Add(this.txtContElectrodes, 3, 10);
            this.tableLayoutPanel8.Controls.Add(this.txtContPass, 1, 10);
            this.tableLayoutPanel8.Controls.Add(this.txtContOscillation, 5, 9);
            this.tableLayoutPanel8.Controls.Add(this.Speed, 3, 9);
            this.tableLayoutPanel8.Controls.Add(this.txtContBead, 1, 9);
            this.tableLayoutPanel8.Controls.Add(this.txtContElectricalOther, 3, 7);
            this.tableLayoutPanel8.Controls.Add(this.txtContInput, 1, 7);
            this.tableLayoutPanel8.Controls.Add(this.txtContAmps, 5, 5);
            this.tableLayoutPanel8.Controls.Add(this.txtContPolarity, 3, 5);
            this.tableLayoutPanel8.Controls.Add(this.label42, 0, 8);
            this.tableLayoutPanel8.Controls.Add(this.label29, 0, 2);
            this.tableLayoutPanel8.Controls.Add(this.label30, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.label31, 2, 1);
            this.tableLayoutPanel8.Controls.Add(this.label32, 4, 1);
            this.tableLayoutPanel8.Controls.Add(this.label33, 2, 2);
            this.tableLayoutPanel8.Controls.Add(this.label34, 4, 2);
            this.tableLayoutPanel8.Controls.Add(this.label39, 0, 3);
            this.tableLayoutPanel8.Controls.Add(this.label40, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.label51, 0, 4);
            this.tableLayoutPanel8.Controls.Add(this.txtContShieldComp, 1, 1);
            this.tableLayoutPanel8.Controls.Add(this.txtContShieldFlow, 1, 2);
            this.tableLayoutPanel8.Controls.Add(this.txtContTrailComp, 3, 1);
            this.tableLayoutPanel8.Controls.Add(this.txtContTrailFlow, 3, 2);
            this.tableLayoutPanel8.Controls.Add(this.txtContGasOther, 1, 3);
            this.tableLayoutPanel8.Controls.Add(this.txtContBackComp, 5, 1);
            this.tableLayoutPanel8.Controls.Add(this.txtContBackFlow, 5, 2);
            this.tableLayoutPanel8.Controls.Add(this.txtContVolts, 1, 6);
            this.tableLayoutPanel8.Controls.Add(this.txtContTungsten, 3, 6);
            this.tableLayoutPanel8.Controls.Add(this.txtContTransfer, 5, 6);
            this.tableLayoutPanel8.Controls.Add(this.label52, 0, 5);
            this.tableLayoutPanel8.Controls.Add(this.label53, 2, 5);
            this.tableLayoutPanel8.Controls.Add(this.label54, 4, 5);
            this.tableLayoutPanel8.Controls.Add(this.label35, 0, 6);
            this.tableLayoutPanel8.Controls.Add(this.label36, 2, 6);
            this.tableLayoutPanel8.Controls.Add(this.label37, 4, 6);
            this.tableLayoutPanel8.Controls.Add(this.label38, 0, 7);
            this.tableLayoutPanel8.Controls.Add(this.label41, 2, 7);
            this.tableLayoutPanel8.Controls.Add(this.label43, 0, 9);
            this.tableLayoutPanel8.Controls.Add(this.label44, 2, 9);
            this.tableLayoutPanel8.Controls.Add(this.label45, 4, 9);
            this.tableLayoutPanel8.Controls.Add(this.label46, 0, 10);
            this.tableLayoutPanel8.Controls.Add(this.label47, 2, 10);
            this.tableLayoutPanel8.Controls.Add(this.label48, 4, 10);
            this.tableLayoutPanel8.Controls.Add(this.label49, 0, 14);
            this.tableLayoutPanel8.Controls.Add(this.cbContDT, 0, 13);
            this.tableLayoutPanel8.Controls.Add(this.cbContMacro, 1, 13);
            this.tableLayoutPanel8.Controls.Add(this.cbContVisual, 1, 12);
            this.tableLayoutPanel8.Controls.Add(this.cbContNDT, 0, 12);
            this.tableLayoutPanel8.Controls.Add(this.cbContHardness, 2, 13);
            this.tableLayoutPanel8.Controls.Add(this.cbContDPI, 2, 12);
            this.tableLayoutPanel8.Controls.Add(this.cbContBend, 3, 13);
            this.tableLayoutPanel8.Controls.Add(this.cbContMPI, 3, 12);
            this.tableLayoutPanel8.Controls.Add(this.cbContTensil, 4, 13);
            this.tableLayoutPanel8.Controls.Add(this.cbContRT, 4, 12);
            this.tableLayoutPanel8.Controls.Add(this.cbContImpact, 5, 13);
            this.tableLayoutPanel8.Controls.Add(this.cbContUT, 5, 12);
            this.tableLayoutPanel8.Controls.Add(this.txtContCurrent, 1, 5);
            this.tableLayoutPanel8.Controls.Add(this.txtContNotes, 1, 14);
            this.tableLayoutPanel8.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 15;
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(1024, 464);
            this.tableLayoutPanel8.TabIndex = 4;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label50.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel8.SetColumnSpan(this.label50, 6);
            this.label50.Dock = Wisej.Web.DockStyle.Fill;
            this.label50.Location = new System.Drawing.Point(3, 333);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(1018, 24);
            this.label50.TabIndex = 96;
            this.label50.Text = "Other";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtContTechniqueOther
            // 
            this.txtContTechniqueOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContTechniqueOther.Location = new System.Drawing.Point(849, 303);
            this.txtContTechniqueOther.Name = "txtContTechniqueOther";
            this.txtContTechniqueOther.Size = new System.Drawing.Size(172, 24);
            this.txtContTechniqueOther.TabIndex = 95;
            // 
            // txtContElectrodes
            // 
            this.txtContElectrodes.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContElectrodes.Location = new System.Drawing.Point(508, 303);
            this.txtContElectrodes.Name = "txtContElectrodes";
            this.txtContElectrodes.Size = new System.Drawing.Size(171, 24);
            this.txtContElectrodes.TabIndex = 94;
            // 
            // txtContPass
            // 
            this.txtContPass.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContPass.Location = new System.Drawing.Point(167, 303);
            this.txtContPass.Name = "txtContPass";
            this.txtContPass.Size = new System.Drawing.Size(171, 24);
            this.txtContPass.TabIndex = 93;
            // 
            // txtContOscillation
            // 
            this.txtContOscillation.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContOscillation.Location = new System.Drawing.Point(849, 273);
            this.txtContOscillation.Name = "txtContOscillation";
            this.txtContOscillation.Size = new System.Drawing.Size(172, 24);
            this.txtContOscillation.TabIndex = 92;
            // 
            // Speed
            // 
            this.Speed.Dock = Wisej.Web.DockStyle.Fill;
            this.Speed.Location = new System.Drawing.Point(508, 273);
            this.Speed.Name = "Speed";
            this.Speed.Size = new System.Drawing.Size(171, 24);
            this.Speed.TabIndex = 91;
            // 
            // txtContBead
            // 
            this.txtContBead.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContBead.Location = new System.Drawing.Point(167, 273);
            this.txtContBead.Name = "txtContBead";
            this.txtContBead.Size = new System.Drawing.Size(171, 24);
            this.txtContBead.TabIndex = 90;
            // 
            // txtContElectricalOther
            // 
            this.tableLayoutPanel8.SetColumnSpan(this.txtContElectricalOther, 3);
            this.txtContElectricalOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContElectricalOther.Location = new System.Drawing.Point(508, 213);
            this.txtContElectricalOther.Name = "txtContElectricalOther";
            this.txtContElectricalOther.Size = new System.Drawing.Size(513, 24);
            this.txtContElectricalOther.TabIndex = 87;
            // 
            // txtContInput
            // 
            this.txtContInput.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContInput.Location = new System.Drawing.Point(167, 213);
            this.txtContInput.Name = "txtContInput";
            this.txtContInput.Size = new System.Drawing.Size(171, 24);
            this.txtContInput.TabIndex = 86;
            // 
            // txtContAmps
            // 
            this.txtContAmps.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContAmps.Location = new System.Drawing.Point(849, 153);
            this.txtContAmps.Name = "txtContAmps";
            this.txtContAmps.Size = new System.Drawing.Size(172, 24);
            this.txtContAmps.TabIndex = 85;
            // 
            // txtContPolarity
            // 
            this.txtContPolarity.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContPolarity.Location = new System.Drawing.Point(508, 153);
            this.txtContPolarity.Name = "txtContPolarity";
            this.txtContPolarity.Size = new System.Drawing.Size(171, 24);
            this.txtContPolarity.TabIndex = 84;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label42.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel8.SetColumnSpan(this.label42, 6);
            this.label42.Dock = Wisej.Web.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(3, 243);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(1018, 24);
            this.label42.TabIndex = 63;
            this.label42.Text = "Technique";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = Wisej.Web.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label29.Location = new System.Drawing.Point(3, 63);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(158, 24);
            this.label29.TabIndex = 1;
            this.label29.Text = "Shielding Flow Rate";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = Wisej.Web.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label30.Location = new System.Drawing.Point(3, 33);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(158, 24);
            this.label30.TabIndex = 0;
            this.label30.Text = "Shielding Composition";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = Wisej.Web.DockStyle.Fill;
            this.label31.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label31.Location = new System.Drawing.Point(344, 33);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(158, 24);
            this.label31.TabIndex = 12;
            this.label31.Text = "Trailing Composition";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = Wisej.Web.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label32.Location = new System.Drawing.Point(685, 33);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(158, 24);
            this.label32.TabIndex = 13;
            this.label32.Text = "Backing Composition";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = Wisej.Web.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label33.Location = new System.Drawing.Point(344, 63);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(158, 24);
            this.label33.TabIndex = 2;
            this.label33.Text = "Trailing Flow Rate";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = Wisej.Web.DockStyle.Fill;
            this.label34.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label34.Location = new System.Drawing.Point(685, 63);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(158, 24);
            this.label34.TabIndex = 16;
            this.label34.Text = "Backing Flow Rate";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Dock = Wisej.Web.DockStyle.Fill;
            this.label39.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label39.Location = new System.Drawing.Point(3, 93);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(158, 24);
            this.label39.TabIndex = 8;
            this.label39.Text = "Other";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label40.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel8.SetColumnSpan(this.label40, 6);
            this.label40.Dock = Wisej.Web.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(3, 3);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(1018, 24);
            this.label40.TabIndex = 31;
            this.label40.Text = "Gas";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label51.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel8.SetColumnSpan(this.label51, 6);
            this.label51.Dock = Wisej.Web.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(3, 123);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(1018, 24);
            this.label51.TabIndex = 32;
            this.label51.Text = "Electrical Data";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtContShieldComp
            // 
            this.txtContShieldComp.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContShieldComp.Location = new System.Drawing.Point(167, 33);
            this.txtContShieldComp.Name = "txtContShieldComp";
            this.txtContShieldComp.Size = new System.Drawing.Size(171, 24);
            this.txtContShieldComp.TabIndex = 36;
            // 
            // txtContShieldFlow
            // 
            this.txtContShieldFlow.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContShieldFlow.Location = new System.Drawing.Point(167, 63);
            this.txtContShieldFlow.Name = "txtContShieldFlow";
            this.txtContShieldFlow.Size = new System.Drawing.Size(171, 24);
            this.txtContShieldFlow.TabIndex = 37;
            // 
            // txtContTrailComp
            // 
            this.txtContTrailComp.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContTrailComp.Location = new System.Drawing.Point(508, 33);
            this.txtContTrailComp.Name = "txtContTrailComp";
            this.txtContTrailComp.Size = new System.Drawing.Size(171, 24);
            this.txtContTrailComp.TabIndex = 40;
            // 
            // txtContTrailFlow
            // 
            this.txtContTrailFlow.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContTrailFlow.Location = new System.Drawing.Point(508, 63);
            this.txtContTrailFlow.Name = "txtContTrailFlow";
            this.txtContTrailFlow.Size = new System.Drawing.Size(171, 24);
            this.txtContTrailFlow.TabIndex = 41;
            // 
            // txtContGasOther
            // 
            this.tableLayoutPanel8.SetColumnSpan(this.txtContGasOther, 5);
            this.txtContGasOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContGasOther.Location = new System.Drawing.Point(167, 93);
            this.txtContGasOther.Name = "txtContGasOther";
            this.txtContGasOther.Size = new System.Drawing.Size(854, 24);
            this.txtContGasOther.TabIndex = 43;
            // 
            // txtContBackComp
            // 
            this.txtContBackComp.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContBackComp.Location = new System.Drawing.Point(849, 33);
            this.txtContBackComp.Name = "txtContBackComp";
            this.txtContBackComp.Size = new System.Drawing.Size(172, 24);
            this.txtContBackComp.TabIndex = 44;
            // 
            // txtContBackFlow
            // 
            this.txtContBackFlow.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContBackFlow.Location = new System.Drawing.Point(849, 63);
            this.txtContBackFlow.Name = "txtContBackFlow";
            this.txtContBackFlow.Size = new System.Drawing.Size(172, 24);
            this.txtContBackFlow.TabIndex = 45;
            // 
            // txtContVolts
            // 
            this.txtContVolts.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContVolts.Location = new System.Drawing.Point(167, 183);
            this.txtContVolts.Name = "txtContVolts";
            this.txtContVolts.Size = new System.Drawing.Size(171, 24);
            this.txtContVolts.TabIndex = 47;
            // 
            // txtContTungsten
            // 
            this.txtContTungsten.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContTungsten.Location = new System.Drawing.Point(508, 183);
            this.txtContTungsten.Name = "txtContTungsten";
            this.txtContTungsten.Size = new System.Drawing.Size(171, 24);
            this.txtContTungsten.TabIndex = 50;
            // 
            // txtContTransfer
            // 
            this.txtContTransfer.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContTransfer.Location = new System.Drawing.Point(849, 183);
            this.txtContTransfer.Name = "txtContTransfer";
            this.txtContTransfer.Size = new System.Drawing.Size(172, 24);
            this.txtContTransfer.TabIndex = 51;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Dock = Wisej.Web.DockStyle.Fill;
            this.label52.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label52.Location = new System.Drawing.Point(3, 153);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(158, 24);
            this.label52.TabIndex = 33;
            this.label52.Text = "Current";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Dock = Wisej.Web.DockStyle.Fill;
            this.label53.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label53.Location = new System.Drawing.Point(344, 153);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(158, 24);
            this.label53.TabIndex = 34;
            this.label53.Text = "Polarity";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Dock = Wisej.Web.DockStyle.Fill;
            this.label54.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label54.Location = new System.Drawing.Point(685, 153);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(158, 24);
            this.label54.TabIndex = 35;
            this.label54.Text = "Amps";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = Wisej.Web.DockStyle.Fill;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label35.Location = new System.Drawing.Point(3, 183);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(158, 24);
            this.label35.TabIndex = 58;
            this.label35.Text = "Volts";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = Wisej.Web.DockStyle.Fill;
            this.label36.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label36.Location = new System.Drawing.Point(344, 183);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(158, 24);
            this.label36.TabIndex = 59;
            this.label36.Text = "Tungsten Electrode Size";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Dock = Wisej.Web.DockStyle.Fill;
            this.label37.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label37.Location = new System.Drawing.Point(685, 183);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(158, 24);
            this.label37.TabIndex = 60;
            this.label37.Text = "Mode of Metal Transfer";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = Wisej.Web.DockStyle.Fill;
            this.label38.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label38.Location = new System.Drawing.Point(3, 213);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(158, 24);
            this.label38.TabIndex = 61;
            this.label38.Text = "Heat Input";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Dock = Wisej.Web.DockStyle.Fill;
            this.label41.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label41.Location = new System.Drawing.Point(344, 213);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(158, 24);
            this.label41.TabIndex = 62;
            this.label41.Text = "Other";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Dock = Wisej.Web.DockStyle.Fill;
            this.label43.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label43.Location = new System.Drawing.Point(3, 273);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(158, 24);
            this.label43.TabIndex = 64;
            this.label43.Text = "String / Weave Bead";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = Wisej.Web.DockStyle.Fill;
            this.label44.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label44.Location = new System.Drawing.Point(344, 273);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(158, 24);
            this.label44.TabIndex = 65;
            this.label44.Text = "Travel Speed";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = Wisej.Web.DockStyle.Fill;
            this.label45.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label45.Location = new System.Drawing.Point(685, 273);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(158, 24);
            this.label45.TabIndex = 66;
            this.label45.Text = "Oscillation";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Dock = Wisej.Web.DockStyle.Fill;
            this.label46.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label46.Location = new System.Drawing.Point(3, 303);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(158, 24);
            this.label46.TabIndex = 67;
            this.label46.Text = "Multi / Single Pass";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Dock = Wisej.Web.DockStyle.Fill;
            this.label47.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label47.Location = new System.Drawing.Point(344, 303);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(158, 24);
            this.label47.TabIndex = 68;
            this.label47.Text = "Single / Multiple Electrodes";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = Wisej.Web.DockStyle.Fill;
            this.label48.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label48.Location = new System.Drawing.Point(685, 303);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(158, 24);
            this.label48.TabIndex = 69;
            this.label48.Text = "Other";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Dock = Wisej.Web.DockStyle.Fill;
            this.label49.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label49.Location = new System.Drawing.Point(3, 423);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(158, 38);
            this.label49.TabIndex = 82;
            this.label49.Text = "Notes";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbContDT
            // 
            this.cbContDT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContDT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContDT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContDT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContDT.Location = new System.Drawing.Point(3, 393);
            this.cbContDT.Name = "cbContDT";
            this.cbContDT.Size = new System.Drawing.Size(158, 24);
            this.cbContDT.TabIndex = 76;
            this.cbContDT.Text = "DT";
            this.cbContDT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContMacro
            // 
            this.cbContMacro.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContMacro.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContMacro.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContMacro.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContMacro.Location = new System.Drawing.Point(167, 393);
            this.cbContMacro.Name = "cbContMacro";
            this.cbContMacro.Size = new System.Drawing.Size(171, 24);
            this.cbContMacro.TabIndex = 77;
            this.cbContMacro.Text = "Macro";
            this.cbContMacro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContVisual
            // 
            this.cbContVisual.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContVisual.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContVisual.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContVisual.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContVisual.Location = new System.Drawing.Point(167, 363);
            this.cbContVisual.Name = "cbContVisual";
            this.cbContVisual.Size = new System.Drawing.Size(171, 24);
            this.cbContVisual.TabIndex = 71;
            this.cbContVisual.Text = "Visual";
            this.cbContVisual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContNDT
            // 
            this.cbContNDT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContNDT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContNDT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContNDT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContNDT.Location = new System.Drawing.Point(3, 363);
            this.cbContNDT.Name = "cbContNDT";
            this.cbContNDT.Size = new System.Drawing.Size(158, 24);
            this.cbContNDT.TabIndex = 70;
            this.cbContNDT.Text = "NDT";
            this.cbContNDT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContHardness
            // 
            this.cbContHardness.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContHardness.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContHardness.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContHardness.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContHardness.Location = new System.Drawing.Point(344, 393);
            this.cbContHardness.Name = "cbContHardness";
            this.cbContHardness.Size = new System.Drawing.Size(158, 24);
            this.cbContHardness.TabIndex = 78;
            this.cbContHardness.Text = "Hardness";
            this.cbContHardness.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContDPI
            // 
            this.cbContDPI.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContDPI.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContDPI.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContDPI.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContDPI.Location = new System.Drawing.Point(344, 363);
            this.cbContDPI.Name = "cbContDPI";
            this.cbContDPI.Size = new System.Drawing.Size(158, 24);
            this.cbContDPI.TabIndex = 72;
            this.cbContDPI.Text = "DPI";
            this.cbContDPI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContBend
            // 
            this.cbContBend.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContBend.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContBend.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContBend.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContBend.Location = new System.Drawing.Point(508, 393);
            this.cbContBend.Name = "cbContBend";
            this.cbContBend.Size = new System.Drawing.Size(171, 24);
            this.cbContBend.TabIndex = 79;
            this.cbContBend.Text = "Bend";
            this.cbContBend.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContMPI
            // 
            this.cbContMPI.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContMPI.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContMPI.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContMPI.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContMPI.Location = new System.Drawing.Point(508, 363);
            this.cbContMPI.Name = "cbContMPI";
            this.cbContMPI.Size = new System.Drawing.Size(171, 24);
            this.cbContMPI.TabIndex = 73;
            this.cbContMPI.Text = "MPI";
            this.cbContMPI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContTensil
            // 
            this.cbContTensil.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContTensil.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContTensil.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContTensil.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContTensil.Location = new System.Drawing.Point(685, 393);
            this.cbContTensil.Name = "cbContTensil";
            this.cbContTensil.Size = new System.Drawing.Size(158, 24);
            this.cbContTensil.TabIndex = 80;
            this.cbContTensil.Text = "Tensil";
            this.cbContTensil.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContRT
            // 
            this.cbContRT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContRT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContRT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContRT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContRT.Location = new System.Drawing.Point(685, 363);
            this.cbContRT.Name = "cbContRT";
            this.cbContRT.Size = new System.Drawing.Size(158, 24);
            this.cbContRT.TabIndex = 74;
            this.cbContRT.Text = "RT";
            this.cbContRT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContImpact
            // 
            this.cbContImpact.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContImpact.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContImpact.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContImpact.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContImpact.Location = new System.Drawing.Point(849, 393);
            this.cbContImpact.Name = "cbContImpact";
            this.cbContImpact.Size = new System.Drawing.Size(172, 24);
            this.cbContImpact.TabIndex = 81;
            this.cbContImpact.Text = "Impact";
            this.cbContImpact.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContUT
            // 
            this.cbContUT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContUT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContUT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContUT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContUT.Location = new System.Drawing.Point(849, 363);
            this.cbContUT.Name = "cbContUT";
            this.cbContUT.Size = new System.Drawing.Size(172, 24);
            this.cbContUT.TabIndex = 75;
            this.cbContUT.Text = "UT";
            this.cbContUT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtContCurrent
            // 
            this.txtContCurrent.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContCurrent.Location = new System.Drawing.Point(167, 153);
            this.txtContCurrent.Name = "txtContCurrent";
            this.txtContCurrent.Size = new System.Drawing.Size(171, 24);
            this.txtContCurrent.TabIndex = 83;
            // 
            // txtContNotes
            // 
            this.tableLayoutPanel8.SetColumnSpan(this.txtContNotes, 5);
            this.txtContNotes.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContNotes.Location = new System.Drawing.Point(167, 423);
            this.txtContNotes.Name = "txtContNotes";
            this.txtContNotes.Size = new System.Drawing.Size(854, 38);
            this.txtContNotes.TabIndex = 88;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.btnContBack, 0, 2);
            this.tableLayoutPanel9.Controls.Add(this.btnContHome, 0, 3);
            this.tableLayoutPanel9.Controls.Add(this.btnContNext, 0, 4);
            this.tableLayoutPanel9.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 5;
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(109, 464);
            this.tableLayoutPanel9.TabIndex = 3;
            // 
            // btnContBack
            // 
            this.btnContBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnContBack.Location = new System.Drawing.Point(3, 187);
            this.btnContBack.Name = "btnContBack";
            this.btnContBack.Size = new System.Drawing.Size(101, 86);
            this.btnContBack.TabIndex = 2;
            this.btnContBack.Text = "Back";
            this.btnContBack.Click += new System.EventHandler(this.btnContBack_Click);
            // 
            // btnContHome
            // 
            this.btnContHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnContHome.Location = new System.Drawing.Point(3, 279);
            this.btnContHome.Name = "btnContHome";
            this.btnContHome.Size = new System.Drawing.Size(101, 86);
            this.btnContHome.TabIndex = 1;
            this.btnContHome.Text = "Home";
            this.btnContHome.Click += new System.EventHandler(this.btnContHome_Click);
            // 
            // btnContNext
            // 
            this.btnContNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnContNext.Location = new System.Drawing.Point(3, 371);
            this.btnContNext.Name = "btnContNext";
            this.btnContNext.Size = new System.Drawing.Size(101, 88);
            this.btnContNext.TabIndex = 0;
            this.btnContNext.Text = "Next";
            this.btnContNext.Click += new System.EventHandler(this.btnContNext_Click);
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel13.Controls.Add(this.label55, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.label56, 0, 0);
            this.tableLayoutPanel13.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(1145, 86);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label55.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label55.Dock = Wisej.Web.DockStyle.Fill;
            this.label55.Location = new System.Drawing.Point(3, 58);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(1139, 25);
            this.label55.TabIndex = 1;
            this.label55.Text = "Notes";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label56.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label56.Dock = Wisej.Web.DockStyle.Fill;
            this.label56.Location = new System.Drawing.Point(3, 3);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(1139, 49);
            this.label56.TabIndex = 0;
            this.label56.Text = "WPQR Details";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabUpload
            // 
            this.tabUpload.Controls.Add(this.tableLayoutPanel14);
            this.tabUpload.Location = new System.Drawing.Point(0, 35);
            this.tabUpload.Name = "tabUpload";
            this.tabUpload.Size = new System.Drawing.Size(1212, 615);
            this.tabUpload.Text = "Upload";
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 3;
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel22, 1, 3);
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel15, 1, 1);
            this.tableLayoutPanel14.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 5;
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel14.TabIndex = 7;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel10, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel11, 1, 0);
            this.tableLayoutPanel22.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel22.TabIndex = 1;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 6;
            this.tableLayoutPanel10.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel10.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel10.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel10.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel10.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel10.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel10.Controls.Add(this.pbUploadSequence, 3, 0);
            this.tableLayoutPanel10.Controls.Add(this.pbUploadPreparation, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.uplUploadSequence, 4, 1);
            this.tableLayoutPanel10.Controls.Add(this.uplUploadPreparation, 1, 1);
            this.tableLayoutPanel10.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 2;
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 80F));
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel10.TabIndex = 6;
            // 
            // pbUploadSequence
            // 
            this.pbUploadSequence.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel10.SetColumnSpan(this.pbUploadSequence, 3);
            this.pbUploadSequence.Dock = Wisej.Web.DockStyle.Fill;
            this.pbUploadSequence.Location = new System.Drawing.Point(513, 3);
            this.pbUploadSequence.Name = "pbUploadSequence";
            this.pbUploadSequence.Size = new System.Drawing.Size(508, 340);
            // 
            // pbUploadPreparation
            // 
            this.pbUploadPreparation.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel10.SetColumnSpan(this.pbUploadPreparation, 3);
            this.pbUploadPreparation.Dock = Wisej.Web.DockStyle.Fill;
            this.pbUploadPreparation.Location = new System.Drawing.Point(3, 3);
            this.pbUploadPreparation.Name = "pbUploadPreparation";
            this.pbUploadPreparation.Size = new System.Drawing.Size(504, 340);
            // 
            // uplUploadSequence
            // 
            this.uplUploadSequence.Dock = Wisej.Web.DockStyle.Fill;
            this.uplUploadSequence.HideValue = true;
            this.uplUploadSequence.Location = new System.Drawing.Point(683, 349);
            this.uplUploadSequence.Name = "uplUploadSequence";
            this.uplUploadSequence.Size = new System.Drawing.Size(164, 81);
            this.uplUploadSequence.TabIndex = 2;
            this.uplUploadSequence.Text = "Upload Weld Sequence Image";
            this.uplUploadSequence.Uploaded += new Wisej.Web.UploadedEventHandler(this.uplUploadSequence_Uploaded);
            // 
            // uplUploadPreparation
            // 
            this.uplUploadPreparation.Dock = Wisej.Web.DockStyle.Fill;
            this.uplUploadPreparation.HideValue = true;
            this.uplUploadPreparation.Location = new System.Drawing.Point(173, 349);
            this.uplUploadPreparation.Name = "uplUploadPreparation";
            this.uplUploadPreparation.Size = new System.Drawing.Size(164, 81);
            this.uplUploadPreparation.TabIndex = 1;
            this.uplUploadPreparation.Text = "Upload Weld Preparation Image";
            this.uplUploadPreparation.Uploaded += new Wisej.Web.UploadedEventHandler(this.uplUploadPreparation_Uploaded);
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.tableLayoutPanel12, 0, 0);
            this.tableLayoutPanel11.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel11.TabIndex = 5;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.btnUploadBack, 0, 2);
            this.tableLayoutPanel12.Controls.Add(this.btnUploadHome, 0, 3);
            this.tableLayoutPanel12.Controls.Add(this.btnUploadComplete, 0, 4);
            this.tableLayoutPanel12.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 5;
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel12.TabIndex = 4;
            // 
            // btnUploadBack
            // 
            this.btnUploadBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnUploadBack.Location = new System.Drawing.Point(3, 173);
            this.btnUploadBack.Name = "btnUploadBack";
            this.btnUploadBack.Size = new System.Drawing.Size(95, 79);
            this.btnUploadBack.TabIndex = 2;
            this.btnUploadBack.Text = "Back";
            this.btnUploadBack.Click += new System.EventHandler(this.btnUploadBack_Click);
            // 
            // btnUploadHome
            // 
            this.btnUploadHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnUploadHome.Location = new System.Drawing.Point(3, 258);
            this.btnUploadHome.Name = "btnUploadHome";
            this.btnUploadHome.Size = new System.Drawing.Size(95, 79);
            this.btnUploadHome.TabIndex = 1;
            this.btnUploadHome.Text = "Home";
            this.btnUploadHome.Click += new System.EventHandler(this.btnUploadHome_Click);
            // 
            // btnUploadComplete
            // 
            this.btnUploadComplete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnUploadComplete.Location = new System.Drawing.Point(3, 343);
            this.btnUploadComplete.Name = "btnUploadComplete";
            this.btnUploadComplete.Size = new System.Drawing.Size(95, 79);
            this.btnUploadComplete.TabIndex = 0;
            this.btnUploadComplete.Text = "Complete";
            this.btnUploadComplete.Click += new System.EventHandler(this.btnUploadComplete_Click);
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 1;
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Controls.Add(this.label76, 0, 1);
            this.tableLayoutPanel15.Controls.Add(this.label57, 0, 0);
            this.tableLayoutPanel15.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 2;
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel15.TabIndex = 0;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label76.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label76.Dock = Wisej.Web.DockStyle.Fill;
            this.label76.Location = new System.Drawing.Point(3, 79);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(1139, 35);
            this.label76.TabIndex = 1;
            this.label76.Text = "Notes";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label57.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label57.Dock = Wisej.Web.DockStyle.Fill;
            this.label57.Location = new System.Drawing.Point(3, 3);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(1139, 70);
            this.label57.TabIndex = 0;
            this.label57.Text = "Weld Preparation and Sequence Upload";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fbWPQR
            // 
            this.Controls.Add(this.Boards);
            this.Name = "fbWPQR";
            this.Size = new System.Drawing.Size(1212, 650);
            this.Boards.ResumeLayout(false);
            this.tabWPQRInfo.ResumeLayout(false);
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel27.PerformLayout();
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel29.ResumeLayout(false);
            this.tableLayoutPanel29.PerformLayout();
            this.tabWPQRRun.ResumeLayout(false);
            this.tableLayoutPanel33.ResumeLayout(false);
            this.tableLayoutPanel34.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvWPQRRun)).EndInit();
            this.tableLayoutPanel35.ResumeLayout(false);
            this.tableLayoutPanel36.ResumeLayout(false);
            this.tableLayoutPanel38.ResumeLayout(false);
            this.tableLayoutPanel38.PerformLayout();
            this.tabWPQRDetails.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tabWPQRDetailsContinued.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.tabUpload.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbUploadSequence)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUploadPreparation)).EndInit();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TabControl Boards;
        private Wisej.Web.TabPage tabWPQRInfo;
        private Wisej.Web.TabPage tabWPQRRun;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel25;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel26;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel27;
        private Wisej.Web.Label label86;
        private Wisej.Web.Label label87;
        private Wisej.Web.Label label88;
        private Wisej.Web.Label label89;
        private Wisej.Web.Label label90;
        private Wisej.Web.Label label99;
        private Wisej.Web.Label label100;
        private Wisej.Web.Label label101;
        private Wisej.Web.Label label102;
        private Wisej.Web.Label label98;
        private Wisej.Web.Label label82;
        private Wisej.Web.Label label81;
        private Wisej.Web.Label label94;
        private Wisej.Web.Label label93;
        private Wisej.Web.Label label79;
        private Wisej.Web.TextBox txtInfoWPQR;
        private Wisej.Web.TextBox txtInfoStandard;
        private Wisej.Web.TextBox txtInfoType;
        private Wisej.Web.TextBox txtInfoJoint;
        private Wisej.Web.TextBox txtInfoMaxThickness;
        private Wisej.Web.TextBox txtInfoOther;
        private Wisej.Web.TextBox txtInfoDia;
        private Wisej.Web.TextBox txtInfoPrepared;
        private Wisej.Web.TextBox txtInfoDate;
        private Wisej.Web.TextBox txtInfoWPS;
        private Wisej.Web.TextBox txtInfoThickness;
        private Wisej.Web.TextBox txtInfoMatStandard;
        private Wisej.Web.TextBox txtInfoPNo;
        private Wisej.Web.TextBox txtInfoMatGrade;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel28;
        private Wisej.Web.Button btnInfoHome;
        private Wisej.Web.Button btnInfoNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel29;
        private Wisej.Web.Label label103;
        private Wisej.Web.Label label104;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel33;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel34;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel35;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel36;
        private Wisej.Web.Button btnRunHome;
        private Wisej.Web.Button btnRunNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel38;
        private Wisej.Web.Label label110;
        private Wisej.Web.Label label111;
        private Wisej.Web.DataGridView dgvWPQRRun;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcPass;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcSide;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcProcess;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcPosition;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcSize;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcSpecification;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcClassification;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcPolarity;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcFluxGas;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcInput;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcAmps;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcVolts;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcSpeed;
        private Wisej.Web.TabPage tabWPQRDetails;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.Label label1;
        private Wisej.Web.Label label2;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label5;
        private Wisej.Web.Label label6;
        private Wisej.Web.Label label7;
        private Wisej.Web.Label label8;
        private Wisej.Web.Label label9;
        private Wisej.Web.Label label10;
        private Wisej.Web.Label label11;
        private Wisej.Web.Label label13;
        private Wisej.Web.Label label14;
        private Wisej.Web.Label label15;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel4;
        private Wisej.Web.Button btnDetailsHome;
        private Wisej.Web.Button btnDetailsNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel5;
        private Wisej.Web.Label label16;
        private Wisej.Web.Label label17;
        private Wisej.Web.Label label18;
        private Wisej.Web.Label label12;
        private Wisej.Web.Label label19;
        private Wisej.Web.Label label26;
        private Wisej.Web.Label label24;
        private Wisej.Web.Label label21;
        private Wisej.Web.Label label22;
        private Wisej.Web.Label label20;
        private Wisej.Web.Label label23;
        private Wisej.Web.Label label25;
        private Wisej.Web.Label label27;
        private Wisej.Web.Label label28;
        private Wisej.Web.TextBox txtDetailsSpecification;
        private Wisej.Web.TextBox txtDetailsANo;
        private Wisej.Web.TextBox txtDetailsForm;
        private Wisej.Web.TextBox txtDetailsWMThickness;
        private Wisej.Web.TextBox txtDetailsClassification;
        private Wisej.Web.TextBox txtDetailsFluxClassification;
        private Wisej.Web.TextBox txtDetailsType;
        private Wisej.Web.TextBox txtDetailsCooling;
        private Wisej.Web.TextBox txtDetailsFillerOther;
        private Wisej.Web.TextBox txtDetailsFNo;
        private Wisej.Web.TextBox txtDetailsSize;
        private Wisej.Web.TextBox txtDetailsName;
        private Wisej.Web.TextBox txtDetailsPosition;
        private Wisej.Web.TextBox txtDetailsPreheat;
        private Wisej.Web.TextBox txtDetailsPWHT;
        private Wisej.Web.TextBox txtDetailsProgression;
        private Wisej.Web.TextBox txtDetailsPositionOther;
        private Wisej.Web.TextBox txtDetailsInterpass;
        private Wisej.Web.TextBox txtDetailsPreheatOther;
        private Wisej.Web.TextBox txtDetailsTime;
        private Wisej.Web.TextBox txtDetailsHeating;
        private Wisej.Web.TextBox txtDetailsPWHTOther;
        private Wisej.Web.TabPage tabWPQRDetailsContinued;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel6;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel7;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel8;
        private Wisej.Web.Label label29;
        private Wisej.Web.Label label30;
        private Wisej.Web.Label label31;
        private Wisej.Web.Label label32;
        private Wisej.Web.Label label33;
        private Wisej.Web.Label label34;
        private Wisej.Web.Label label39;
        private Wisej.Web.Label label40;
        private Wisej.Web.Label label51;
        private Wisej.Web.Label label52;
        private Wisej.Web.Label label53;
        private Wisej.Web.Label label54;
        private Wisej.Web.TextBox txtContShieldComp;
        private Wisej.Web.TextBox txtContShieldFlow;
        private Wisej.Web.TextBox txtContTrailComp;
        private Wisej.Web.TextBox txtContTrailFlow;
        private Wisej.Web.TextBox txtContGasOther;
        private Wisej.Web.TextBox txtContBackComp;
        private Wisej.Web.TextBox txtContBackFlow;
        private Wisej.Web.TextBox txtContVolts;
        private Wisej.Web.TextBox txtContTungsten;
        private Wisej.Web.TextBox txtContTransfer;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel9;
        private Wisej.Web.Button btnContHome;
        private Wisej.Web.Button btnContNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel13;
        private Wisej.Web.Label label55;
        private Wisej.Web.Label label56;
        private Wisej.Web.Label label42;
        private Wisej.Web.Label label35;
        private Wisej.Web.Label label36;
        private Wisej.Web.Label label37;
        private Wisej.Web.Label label38;
        private Wisej.Web.Label label41;
        private Wisej.Web.Label label43;
        private Wisej.Web.Label label44;
        private Wisej.Web.Label label45;
        private Wisej.Web.Label label46;
        private Wisej.Web.Label label47;
        private Wisej.Web.Label label48;
        private Wisej.Web.CheckBox cbContNDT;
        private Wisej.Web.CheckBox cbContVisual;
        private Wisej.Web.CheckBox cbContDPI;
        private Wisej.Web.CheckBox cbContMPI;
        private Wisej.Web.CheckBox cbContRT;
        private Wisej.Web.CheckBox cbContUT;
        private Wisej.Web.CheckBox cbContHardness;
        private Wisej.Web.CheckBox cbContBend;
        private Wisej.Web.CheckBox cbContTensil;
        private Wisej.Web.CheckBox cbContImpact;
        private Wisej.Web.Label label49;
        private Wisej.Web.CheckBox cbContDT;
        private Wisej.Web.CheckBox cbContMacro;
        private Wisej.Web.Label label50;
        private Wisej.Web.TextBox txtContTechniqueOther;
        private Wisej.Web.TextBox txtContElectrodes;
        private Wisej.Web.TextBox txtContPass;
        private Wisej.Web.TextBox txtContOscillation;
        private Wisej.Web.TextBox Speed;
        private Wisej.Web.TextBox txtContBead;
        private Wisej.Web.TextBox txtContElectricalOther;
        private Wisej.Web.TextBox txtContInput;
        private Wisej.Web.TextBox txtContAmps;
        private Wisej.Web.TextBox txtContPolarity;
        private Wisej.Web.TextBox txtContCurrent;
        private Wisej.Web.TextBox txtContNotes;
        private Wisej.Web.Button btnContBack;
        private Wisej.Web.Button btnRunBack;
        private Wisej.Web.Button btnDetailsBack;
        private Wisej.Web.Button btnInfoBack;
        private Wisej.Web.TabPage tabUpload;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel14;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel22;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel10;
        private Wisej.Web.PictureBox pbUploadSequence;
        private Wisej.Web.PictureBox pbUploadPreparation;
        private Wisej.Web.Upload uplUploadSequence;
        private Wisej.Web.Upload uplUploadPreparation;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel11;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel12;
        private Wisej.Web.Button btnUploadBack;
        private Wisej.Web.Button btnUploadHome;
        private Wisej.Web.Button btnUploadComplete;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel15;
        private Wisej.Web.Label label76;
        private Wisej.Web.Label label57;
    }
}
