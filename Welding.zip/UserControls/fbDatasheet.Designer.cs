﻿namespace WeldingManagement
{
    partial class fbDatasheet
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Boards = new Wisej.Web.TabControl();
            this.tabTestInfo = new Wisej.Web.TabPage();
            this.tableLayoutPanel15 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel16 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel18 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel30 = new Wisej.Web.TableLayoutPanel();
            this.btnInfoBack = new Wisej.Web.Button();
            this.btnInfoHome = new Wisej.Web.Button();
            this.btnInfoNext = new Wisej.Web.Button();
            this.tableLayoutPanel17 = new Wisej.Web.TableLayoutPanel();
            this.txtInfoBatchNo = new Wisej.Web.TextBox();
            this.txtInfoClassification = new Wisej.Web.TextBox();
            this.txtInfoProduct = new Wisej.Web.TextBox();
            this.txtInfoManufacturer = new Wisej.Web.TextBox();
            this.txtInfoNotes = new Wisej.Web.TextBox();
            this.txtInfoAngle = new Wisej.Web.TextBox();
            this.txtInfoGap = new Wisej.Web.TextBox();
            this.txtInfoFace = new Wisej.Web.TextBox();
            this.txtInfoProcess = new Wisej.Web.TextBox();
            this.txtInfoDate = new Wisej.Web.TextBox();
            this.txtInfoWelder = new Wisej.Web.TextBox();
            this.txtInfoHeatNo = new Wisej.Web.TextBox();
            this.txtInfoMatThickness = new Wisej.Web.TextBox();
            this.txtInfoMatGrade = new Wisej.Web.TextBox();
            this.txtInfoMatStandard = new Wisej.Web.TextBox();
            this.txtInfoType = new Wisej.Web.TextBox();
            this.txtInfoDesign = new Wisej.Web.TextBox();
            this.txtInfoStandard = new Wisej.Web.TextBox();
            this.txtInfoJob = new Wisej.Web.TextBox();
            this.txtInfoWPQR = new Wisej.Web.TextBox();
            this.label40 = new Wisej.Web.Label();
            this.label39 = new Wisej.Web.Label();
            this.label38 = new Wisej.Web.Label();
            this.label37 = new Wisej.Web.Label();
            this.label41 = new Wisej.Web.Label();
            this.label42 = new Wisej.Web.Label();
            this.label43 = new Wisej.Web.Label();
            this.label44 = new Wisej.Web.Label();
            this.label45 = new Wisej.Web.Label();
            this.label46 = new Wisej.Web.Label();
            this.label47 = new Wisej.Web.Label();
            this.label48 = new Wisej.Web.Label();
            this.label49 = new Wisej.Web.Label();
            this.label50 = new Wisej.Web.Label();
            this.label51 = new Wisej.Web.Label();
            this.label52 = new Wisej.Web.Label();
            this.label53 = new Wisej.Web.Label();
            this.label54 = new Wisej.Web.Label();
            this.label55 = new Wisej.Web.Label();
            this.label56 = new Wisej.Web.Label();
            this.label57 = new Wisej.Web.Label();
            this.label58 = new Wisej.Web.Label();
            this.label59 = new Wisej.Web.Label();
            this.label60 = new Wisej.Web.Label();
            this.txtInfoPosition = new Wisej.Web.TextBox();
            this.txtInfoPreheat = new Wisej.Web.TextBox();
            this.tableLayoutPanel19 = new Wisej.Web.TableLayoutPanel();
            this.label61 = new Wisej.Web.Label();
            this.label62 = new Wisej.Web.Label();
            this.tabDatasheet = new Wisej.Web.TabPage();
            this.tableLayoutPanel20 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel21 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel23 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel31 = new Wisej.Web.TableLayoutPanel();
            this.btnRunBack = new Wisej.Web.Button();
            this.btnRunAdd = new Wisej.Web.Button();
            this.btnRunHome = new Wisej.Web.Button();
            this.btnRunNext = new Wisej.Web.Button();
            this.tableLayoutPanel22 = new Wisej.Web.TableLayoutPanel();
            this.lvRunParameters = new Wisej.Web.ListView();
            this.chSide = new Wisej.Web.ColumnHeader();
            this.chPass = new Wisej.Web.ColumnHeader();
            this.chDia = new Wisej.Web.ColumnHeader();
            this.chSupply = new Wisej.Web.ColumnHeader();
            this.chAmps = new Wisej.Web.ColumnHeader();
            this.chVolts = new Wisej.Web.ColumnHeader();
            this.chInterpass = new Wisej.Web.ColumnHeader();
            this.chLength = new Wisej.Web.ColumnHeader();
            this.chActual = new Wisej.Web.ColumnHeader();
            this.chWeldTime = new Wisej.Web.ColumnHeader();
            this.chWeldSpeed = new Wisej.Web.ColumnHeader();
            this.chInput = new Wisej.Web.ColumnHeader();
            this.chShield = new Wisej.Web.ColumnHeader();
            this.chPurge = new Wisej.Web.ColumnHeader();
            this.txtRunPurge = new Wisej.Web.TextBox();
            this.txtRunShield = new Wisej.Web.TextBox();
            this.txtRunInput = new Wisej.Web.TextBox();
            this.txtRunActual = new Wisej.Web.TextBox();
            this.txtRunLength = new Wisej.Web.TextBox();
            this.txtRunInterpass = new Wisej.Web.TextBox();
            this.txtRunVolts = new Wisej.Web.TextBox();
            this.txtRunAmps = new Wisej.Web.TextBox();
            this.txtRunSupply = new Wisej.Web.TextBox();
            this.txtRunDia = new Wisej.Web.TextBox();
            this.txtRunPass = new Wisej.Web.TextBox();
            this.txtRunSide = new Wisej.Web.TextBox();
            this.label63 = new Wisej.Web.Label();
            this.label64 = new Wisej.Web.Label();
            this.label65 = new Wisej.Web.Label();
            this.label66 = new Wisej.Web.Label();
            this.label67 = new Wisej.Web.Label();
            this.label68 = new Wisej.Web.Label();
            this.label69 = new Wisej.Web.Label();
            this.label70 = new Wisej.Web.Label();
            this.label71 = new Wisej.Web.Label();
            this.label72 = new Wisej.Web.Label();
            this.label73 = new Wisej.Web.Label();
            this.label74 = new Wisej.Web.Label();
            this.label75 = new Wisej.Web.Label();
            this.label76 = new Wisej.Web.Label();
            this.txtRunSpeed = new Wisej.Web.TextBox();
            this.txtRunTime = new Wisej.Web.TextBox();
            this.tableLayoutPanel24 = new Wisej.Web.TableLayoutPanel();
            this.label77 = new Wisej.Web.Label();
            this.label78 = new Wisej.Web.Label();
            this.tabDrawing = new Wisej.Web.TabPage();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel5 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel8 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel9 = new Wisej.Web.TableLayoutPanel();
            this.cbDrawingFlipV = new Wisej.Web.CheckBox();
            this.cbDrawingFlipH = new Wisej.Web.CheckBox();
            this.txtDrawingAngle = new Wisej.Web.TextBox();
            this.txtDrawingRootFace = new Wisej.Web.TextBox();
            this.label2 = new Wisej.Web.Label();
            this.txtDrawingRotation = new Wisej.Web.TextBox();
            this.label1 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.label4 = new Wisej.Web.Label();
            this.label5 = new Wisej.Web.Label();
            this.pDrawingShapePreview = new Wisej.Web.Panel();
            this.tableLayoutPanel7 = new Wisej.Web.TableLayoutPanel();
            this.pDrawingWeldSequence = new Wisej.Web.Panel();
            this.rbDrawingFlange = new Wisej.Web.RadioButton();
            this.rbDrawingGroove = new Wisej.Web.RadioButton();
            this.rbDrawingBevel = new Wisej.Web.RadioButton();
            this.rbDrawingWeld = new Wisej.Web.RadioButton();
            this.rbDrawingRectangle = new Wisej.Web.RadioButton();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel4 = new Wisej.Web.TableLayoutPanel();
            this.btnDrawingUndo = new Wisej.Web.Button();
            this.btnDrawingBack = new Wisej.Web.Button();
            this.btnDrawingHome = new Wisej.Web.Button();
            this.btnDrawingComplete = new Wisej.Web.Button();
            this.tableLayoutPanel6 = new Wisej.Web.TableLayoutPanel();
            this.label15 = new Wisej.Web.Label();
            this.label16 = new Wisej.Web.Label();
            this.uplDrawingUpload = new Wisej.Web.Upload();
            this.Boards.SuspendLayout();
            this.tabTestInfo.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.tabDatasheet.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.tabDrawing.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // Boards
            // 
            this.Boards.Alignment = Wisej.Web.TabAlignment.Top;
            this.Boards.BorderStyle = Wisej.Web.BorderStyle.None;
            this.Boards.Controls.Add(this.tabTestInfo);
            this.Boards.Controls.Add(this.tabDatasheet);
            this.Boards.Controls.Add(this.tabDrawing);
            this.Boards.Display = Wisej.Web.Display.Label;
            this.Boards.Dock = Wisej.Web.DockStyle.Fill;
            this.Boards.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Boards.Location = new System.Drawing.Point(0, 0);
            this.Boards.Name = "Boards";
            this.Boards.Orientation = Wisej.Web.Orientation.Horizontal;
            this.Boards.PageInsets = new Wisej.Web.Padding(0, 35, 0, 0);
            this.Boards.SelectedIndex = 0;
            this.Boards.Size = new System.Drawing.Size(1212, 650);
            this.Boards.TabIndex = 2;
            this.Boards.TabStop = false;
            this.Boards.Selecting += new Wisej.Web.TabControlCancelEventHandler(this.Boards_Selecting);
            // 
            // tabTestInfo
            // 
            this.tabTestInfo.Controls.Add(this.tableLayoutPanel15);
            this.tabTestInfo.Location = new System.Drawing.Point(0, 35);
            this.tabTestInfo.Name = "tabTestInfo";
            this.tabTestInfo.Size = new System.Drawing.Size(1212, 615);
            this.tabTestInfo.Text = "Info";
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 3;
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.Controls.Add(this.tableLayoutPanel16, 1, 3);
            this.tableLayoutPanel15.Controls.Add(this.tableLayoutPanel19, 1, 1);
            this.tableLayoutPanel15.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 5;
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel15.TabIndex = 2;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel16.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel18, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel17, 0, 0);
            this.tableLayoutPanel16.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel16.TabIndex = 1;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 1;
            this.tableLayoutPanel18.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Controls.Add(this.tableLayoutPanel30, 0, 0);
            this.tableLayoutPanel18.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel18.TabIndex = 5;
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel30.ColumnCount = 1;
            this.tableLayoutPanel30.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel30.Controls.Add(this.btnInfoBack, 0, 2);
            this.tableLayoutPanel30.Controls.Add(this.btnInfoHome, 0, 3);
            this.tableLayoutPanel30.Controls.Add(this.btnInfoNext, 0, 4);
            this.tableLayoutPanel30.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel30.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 5;
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel30.TabIndex = 4;
            // 
            // btnInfoBack
            // 
            this.btnInfoBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoBack.Location = new System.Drawing.Point(3, 173);
            this.btnInfoBack.Name = "btnInfoBack";
            this.btnInfoBack.Size = new System.Drawing.Size(95, 79);
            this.btnInfoBack.TabIndex = 3;
            this.btnInfoBack.Text = "Back";
            this.btnInfoBack.Click += new System.EventHandler(this.btnInfoBack_Click);
            // 
            // btnInfoHome
            // 
            this.btnInfoHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoHome.Location = new System.Drawing.Point(3, 258);
            this.btnInfoHome.Name = "btnInfoHome";
            this.btnInfoHome.Size = new System.Drawing.Size(95, 79);
            this.btnInfoHome.TabIndex = 1;
            this.btnInfoHome.Text = "Home";
            this.btnInfoHome.Click += new System.EventHandler(this.btnInfoHome_Click);
            // 
            // btnInfoNext
            // 
            this.btnInfoNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoNext.Location = new System.Drawing.Point(3, 343);
            this.btnInfoNext.Name = "btnInfoNext";
            this.btnInfoNext.Size = new System.Drawing.Size(95, 79);
            this.btnInfoNext.TabIndex = 0;
            this.btnInfoNext.Text = "Next";
            this.btnInfoNext.Click += new System.EventHandler(this.btnInfoNext_Click);
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 4;
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.Controls.Add(this.txtInfoBatchNo, 3, 11);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoClassification, 3, 10);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoProduct, 3, 9);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoManufacturer, 3, 8);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoNotes, 3, 6);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoAngle, 3, 5);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoGap, 3, 4);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoFace, 3, 3);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoProcess, 3, 2);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoDate, 3, 1);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoWelder, 3, 0);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoHeatNo, 1, 11);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoMatThickness, 1, 10);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoMatGrade, 1, 9);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoMatStandard, 1, 8);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoType, 1, 4);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoDesign, 1, 3);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoStandard, 1, 2);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoJob, 1, 1);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoWPQR, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.label40, 2, 11);
            this.tableLayoutPanel17.Controls.Add(this.label39, 2, 10);
            this.tableLayoutPanel17.Controls.Add(this.label38, 2, 9);
            this.tableLayoutPanel17.Controls.Add(this.label37, 2, 8);
            this.tableLayoutPanel17.Controls.Add(this.label41, 2, 7);
            this.tableLayoutPanel17.Controls.Add(this.label42, 2, 6);
            this.tableLayoutPanel17.Controls.Add(this.label43, 2, 5);
            this.tableLayoutPanel17.Controls.Add(this.label44, 2, 4);
            this.tableLayoutPanel17.Controls.Add(this.label45, 2, 3);
            this.tableLayoutPanel17.Controls.Add(this.label46, 2, 2);
            this.tableLayoutPanel17.Controls.Add(this.label47, 2, 1);
            this.tableLayoutPanel17.Controls.Add(this.label48, 2, 0);
            this.tableLayoutPanel17.Controls.Add(this.label49, 0, 11);
            this.tableLayoutPanel17.Controls.Add(this.label50, 0, 10);
            this.tableLayoutPanel17.Controls.Add(this.label51, 0, 9);
            this.tableLayoutPanel17.Controls.Add(this.label52, 0, 8);
            this.tableLayoutPanel17.Controls.Add(this.label53, 0, 7);
            this.tableLayoutPanel17.Controls.Add(this.label54, 0, 6);
            this.tableLayoutPanel17.Controls.Add(this.label55, 0, 5);
            this.tableLayoutPanel17.Controls.Add(this.label56, 0, 4);
            this.tableLayoutPanel17.Controls.Add(this.label57, 0, 3);
            this.tableLayoutPanel17.Controls.Add(this.label58, 0, 2);
            this.tableLayoutPanel17.Controls.Add(this.label59, 0, 1);
            this.tableLayoutPanel17.Controls.Add(this.label60, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoPosition, 1, 5);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoPreheat, 1, 6);
            this.tableLayoutPanel17.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 12;
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel17.TabIndex = 4;
            // 
            // txtInfoBatchNo
            // 
            this.txtInfoBatchNo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoBatchNo.Location = new System.Drawing.Point(771, 399);
            this.txtInfoBatchNo.Name = "txtInfoBatchNo";
            this.txtInfoBatchNo.Size = new System.Drawing.Size(250, 31);
            this.txtInfoBatchNo.TabIndex = 47;
            // 
            // txtInfoClassification
            // 
            this.txtInfoClassification.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoClassification.Location = new System.Drawing.Point(771, 363);
            this.txtInfoClassification.Name = "txtInfoClassification";
            this.txtInfoClassification.Size = new System.Drawing.Size(250, 30);
            this.txtInfoClassification.TabIndex = 46;
            // 
            // txtInfoProduct
            // 
            this.txtInfoProduct.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoProduct.Location = new System.Drawing.Point(771, 327);
            this.txtInfoProduct.Name = "txtInfoProduct";
            this.txtInfoProduct.Size = new System.Drawing.Size(250, 30);
            this.txtInfoProduct.TabIndex = 45;
            // 
            // txtInfoManufacturer
            // 
            this.txtInfoManufacturer.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoManufacturer.Location = new System.Drawing.Point(771, 291);
            this.txtInfoManufacturer.Name = "txtInfoManufacturer";
            this.txtInfoManufacturer.Size = new System.Drawing.Size(250, 30);
            this.txtInfoManufacturer.TabIndex = 44;
            // 
            // txtInfoNotes
            // 
            this.txtInfoNotes.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoNotes.Location = new System.Drawing.Point(771, 219);
            this.txtInfoNotes.Name = "txtInfoNotes";
            this.txtInfoNotes.Size = new System.Drawing.Size(250, 30);
            this.txtInfoNotes.TabIndex = 42;
            // 
            // txtInfoAngle
            // 
            this.txtInfoAngle.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoAngle.Location = new System.Drawing.Point(771, 183);
            this.txtInfoAngle.Name = "txtInfoAngle";
            this.txtInfoAngle.Size = new System.Drawing.Size(250, 30);
            this.txtInfoAngle.TabIndex = 41;
            // 
            // txtInfoGap
            // 
            this.txtInfoGap.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoGap.Location = new System.Drawing.Point(771, 147);
            this.txtInfoGap.Name = "txtInfoGap";
            this.txtInfoGap.Size = new System.Drawing.Size(250, 30);
            this.txtInfoGap.TabIndex = 40;
            // 
            // txtInfoFace
            // 
            this.txtInfoFace.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoFace.Location = new System.Drawing.Point(771, 111);
            this.txtInfoFace.Name = "txtInfoFace";
            this.txtInfoFace.Size = new System.Drawing.Size(250, 30);
            this.txtInfoFace.TabIndex = 39;
            // 
            // txtInfoProcess
            // 
            this.txtInfoProcess.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoProcess.Location = new System.Drawing.Point(771, 75);
            this.txtInfoProcess.Name = "txtInfoProcess";
            this.txtInfoProcess.Size = new System.Drawing.Size(250, 30);
            this.txtInfoProcess.TabIndex = 38;
            // 
            // txtInfoDate
            // 
            this.txtInfoDate.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoDate.Location = new System.Drawing.Point(771, 39);
            this.txtInfoDate.Name = "txtInfoDate";
            this.txtInfoDate.Size = new System.Drawing.Size(250, 30);
            this.txtInfoDate.TabIndex = 37;
            // 
            // txtInfoWelder
            // 
            this.txtInfoWelder.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoWelder.Location = new System.Drawing.Point(771, 3);
            this.txtInfoWelder.Name = "txtInfoWelder";
            this.txtInfoWelder.Size = new System.Drawing.Size(250, 30);
            this.txtInfoWelder.TabIndex = 36;
            // 
            // txtInfoHeatNo
            // 
            this.txtInfoHeatNo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoHeatNo.Location = new System.Drawing.Point(259, 399);
            this.txtInfoHeatNo.Name = "txtInfoHeatNo";
            this.txtInfoHeatNo.Size = new System.Drawing.Size(250, 31);
            this.txtInfoHeatNo.TabIndex = 35;
            // 
            // txtInfoMatThickness
            // 
            this.txtInfoMatThickness.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatThickness.Location = new System.Drawing.Point(259, 363);
            this.txtInfoMatThickness.Name = "txtInfoMatThickness";
            this.txtInfoMatThickness.Size = new System.Drawing.Size(250, 30);
            this.txtInfoMatThickness.TabIndex = 34;
            // 
            // txtInfoMatGrade
            // 
            this.txtInfoMatGrade.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatGrade.Location = new System.Drawing.Point(259, 327);
            this.txtInfoMatGrade.Name = "txtInfoMatGrade";
            this.txtInfoMatGrade.Size = new System.Drawing.Size(250, 30);
            this.txtInfoMatGrade.TabIndex = 33;
            // 
            // txtInfoMatStandard
            // 
            this.txtInfoMatStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatStandard.Location = new System.Drawing.Point(259, 291);
            this.txtInfoMatStandard.Name = "txtInfoMatStandard";
            this.txtInfoMatStandard.Size = new System.Drawing.Size(250, 30);
            this.txtInfoMatStandard.TabIndex = 32;
            // 
            // txtInfoType
            // 
            this.txtInfoType.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoType.Location = new System.Drawing.Point(259, 147);
            this.txtInfoType.Name = "txtInfoType";
            this.txtInfoType.Size = new System.Drawing.Size(250, 30);
            this.txtInfoType.TabIndex = 28;
            // 
            // txtInfoDesign
            // 
            this.txtInfoDesign.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoDesign.Location = new System.Drawing.Point(259, 111);
            this.txtInfoDesign.Name = "txtInfoDesign";
            this.txtInfoDesign.Size = new System.Drawing.Size(250, 30);
            this.txtInfoDesign.TabIndex = 27;
            // 
            // txtInfoStandard
            // 
            this.txtInfoStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoStandard.Location = new System.Drawing.Point(259, 75);
            this.txtInfoStandard.Name = "txtInfoStandard";
            this.txtInfoStandard.Size = new System.Drawing.Size(250, 30);
            this.txtInfoStandard.TabIndex = 26;
            // 
            // txtInfoJob
            // 
            this.txtInfoJob.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoJob.Location = new System.Drawing.Point(259, 39);
            this.txtInfoJob.Name = "txtInfoJob";
            this.txtInfoJob.Size = new System.Drawing.Size(250, 30);
            this.txtInfoJob.TabIndex = 25;
            // 
            // txtInfoWPQR
            // 
            this.txtInfoWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoWPQR.Location = new System.Drawing.Point(259, 3);
            this.txtInfoWPQR.Name = "txtInfoWPQR";
            this.txtInfoWPQR.Size = new System.Drawing.Size(250, 30);
            this.txtInfoWPQR.TabIndex = 24;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = Wisej.Web.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(515, 399);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(250, 31);
            this.label40.TabIndex = 23;
            this.label40.Text = "Batch / Cast Number";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Dock = Wisej.Web.DockStyle.Fill;
            this.label39.Location = new System.Drawing.Point(515, 363);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(250, 30);
            this.label39.TabIndex = 22;
            this.label39.Text = "Classification";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = Wisej.Web.DockStyle.Fill;
            this.label38.Location = new System.Drawing.Point(515, 327);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(250, 30);
            this.label38.TabIndex = 21;
            this.label38.Text = "Product Name";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Dock = Wisej.Web.DockStyle.Fill;
            this.label37.Location = new System.Drawing.Point(515, 291);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(250, 30);
            this.label37.TabIndex = 20;
            this.label37.Text = "Manufacturer";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label41.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel17.SetColumnSpan(this.label41, 2);
            this.label41.Dock = Wisej.Web.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(515, 255);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(506, 30);
            this.label41.TabIndex = 19;
            this.label41.Text = "Consumable Details";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = Wisej.Web.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(515, 219);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(250, 30);
            this.label42.TabIndex = 18;
            this.label42.Text = "Notes";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Dock = Wisej.Web.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(515, 183);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(250, 30);
            this.label43.TabIndex = 17;
            this.label43.Text = "Included Angle (°)";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = Wisej.Web.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(515, 147);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(250, 30);
            this.label44.TabIndex = 16;
            this.label44.Text = "Root Gap (mm)";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = Wisej.Web.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(515, 111);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(250, 30);
            this.label45.TabIndex = 15;
            this.label45.Text = "Root Face (mm)";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Dock = Wisej.Web.DockStyle.Fill;
            this.label46.Location = new System.Drawing.Point(515, 75);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(250, 30);
            this.label46.TabIndex = 14;
            this.label46.Text = "Welding Process";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Dock = Wisej.Web.DockStyle.Fill;
            this.label47.Location = new System.Drawing.Point(515, 39);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(250, 30);
            this.label47.TabIndex = 13;
            this.label47.Text = "Date";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = Wisej.Web.DockStyle.Fill;
            this.label48.Location = new System.Drawing.Point(515, 3);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(250, 30);
            this.label48.TabIndex = 12;
            this.label48.Text = "Welder ID";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Dock = Wisej.Web.DockStyle.Fill;
            this.label49.Location = new System.Drawing.Point(3, 399);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(250, 31);
            this.label49.TabIndex = 11;
            this.label49.Text = "Platecast / Heat Number";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Dock = Wisej.Web.DockStyle.Fill;
            this.label50.Location = new System.Drawing.Point(3, 363);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(250, 30);
            this.label50.TabIndex = 10;
            this.label50.Text = "Thickness (mm)";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Dock = Wisej.Web.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(3, 327);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(250, 30);
            this.label51.TabIndex = 9;
            this.label51.Text = "Material Grade";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Dock = Wisej.Web.DockStyle.Fill;
            this.label52.Location = new System.Drawing.Point(3, 291);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(250, 30);
            this.label52.TabIndex = 8;
            this.label52.Text = "Material Standard";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label53.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel17.SetColumnSpan(this.label53, 2);
            this.label53.Dock = Wisej.Web.DockStyle.Fill;
            this.label53.Location = new System.Drawing.Point(3, 255);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(506, 30);
            this.label53.TabIndex = 7;
            this.label53.Text = "Material Details";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Dock = Wisej.Web.DockStyle.Fill;
            this.label54.Location = new System.Drawing.Point(3, 219);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(250, 30);
            this.label54.TabIndex = 6;
            this.label54.Text = "Preheat (°)";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Dock = Wisej.Web.DockStyle.Fill;
            this.label55.Location = new System.Drawing.Point(3, 183);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(250, 30);
            this.label55.TabIndex = 5;
            this.label55.Text = "Welding Position";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Dock = Wisej.Web.DockStyle.Fill;
            this.label56.Location = new System.Drawing.Point(3, 147);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(250, 30);
            this.label56.TabIndex = 4;
            this.label56.Text = "Joint Type";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Dock = Wisej.Web.DockStyle.Fill;
            this.label57.Location = new System.Drawing.Point(3, 111);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(250, 30);
            this.label57.TabIndex = 3;
            this.label57.Text = "Joint Design";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Dock = Wisej.Web.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(3, 75);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(250, 30);
            this.label58.TabIndex = 2;
            this.label58.Text = "Welding Standard";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Dock = Wisej.Web.DockStyle.Fill;
            this.label59.Location = new System.Drawing.Point(3, 39);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(250, 30);
            this.label59.TabIndex = 1;
            this.label59.Text = "Job Number";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Dock = Wisej.Web.DockStyle.Fill;
            this.label60.Location = new System.Drawing.Point(3, 3);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(250, 30);
            this.label60.TabIndex = 0;
            this.label60.Text = "WPQR Number";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtInfoPosition
            // 
            this.txtInfoPosition.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPosition.Location = new System.Drawing.Point(259, 183);
            this.txtInfoPosition.Name = "txtInfoPosition";
            this.txtInfoPosition.Size = new System.Drawing.Size(250, 30);
            this.txtInfoPosition.TabIndex = 29;
            // 
            // txtInfoPreheat
            // 
            this.txtInfoPreheat.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPreheat.Location = new System.Drawing.Point(259, 219);
            this.txtInfoPreheat.Name = "txtInfoPreheat";
            this.txtInfoPreheat.Size = new System.Drawing.Size(250, 30);
            this.txtInfoPreheat.TabIndex = 30;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 1;
            this.tableLayoutPanel19.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel19.Controls.Add(this.label61, 0, 1);
            this.tableLayoutPanel19.Controls.Add(this.label62, 0, 0);
            this.tableLayoutPanel19.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 2;
            this.tableLayoutPanel19.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel19.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel19.TabIndex = 0;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label61.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label61.Dock = Wisej.Web.DockStyle.Fill;
            this.label61.Location = new System.Drawing.Point(3, 79);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(1139, 35);
            this.label61.TabIndex = 1;
            this.label61.Text = "Notes";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label62.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label62.Dock = Wisej.Web.DockStyle.Fill;
            this.label62.Location = new System.Drawing.Point(3, 3);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(1139, 70);
            this.label62.TabIndex = 0;
            this.label62.Text = "Welding Test Datasheet Information";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabDatasheet
            // 
            this.tabDatasheet.Controls.Add(this.tableLayoutPanel20);
            this.tabDatasheet.Location = new System.Drawing.Point(0, 35);
            this.tabDatasheet.Name = "tabDatasheet";
            this.tabDatasheet.Size = new System.Drawing.Size(1212, 615);
            this.tabDatasheet.Text = "Run";
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.ColumnCount = 3;
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel21, 1, 3);
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel24, 1, 1);
            this.tableLayoutPanel20.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 5;
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel20.TabIndex = 3;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel21.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel23, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel22, 0, 0);
            this.tableLayoutPanel21.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel21.TabIndex = 1;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 1;
            this.tableLayoutPanel23.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Controls.Add(this.tableLayoutPanel31, 0, 0);
            this.tableLayoutPanel23.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel23.TabIndex = 5;
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel31.ColumnCount = 1;
            this.tableLayoutPanel31.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel31.Controls.Add(this.btnRunBack, 0, 2);
            this.tableLayoutPanel31.Controls.Add(this.btnRunAdd, 0, 1);
            this.tableLayoutPanel31.Controls.Add(this.btnRunHome, 0, 3);
            this.tableLayoutPanel31.Controls.Add(this.btnRunNext, 0, 4);
            this.tableLayoutPanel31.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel31.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 5;
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel31.TabIndex = 4;
            // 
            // btnRunBack
            // 
            this.btnRunBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunBack.Location = new System.Drawing.Point(3, 173);
            this.btnRunBack.Name = "btnRunBack";
            this.btnRunBack.Size = new System.Drawing.Size(95, 79);
            this.btnRunBack.TabIndex = 3;
            this.btnRunBack.Text = "Back";
            this.btnRunBack.Click += new System.EventHandler(this.btnRunBack_Click);
            // 
            // btnRunAdd
            // 
            this.btnRunAdd.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunAdd.Location = new System.Drawing.Point(3, 88);
            this.btnRunAdd.Name = "btnRunAdd";
            this.btnRunAdd.Size = new System.Drawing.Size(95, 79);
            this.btnRunAdd.TabIndex = 2;
            this.btnRunAdd.Text = "Add Run";
            this.btnRunAdd.Click += new System.EventHandler(this.btnRunAdd_Click);
            // 
            // btnRunHome
            // 
            this.btnRunHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunHome.Location = new System.Drawing.Point(3, 258);
            this.btnRunHome.Name = "btnRunHome";
            this.btnRunHome.Size = new System.Drawing.Size(95, 79);
            this.btnRunHome.TabIndex = 1;
            this.btnRunHome.Text = "Home";
            this.btnRunHome.Click += new System.EventHandler(this.btnRunHome_Click);
            // 
            // btnRunNext
            // 
            this.btnRunNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunNext.Location = new System.Drawing.Point(3, 343);
            this.btnRunNext.Name = "btnRunNext";
            this.btnRunNext.Size = new System.Drawing.Size(95, 79);
            this.btnRunNext.TabIndex = 0;
            this.btnRunNext.Text = "Next";
            this.btnRunNext.Click += new System.EventHandler(this.btnRunNext_Click);
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 14;
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.Controls.Add(this.lvRunParameters, 0, 2);
            this.tableLayoutPanel22.Controls.Add(this.txtRunPurge, 13, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunShield, 12, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunInput, 11, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunActual, 8, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunLength, 7, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunInterpass, 6, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunVolts, 5, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunAmps, 4, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunSupply, 3, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunDia, 2, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunPass, 1, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunSide, 0, 1);
            this.tableLayoutPanel22.Controls.Add(this.label63, 13, 0);
            this.tableLayoutPanel22.Controls.Add(this.label64, 12, 0);
            this.tableLayoutPanel22.Controls.Add(this.label65, 11, 0);
            this.tableLayoutPanel22.Controls.Add(this.label66, 10, 0);
            this.tableLayoutPanel22.Controls.Add(this.label67, 9, 0);
            this.tableLayoutPanel22.Controls.Add(this.label68, 8, 0);
            this.tableLayoutPanel22.Controls.Add(this.label69, 7, 0);
            this.tableLayoutPanel22.Controls.Add(this.label70, 6, 0);
            this.tableLayoutPanel22.Controls.Add(this.label71, 5, 0);
            this.tableLayoutPanel22.Controls.Add(this.label72, 4, 0);
            this.tableLayoutPanel22.Controls.Add(this.label73, 3, 0);
            this.tableLayoutPanel22.Controls.Add(this.label74, 2, 0);
            this.tableLayoutPanel22.Controls.Add(this.label75, 1, 0);
            this.tableLayoutPanel22.Controls.Add(this.label76, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.txtRunSpeed, 10, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtRunTime, 9, 1);
            this.tableLayoutPanel22.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 3;
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 60F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel22.TabIndex = 4;
            // 
            // lvRunParameters
            // 
            this.lvRunParameters.Columns.AddRange(new Wisej.Web.ColumnHeader[] {
            this.chSide,
            this.chPass,
            this.chDia,
            this.chSupply,
            this.chAmps,
            this.chVolts,
            this.chInterpass,
            this.chLength,
            this.chActual,
            this.chWeldTime,
            this.chWeldSpeed,
            this.chInput,
            this.chShield,
            this.chPurge});
            this.tableLayoutPanel22.SetColumnSpan(this.lvRunParameters, 14);
            this.lvRunParameters.Dock = Wisej.Web.DockStyle.Fill;
            this.lvRunParameters.Location = new System.Drawing.Point(3, 175);
            this.lvRunParameters.Name = "lvRunParameters";
            this.lvRunParameters.Size = new System.Drawing.Size(1018, 255);
            this.lvRunParameters.TabIndex = 28;
            // 
            // chSide
            // 
            this.chSide.Name = "chSide";
            this.chSide.Text = "Side";
            // 
            // chPass
            // 
            this.chPass.Name = "chPass";
            this.chPass.Text = "Pass";
            // 
            // chDia
            // 
            this.chDia.Name = "chDia";
            this.chDia.Text = "Dia";
            // 
            // chSupply
            // 
            this.chSupply.Name = "chSupply";
            this.chSupply.Text = "Supply";
            // 
            // chAmps
            // 
            this.chAmps.Name = "chAmps";
            this.chAmps.Text = "Amps";
            // 
            // chVolts
            // 
            this.chVolts.Name = "chVolts";
            this.chVolts.Text = "Volts";
            // 
            // chInterpass
            // 
            this.chInterpass.Name = "chInterpass";
            this.chInterpass.Text = "Interpass";
            // 
            // chLength
            // 
            this.chLength.Name = "chLength";
            this.chLength.Text = "Length";
            // 
            // chActual
            // 
            this.chActual.Name = "chActual";
            this.chActual.Text = "Actual";
            // 
            // chWeldTime
            // 
            this.chWeldTime.Name = "chWeldTime";
            this.chWeldTime.Text = "Weld Time";
            // 
            // chWeldSpeed
            // 
            this.chWeldSpeed.Name = "chWeldSpeed";
            this.chWeldSpeed.Text = "Weld Speed";
            // 
            // chInput
            // 
            this.chInput.Name = "chInput";
            this.chInput.Text = "Input";
            // 
            // chShield
            // 
            this.chShield.Name = "chShield";
            this.chShield.Text = "Shield Gas";
            // 
            // chPurge
            // 
            this.chPurge.Name = "chPurge";
            this.chPurge.Text = "Purge Gas";
            // 
            // txtRunPurge
            // 
            this.txtRunPurge.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunPurge.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunPurge.Location = new System.Drawing.Point(952, 89);
            this.txtRunPurge.Name = "txtRunPurge";
            this.txtRunPurge.Size = new System.Drawing.Size(69, 80);
            this.txtRunPurge.TabIndex = 27;
            this.txtRunPurge.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunShield
            // 
            this.txtRunShield.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunShield.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunShield.Location = new System.Drawing.Point(879, 89);
            this.txtRunShield.Name = "txtRunShield";
            this.txtRunShield.Size = new System.Drawing.Size(67, 80);
            this.txtRunShield.TabIndex = 26;
            this.txtRunShield.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunInput
            // 
            this.txtRunInput.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunInput.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunInput.Location = new System.Drawing.Point(806, 89);
            this.txtRunInput.Name = "txtRunInput";
            this.txtRunInput.ReadOnly = true;
            this.txtRunInput.Size = new System.Drawing.Size(67, 80);
            this.txtRunInput.TabIndex = 25;
            this.txtRunInput.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunActual
            // 
            this.txtRunActual.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunActual.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunActual.Location = new System.Drawing.Point(587, 89);
            this.txtRunActual.Name = "txtRunActual";
            this.txtRunActual.Size = new System.Drawing.Size(67, 80);
            this.txtRunActual.TabIndex = 22;
            this.txtRunActual.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunLength
            // 
            this.txtRunLength.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunLength.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunLength.Location = new System.Drawing.Point(514, 89);
            this.txtRunLength.Name = "txtRunLength";
            this.txtRunLength.Size = new System.Drawing.Size(67, 80);
            this.txtRunLength.TabIndex = 21;
            this.txtRunLength.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunInterpass
            // 
            this.txtRunInterpass.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunInterpass.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunInterpass.Location = new System.Drawing.Point(441, 89);
            this.txtRunInterpass.Name = "txtRunInterpass";
            this.txtRunInterpass.Size = new System.Drawing.Size(67, 80);
            this.txtRunInterpass.TabIndex = 20;
            this.txtRunInterpass.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunVolts
            // 
            this.txtRunVolts.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunVolts.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunVolts.Location = new System.Drawing.Point(368, 89);
            this.txtRunVolts.Name = "txtRunVolts";
            this.txtRunVolts.Size = new System.Drawing.Size(67, 80);
            this.txtRunVolts.TabIndex = 19;
            this.txtRunVolts.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunAmps
            // 
            this.txtRunAmps.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunAmps.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunAmps.Location = new System.Drawing.Point(295, 89);
            this.txtRunAmps.Name = "txtRunAmps";
            this.txtRunAmps.Size = new System.Drawing.Size(67, 80);
            this.txtRunAmps.TabIndex = 18;
            this.txtRunAmps.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunSupply
            // 
            this.txtRunSupply.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunSupply.Location = new System.Drawing.Point(222, 89);
            this.txtRunSupply.Name = "txtRunSupply";
            this.txtRunSupply.Size = new System.Drawing.Size(67, 80);
            this.txtRunSupply.TabIndex = 17;
            this.txtRunSupply.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunDia
            // 
            this.txtRunDia.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunDia.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunDia.Location = new System.Drawing.Point(149, 89);
            this.txtRunDia.Name = "txtRunDia";
            this.txtRunDia.Size = new System.Drawing.Size(67, 80);
            this.txtRunDia.TabIndex = 16;
            this.txtRunDia.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunPass
            // 
            this.txtRunPass.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunPass.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunPass.Location = new System.Drawing.Point(76, 89);
            this.txtRunPass.Name = "txtRunPass";
            this.txtRunPass.Size = new System.Drawing.Size(67, 80);
            this.txtRunPass.TabIndex = 15;
            this.txtRunPass.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunSide
            // 
            this.txtRunSide.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunSide.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunSide.Location = new System.Drawing.Point(3, 89);
            this.txtRunSide.Name = "txtRunSide";
            this.txtRunSide.Size = new System.Drawing.Size(67, 80);
            this.txtRunSide.TabIndex = 14;
            this.txtRunSide.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label63.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label63.Dock = Wisej.Web.DockStyle.Fill;
            this.label63.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label63.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label63.Location = new System.Drawing.Point(952, 3);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(69, 80);
            this.label63.TabIndex = 13;
            this.label63.Text = "Purge Gas \r\nL/min";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label64.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label64.Dock = Wisej.Web.DockStyle.Fill;
            this.label64.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label64.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label64.Location = new System.Drawing.Point(879, 3);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(67, 80);
            this.label64.TabIndex = 12;
            this.label64.Text = "Shield Gas \r\nL/min";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label65.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label65.Dock = Wisej.Web.DockStyle.Fill;
            this.label65.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label65.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label65.Location = new System.Drawing.Point(806, 3);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(67, 80);
            this.label65.TabIndex = 11;
            this.label65.Text = "Energy Input kJ/mm";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label66.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label66.Dock = Wisej.Web.DockStyle.Fill;
            this.label66.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label66.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label66.Location = new System.Drawing.Point(733, 3);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(67, 80);
            this.label66.TabIndex = 10;
            this.label66.Text = "Weld Speed mm/min";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label67.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label67.Dock = Wisej.Web.DockStyle.Fill;
            this.label67.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label67.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label67.Location = new System.Drawing.Point(660, 3);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(67, 80);
            this.label67.TabIndex = 9;
            this.label67.Text = "Weld Time \r\ns";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label68.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label68.Dock = Wisej.Web.DockStyle.Fill;
            this.label68.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label68.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label68.Location = new System.Drawing.Point(587, 3);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(67, 80);
            this.label68.TabIndex = 8;
            this.label68.Text = "Actual Length";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label69.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label69.Dock = Wisej.Web.DockStyle.Fill;
            this.label69.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label69.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label69.Location = new System.Drawing.Point(514, 3);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(67, 80);
            this.label69.TabIndex = 7;
            this.label69.Text = "Length";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label70.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label70.Dock = Wisej.Web.DockStyle.Fill;
            this.label70.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label70.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label70.Location = new System.Drawing.Point(441, 3);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(67, 80);
            this.label70.TabIndex = 6;
            this.label70.Text = "Interpass Temp\r\n°C";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label71.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label71.Dock = Wisej.Web.DockStyle.Fill;
            this.label71.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label71.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label71.Location = new System.Drawing.Point(368, 3);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(67, 80);
            this.label71.TabIndex = 5;
            this.label71.Text = "Volts";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label72.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label72.Dock = Wisej.Web.DockStyle.Fill;
            this.label72.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label72.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label72.Location = new System.Drawing.Point(295, 3);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(67, 80);
            this.label72.TabIndex = 4;
            this.label72.Text = "Amps";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label73.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label73.Dock = Wisej.Web.DockStyle.Fill;
            this.label73.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label73.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label73.Location = new System.Drawing.Point(222, 3);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(67, 80);
            this.label73.TabIndex = 3;
            this.label73.Text = "Supply";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label74.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label74.Dock = Wisej.Web.DockStyle.Fill;
            this.label74.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label74.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label74.Location = new System.Drawing.Point(149, 3);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(67, 80);
            this.label74.TabIndex = 2;
            this.label74.Text = "Filler Dia \r\nmm";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label75.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label75.Dock = Wisej.Web.DockStyle.Fill;
            this.label75.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label75.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label75.Location = new System.Drawing.Point(76, 3);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(67, 80);
            this.label75.TabIndex = 1;
            this.label75.Text = "Pass Number";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label76.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label76.Dock = Wisej.Web.DockStyle.Fill;
            this.label76.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label76.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label76.Location = new System.Drawing.Point(3, 3);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(67, 80);
            this.label76.TabIndex = 0;
            this.label76.Text = "Side";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtRunSpeed
            // 
            this.txtRunSpeed.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunSpeed.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunSpeed.Location = new System.Drawing.Point(733, 89);
            this.txtRunSpeed.Name = "txtRunSpeed";
            this.txtRunSpeed.ReadOnly = true;
            this.txtRunSpeed.Size = new System.Drawing.Size(67, 80);
            this.txtRunSpeed.TabIndex = 24;
            this.txtRunSpeed.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // txtRunTime
            // 
            this.txtRunTime.Dock = Wisej.Web.DockStyle.Fill;
            this.txtRunTime.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtRunTime.Location = new System.Drawing.Point(660, 89);
            this.txtRunTime.Name = "txtRunTime";
            this.txtRunTime.Size = new System.Drawing.Size(67, 80);
            this.txtRunTime.TabIndex = 23;
            this.txtRunTime.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 1;
            this.tableLayoutPanel24.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel24.Controls.Add(this.label77, 0, 1);
            this.tableLayoutPanel24.Controls.Add(this.label78, 0, 0);
            this.tableLayoutPanel24.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 2;
            this.tableLayoutPanel24.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel24.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel24.TabIndex = 0;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label77.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label77.Dock = Wisej.Web.DockStyle.Fill;
            this.label77.Location = new System.Drawing.Point(3, 79);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(1139, 35);
            this.label77.TabIndex = 1;
            this.label77.Text = "Double click to remove run";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label78.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label78.Dock = Wisej.Web.DockStyle.Fill;
            this.label78.Location = new System.Drawing.Point(3, 3);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(1139, 70);
            this.label78.TabIndex = 0;
            this.label78.Text = "Welding Test Datasheet Parameters";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabDrawing
            // 
            this.tabDrawing.Controls.Add(this.tableLayoutPanel1);
            this.tabDrawing.Location = new System.Drawing.Point(0, 35);
            this.tabDrawing.Name = "tabDrawing";
            this.tabDrawing.Size = new System.Drawing.Size(1212, 615);
            this.tabDrawing.Text = "Drawing";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel6, 1, 1);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 1, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 80F));
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel8, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel7, 1, 0);
            this.tableLayoutPanel5.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel5.TabIndex = 6;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel9, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.pDrawingShapePreview, 0, 1);
            this.tableLayoutPanel8.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(198, 427);
            this.tableLayoutPanel8.TabIndex = 8;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel9.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.cbDrawingFlipV, 1, 4);
            this.tableLayoutPanel9.Controls.Add(this.cbDrawingFlipH, 1, 3);
            this.tableLayoutPanel9.Controls.Add(this.txtDrawingAngle, 1, 2);
            this.tableLayoutPanel9.Controls.Add(this.txtDrawingRootFace, 1, 1);
            this.tableLayoutPanel9.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.txtDrawingRotation, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel9.Controls.Add(this.label4, 0, 3);
            this.tableLayoutPanel9.Controls.Add(this.label5, 0, 4);
            this.tableLayoutPanel9.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 5;
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(192, 207);
            this.tableLayoutPanel9.TabIndex = 9;
            // 
            // cbDrawingFlipV
            // 
            this.cbDrawingFlipV.Appearance = Wisej.Web.Appearance.Switch;
            this.cbDrawingFlipV.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbDrawingFlipV.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDrawingFlipV.Location = new System.Drawing.Point(99, 167);
            this.cbDrawingFlipV.Name = "cbDrawingFlipV";
            this.cbDrawingFlipV.Size = new System.Drawing.Size(90, 37);
            this.cbDrawingFlipV.TabIndex = 9;
            // 
            // cbDrawingFlipH
            // 
            this.cbDrawingFlipH.Appearance = Wisej.Web.Appearance.Switch;
            this.cbDrawingFlipH.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbDrawingFlipH.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDrawingFlipH.Location = new System.Drawing.Point(99, 126);
            this.cbDrawingFlipH.Name = "cbDrawingFlipH";
            this.cbDrawingFlipH.Size = new System.Drawing.Size(90, 35);
            this.cbDrawingFlipH.TabIndex = 8;
            // 
            // txtDrawingAngle
            // 
            this.txtDrawingAngle.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDrawingAngle.InputType.Max = "89";
            this.txtDrawingAngle.InputType.Min = "0";
            this.txtDrawingAngle.InputType.Step = 0.5D;
            this.txtDrawingAngle.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDrawingAngle.Location = new System.Drawing.Point(99, 85);
            this.txtDrawingAngle.Name = "txtDrawingAngle";
            this.txtDrawingAngle.Size = new System.Drawing.Size(90, 35);
            this.txtDrawingAngle.TabIndex = 7;
            // 
            // txtDrawingRootFace
            // 
            this.txtDrawingRootFace.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDrawingRootFace.InputType.Max = "300";
            this.txtDrawingRootFace.InputType.Min = "0";
            this.txtDrawingRootFace.InputType.Step = 0.5D;
            this.txtDrawingRootFace.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDrawingRootFace.Location = new System.Drawing.Point(99, 44);
            this.txtDrawingRootFace.Name = "txtDrawingRootFace";
            this.txtDrawingRootFace.Size = new System.Drawing.Size(90, 35);
            this.txtDrawingRootFace.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 35);
            this.label2.TabIndex = 2;
            this.label2.Text = "Root Face";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDrawingRotation
            // 
            this.txtDrawingRotation.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDrawingRotation.InputType.Max = "45";
            this.txtDrawingRotation.InputType.Min = "-45";
            this.txtDrawingRotation.InputType.Step = 0.5D;
            this.txtDrawingRotation.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDrawingRotation.Location = new System.Drawing.Point(99, 3);
            this.txtDrawingRotation.Name = "txtDrawingRotation";
            this.txtDrawingRotation.Size = new System.Drawing.Size(90, 35);
            this.txtDrawingRotation.TabIndex = 1;
            this.txtDrawingRotation.TextChanged += new System.EventHandler(this.txtDrawingRotation_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "Rotation";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = Wisej.Web.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 35);
            this.label3.TabIndex = 3;
            this.label3.Text = "Angle";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = Wisej.Web.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(3, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 35);
            this.label4.TabIndex = 4;
            this.label4.Text = "Flip (h)";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = Wisej.Web.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(3, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 37);
            this.label5.TabIndex = 5;
            this.label5.Text = "Flip (v)";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pDrawingShapePreview
            // 
            this.pDrawingShapePreview.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel8.SetColumnSpan(this.pDrawingShapePreview, 5);
            this.pDrawingShapePreview.Dock = Wisej.Web.DockStyle.Fill;
            this.pDrawingShapePreview.Location = new System.Drawing.Point(3, 216);
            this.pDrawingShapePreview.Name = "pDrawingShapePreview";
            this.pDrawingShapePreview.Size = new System.Drawing.Size(192, 208);
            this.pDrawingShapePreview.TabIndex = 8;
            this.pDrawingShapePreview.Paint += new Wisej.Web.PaintEventHandler(this.pDrawingShapePreview_Paint);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 5;
            this.tableLayoutPanel7.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel7.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel7.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel7.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel7.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel7.Controls.Add(this.pDrawingWeldSequence, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.rbDrawingFlange, 4, 1);
            this.tableLayoutPanel7.Controls.Add(this.rbDrawingGroove, 3, 1);
            this.tableLayoutPanel7.Controls.Add(this.rbDrawingBevel, 2, 1);
            this.tableLayoutPanel7.Controls.Add(this.rbDrawingWeld, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.rbDrawingRectangle, 0, 1);
            this.tableLayoutPanel7.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(207, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel7.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(814, 427);
            this.tableLayoutPanel7.TabIndex = 7;
            // 
            // pDrawingWeldSequence
            // 
            this.pDrawingWeldSequence.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel7.SetColumnSpan(this.pDrawingWeldSequence, 5);
            this.pDrawingWeldSequence.Dock = Wisej.Web.DockStyle.Fill;
            this.pDrawingWeldSequence.Location = new System.Drawing.Point(3, 3);
            this.pDrawingWeldSequence.Name = "pDrawingWeldSequence";
            this.pDrawingWeldSequence.Size = new System.Drawing.Size(808, 378);
            this.pDrawingWeldSequence.TabIndex = 7;
            this.pDrawingWeldSequence.MouseDown += new Wisej.Web.MouseEventHandler(this.pDrawingWeldSequence_MouseDown);
            this.pDrawingWeldSequence.MouseMove += new Wisej.Web.MouseEventHandler(this.pDrawingWeldSequence_MouseMove);
            this.pDrawingWeldSequence.MouseUp += new Wisej.Web.MouseEventHandler(this.pDrawingWeldSequence_MouseUp);
            this.pDrawingWeldSequence.Paint += new Wisej.Web.PaintEventHandler(this.pDrawingWeldSequence_Paint);
            // 
            // rbDrawingFlange
            // 
            this.rbDrawingFlange.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDrawingFlange.Location = new System.Drawing.Point(651, 387);
            this.rbDrawingFlange.Name = "rbDrawingFlange";
            this.rbDrawingFlange.Size = new System.Drawing.Size(160, 37);
            this.rbDrawingFlange.TabIndex = 6;
            this.rbDrawingFlange.Text = "Flange";
            this.rbDrawingFlange.CheckedChanged += new System.EventHandler(this.rbDrawingFlange_CheckedChanged);
            // 
            // rbDrawingGroove
            // 
            this.rbDrawingGroove.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDrawingGroove.Location = new System.Drawing.Point(489, 387);
            this.rbDrawingGroove.Name = "rbDrawingGroove";
            this.rbDrawingGroove.Size = new System.Drawing.Size(156, 37);
            this.rbDrawingGroove.TabIndex = 5;
            this.rbDrawingGroove.Text = "Groove";
            this.rbDrawingGroove.CheckedChanged += new System.EventHandler(this.rbDrawingGroove_CheckedChanged);
            // 
            // rbDrawingBevel
            // 
            this.rbDrawingBevel.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDrawingBevel.Location = new System.Drawing.Point(327, 387);
            this.rbDrawingBevel.Name = "rbDrawingBevel";
            this.rbDrawingBevel.Size = new System.Drawing.Size(156, 37);
            this.rbDrawingBevel.TabIndex = 4;
            this.rbDrawingBevel.Text = "Bevel";
            this.rbDrawingBevel.CheckedChanged += new System.EventHandler(this.rbDrawingBevel_CheckedChanged);
            // 
            // rbDrawingWeld
            // 
            this.rbDrawingWeld.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDrawingWeld.Location = new System.Drawing.Point(165, 387);
            this.rbDrawingWeld.Name = "rbDrawingWeld";
            this.rbDrawingWeld.Size = new System.Drawing.Size(156, 37);
            this.rbDrawingWeld.TabIndex = 3;
            this.rbDrawingWeld.Text = "Weld";
            this.rbDrawingWeld.CheckedChanged += new System.EventHandler(this.rbDrawingCircle_CheckedChanged);
            // 
            // rbDrawingRectangle
            // 
            this.rbDrawingRectangle.Checked = true;
            this.rbDrawingRectangle.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDrawingRectangle.Location = new System.Drawing.Point(3, 387);
            this.rbDrawingRectangle.Name = "rbDrawingRectangle";
            this.rbDrawingRectangle.Size = new System.Drawing.Size(156, 37);
            this.rbDrawingRectangle.TabIndex = 2;
            this.rbDrawingRectangle.TabStop = true;
            this.rbDrawingRectangle.Text = "Rectangle";
            this.rbDrawingRectangle.CheckedChanged += new System.EventHandler(this.rbDrawingRectangle_CheckedChanged);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel3.TabIndex = 5;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.uplDrawingUpload, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.btnDrawingUndo, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.btnDrawingBack, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.btnDrawingHome, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.btnDrawingComplete, 0, 5);
            this.tableLayoutPanel4.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 6;
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel4.TabIndex = 4;
            // 
            // btnDrawingUndo
            // 
            this.btnDrawingUndo.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDrawingUndo.Location = new System.Drawing.Point(3, 3);
            this.btnDrawingUndo.Name = "btnDrawingUndo";
            this.btnDrawingUndo.Size = new System.Drawing.Size(95, 64);
            this.btnDrawingUndo.TabIndex = 4;
            this.btnDrawingUndo.Text = "Undo";
            this.btnDrawingUndo.Click += new System.EventHandler(this.btnDrawingUndo_Click);
            // 
            // btnDrawingBack
            // 
            this.btnDrawingBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDrawingBack.Location = new System.Drawing.Point(3, 213);
            this.btnDrawingBack.Name = "btnDrawingBack";
            this.btnDrawingBack.Size = new System.Drawing.Size(95, 64);
            this.btnDrawingBack.TabIndex = 3;
            this.btnDrawingBack.Text = "Back";
            this.btnDrawingBack.Click += new System.EventHandler(this.btnDrawingBack_Click);
            // 
            // btnDrawingHome
            // 
            this.btnDrawingHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDrawingHome.Location = new System.Drawing.Point(3, 283);
            this.btnDrawingHome.Name = "btnDrawingHome";
            this.btnDrawingHome.Size = new System.Drawing.Size(95, 64);
            this.btnDrawingHome.TabIndex = 1;
            this.btnDrawingHome.Text = "Home";
            this.btnDrawingHome.Click += new System.EventHandler(this.btnDrawingHome_Click);
            // 
            // btnDrawingComplete
            // 
            this.btnDrawingComplete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDrawingComplete.Location = new System.Drawing.Point(3, 353);
            this.btnDrawingComplete.Name = "btnDrawingComplete";
            this.btnDrawingComplete.Size = new System.Drawing.Size(95, 69);
            this.btnDrawingComplete.TabIndex = 0;
            this.btnDrawingComplete.Text = "Complete";
            this.btnDrawingComplete.Click += new System.EventHandler(this.btnDrawingComplete_Click);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.label15, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel6.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label15.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label15.Dock = Wisej.Web.DockStyle.Fill;
            this.label15.Location = new System.Drawing.Point(3, 79);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(1139, 35);
            this.label15.TabIndex = 1;
            this.label15.Text = "Notes";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label16.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label16.Dock = Wisej.Web.DockStyle.Fill;
            this.label16.Location = new System.Drawing.Point(3, 3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(1139, 70);
            this.label16.TabIndex = 0;
            this.label16.Text = "Weld Sequence / Run Pass Location Upload";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uplDrawingUpload
            // 
            this.uplDrawingUpload.AllowedFileTypes = "\"image\"";
            this.uplDrawingUpload.ButtonPosition = System.Drawing.ContentAlignment.TopCenter;
            this.uplDrawingUpload.Dock = Wisej.Web.DockStyle.Fill;
            this.uplDrawingUpload.HideValue = true;
            this.uplDrawingUpload.Location = new System.Drawing.Point(3, 73);
            this.uplDrawingUpload.Name = "uplDrawingUpload";
            this.uplDrawingUpload.ResizableEdges = ((Wisej.Web.AnchorStyles)((((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left) 
            | Wisej.Web.AnchorStyles.Right)));
            this.uplDrawingUpload.Size = new System.Drawing.Size(95, 64);
            this.uplDrawingUpload.TabIndex = 5;
            this.uplDrawingUpload.Text = "Image";
            this.uplDrawingUpload.Uploaded += new Wisej.Web.UploadedEventHandler(this.uplDrawingUpload_Uploaded);
            // 
            // fbDatasheet
            // 
            this.Controls.Add(this.Boards);
            this.Name = "fbDatasheet";
            this.Size = new System.Drawing.Size(1212, 650);
            this.Boards.ResumeLayout(false);
            this.tabTestInfo.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel30.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            this.tabDatasheet.ResumeLayout(false);
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel31.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel22.PerformLayout();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel24.PerformLayout();
            this.tabDrawing.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TabControl Boards;
        private Wisej.Web.TabPage tabTestInfo;
        private Wisej.Web.TabPage tabDrawing;
        private Wisej.Web.TabPage tabDatasheet;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel20;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel21;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel23;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel31;
        private Wisej.Web.Button btnRunAdd;
        private Wisej.Web.Button btnRunHome;
        private Wisej.Web.Button btnRunNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel22;
        private Wisej.Web.ListView lvRunParameters;
        private Wisej.Web.TextBox txtRunPurge;
        private Wisej.Web.TextBox txtRunShield;
        private Wisej.Web.TextBox txtRunInput;
        private Wisej.Web.TextBox txtRunActual;
        private Wisej.Web.TextBox txtRunLength;
        private Wisej.Web.TextBox txtRunInterpass;
        private Wisej.Web.TextBox txtRunVolts;
        private Wisej.Web.TextBox txtRunAmps;
        private Wisej.Web.TextBox txtRunSupply;
        private Wisej.Web.TextBox txtRunDia;
        private Wisej.Web.TextBox txtRunPass;
        private Wisej.Web.TextBox txtRunSide;
        private Wisej.Web.Label label63;
        private Wisej.Web.Label label64;
        private Wisej.Web.Label label65;
        private Wisej.Web.Label label66;
        private Wisej.Web.Label label67;
        private Wisej.Web.Label label68;
        private Wisej.Web.Label label69;
        private Wisej.Web.Label label70;
        private Wisej.Web.Label label71;
        private Wisej.Web.Label label72;
        private Wisej.Web.Label label73;
        private Wisej.Web.Label label74;
        private Wisej.Web.Label label75;
        private Wisej.Web.Label label76;
        private Wisej.Web.TextBox txtRunSpeed;
        private Wisej.Web.TextBox txtRunTime;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel24;
        private Wisej.Web.Label label77;
        private Wisej.Web.Label label78;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel15;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel16;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel18;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel30;
        private Wisej.Web.Button btnInfoHome;
        private Wisej.Web.Button btnInfoNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel17;
        private Wisej.Web.TextBox txtInfoBatchNo;
        private Wisej.Web.TextBox txtInfoClassification;
        private Wisej.Web.TextBox txtInfoProduct;
        private Wisej.Web.TextBox txtInfoManufacturer;
        private Wisej.Web.TextBox txtInfoNotes;
        private Wisej.Web.TextBox txtInfoAngle;
        private Wisej.Web.TextBox txtInfoGap;
        private Wisej.Web.TextBox txtInfoFace;
        private Wisej.Web.TextBox txtInfoProcess;
        private Wisej.Web.TextBox txtInfoDate;
        private Wisej.Web.TextBox txtInfoWelder;
        private Wisej.Web.TextBox txtInfoHeatNo;
        private Wisej.Web.TextBox txtInfoMatThickness;
        private Wisej.Web.TextBox txtInfoMatGrade;
        private Wisej.Web.TextBox txtInfoMatStandard;
        private Wisej.Web.TextBox txtInfoType;
        private Wisej.Web.TextBox txtInfoDesign;
        private Wisej.Web.TextBox txtInfoStandard;
        private Wisej.Web.TextBox txtInfoJob;
        private Wisej.Web.TextBox txtInfoWPQR;
        private Wisej.Web.Label label40;
        private Wisej.Web.Label label39;
        private Wisej.Web.Label label38;
        private Wisej.Web.Label label37;
        private Wisej.Web.Label label41;
        private Wisej.Web.Label label42;
        private Wisej.Web.Label label43;
        private Wisej.Web.Label label44;
        private Wisej.Web.Label label45;
        private Wisej.Web.Label label46;
        private Wisej.Web.Label label47;
        private Wisej.Web.Label label48;
        private Wisej.Web.Label label49;
        private Wisej.Web.Label label50;
        private Wisej.Web.Label label51;
        private Wisej.Web.Label label52;
        private Wisej.Web.Label label53;
        private Wisej.Web.Label label54;
        private Wisej.Web.Label label55;
        private Wisej.Web.Label label56;
        private Wisej.Web.Label label57;
        private Wisej.Web.Label label58;
        private Wisej.Web.Label label59;
        private Wisej.Web.Label label60;
        private Wisej.Web.TextBox txtInfoPosition;
        private Wisej.Web.TextBox txtInfoPreheat;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel19;
        private Wisej.Web.Label label61;
        private Wisej.Web.Label label62;
        private Wisej.Web.Button btnInfoBack;
        private Wisej.Web.Button btnRunBack;
        private Wisej.Web.ColumnHeader chSide;
        private Wisej.Web.ColumnHeader chPass;
        private Wisej.Web.ColumnHeader chDia;
        private Wisej.Web.ColumnHeader chSupply;
        private Wisej.Web.ColumnHeader chAmps;
        private Wisej.Web.ColumnHeader chVolts;
        private Wisej.Web.ColumnHeader chInterpass;
        private Wisej.Web.ColumnHeader chLength;
        private Wisej.Web.ColumnHeader chActual;
        private Wisej.Web.ColumnHeader chWeldTime;
        private Wisej.Web.ColumnHeader chWeldSpeed;
        private Wisej.Web.ColumnHeader chInput;
        private Wisej.Web.ColumnHeader chShield;
        private Wisej.Web.ColumnHeader chPurge;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel4;
        private Wisej.Web.Button btnDrawingBack;
        private Wisej.Web.Button btnDrawingHome;
        private Wisej.Web.Button btnDrawingComplete;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel6;
        private Wisej.Web.Label label15;
        private Wisej.Web.Label label16;
        private Wisej.Web.Button btnDrawingUndo;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel5;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel7;
        private Wisej.Web.Panel pDrawingWeldSequence;
        private Wisej.Web.RadioButton rbDrawingFlange;
        private Wisej.Web.RadioButton rbDrawingGroove;
        private Wisej.Web.RadioButton rbDrawingBevel;
        private Wisej.Web.RadioButton rbDrawingWeld;
        private Wisej.Web.RadioButton rbDrawingRectangle;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel8;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel9;
        private Wisej.Web.Panel pDrawingShapePreview;
        private Wisej.Web.TextBox txtDrawingRotation;
        private Wisej.Web.Label label1;
        private Wisej.Web.Label label2;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label5;
        private Wisej.Web.TextBox txtDrawingRootFace;
        private Wisej.Web.TextBox txtDrawingAngle;
        private Wisej.Web.CheckBox cbDrawingFlipV;
        private Wisej.Web.CheckBox cbDrawingFlipH;
        private Wisej.Web.Upload uplDrawingUpload;
    }
}
