﻿namespace WeldingManagement.UserControls
{
    partial class FilmStrip
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Wisej.Web.ImageListEntry imageListEntry6 = new Wisej.Web.ImageListEntry();
            this.FilmStripPanel = new Wisej.Web.Panel();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.tblCommentRow = new Wisej.Web.TableLayoutPanel();
            this.btnFavImage = new Wisej.Web.Button();
            this.imageList1 = new Wisej.Web.ImageList(this.components);
            this.txtImageComment = new Wisej.Web.TextBox();
            this.btnUpdateComment = new Wisej.Web.Button();
            this.panel1 = new Wisej.Web.Panel();
            this.pbCamera = new Wisej.Web.PictureBox();
            this.mnuCopy = new Wisej.Web.ContextMenu();
            this.menuCopy = new Wisej.Web.MenuItem();
            this.mnuCopySmall = new Wisej.Web.MenuItem();
            this.mnuCopyMedium = new Wisej.Web.MenuItem();
            this.mnuCopyFull = new Wisej.Web.MenuItem();
            this.menuSaveAs = new Wisej.Web.MenuItem();
            this.FilmStripPanel.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tblCommentRow.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCamera)).BeginInit();
            this.SuspendLayout();
            // 
            // FilmStripPanel
            // 
            this.FilmStripPanel.AutoScroll = true;
            this.FilmStripPanel.BackColor = System.Drawing.Color.White;
            this.FilmStripPanel.Controls.Add(this.tableLayoutPanel1);
            this.FilmStripPanel.Dock = Wisej.Web.DockStyle.Fill;
            this.FilmStripPanel.Location = new System.Drawing.Point(0, 0);
            this.FilmStripPanel.Name = "FilmStripPanel";
            this.FilmStripPanel.Size = new System.Drawing.Size(448, 398);
            this.FilmStripPanel.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tblCommentRow, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.pbCamera, 0, 0);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 150F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(448, 398);
            this.tableLayoutPanel1.TabIndex = 4;
            this.tableLayoutPanel1.TabStop = true;
            // 
            // tblCommentRow
            // 
            this.tblCommentRow.ColumnCount = 3;
            this.tblCommentRow.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 80F));
            this.tblCommentRow.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Absolute, 65F));
            this.tblCommentRow.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Absolute, 43F));
            this.tblCommentRow.Controls.Add(this.btnFavImage, 2, 0);
            this.tblCommentRow.Controls.Add(this.txtImageComment, 0, 0);
            this.tblCommentRow.Controls.Add(this.btnUpdateComment, 1, 0);
            this.tblCommentRow.Dock = Wisej.Web.DockStyle.Fill;
            this.tblCommentRow.Location = new System.Drawing.Point(3, 201);
            this.tblCommentRow.Name = "tblCommentRow";
            this.tblCommentRow.RowCount = 1;
            this.tblCommentRow.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tblCommentRow.Size = new System.Drawing.Size(442, 44);
            this.tblCommentRow.TabIndex = 3;
            this.tblCommentRow.Visible = false;
            // 
            // btnFavImage
            // 
            this.btnFavImage.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnFavImage.ImageIndex = 0;
            this.btnFavImage.ImageList = this.imageList1;
            this.btnFavImage.Location = new System.Drawing.Point(402, 3);
            this.btnFavImage.Name = "btnFavImage";
            this.btnFavImage.Size = new System.Drawing.Size(37, 33);
            this.btnFavImage.TabIndex = 2;
            this.btnFavImage.Click += new System.EventHandler(this.btnFavImage_Click);
            // 
            // imageList1
            // 
            this.imageList1.Images.AddRange(new Wisej.Web.ImageListEntry[] {
            imageListEntry6});
            // 
            // txtImageComment
            // 
            this.txtImageComment.AutoSize = false;
            this.txtImageComment.Dock = Wisej.Web.DockStyle.Fill;
            this.txtImageComment.Location = new System.Drawing.Point(3, 3);
            this.txtImageComment.Multiline = true;
            this.txtImageComment.Name = "txtImageComment";
            this.txtImageComment.Size = new System.Drawing.Size(328, 38);
            this.txtImageComment.TabIndex = 1;
            this.txtImageComment.Watermark = "Add note...";
            // 
            // btnUpdateComment
            // 
            this.btnUpdateComment.Dock = Wisej.Web.DockStyle.Fill;
            this.btnUpdateComment.Location = new System.Drawing.Point(337, 3);
            this.btnUpdateComment.Name = "btnUpdateComment";
            this.btnUpdateComment.Size = new System.Drawing.Size(59, 38);
            this.btnUpdateComment.TabIndex = 0;
            this.btnUpdateComment.Text = "Save \r\nNote";
            this.btnUpdateComment.Click += new System.EventHandler(this.btnUpdateComment_Click);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.AutoSize = true;
            this.panel1.Dock = Wisej.Web.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 248);
            this.panel1.Margin = new Wisej.Web.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.ScrollBars = Wisej.Web.ScrollBars.Horizontal;
            this.panel1.ShowCloseButton = false;
            this.panel1.Size = new System.Drawing.Size(448, 150);
            this.panel1.TabIndex = 1;
            this.panel1.TabStop = true;
            // 
            // pbCamera
            // 
            this.pbCamera.ContextMenu = this.mnuCopy;
            this.pbCamera.Dock = Wisej.Web.DockStyle.Fill;
            this.pbCamera.Location = new System.Drawing.Point(3, 3);
            this.pbCamera.Name = "pbCamera";
            this.pbCamera.Size = new System.Drawing.Size(442, 192);
            this.pbCamera.SizeMode = Wisej.Web.PictureBoxSizeMode.CenterImage;
            this.pbCamera.Paint += new Wisej.Web.PaintEventHandler(this.pbCamera_Paint);
            // 
            // mnuCopy
            // 
            this.mnuCopy.MenuItems.AddRange(new Wisej.Web.MenuItem[] {
            this.menuCopy});
            this.mnuCopy.Name = "mnuCopy";
            this.mnuCopy.RightToLeft = Wisej.Web.RightToLeft.No;
            // 
            // menuCopy
            // 
            this.menuCopy.AutoShowLoader = true;
            this.menuCopy.Index = 0;
            this.menuCopy.MenuItems.AddRange(new Wisej.Web.MenuItem[] {
            this.mnuCopySmall,
            this.mnuCopyMedium,
            this.mnuCopyFull});
            this.menuCopy.Name = "menuCopy";
            this.menuCopy.ShowShortcut = false;
            this.menuCopy.Text = "Clipboard";
            this.menuCopy.Popup += new System.EventHandler(this.menuCopy_Popup);
            // 
            // mnuCopySmall
            // 
            this.mnuCopySmall.Index = 0;
            this.mnuCopySmall.Name = "mnuCopySmall";
            this.mnuCopySmall.Text = "Small (Email)";
            this.mnuCopySmall.Click += new System.EventHandler(this.mnuCopySmall_Click);
            // 
            // mnuCopyMedium
            // 
            this.mnuCopyMedium.Index = 1;
            this.mnuCopyMedium.Name = "mnuCopyMedium";
            this.mnuCopyMedium.Text = "Medium (MDR)";
            this.mnuCopyMedium.Click += new System.EventHandler(this.mnuCopyMedium_Click);
            // 
            // mnuCopyFull
            // 
            this.mnuCopyFull.Index = 2;
            this.mnuCopyFull.Name = "mnuCopyFull";
            this.mnuCopyFull.Text = "Full";
            this.mnuCopyFull.Click += new System.EventHandler(this.mnuCopyFull_Click);
            // 
            // menuSaveAs
            // 
            this.menuSaveAs.Enabled = false;
            this.menuSaveAs.Index = -1;
            this.menuSaveAs.Name = "menuSaveAs";
            this.menuSaveAs.ShowShortcut = false;
            this.menuSaveAs.Text = "Save";
            this.menuSaveAs.Visible = false;
            // 
            // FilmStrip
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.Controls.Add(this.FilmStripPanel);
            this.Name = "FilmStrip";
            this.Size = new System.Drawing.Size(450, 400);
            this.Load += new System.EventHandler(this.FilmStrip_Load);
            this.Resize += new System.EventHandler(this.FilmStrip_Resize);
            this.FilmStripPanel.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tblCommentRow.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbCamera)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel FilmStripPanel;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tblCommentRow;
        private Wisej.Web.Button btnFavImage;
        private Wisej.Web.ImageList imageList1;
        private Wisej.Web.TextBox txtImageComment;
        private Wisej.Web.Button btnUpdateComment;
        private Wisej.Web.Panel panel1;
        private Wisej.Web.PictureBox pbCamera;
        private Wisej.Web.ContextMenu mnuCopy;
        private Wisej.Web.MenuItem menuCopy;
        private Wisej.Web.MenuItem mnuCopySmall;
        private Wisej.Web.MenuItem mnuCopyMedium;
        private Wisej.Web.MenuItem mnuCopyFull;
        private Wisej.Web.MenuItem menuSaveAs;
    }
}
