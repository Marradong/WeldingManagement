﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Wisej.Web;

namespace WeldingManagement.UserControls
{
    public partial class MultiSelectComboBox : UserControl
    {
        private List<object> _OutputDataList = new List<object>();

        private object[] _InputDataList;

        // private CancellationTokenSource cancellationTokenSource; //NOT THAT MUCH FASTER

        public MultiSelectComboBox()
        {
            InitializeComponent();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user selects/deselects an item")]
        public event EventHandler SelectionChanged;
        private void clbUserControlData_AfterItemCheck(object sender, ItemCheckEventArgs e)
        {
            var item = clbUserControlData.Items[e.Index];
            //string objJson = JsonConvert.SerializeObject(item);

            if (e.NewValue == CheckState.Unchecked)
            {
                _OutputDataList.Remove(item);
            }
            else if (!_OutputDataList.Any(o => o.ToString() == item.ToString()))
            {
                    _OutputDataList.Add(item);
            }

            Update_Text();

            SelectionChanged?.Invoke(this, e);
        }

        private void cboUserControl_KeyPress(object sender, KeyPressEventArgs e)
        {
            object[] filteredDataList = ((string[])_InputDataList).Where(i => i.Contains(cboUserControl.Text)).ToArray();
            Update_clbItems(filteredDataList);

            // NOT THAT MUCH FASTER
            //if (cancellationTokenSource != null)
            //{
            //    cancellationTokenSource.Cancel();
            //}

            //CancellationToken cancellationToken = new CancellationTokenSource().Token;

            //Task.Run(() =>
            //{
            //    string searchText = cboUserControl.Text;
            //    object[] filteredDataList = ((string[])_InputDataList).Where(i => i.Contains(searchText)).ToArray();

            //    if (!cancellationToken.IsCancellationRequested)
            //    {
            //        Update_clbItems(filteredDataList);
            //    }
            //}, cancellationToken);
        }

        private void Update_clbItems(object[] items)
        {
            if (items == null)
            {
                return;
            }

            clbUserControlData.Items.Clear();

            clbUserControlData.Items.AddRange(items.ToArray());

            var outputItems = new HashSet<string>(_OutputDataList.Select(item => item.ToString()));

            for (int i = 0; i < clbUserControlData.Items.Count; i++)
            {
                if (outputItems.Contains(clbUserControlData.Items[i].ToString()))
                {
                    clbUserControlData.SetItemChecked(i, true);
                }
            }

            clbUserControlData.Refresh();
            cboUserControl.Refresh();
        }

        private void Update_Text()
        {
            string comboString = "";

            foreach (object obj in _OutputDataList)
            {
                comboString += $"{obj}, ";
            }

            if (!comboString.Equals(""))
            {
                comboString = comboString.Remove(comboString.Length - 2);
            }

            txtUserControlOutput.Text = comboString;
        }

        [Browsable(true)]
        [Category("Data")]
        [Description("Sets a list of objects for the user to choose from via the combobox")]
        public void Set_InputDataList(object[] inputDataList)
        {
            _InputDataList = inputDataList;

            Update_clbItems(_InputDataList);
        }

        [Browsable(true)]
        [Category("Data")]
        [Description("Returns a list of objects containing data selected by the user via the combobox")]
        public List<object> Get_OuputDataList()
        {
            return _OutputDataList;
        }

        [Browsable(true)]
        [Category("Data")]
        [Description("Sets a list of objects containing data selected by the user via the combobox")]
        public void Set_OuputDataList(List<object> outputDataList)
        {
            if (_InputDataList == null)
            {
                return;
            }

            _OutputDataList = outputDataList;
            Update_clbItems(_InputDataList);
            Update_Text();
        }

        [Browsable(true)]
        [Category("Data")]
        [Description("Clears data selected by the user via the combobox")]
        public void ClearSelection()
        {
            clbUserControlData.SelectedItems.Clear();
            Set_OuputDataList(new List<object>());
            Update_Text();
        }

        public override string ToString()
        {
            return txtUserControlOutput.Text;
        }
    }
}
