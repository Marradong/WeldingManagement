﻿using System;
using System.ComponentModel;
using System.Drawing;
using Wisej.Web;

namespace WeldingManagement
{
    public partial class fbRequest : Wisej.Web.UserControl
    {
        #region FlipBoard
        bool IsDesignMode = (LicenseManager.UsageMode == LicenseUsageMode.Designtime);
        bool checkCancel = true;

        [Category("Board")]
        [Description("Number to display")]
        private void Boards_Selecting(object sender, TabControlCancelEventArgs e)
        {
            e.Cancel = checkCancel;
            checkCancel = true;
        }

        private BoardId showBoard = BoardId.Info;
        public BoardId ShowBoard
        {
            get
            {
                return showBoard;
            }
            set
            {
                showBoard = value;
                checkCancel = false;

                //Change Boards
                Boards.SelectedIndex = (int)showBoard;
                Boards.Refresh();

                //Exectute Board Show Code
                switch (ShowBoard)
                {
                    case BoardId.Info:

                        string LoggedIn = "True";
                        if (LoggedIn == "True")
                        {
                            Boards.SelectedIndex = (int)BoardId.Info;
                            Boards.Refresh();
                        }
                        else
                        {
                            //txtUserName.Text = txtEmpId.Text = txtPassword.Text = "";
                            //if (txtUserName.Text == "")
                            //    txtUserName.Text = Environment.UserName;

                            Boards.SelectedIndex = (int)BoardId.Info;
                        }

                        break;
                    case BoardId.Details:
                        break;
                }
            }
        }

        public enum BoardId
        {
            Info = 0,
            Details = 1,
            Documents = 2,
            Technical = 3,
            Operational = 4
        }
        public fbRequest()
        {
            InitializeComponent();


            Boards.BorderStyle = Wisej.Web.BorderStyle.None;
            Boards.ItemSize = new Size(1, 1); //Hide Tabs - they are not selectable
            Boards.SizeMode = TabSizeMode.Fixed;

            foreach (TabPage tab in Boards.TabPages)
            {
                tab.Text = "";
                tab.BackColor = Color.White;
            }
        }
        #endregion

        #region Info

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on info screen")]
        public event EventHandler btnInfoHomeClick;
        private void btnInfoHome_Click(object sender, EventArgs e)
        {
            btnInfoHomeClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        private void btnInfoNext_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Details;
            this.Refresh();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on info screen")]
        public event EventHandler btnInfoBackClick;
        private void btnInfoBack_Click(object sender, EventArgs e)
        {
            btnInfoBackClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }
        #endregion

        #region Details
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on details screen")]
        public event EventHandler btnDetailsCompleteClick;

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on details screen")]
        public event EventHandler btnDetailsHomeClick;
        private void btnDetailsHome_Click(object sender, EventArgs e)
        {
            btnDetailsHomeClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        private void btnDetailsBack_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        private void btnDetailsNext_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Documents;
            this.Refresh();
        }
        #endregion

        #region Technical
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on technical screen")]
        public event EventHandler btnTechnicalCompleteClick;
        private void btnTechnicalComplete_Click(object sender, EventArgs e)
        {
            btnTechnicalCompleteClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Operational;
            this.Refresh();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on technical screen")]
        public event EventHandler btnTechnicalHomeClick;
        private void btnTechnicalHome_Click(object sender, EventArgs e)
        {
            btnTechnicalHomeClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }
        #endregion

        #region Operational
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on operational screen")]
        public event EventHandler btnOperationCompleteClick;
        private void btnOperationComplete_Click(object sender, EventArgs e)
        {
            btnOperationCompleteClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on operational screen")]
        public event EventHandler btnOperationHomeClick;
        private void btnOperationHome_Click(object sender, EventArgs e)
        {
            btnOperationHomeClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }
        #endregion

        #region Documents
        private void btnDocumentsBack_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Details;
            this.Refresh();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on Documents screen")]
        public event EventHandler btnDocumentsHomeClick;
        private void btnDocumentsHome_Click(object sender, EventArgs e)
        {
            btnDocumentsHomeClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on Documents screen")]
        public event EventHandler btnDocumentsCompleteClick;
        private void btnDocumentsComplete_Click(object sender, EventArgs e)
        {
            btnDocumentsCompleteClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        private void uplDocumentsProvide_Uploaded(object sender, UploadedEventArgs e)
        {

        }
        #endregion
    }
}
