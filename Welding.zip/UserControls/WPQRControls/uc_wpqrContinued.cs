﻿using ApiClient;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.WPQRControls
{
    public partial class uc_wpqrContinued : Wisej.Web.UserControl
    {
        private up_hmSave up_hmSave1;
        private Panel overlayPanel;

        public uc_wpqrContinued()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks next button on details continued screen")]
        public event EventHandler btnContNextClick;
        private void btnContNext_Click(object sender, EventArgs e)
        {
            Save_Action();
            Update_Status();

            btnContNextClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on details continued screen")]
        public event EventHandler btnContHomeClick;
        private void btnContHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnContHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on details continued screen")]
        public event EventHandler btnContBackClick;
        private void btnContBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnContBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnContBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            wpqr.Status = Actions.WPQRAttachments;

            ApiCalls.UpdateWPQR(wpqr.WPQRId, wpqr);

            this.Tag = new Tag(ApiCalls.ReadWPQR(wpqr.WPQRId), TagType.WPQR);
        }

        private void Save_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            if (!string.IsNullOrEmpty(txtContShieldComp.Text))
                wpqr.ShieldComposition = txtContShieldComp.Text;

            if (!string.IsNullOrEmpty(txtContTrailComp.Text))
                wpqr.TrailingComposition = txtContTrailComp.Text;

            if (!string.IsNullOrEmpty(txtContBackComp.Text))
                wpqr.BackingComposition = txtContBackComp.Text;

            if (!string.IsNullOrEmpty(txtContShieldFlow.Text))
                wpqr.ShieldFlowRate = double.TryParse(txtContShieldFlow.Text, out double result) ? result : 0;

            if (!string.IsNullOrEmpty(txtContTrailFlow.Text))
                wpqr.TrailingFlowRate = double.TryParse(txtContTrailFlow.Text, out double result) ? result : 0;

            if (!string.IsNullOrEmpty(txtContBackFlow.Text))
                wpqr.BackingFlowRate = double.TryParse(txtContBackFlow.Text, out double result) ? result : 0;

            if (!string.IsNullOrEmpty(txtContGasOther.Text))
                wpqr.GasNotes = txtContGasOther.Text;

            if (!string.IsNullOrEmpty(txtContCurrent.Text))
                wpqr.Current = txtContCurrent.Text;

            if (!string.IsNullOrEmpty(txtContPolarity.Text))
                wpqr.Polarity = txtContPolarity.Text;

            if (!string.IsNullOrEmpty(txtContMinAmps.Text))
                wpqr.MinAmps = double.TryParse(txtContMinAmps.Text, out double result) ? result : 0;

            if (!string.IsNullOrEmpty(txtContMaxAmps.Text))
                wpqr.MaxAmps = double.TryParse(txtContMinAmps.Text, out double result) ? result : 0;

            if (!string.IsNullOrEmpty(txtContMinVolts.Text))
                wpqr.MinVolts = double.TryParse(txtContMinVolts.Text, out double result) ? result : 0;

            if (!string.IsNullOrEmpty(txtContMaxVolts.Text))
                wpqr.MaxVolts = double.TryParse(txtContMaxVolts.Text, out double result) ? result : 0;

            if (!string.IsNullOrEmpty(txtContTungsten.Text))
                wpqr.TESize = double.TryParse(txtContTungsten.Text, out double result) ? result : 0;

            if (!string.IsNullOrEmpty(txtContTransfer.Text))
                wpqr.MetalTransfer = txtContTransfer.Text;

            if (!string.IsNullOrEmpty(txtContMinInput.Text))
                wpqr.MinHeatInput = double.TryParse(txtContMinInput.Text, out double result) ? result : 0;

            if (!string.IsNullOrEmpty(txtContMaxInput.Text))
                wpqr.MaxHeatInput = double.TryParse(txtContMaxInput.Text, out double result) ? result : 0;

            if (!string.IsNullOrEmpty(txtContElectricalOther.Text))
                wpqr.ElectricalNotes = txtContElectricalOther.Text;

            if (!string.IsNullOrEmpty(txtContBead.Text))
                wpqr.BeadType = txtContBead.Text;

            if (!string.IsNullOrEmpty(txtContMinSpeed.Text))
                wpqr.MinTravelSpeed = double.TryParse(txtContMinSpeed.Text, out double result) ? result : 0;

            if (!string.IsNullOrEmpty(txtContMaxSpeed.Text))
                wpqr.MaxTravelSpeed = double.TryParse(txtContMaxSpeed.Text, out double result) ? result : 0;

            if (!string.IsNullOrEmpty(txtContOscillation.Text))
                wpqr.Oscillation = txtContOscillation.Text;

            if (!string.IsNullOrEmpty(txtContPass.Text))
                wpqr.PassType = txtContPass.Text;

            if (!string.IsNullOrEmpty(txtContElectrodes.Text))
                wpqr.ElectrodeType = txtContElectrodes.Text;

            if (!string.IsNullOrEmpty(txtContTechniqueOther.Text))
                wpqr.TechniqueNotes = txtContTechniqueOther.Text;

            if (!string.IsNullOrEmpty(txtContNotes.Text))
                wpqr.Notes = txtContNotes.Text;

            wpqr.NDTReq = cbContNDT.Checked;
            wpqr.VIReq = cbContVisual.Checked;
            wpqr.DPIReq = cbContDPI.Checked;
            wpqr.MPIReq = cbContMPI.Checked;
            wpqr.RTReq = cbContRT.Checked;
            wpqr.UTReq = cbContUT.Checked;

            wpqr.DTReq = cbContDT.Checked;
            wpqr.MacroReq = cbContMacro.Checked;
            wpqr.HardnessReq = cbContHardness.Checked;
            wpqr.BendReq = cbContBend.Checked;
            wpqr.TensilReq = cbContTensil.Checked;
            wpqr.ImpactReq = cbContImpact.Checked;

            ApiCalls.UpdateWPQR(wpqr.WPQRId, wpqr);

            this.Tag = new Tag(ApiCalls.ReadWPQR(wpqr.WPQRId), TagType.WPQR);
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            txtContShieldComp.Text = wpqr.ShieldComposition?.ToString() ?? "";
            txtContTrailComp.Text = wpqr.TrailingComposition?.ToString() ?? "";
            txtContBackComp.Text = wpqr.BackingComposition?.ToString() ?? "";
            txtContShieldFlow.Text = wpqr.ShieldFlowRate?.ToString() ?? wpqr.Welder_Qualification.Datasheet.Datasheet_Run.FirstOrDefault().ShieldGas.ToString();
            txtContTrailFlow.Text = wpqr.TrailingFlowRate?.ToString() ?? "";
            txtContBackFlow.Text = wpqr.BackingFlowRate?.ToString() ?? "";
            txtContGasOther.Text = wpqr.GasNotes?.ToString() ?? "";

            txtContCurrent.Text = wpqr.Current?.ToString() ?? "";
            txtContPolarity.Text = wpqr.Polarity?.ToString() ?? "";
            txtContMinAmps.Text = wpqr.MinAmps?.ToString() ?? wpqr.Welder_Qualification.Datasheet.Datasheet_Run.Min(d => d.Amps).ToString();
            txtContMaxAmps.Text = wpqr.MaxAmps?.ToString() ?? wpqr.Welder_Qualification.Datasheet.Datasheet_Run.Max(d => d.Amps).ToString();
            txtContMinVolts.Text = wpqr.MinVolts?.ToString() ?? wpqr.Welder_Qualification.Datasheet.Datasheet_Run.Min(d => d.Volts).ToString();
            txtContMaxVolts.Text = wpqr.MaxVolts?.ToString() ?? wpqr.Welder_Qualification.Datasheet.Datasheet_Run.Max(d => d.Volts).ToString();
            txtContTungsten.Text = wpqr.TESize?.ToString() ?? "";
            txtContTransfer.Text = wpqr.MetalTransfer?.ToString() ?? "";
            txtContMinInput.Text = wpqr.MinHeatInput?.ToString() ?? wpqr.Welder_Qualification.Datasheet.Datasheet_Run.Min(d => d.HeatInput).ToString();
            txtContMaxInput.Text = wpqr.MaxHeatInput?.ToString() ?? wpqr.Welder_Qualification.Datasheet.Datasheet_Run.Max(d => d.HeatInput).ToString();
            txtContElectricalOther.Text = wpqr.ElectricalNotes?.ToString() ?? "";

            txtContBead.Text = wpqr.BeadType?.ToString() ?? "";
            txtContMinSpeed.Text = wpqr.MinTravelSpeed?.ToString() ?? wpqr.Welder_Qualification.Datasheet.Datasheet_Run.Min(d => d.WeldSpeed).ToString();
            txtContMaxSpeed.Text = wpqr.MaxTravelSpeed?.ToString() ?? wpqr.Welder_Qualification.Datasheet.Datasheet_Run.Max(d => d.WeldSpeed).ToString();
            txtContOscillation.Text = wpqr.Oscillation?.ToString() ?? "";
            txtContPass.Text = wpqr.PassType?.ToString() ?? "";
            txtContElectrodes.Text = wpqr.ElectrodeType?.ToString() ?? "";
            txtContTechniqueOther.Text = wpqr.TechniqueNotes?.ToString() ?? "";

            txtContNotes.Text = wpqr.Notes?.ToString() ?? "";

            cbContNDT.Checked = wpqr.NDTReq == true;
            cbContVisual.Checked = wpqr.VIReq == true;
            cbContDPI.Checked = wpqr.DPIReq == true;
            cbContMPI.Checked = wpqr.MPIReq == true;
            cbContRT.Checked = wpqr.RTReq == true;
            cbContUT.Checked = wpqr.UTReq == true;

            cbContDT.Checked = wpqr.DTReq == true;
            cbContMacro.Checked = wpqr.MacroReq == true;
            cbContHardness.Checked = wpqr.HardnessReq == true;
            cbContBend.Checked = wpqr.BendReq == true;
            cbContTensil.Checked = wpqr.TensilReq == true;
            cbContImpact.Checked = wpqr.ImpactReq == true;
        }

        private void uc_wpqrContinued_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }

        private void label56_DoubleClick(object sender, EventArgs e)
        {
            if (UIFormatting.adminUsers.Contains(Application.Cookies["EmployeeNumber"].TrimStart('E')))
            {
                txtContShieldComp.Text = "N/A";
                txtContTrailComp.Text = "N/A";
                txtContBackComp.Text = "N/A";
                txtContShieldFlow.Text = "0";
                txtContTrailFlow.Text = "0";
                txtContBackFlow.Text = "0";
                txtContGasOther.Text = "N/A";

                txtContCurrent.Text = "DC";
                txtContPolarity.Text = "Positive";
                txtContMinAmps.Text = "100";
                txtContMaxAmps.Text = "200";
                txtContMinVolts.Text = "50";
                txtContMaxVolts.Text = "100";
                txtContTungsten.Text = "0";
                txtContTransfer.Text = "FCAW";
                txtContMinInput.Text = "10";
                txtContMaxInput.Text = "20";
                txtContElectricalOther.Text = "N/A";

                txtContBead.Text = "String";
                txtContMinSpeed.Text = "124.5";
                txtContMaxSpeed.Text = "224.5";
                txtContOscillation.Text = "N/A";
                txtContPass.Text = "Multiple";
                txtContElectrodes.Text = "Single";
                txtContTechniqueOther.Text = "N/A";

                txtContNotes.Text = "WPQR for Demonstration Purposes";
            }
        }
    }
}
