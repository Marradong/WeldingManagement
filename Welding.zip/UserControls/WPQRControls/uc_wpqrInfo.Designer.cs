﻿namespace WeldingManagement.UserControls.WPQRControls
{
    partial class uc_wpqrInfo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_wpqrInfo));
            this.tableLayoutPanel25 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel26 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel28 = new Wisej.Web.TableLayoutPanel();
            this.btnInfoBack = new Wisej.Web.Button();
            this.btnInfoHome = new Wisej.Web.Button();
            this.btnInfoNext = new Wisej.Web.Button();
            this.tableLayoutPanel27 = new Wisej.Web.TableLayoutPanel();
            this.cboInfoPrepared = new Wisej.Web.ComboBox();
            this.dtpInfoDate = new Wisej.Web.DateTimePicker();
            this.label86 = new Wisej.Web.Label();
            this.label87 = new Wisej.Web.Label();
            this.label88 = new Wisej.Web.Label();
            this.label89 = new Wisej.Web.Label();
            this.label90 = new Wisej.Web.Label();
            this.label99 = new Wisej.Web.Label();
            this.label100 = new Wisej.Web.Label();
            this.label101 = new Wisej.Web.Label();
            this.label102 = new Wisej.Web.Label();
            this.label98 = new Wisej.Web.Label();
            this.label82 = new Wisej.Web.Label();
            this.label81 = new Wisej.Web.Label();
            this.label94 = new Wisej.Web.Label();
            this.label93 = new Wisej.Web.Label();
            this.label79 = new Wisej.Web.Label();
            this.txtInfoWPQR = new Wisej.Web.TextBox();
            this.txtInfoStandard = new Wisej.Web.TextBox();
            this.txtInfoType = new Wisej.Web.TextBox();
            this.txtInfoJoint = new Wisej.Web.TextBox();
            this.txtInfoMaxThickness = new Wisej.Web.TextBox();
            this.txtInfoOther = new Wisej.Web.TextBox();
            this.txtInfoDia = new Wisej.Web.TextBox();
            this.txtInfoWPS = new Wisej.Web.TextBox();
            this.txtInfoThickness = new Wisej.Web.TextBox();
            this.txtInfoMatStandard = new Wisej.Web.TextBox();
            this.txtInfoPNo = new Wisej.Web.TextBox();
            this.txtInfoMatGrade = new Wisej.Web.TextBox();
            this.tableLayoutPanel29 = new Wisej.Web.TableLayoutPanel();
            this.lblInfoNote = new Wisej.Web.LinkLabel();
            this.label104 = new Wisej.Web.Label();
            this.tableLayoutPanel25.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel25.ColumnCount = 3;
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.Controls.Add(this.tableLayoutPanel26, 1, 3);
            this.tableLayoutPanel25.Controls.Add(this.tableLayoutPanel29, 1, 1);
            this.tableLayoutPanel25.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 5;
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel25.TabIndex = 4;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 2;
            this.tableLayoutPanel26.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel26.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel26.Controls.Add(this.tableLayoutPanel1, 1, 0);
            this.tableLayoutPanel26.Controls.Add(this.tableLayoutPanel27, 0, 0);
            this.tableLayoutPanel26.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel26.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel28, 0, 0);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel28.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel28.ColumnCount = 1;
            this.tableLayoutPanel28.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel28.Controls.Add(this.btnInfoBack, 0, 2);
            this.tableLayoutPanel28.Controls.Add(this.btnInfoHome, 0, 3);
            this.tableLayoutPanel28.Controls.Add(this.btnInfoNext, 0, 4);
            this.tableLayoutPanel28.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel28.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 5;
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel28.TabIndex = 4;
            // 
            // btnInfoBack
            // 
            this.btnInfoBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnInfoBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoBack.Location = new System.Drawing.Point(3, 173);
            this.btnInfoBack.Name = "btnInfoBack";
            this.btnInfoBack.Size = new System.Drawing.Size(95, 79);
            this.btnInfoBack.TabIndex = 16;
            this.btnInfoBack.Text = "Back";
            this.btnInfoBack.Click += new System.EventHandler(this.btnInfoBack_Click);
            // 
            // btnInfoHome
            // 
            this.btnInfoHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnInfoHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoHome.Location = new System.Drawing.Point(3, 258);
            this.btnInfoHome.Name = "btnInfoHome";
            this.btnInfoHome.Size = new System.Drawing.Size(95, 79);
            this.btnInfoHome.TabIndex = 15;
            this.btnInfoHome.Text = "Home";
            this.btnInfoHome.Click += new System.EventHandler(this.btnInfoHome_Click);
            // 
            // btnInfoNext
            // 
            this.btnInfoNext.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnInfoNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoNext.Location = new System.Drawing.Point(3, 343);
            this.btnInfoNext.Name = "btnInfoNext";
            this.btnInfoNext.Size = new System.Drawing.Size(95, 79);
            this.btnInfoNext.TabIndex = 14;
            this.btnInfoNext.Text = "Next";
            this.btnInfoNext.Click += new System.EventHandler(this.btnInfoNext_Click);
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.ColumnCount = 4;
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel27.Controls.Add(this.cboInfoPrepared, 3, 0);
            this.tableLayoutPanel27.Controls.Add(this.dtpInfoDate, 3, 1);
            this.tableLayoutPanel27.Controls.Add(this.label86, 2, 4);
            this.tableLayoutPanel27.Controls.Add(this.label87, 2, 3);
            this.tableLayoutPanel27.Controls.Add(this.label88, 2, 2);
            this.tableLayoutPanel27.Controls.Add(this.label89, 2, 1);
            this.tableLayoutPanel27.Controls.Add(this.label90, 2, 0);
            this.tableLayoutPanel27.Controls.Add(this.label99, 0, 3);
            this.tableLayoutPanel27.Controls.Add(this.label100, 0, 2);
            this.tableLayoutPanel27.Controls.Add(this.label101, 0, 1);
            this.tableLayoutPanel27.Controls.Add(this.label102, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.label98, 0, 5);
            this.tableLayoutPanel27.Controls.Add(this.label82, 0, 4);
            this.tableLayoutPanel27.Controls.Add(this.label81, 0, 6);
            this.tableLayoutPanel27.Controls.Add(this.label94, 0, 7);
            this.tableLayoutPanel27.Controls.Add(this.label93, 2, 7);
            this.tableLayoutPanel27.Controls.Add(this.label79, 0, 8);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoWPQR, 1, 0);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoStandard, 1, 1);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoType, 1, 2);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoJoint, 1, 3);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoMaxThickness, 1, 4);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoOther, 1, 5);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoDia, 3, 4);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoWPS, 3, 2);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoThickness, 3, 3);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoMatStandard, 1, 7);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoPNo, 1, 8);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoMatGrade, 3, 7);
            this.tableLayoutPanel27.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 9;
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel27.TabIndex = 4;
            // 
            // cboInfoPrepared
            // 
            this.cboInfoPrepared.AutoCompleteMode = Wisej.Web.AutoCompleteMode.Filter;
            this.cboInfoPrepared.Dock = Wisej.Web.DockStyle.Fill;
            this.cboInfoPrepared.Location = new System.Drawing.Point(771, 3);
            this.cboInfoPrepared.Name = "cboInfoPrepared";
            this.cboInfoPrepared.Size = new System.Drawing.Size(250, 42);
            this.cboInfoPrepared.Sorted = true;
            this.cboInfoPrepared.TabIndex = 5;
            // 
            // dtpInfoDate
            // 
            this.dtpInfoDate.Dock = Wisej.Web.DockStyle.Fill;
            this.dtpInfoDate.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpInfoDate.Location = new System.Drawing.Point(771, 51);
            this.dtpInfoDate.Name = "dtpInfoDate";
            this.dtpInfoDate.Size = new System.Drawing.Size(250, 42);
            this.dtpInfoDate.TabIndex = 6;
            this.dtpInfoDate.Value = new System.DateTime(2024, 2, 20, 14, 41, 10, 644);
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.BackColor = System.Drawing.Color.FromName("@window");
            this.label86.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label86.Dock = Wisej.Web.DockStyle.Fill;
            this.label86.Location = new System.Drawing.Point(515, 195);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(250, 42);
            this.label86.TabIndex = 16;
            this.label86.Text = "Diameter (mm)";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.BackColor = System.Drawing.Color.FromName("@window");
            this.label87.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label87.Dock = Wisej.Web.DockStyle.Fill;
            this.label87.Location = new System.Drawing.Point(515, 147);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(250, 42);
            this.label87.TabIndex = 15;
            this.label87.Text = "Thickness (mm)";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.BackColor = System.Drawing.Color.FromName("@window");
            this.label88.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label88.Dock = Wisej.Web.DockStyle.Fill;
            this.label88.Location = new System.Drawing.Point(515, 99);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(250, 42);
            this.label88.TabIndex = 14;
            this.label88.Text = "WPS Number";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.BackColor = System.Drawing.Color.FromName("@window");
            this.label89.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label89.Dock = Wisej.Web.DockStyle.Fill;
            this.label89.Location = new System.Drawing.Point(515, 51);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(250, 42);
            this.label89.TabIndex = 13;
            this.label89.Text = "Date";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.BackColor = System.Drawing.Color.FromName("@window");
            this.label90.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label90.Dock = Wisej.Web.DockStyle.Fill;
            this.label90.Location = new System.Drawing.Point(515, 3);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(250, 42);
            this.label90.TabIndex = 12;
            this.label90.Text = "Prepared By Emp ID";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.BackColor = System.Drawing.Color.FromName("@window");
            this.label99.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label99.Dock = Wisej.Web.DockStyle.Fill;
            this.label99.Location = new System.Drawing.Point(3, 147);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(250, 42);
            this.label99.TabIndex = 3;
            this.label99.Text = "Joint Type";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.BackColor = System.Drawing.Color.FromName("@window");
            this.label100.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label100.Dock = Wisej.Web.DockStyle.Fill;
            this.label100.Location = new System.Drawing.Point(3, 99);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(250, 42);
            this.label100.TabIndex = 2;
            this.label100.Text = "Welding Type";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.BackColor = System.Drawing.Color.FromName("@window");
            this.label101.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label101.Dock = Wisej.Web.DockStyle.Fill;
            this.label101.Location = new System.Drawing.Point(3, 51);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(250, 42);
            this.label101.TabIndex = 1;
            this.label101.Text = "Welding Code / Standard";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.BackColor = System.Drawing.Color.FromName("@window");
            this.label102.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label102.Dock = Wisej.Web.DockStyle.Fill;
            this.label102.Location = new System.Drawing.Point(3, 3);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(250, 42);
            this.label102.TabIndex = 0;
            this.label102.Text = "WPQR Number";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.BackColor = System.Drawing.Color.FromName("@window");
            this.label98.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label98.Dock = Wisej.Web.DockStyle.Fill;
            this.label98.Location = new System.Drawing.Point(3, 243);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(250, 42);
            this.label98.TabIndex = 4;
            this.label98.Text = "Other";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.BackColor = System.Drawing.Color.FromName("@window");
            this.label82.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label82.Dock = Wisej.Web.DockStyle.Fill;
            this.label82.Location = new System.Drawing.Point(3, 195);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(250, 42);
            this.label82.TabIndex = 20;
            this.label82.Text = "Maximum Pass Thickness (mm)";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label81.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel27.SetColumnSpan(this.label81, 4);
            this.label81.Dock = Wisej.Web.DockStyle.Fill;
            this.label81.Location = new System.Drawing.Point(3, 291);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(1018, 42);
            this.label81.TabIndex = 21;
            this.label81.Text = "Base Metals";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.BackColor = System.Drawing.Color.FromName("@window");
            this.label94.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label94.Dock = Wisej.Web.DockStyle.Fill;
            this.label94.Location = new System.Drawing.Point(3, 339);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(250, 42);
            this.label94.TabIndex = 8;
            this.label94.Text = "Material Standard";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.BackColor = System.Drawing.Color.FromName("@window");
            this.label93.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label93.Dock = Wisej.Web.DockStyle.Fill;
            this.label93.Location = new System.Drawing.Point(515, 339);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(250, 42);
            this.label93.TabIndex = 9;
            this.label93.Text = "Material Grade";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.BackColor = System.Drawing.Color.FromName("@window");
            this.label79.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label79.Dock = Wisej.Web.DockStyle.Fill;
            this.label79.Location = new System.Drawing.Point(3, 387);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(250, 43);
            this.label79.TabIndex = 22;
            this.label79.Text = "P / Group Number";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtInfoWPQR
            // 
            this.txtInfoWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoWPQR.Location = new System.Drawing.Point(259, 3);
            this.txtInfoWPQR.Name = "txtInfoWPQR";
            this.txtInfoWPQR.Size = new System.Drawing.Size(250, 42);
            this.txtInfoWPQR.TabIndex = 0;
            // 
            // txtInfoStandard
            // 
            this.txtInfoStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoStandard.Location = new System.Drawing.Point(259, 51);
            this.txtInfoStandard.Name = "txtInfoStandard";
            this.txtInfoStandard.Size = new System.Drawing.Size(250, 42);
            this.txtInfoStandard.TabIndex = 1;
            // 
            // txtInfoType
            // 
            this.txtInfoType.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoType.Location = new System.Drawing.Point(259, 99);
            this.txtInfoType.Name = "txtInfoType";
            this.txtInfoType.Size = new System.Drawing.Size(250, 42);
            this.txtInfoType.TabIndex = 2;
            // 
            // txtInfoJoint
            // 
            this.txtInfoJoint.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoJoint.Location = new System.Drawing.Point(259, 147);
            this.txtInfoJoint.Name = "txtInfoJoint";
            this.txtInfoJoint.Size = new System.Drawing.Size(250, 42);
            this.txtInfoJoint.TabIndex = 3;
            // 
            // txtInfoMaxThickness
            // 
            this.txtInfoMaxThickness.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMaxThickness.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtInfoMaxThickness.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtInfoMaxThickness.Location = new System.Drawing.Point(259, 195);
            this.txtInfoMaxThickness.Name = "txtInfoMaxThickness";
            this.txtInfoMaxThickness.Size = new System.Drawing.Size(250, 42);
            this.txtInfoMaxThickness.TabIndex = 4;
            // 
            // txtInfoOther
            // 
            this.tableLayoutPanel27.SetColumnSpan(this.txtInfoOther, 3);
            this.txtInfoOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoOther.Location = new System.Drawing.Point(259, 243);
            this.txtInfoOther.Multiline = true;
            this.txtInfoOther.Name = "txtInfoOther";
            this.txtInfoOther.Size = new System.Drawing.Size(762, 42);
            this.txtInfoOther.TabIndex = 10;
            // 
            // txtInfoDia
            // 
            this.txtInfoDia.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoDia.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtInfoDia.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtInfoDia.Location = new System.Drawing.Point(771, 195);
            this.txtInfoDia.Name = "txtInfoDia";
            this.txtInfoDia.Size = new System.Drawing.Size(250, 42);
            this.txtInfoDia.TabIndex = 9;
            // 
            // txtInfoWPS
            // 
            this.txtInfoWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoWPS.Location = new System.Drawing.Point(771, 99);
            this.txtInfoWPS.Name = "txtInfoWPS";
            this.txtInfoWPS.Size = new System.Drawing.Size(250, 42);
            this.txtInfoWPS.TabIndex = 7;
            // 
            // txtInfoThickness
            // 
            this.txtInfoThickness.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoThickness.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtInfoThickness.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtInfoThickness.Location = new System.Drawing.Point(771, 147);
            this.txtInfoThickness.Name = "txtInfoThickness";
            this.txtInfoThickness.Size = new System.Drawing.Size(250, 42);
            this.txtInfoThickness.TabIndex = 8;
            // 
            // txtInfoMatStandard
            // 
            this.txtInfoMatStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatStandard.Location = new System.Drawing.Point(259, 339);
            this.txtInfoMatStandard.Name = "txtInfoMatStandard";
            this.txtInfoMatStandard.Size = new System.Drawing.Size(250, 42);
            this.txtInfoMatStandard.TabIndex = 11;
            // 
            // txtInfoPNo
            // 
            this.tableLayoutPanel27.SetColumnSpan(this.txtInfoPNo, 3);
            this.txtInfoPNo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPNo.Location = new System.Drawing.Point(259, 387);
            this.txtInfoPNo.Name = "txtInfoPNo";
            this.txtInfoPNo.Size = new System.Drawing.Size(762, 43);
            this.txtInfoPNo.TabIndex = 13;
            // 
            // txtInfoMatGrade
            // 
            this.txtInfoMatGrade.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatGrade.Location = new System.Drawing.Point(771, 339);
            this.txtInfoMatGrade.Name = "txtInfoMatGrade";
            this.txtInfoMatGrade.Size = new System.Drawing.Size(250, 42);
            this.txtInfoMatGrade.TabIndex = 12;
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.ColumnCount = 1;
            this.tableLayoutPanel29.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel29.Controls.Add(this.lblInfoNote, 0, 1);
            this.tableLayoutPanel29.Controls.Add(this.label104, 0, 0);
            this.tableLayoutPanel29.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel29.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 2;
            this.tableLayoutPanel29.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel29.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel29.TabIndex = 0;
            // 
            // lblInfoNote
            // 
            this.lblInfoNote.AutoSize = true;
            this.lblInfoNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblInfoNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblInfoNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblInfoNote.LinkArea = new Wisej.Web.LinkArea(238, 84);
            this.lblInfoNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblInfoNote.Location = new System.Drawing.Point(6, 79);
            this.lblInfoNote.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.lblInfoNote.Name = "lblInfoNote";
            this.lblInfoNote.Size = new System.Drawing.Size(1133, 35);
            this.lblInfoNote.TabIndex = 11;
            this.lblInfoNote.Text = resources.GetString("lblInfoNote.Text");
            this.lblInfoNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfoNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblInfoNote_LinkClicked);
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label104.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label104.CssStyle = "border-radius: 4px;";
            this.label104.Dock = Wisej.Web.DockStyle.Fill;
            this.label104.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label104.Location = new System.Drawing.Point(6, 3);
            this.label104.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(1133, 70);
            this.label104.TabIndex = 0;
            this.label104.Text = "WPQR Information";
            this.label104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label104.DoubleClick += new System.EventHandler(this.label104_DoubleClick);
            // 
            // uc_wpqrInfo
            // 
            this.Controls.Add(this.tableLayoutPanel25);
            this.Name = "uc_wpqrInfo";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_wpqrInfo_VisibleChanged);
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel27.PerformLayout();
            this.tableLayoutPanel29.ResumeLayout(false);
            this.tableLayoutPanel29.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel25;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel26;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel27;
        private Wisej.Web.Label label86;
        private Wisej.Web.Label label87;
        private Wisej.Web.Label label88;
        private Wisej.Web.Label label89;
        private Wisej.Web.Label label90;
        private Wisej.Web.Label label99;
        private Wisej.Web.Label label100;
        private Wisej.Web.Label label101;
        private Wisej.Web.Label label102;
        private Wisej.Web.Label label98;
        private Wisej.Web.Label label82;
        private Wisej.Web.Label label81;
        private Wisej.Web.Label label94;
        private Wisej.Web.Label label93;
        private Wisej.Web.Label label79;
        private Wisej.Web.TextBox txtInfoWPQR;
        private Wisej.Web.TextBox txtInfoStandard;
        private Wisej.Web.TextBox txtInfoType;
        private Wisej.Web.TextBox txtInfoJoint;
        private Wisej.Web.TextBox txtInfoMaxThickness;
        private Wisej.Web.TextBox txtInfoOther;
        private Wisej.Web.TextBox txtInfoDia;
        private Wisej.Web.TextBox txtInfoWPS;
        private Wisej.Web.TextBox txtInfoThickness;
        private Wisej.Web.TextBox txtInfoMatStandard;
        private Wisej.Web.TextBox txtInfoPNo;
        private Wisej.Web.TextBox txtInfoMatGrade;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel29;
        private Wisej.Web.Label label104;
        private Wisej.Web.DateTimePicker dtpInfoDate;
        private Wisej.Web.ComboBox cboInfoPrepared;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel28;
        private Wisej.Web.Button btnInfoBack;
        private Wisej.Web.Button btnInfoHome;
        private Wisej.Web.Button btnInfoNext;
        private Wisej.Web.LinkLabel lblInfoNote;
    }
}
