﻿using ApiClient;
using PeopleEF;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.WPQRControls
{
    public partial class uc_wpqrInfo : Wisej.Web.UserControl
    {
        private up_hmSave up_hmSave1;
        private Panel overlayPanel;

        public uc_wpqrInfo()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks next button on info screen")]
        public event EventHandler btnInfoNextClick;
        private void btnInfoNext_Click(object sender, EventArgs e)
        {
            Save_Action();
            Update_Status();

            btnInfoNextClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on info screen")]
        public event EventHandler btnInfoHomeClick;
        private void btnInfoHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnInfoHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on info screen")]
        public event EventHandler btnInfoBackClick;
        private void btnInfoBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnInfoBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnInfoBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            wpqr.Status = Actions.WPQRParameters;

            ApiCalls.UpdateWPQR(wpqr.WPQRId, wpqr);

            this.Tag = new Tag(ApiCalls.ReadWPQR(wpqr.WPQRId), TagType.WPQR);
        }

        private void Save_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            wpqr.WPQRNumber = txtInfoWPQR.Text;

            if (!string.IsNullOrEmpty(txtInfoStandard.Text))
                wpqr.WeldingStandard = txtInfoStandard.Text;

            wpqr.Date = dtpInfoDate.Value;

            if (!string.IsNullOrEmpty(txtInfoType.Text))
                wpqr.WeldingType = txtInfoType.Text;

            if (!string.IsNullOrEmpty(txtInfoJoint.Text))
                wpqr.JointType = txtInfoJoint.Text;

            wpqr.Thickness = double.TryParse(txtInfoThickness.Text, out double thickness) ? thickness : 0;
            wpqr.MaxThickness = double.TryParse(txtInfoMaxThickness.Text, out double maxThickness) ? maxThickness : -1;
            wpqr.Diameter = double.TryParse(txtInfoDia.Text, out double diameter) ? diameter : 0;

            if (!string.IsNullOrEmpty(txtInfoOther.Text))
                wpqr.Other = txtInfoOther.Text;

            if (!string.IsNullOrEmpty(txtInfoMatStandard.Text))
                wpqr.BMSpecfication = txtInfoMatStandard.Text;

            if (!string.IsNullOrEmpty(txtInfoMatGrade.Text))
                wpqr.BMGrade = txtInfoMatGrade.Text;

            if (!string.IsNullOrEmpty(txtInfoPNo.Text))
                wpqr.BMGroupPNumber = txtInfoPNo.Text;

            if (cboInfoPrepared.SelectedItem != null)
                wpqr.WPQRPreparerEID = ((Tag)cboInfoPrepared.SelectedItem).getTagName();

            ApiCalls.UpdateWPQR(wpqr.WPQRId, wpqr);

            this.Tag = new Tag(ApiCalls.ReadWPQR(wpqr.WPQRId), TagType.WPQR);
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            Tag[] pplTags = QAWebApiClient.ApiCalls.GetPeople().Select(ppl => new Tag(ppl, TagType.None, ppl.EmployeeNumber)).ToArray();

            cboInfoPrepared.Items.Clear();
            cboInfoPrepared.Items.AddRange(pplTags);

            cboInfoPrepared.SelectedItem = pplTags.FirstOrDefault(tag => ((Person)tag.getTagObject()).EmployeeNumber == Application.Cookies["EmployeeNumber"]);

            if (thisTag.getTagObject() is WPQR)
            {
                WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

                Datasheet ds = wpqr.Welder_Qualification.Datasheet;

                txtInfoWPQR.Text = wpqr.WPQRNumber?.ToString() ?? ds.WPQRNumber.ToString();
                txtInfoWPS.Text = txtInfoWPQR.Text;

                txtInfoStandard.Text = wpqr.WeldingStandard?.ToString() ?? ds.WeldingStandard;

                cboInfoPrepared.SelectedItem = pplTags.FirstOrDefault(tag => ((Person)tag.getTagObject()).EmployeeNumber == (wpqr.WPQRPreparerEID?.ToString() ?? Application.Cookies["EmployeeNumber"]));

                dtpInfoDate.Value = wpqr.Date ?? DateTime.Now;
                txtInfoType.Text = wpqr.WeldingType?.ToString() ?? wpqr.Welder_Qualification.Datasheet.WeldingProcess.ToString();

                txtInfoJoint.Text = wpqr.JointType?.ToString() ?? ds.JointDesign + " " + ds.JointType;
                txtInfoThickness.Text = wpqr.Thickness?.ToString() ?? ds.MaterialThickness.ToString();
                txtInfoMaxThickness.Text = wpqr.MaxThickness?.ToString() ?? "";
                txtInfoDia.Text = wpqr.Diameter?.ToString() ?? "";
                txtInfoOther.Text = wpqr.Other?.ToString() ?? "";
                txtInfoMatStandard.Text = wpqr.BMSpecfication?.ToString() ?? ds.MaterialStd;
                txtInfoMatGrade.Text = wpqr.BMGrade?.ToString() ?? ds.MaterialGrd;
                txtInfoPNo.Text = wpqr.BMGroupPNumber?.ToString() ?? "";
            }

            cboInfoPrepared.Refresh();
        }

        private void uc_wpqrInfo_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }

        private void label104_DoubleClick(object sender, EventArgs e)
        {
            if (UIFormatting.adminUsers.Contains(Application.Cookies["EmployeeNumber"].TrimStart('E')))
            {
                txtInfoMaxThickness.Text = "3";
                txtInfoDia.Text = "0";
                txtInfoOther.Text = "WPQR for Demonstration Purposes";
                txtInfoPNo.Text = "1";
            }
        }
    }
}
