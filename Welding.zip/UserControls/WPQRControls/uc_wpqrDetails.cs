﻿using ApiClient;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.WPQRControls
{
    public partial class uc_wpqrDetails : Wisej.Web.UserControl
    {
        private up_hmSave up_hmSave1;
        private Panel overlayPanel;

        public uc_wpqrDetails()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks next button on details screen")]
        public event EventHandler btnDetailsNextClick;
        private void btnDetailsNext_Click(object sender, EventArgs e)
        {
            Save_Action();
            Update_Status();

            btnDetailsNextClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on details screen")]
        public event EventHandler btnDetailsHomeClick;
        private void btnDetailsHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnDetailsHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on details screen")]
        public event EventHandler btnDetailsBackClick;
        private void btnDetailsBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnDetailsBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnDetailsBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            wpqr.Status = Actions.WPQRDetailsContinued;

            ApiCalls.UpdateWPQR(wpqr.WPQRId, wpqr);

            this.Tag = new Tag(ApiCalls.ReadWPQR(wpqr.WPQRId), TagType.WPQR);
        }

        private void Save_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            if (!string.IsNullOrEmpty(txtDetailsSpecification.Text))
                wpqr.FillerSpecification = txtDetailsSpecification.Text;

            if (!string.IsNullOrEmpty(txtDetailsClassification.Text))
                wpqr.FillerClassification = txtDetailsClassification.Text;

            if (!string.IsNullOrEmpty(txtDetailsFNo.Text))
                wpqr.FillerFNumber = txtDetailsFNo.Text;

            if (!string.IsNullOrEmpty(txtDetailsANo.Text))
                wpqr.FillerANumber = txtDetailsANo.Text;

            if (!string.IsNullOrEmpty(txtDetailsFluxClassification.Text))
                wpqr.EFluxClassification = txtDetailsFluxClassification.Text;

            if (!string.IsNullOrEmpty(txtDetailsSize.Text))
                wpqr.FillerSize = double.TryParse(txtDetailsSize.Text, out double size) ? size : 0;

            if (!string.IsNullOrEmpty(txtDetailsForm.Text))
                wpqr.FillerForm = txtDetailsForm.Text;

            if (!string.IsNullOrEmpty(txtDetailsType.Text))
                wpqr.FluxType = txtDetailsType.Text;

            if (!string.IsNullOrEmpty(txtDetailsName.Text))
                wpqr.FluxTradeName = txtDetailsName.Text;

            if (!string.IsNullOrEmpty(txtDetailsWMThickness.Text))
                wpqr.WMThickness = double.TryParse(txtDetailsWMThickness.Text, out double wm) ? wm : 0;

            if (!string.IsNullOrEmpty(txtDetailsFillerOther.Text))
                wpqr.FillerNotes = txtDetailsFillerOther.Text;

            if (!string.IsNullOrEmpty(txtDetailsPosition.Text))
                wpqr.Position = txtDetailsPosition.Text;

            if (!string.IsNullOrEmpty(txtDetailsProgression.Text))
                wpqr.WeldProgression = txtDetailsProgression.Text;

            if (!string.IsNullOrEmpty(txtDetailsPositionOther.Text))
                wpqr.PositionNotes = txtDetailsPositionOther.Text;

            if (!string.IsNullOrEmpty(txtDetailsPreheat.Text))
                wpqr.PreheatTemp = double.TryParse(txtDetailsPreheat.Text, out double preheat) ? preheat : 0;

            if (!string.IsNullOrEmpty(txtDetailsInterpass.Text))
                wpqr.InterpassTemp = double.TryParse(txtDetailsInterpass.Text, out double interpass) ? interpass : 0;

            if (!string.IsNullOrEmpty(txtDetailsPreheatOther.Text))
                wpqr.PreheatNotes = txtDetailsPreheatOther.Text;

            if (!string.IsNullOrEmpty(txtDetailsPWHT.Text))
                wpqr.PWHTTemp = double.TryParse(txtDetailsPWHT.Text, out double pwht) ? pwht : 0;

            if (!string.IsNullOrEmpty(txtDetailsTime.Text))
                wpqr.PWHTTime = double.TryParse(txtDetailsTime.Text, out double time) ? time : 0;

            if (!string.IsNullOrEmpty(txtDetailsHeating.Text))
                wpqr.HeatingRate = double.TryParse(txtDetailsHeating.Text, out double heating) ? heating : 0;

            if (!string.IsNullOrEmpty(txtDetailsCooling.Text))
                wpqr.CoolingRate = double.TryParse(txtDetailsCooling.Text, out double cooling) ? cooling : 0;

            if (!string.IsNullOrEmpty(txtDetailsPWHTOther.Text))
                wpqr.PWHTNotes = txtDetailsPWHTOther.Text;

            ApiCalls.UpdateWPQR(wpqr.WPQRId, wpqr);

            this.Tag = new Tag(ApiCalls.ReadWPQR(wpqr.WPQRId), TagType.WPQR);
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            txtDetailsSpecification.Text = wpqr.FillerSpecification?.ToString() ?? wpqr.WPQR_Run.FirstOrDefault().Specification;
            txtDetailsClassification.Text = wpqr.FillerClassification?.ToString() ?? wpqr.WPQR_Run.FirstOrDefault().Classification;
            txtDetailsFNo.Text = wpqr.FillerFNumber?.ToString() ?? "";
            txtDetailsANo.Text = wpqr.FillerANumber?.ToString() ?? "";
            txtDetailsFluxClassification.Text = wpqr.EFluxClassification?.ToString() ?? "";
            txtDetailsSize.Text = wpqr.FillerSize?.ToString() ?? wpqr.WPQR_Run.FirstOrDefault().FillerDia.ToString();
            txtDetailsForm.Text = wpqr.FillerForm?.ToString() ?? "";
            txtDetailsType.Text = wpqr.FluxType?.ToString() ?? "";
            txtDetailsName.Text = wpqr.FluxTradeName?.ToString() ?? "";
            txtDetailsWMThickness.Text = wpqr.WMThickness?.ToString() ?? wpqr.MaxThickness.ToString();
            txtDetailsFillerOther.Text = wpqr.FillerNotes?.ToString() ?? "";
            txtDetailsPosition.Text = wpqr.Position?.ToString() ?? wpqr.Welder_Qualification.Datasheet.WeldingPosition;
            txtDetailsProgression.Text = wpqr.WeldProgression?.ToString() ?? "";
            txtDetailsPositionOther.Text = wpqr.PositionNotes?.ToString() ?? "";
            txtDetailsPreheat.Text = wpqr.PreheatTemp?.ToString() ?? wpqr.Welder_Qualification.Datasheet.PreheatTemp.ToString();
            txtDetailsInterpass.Text = wpqr.InterpassTemp?.ToString() ?? wpqr.Welder_Qualification.Datasheet.Datasheet_Run.Max(d => d.Interpass).ToString();
            txtDetailsPreheatOther.Text = wpqr.PreheatNotes?.ToString() ?? "";
            txtDetailsPWHT.Text = wpqr.PWHTTemp?.ToString() ?? "";
            txtDetailsTime.Text = wpqr.PWHTTime?.ToString() ?? "";
            txtDetailsHeating.Text = wpqr.HeatingRate?.ToString() ?? "";
            txtDetailsCooling.Text = wpqr.CoolingRate?.ToString() ?? "";
            txtDetailsPWHTOther.Text = wpqr.PWHTNotes?.ToString() ?? "";
        }

        private void uc_wpqrDetails_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }

        private void label17_DoubleClick(object sender, EventArgs e)
        {
            if (UIFormatting.adminUsers.Contains(Application.Cookies["EmployeeNumber"].TrimStart('E')))
            {
                txtDetailsSpecification.Text = "AS/NZS 14341";
                txtDetailsClassification.Text = "AS/NZS 14341";
                txtDetailsFNo.Text = "1";
                txtDetailsANo.Text = "1";
                txtDetailsFluxClassification.Text = "N/A";
                txtDetailsSize.Text = "1.2";
                txtDetailsForm.Text = "Rod";
                txtDetailsType.Text = "N/A";
                txtDetailsName.Text = "N/A";
                txtDetailsWMThickness.Text = "3mm";
                txtDetailsFillerOther.Text = "N/A";
                txtDetailsPosition.Text = "1G";
                txtDetailsProgression.Text = "Downhill";
                txtDetailsPositionOther.Text = "N/A";
                txtDetailsPreheat.Text = "0";
                txtDetailsInterpass.Text = "75";
                txtDetailsPreheatOther.Text = "N/A";
                txtDetailsPWHT.Text = "0";
                txtDetailsTime.Text = "0";
                txtDetailsHeating.Text = "0";
                txtDetailsCooling.Text = "0";
                txtDetailsPWHTOther.Text = "N/A";
            }
        }
    }
}
