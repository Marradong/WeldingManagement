﻿using ApiClient;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.WPQRControls
{
    public partial class uc_wpqrSelect : Wisej.Web.UserControl
    {
        private up_hmSave up_hmSave1;
        private Panel overlayPanel;

        public uc_wpqrSelect()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks next button on select screen")]
        public event EventHandler btnSelectNextClick;
        private void btnSelectNext_Click(object sender, EventArgs e)
        {
            if (cboSelectWQ.SelectedItem == null)
            {
                return;
            }

            Save_Action();
            Update_Status();

            btnSelectNextClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on select screen")]
        public event EventHandler btnSelectHomeClick;
        protected void btnSelectHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnSelectHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on select screen")]
        public event EventHandler btnSelectBackClick;
        private void btnSelectBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnSelectBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnSelectBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            wpqr.Status = Actions.WPQRInformation;

            ApiCalls.UpdateWPQR(wpqr.WPQRId, wpqr);

            this.Tag = new Tag(ApiCalls.ReadWPQR(wpqr.WPQRId), TagType.WPQR);
        }

        private void Save_Action()
        {
            if (cboSelectWQ.SelectedItem == null)
            {
                return;
            }

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)((Tag)cboSelectWQ.SelectedItem).getTagObject()).Welder_QualificationId);

            if (thisTag.getTagObject() is WeldingAction)
            {
                WeldingAction wa = ApiCalls.ReadWeldingAction(((WeldingAction)thisTag.getTagObject()).WeldingActionId);

                ApiCalls.CreateWPQR(wq.Welder_QualificationId, new WPQR(wq.Welder_QualificationId, wq, wa) { Status = Actions.WPQRSelectWelderQual });

                this.Tag = new Tag(ApiCalls.ReadWPQR(wq.Welder_QualificationId), TagType.WPQR);
            }
            else if (thisTag.getTagObject() is WPQR)
            {
                WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

                if (wpqr.Welder_Qualification.Welder_QualificationId != wq.Welder_QualificationId)
                {
                    ApiCalls.DeleteWPQR(wpqr.WPQRId);

                    WPQR createdWPQR = ApiCalls.CreateWPQR(wq.Welder_QualificationId, new WPQR(wq.Welder_QualificationId, wq, wq.WeldingAction) { Status = Actions.WPQRSelectWelderQual });

                    this.Tag = new Tag(ApiCalls.ReadWPQR(createdWPQR.WPQRId), TagType.WPQR);
                }
            }
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            if (thisTag.getTagObject() is WPQR)
            {
                WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

                // Re-read to get navigation properties
                WeldingAction wa = wpqr.Welder_Qualification.WeldingAction;
                wa = ApiCalls.ReadWeldingAction(wa.WeldingActionId);

                cboSelectWQ.Items.Clear();

                Tag[] wqTags = wa.Welder_Qualification
                    .Where(wq => wq.Status == Actions.Complete)
                    .Select(wq => new Tag(wq, TagType.None, wq.Datasheet.WelderEID + ": IWP" + wq.Datasheet.WPQRNumber + " - " + (wq.Pass == true ? "Pass" : "Fail"))).ToArray();
                cboSelectWQ.Items.AddRange(wqTags);

                cboSelectWQ.SelectedItem = wqTags.FirstOrDefault(tag => ((Welder_Qualification)tag.getTagObject()).Welder_QualificationId == wpqr.Welder_Qualification.Welder_QualificationId);

                cboSelectWQ.Refresh();
            }
            else if (thisTag.getTagObject() is WeldingAction)
            {
                WeldingAction wa = ApiCalls.ReadWeldingAction(((WeldingAction)thisTag.getTagObject()).WeldingActionId);

                cboSelectWQ.Items.Clear();

                Tag[] wqTags = wa.Welder_Qualification
                    .Where(wq => wq.Status == Actions.Complete)
                    .Select(wq => new Tag(wq, TagType.None, wq.Datasheet.WelderEID + ": IWP" + wq.Datasheet.WPQRNumber + " - " + (wq.Pass == true ? "Pass" : "Fail"))).ToArray();
                cboSelectWQ.Items.AddRange(wqTags);

                cboSelectWQ.Refresh();
            }
        }

        private void uc_wpqrSelect_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private void cboSelectWQ_SelectedItemChanged(object sender, EventArgs e)
        {
            Tag thisTag = (Tag)cboSelectWQ.SelectedItem;

            if (thisTag == null || !(thisTag.getTagObject() is Welder_Qualification))
            {
                return;
            }

            Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

            txtSelectJob.Text = wq.WeldingAction.Job.JobNo?.ToString() ?? "";

            if (wq.Datasheet == null)
            {
                return;
            }

            txtSelectWelder.Text = wq.Datasheet.WelderEID;
            txtSelectWPQR.Text = wq.Datasheet.WPQRNumber?.ToString() ?? "";
            dtpSelectDate.Value = wq.Datasheet.TestDate ?? DateTime.Now;

            txtSelectStandard.Text = wq.Datasheet.WeldingStandard?.ToString() ?? "";
            txtSelectProcess.Text = wq.Datasheet.WeldingProcess?.ToString() ?? "";
            txtSelectDesign.Text = wq.Datasheet.JointDesign?.ToString() ?? "";
            txtSelectFace.Text = wq.Datasheet.RootFace?.ToString() ?? "";
            txtSelectType.Text = wq.Datasheet.JointType?.ToString() ?? "";
            txtSelectGap.Text = wq.Datasheet.RootGap?.ToString() ?? "";
            txtSelectPosition.Text = wq.Datasheet.WeldingPosition?.ToString() ?? "";
            txtSelectAngle.Text = wq.Datasheet.IncludedAngle?.ToString() ?? "";
            txtSelectPreheat.Text = wq.Datasheet.PreheatTemp?.ToString() ?? "";
            txtSelectNotes.Text = wq.Datasheet.Notes?.ToString() ?? "";

            txtSelectMatStandard.Text = wq.Datasheet.MaterialStd?.ToString() ?? "";
            txtSelectMatGrade.Text = wq.Datasheet.MaterialGrd?.ToString() ?? "";
            txtSelectMatThickness.Text = wq.Datasheet.MaterialThickness?.ToString() ?? "";
            txtSelectHeatNo.Text = wq.Datasheet.HeatNumber?.ToString() ?? "";
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }
    }
}
