﻿namespace WeldingManagement.UserControls.WPQRControls
{
    partial class uc_wpqrSelect
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_wpqrSelect));
            this.tableLayoutPanel15 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel16 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel18 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel30 = new Wisej.Web.TableLayoutPanel();
            this.btnSelectBack = new Wisej.Web.Button();
            this.btnSelectHome = new Wisej.Web.Button();
            this.btnSelectNext = new Wisej.Web.Button();
            this.tableLayoutPanel17 = new Wisej.Web.TableLayoutPanel();
            this.cboSelectWQ = new Wisej.Web.ComboBox();
            this.label2 = new Wisej.Web.Label();
            this.label1 = new Wisej.Web.Label();
            this.dtpSelectDate = new Wisej.Web.DateTimePicker();
            this.txtSelectNotes = new Wisej.Web.TextBox();
            this.txtSelectAngle = new Wisej.Web.TextBox();
            this.txtSelectGap = new Wisej.Web.TextBox();
            this.txtSelectFace = new Wisej.Web.TextBox();
            this.txtSelectProcess = new Wisej.Web.TextBox();
            this.txtSelectWelder = new Wisej.Web.TextBox();
            this.txtSelectHeatNo = new Wisej.Web.TextBox();
            this.txtSelectMatThickness = new Wisej.Web.TextBox();
            this.txtSelectMatGrade = new Wisej.Web.TextBox();
            this.txtSelectMatStandard = new Wisej.Web.TextBox();
            this.txtSelectType = new Wisej.Web.TextBox();
            this.txtSelectDesign = new Wisej.Web.TextBox();
            this.txtSelectStandard = new Wisej.Web.TextBox();
            this.txtSelectJob = new Wisej.Web.TextBox();
            this.txtSelectWPQR = new Wisej.Web.TextBox();
            this.label42 = new Wisej.Web.Label();
            this.label43 = new Wisej.Web.Label();
            this.label44 = new Wisej.Web.Label();
            this.label45 = new Wisej.Web.Label();
            this.label46 = new Wisej.Web.Label();
            this.label47 = new Wisej.Web.Label();
            this.label48 = new Wisej.Web.Label();
            this.label49 = new Wisej.Web.Label();
            this.label50 = new Wisej.Web.Label();
            this.label51 = new Wisej.Web.Label();
            this.label52 = new Wisej.Web.Label();
            this.label53 = new Wisej.Web.Label();
            this.label54 = new Wisej.Web.Label();
            this.label55 = new Wisej.Web.Label();
            this.label56 = new Wisej.Web.Label();
            this.label57 = new Wisej.Web.Label();
            this.label58 = new Wisej.Web.Label();
            this.label59 = new Wisej.Web.Label();
            this.label60 = new Wisej.Web.Label();
            this.txtSelectPosition = new Wisej.Web.TextBox();
            this.txtSelectPreheat = new Wisej.Web.TextBox();
            this.tableLayoutPanel19 = new Wisej.Web.TableLayoutPanel();
            this.label62 = new Wisej.Web.Label();
            this.lblInfoNote = new Wisej.Web.LinkLabel();
            this.tableLayoutPanel15.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel15.ColumnCount = 3;
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.Controls.Add(this.tableLayoutPanel16, 1, 3);
            this.tableLayoutPanel15.Controls.Add(this.tableLayoutPanel19, 1, 1);
            this.tableLayoutPanel15.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 5;
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel15.TabIndex = 4;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel16.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel18, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel17, 0, 0);
            this.tableLayoutPanel16.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel16.TabIndex = 1;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 1;
            this.tableLayoutPanel18.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Controls.Add(this.tableLayoutPanel30, 0, 0);
            this.tableLayoutPanel18.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel18.TabIndex = 5;
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel30.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel30.ColumnCount = 1;
            this.tableLayoutPanel30.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel30.Controls.Add(this.btnSelectBack, 0, 2);
            this.tableLayoutPanel30.Controls.Add(this.btnSelectHome, 0, 3);
            this.tableLayoutPanel30.Controls.Add(this.btnSelectNext, 0, 4);
            this.tableLayoutPanel30.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel30.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel30.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 5;
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel30.TabIndex = 4;
            // 
            // btnSelectBack
            // 
            this.btnSelectBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnSelectBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnSelectBack.Location = new System.Drawing.Point(3, 173);
            this.btnSelectBack.Name = "btnSelectBack";
            this.btnSelectBack.Size = new System.Drawing.Size(95, 79);
            this.btnSelectBack.TabIndex = 3;
            this.btnSelectBack.Text = "Back";
            this.btnSelectBack.Click += new System.EventHandler(this.btnSelectBack_Click);
            // 
            // btnSelectHome
            // 
            this.btnSelectHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnSelectHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnSelectHome.Location = new System.Drawing.Point(3, 258);
            this.btnSelectHome.Name = "btnSelectHome";
            this.btnSelectHome.Size = new System.Drawing.Size(95, 79);
            this.btnSelectHome.TabIndex = 1;
            this.btnSelectHome.Text = "Home";
            this.btnSelectHome.Click += new System.EventHandler(this.btnSelectHome_Click);
            // 
            // btnSelectNext
            // 
            this.btnSelectNext.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnSelectNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnSelectNext.Location = new System.Drawing.Point(3, 343);
            this.btnSelectNext.Name = "btnSelectNext";
            this.btnSelectNext.Size = new System.Drawing.Size(95, 79);
            this.btnSelectNext.TabIndex = 0;
            this.btnSelectNext.Text = "Next";
            this.btnSelectNext.Click += new System.EventHandler(this.btnSelectNext_Click);
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 4;
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.Controls.Add(this.cboSelectWQ, 2, 0);
            this.tableLayoutPanel17.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel17.Controls.Add(this.dtpSelectDate, 3, 3);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectNotes, 3, 8);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectAngle, 3, 7);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectGap, 3, 6);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectFace, 3, 5);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectProcess, 3, 4);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectWelder, 3, 2);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectHeatNo, 3, 11);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectMatThickness, 3, 10);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectMatGrade, 1, 11);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectMatStandard, 1, 10);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectType, 1, 6);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectDesign, 1, 5);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectStandard, 1, 4);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectJob, 1, 3);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectWPQR, 1, 2);
            this.tableLayoutPanel17.Controls.Add(this.label42, 2, 8);
            this.tableLayoutPanel17.Controls.Add(this.label43, 2, 7);
            this.tableLayoutPanel17.Controls.Add(this.label44, 2, 6);
            this.tableLayoutPanel17.Controls.Add(this.label45, 2, 5);
            this.tableLayoutPanel17.Controls.Add(this.label46, 2, 4);
            this.tableLayoutPanel17.Controls.Add(this.label47, 2, 3);
            this.tableLayoutPanel17.Controls.Add(this.label48, 2, 2);
            this.tableLayoutPanel17.Controls.Add(this.label49, 2, 11);
            this.tableLayoutPanel17.Controls.Add(this.label50, 2, 10);
            this.tableLayoutPanel17.Controls.Add(this.label51, 0, 11);
            this.tableLayoutPanel17.Controls.Add(this.label52, 0, 10);
            this.tableLayoutPanel17.Controls.Add(this.label53, 0, 9);
            this.tableLayoutPanel17.Controls.Add(this.label54, 0, 8);
            this.tableLayoutPanel17.Controls.Add(this.label55, 0, 7);
            this.tableLayoutPanel17.Controls.Add(this.label56, 0, 6);
            this.tableLayoutPanel17.Controls.Add(this.label57, 0, 5);
            this.tableLayoutPanel17.Controls.Add(this.label58, 0, 4);
            this.tableLayoutPanel17.Controls.Add(this.label59, 0, 3);
            this.tableLayoutPanel17.Controls.Add(this.label60, 0, 2);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectPosition, 1, 7);
            this.tableLayoutPanel17.Controls.Add(this.txtSelectPreheat, 1, 8);
            this.tableLayoutPanel17.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 12;
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel17.TabIndex = 4;
            // 
            // cboSelectWQ
            // 
            this.tableLayoutPanel17.SetColumnSpan(this.cboSelectWQ, 2);
            this.cboSelectWQ.Dock = Wisej.Web.DockStyle.Fill;
            this.cboSelectWQ.Location = new System.Drawing.Point(515, 3);
            this.cboSelectWQ.Name = "cboSelectWQ";
            this.cboSelectWQ.Size = new System.Drawing.Size(506, 30);
            this.cboSelectWQ.TabIndex = 51;
            this.cboSelectWQ.SelectedItemChanged += new System.EventHandler(this.cboSelectWQ_SelectedItemChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromName("@window");
            this.label2.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.tableLayoutPanel17.SetColumnSpan(this.label2, 2);
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(506, 30);
            this.label2.TabIndex = 50;
            this.label2.Text = "Please select the Welder Qualification this WPQR will be based on:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel17.SetColumnSpan(this.label1, 4);
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1018, 30);
            this.label1.TabIndex = 49;
            this.label1.Text = "Welder Qualificiation Details";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtpSelectDate
            // 
            this.dtpSelectDate.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.dtpSelectDate.Dock = Wisej.Web.DockStyle.Fill;
            this.dtpSelectDate.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpSelectDate.Location = new System.Drawing.Point(771, 111);
            this.dtpSelectDate.Name = "dtpSelectDate";
            this.dtpSelectDate.ReadOnly = true;
            this.dtpSelectDate.Size = new System.Drawing.Size(250, 30);
            this.dtpSelectDate.TabIndex = 48;
            this.dtpSelectDate.Value = new System.DateTime(2024, 2, 19, 13, 55, 37, 653);
            // 
            // txtSelectNotes
            // 
            this.txtSelectNotes.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectNotes.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectNotes.Location = new System.Drawing.Point(771, 291);
            this.txtSelectNotes.Name = "txtSelectNotes";
            this.txtSelectNotes.ReadOnly = true;
            this.txtSelectNotes.Size = new System.Drawing.Size(250, 30);
            this.txtSelectNotes.TabIndex = 42;
            // 
            // txtSelectAngle
            // 
            this.txtSelectAngle.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectAngle.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectAngle.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtSelectAngle.Location = new System.Drawing.Point(771, 255);
            this.txtSelectAngle.Name = "txtSelectAngle";
            this.txtSelectAngle.ReadOnly = true;
            this.txtSelectAngle.Size = new System.Drawing.Size(250, 30);
            this.txtSelectAngle.TabIndex = 41;
            // 
            // txtSelectGap
            // 
            this.txtSelectGap.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectGap.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectGap.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtSelectGap.Location = new System.Drawing.Point(771, 219);
            this.txtSelectGap.Name = "txtSelectGap";
            this.txtSelectGap.ReadOnly = true;
            this.txtSelectGap.Size = new System.Drawing.Size(250, 30);
            this.txtSelectGap.TabIndex = 40;
            // 
            // txtSelectFace
            // 
            this.txtSelectFace.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectFace.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectFace.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtSelectFace.Location = new System.Drawing.Point(771, 183);
            this.txtSelectFace.Name = "txtSelectFace";
            this.txtSelectFace.ReadOnly = true;
            this.txtSelectFace.Size = new System.Drawing.Size(250, 30);
            this.txtSelectFace.TabIndex = 39;
            // 
            // txtSelectProcess
            // 
            this.txtSelectProcess.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectProcess.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectProcess.Location = new System.Drawing.Point(771, 147);
            this.txtSelectProcess.Name = "txtSelectProcess";
            this.txtSelectProcess.ReadOnly = true;
            this.txtSelectProcess.Size = new System.Drawing.Size(250, 30);
            this.txtSelectProcess.TabIndex = 38;
            // 
            // txtSelectWelder
            // 
            this.txtSelectWelder.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectWelder.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectWelder.Location = new System.Drawing.Point(771, 75);
            this.txtSelectWelder.Name = "txtSelectWelder";
            this.txtSelectWelder.ReadOnly = true;
            this.txtSelectWelder.Size = new System.Drawing.Size(250, 30);
            this.txtSelectWelder.TabIndex = 36;
            // 
            // txtSelectHeatNo
            // 
            this.txtSelectHeatNo.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectHeatNo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectHeatNo.Location = new System.Drawing.Point(771, 399);
            this.txtSelectHeatNo.Name = "txtSelectHeatNo";
            this.txtSelectHeatNo.ReadOnly = true;
            this.txtSelectHeatNo.Size = new System.Drawing.Size(250, 31);
            this.txtSelectHeatNo.TabIndex = 35;
            // 
            // txtSelectMatThickness
            // 
            this.txtSelectMatThickness.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectMatThickness.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectMatThickness.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtSelectMatThickness.Location = new System.Drawing.Point(771, 363);
            this.txtSelectMatThickness.Name = "txtSelectMatThickness";
            this.txtSelectMatThickness.ReadOnly = true;
            this.txtSelectMatThickness.Size = new System.Drawing.Size(250, 30);
            this.txtSelectMatThickness.TabIndex = 34;
            // 
            // txtSelectMatGrade
            // 
            this.txtSelectMatGrade.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectMatGrade.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectMatGrade.Location = new System.Drawing.Point(259, 399);
            this.txtSelectMatGrade.Name = "txtSelectMatGrade";
            this.txtSelectMatGrade.ReadOnly = true;
            this.txtSelectMatGrade.Size = new System.Drawing.Size(250, 31);
            this.txtSelectMatGrade.TabIndex = 33;
            // 
            // txtSelectMatStandard
            // 
            this.txtSelectMatStandard.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectMatStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectMatStandard.Location = new System.Drawing.Point(259, 363);
            this.txtSelectMatStandard.Name = "txtSelectMatStandard";
            this.txtSelectMatStandard.ReadOnly = true;
            this.txtSelectMatStandard.Size = new System.Drawing.Size(250, 30);
            this.txtSelectMatStandard.TabIndex = 32;
            // 
            // txtSelectType
            // 
            this.txtSelectType.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectType.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectType.Location = new System.Drawing.Point(259, 219);
            this.txtSelectType.Name = "txtSelectType";
            this.txtSelectType.ReadOnly = true;
            this.txtSelectType.Size = new System.Drawing.Size(250, 30);
            this.txtSelectType.TabIndex = 28;
            // 
            // txtSelectDesign
            // 
            this.txtSelectDesign.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectDesign.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectDesign.Location = new System.Drawing.Point(259, 183);
            this.txtSelectDesign.Name = "txtSelectDesign";
            this.txtSelectDesign.ReadOnly = true;
            this.txtSelectDesign.Size = new System.Drawing.Size(250, 30);
            this.txtSelectDesign.TabIndex = 27;
            // 
            // txtSelectStandard
            // 
            this.txtSelectStandard.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectStandard.Location = new System.Drawing.Point(259, 147);
            this.txtSelectStandard.Name = "txtSelectStandard";
            this.txtSelectStandard.ReadOnly = true;
            this.txtSelectStandard.Size = new System.Drawing.Size(250, 30);
            this.txtSelectStandard.TabIndex = 26;
            // 
            // txtSelectJob
            // 
            this.txtSelectJob.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectJob.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectJob.Location = new System.Drawing.Point(259, 111);
            this.txtSelectJob.Name = "txtSelectJob";
            this.txtSelectJob.ReadOnly = true;
            this.txtSelectJob.Size = new System.Drawing.Size(250, 30);
            this.txtSelectJob.TabIndex = 25;
            // 
            // txtSelectWPQR
            // 
            this.txtSelectWPQR.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectWPQR.InputType.Min = "0";
            this.txtSelectWPQR.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtSelectWPQR.InputType.Step = 1D;
            this.txtSelectWPQR.Location = new System.Drawing.Point(259, 75);
            this.txtSelectWPQR.Name = "txtSelectWPQR";
            this.txtSelectWPQR.ReadOnly = true;
            this.txtSelectWPQR.Size = new System.Drawing.Size(250, 30);
            this.txtSelectWPQR.TabIndex = 24;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.FromName("@window");
            this.label42.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label42.Dock = Wisej.Web.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(515, 291);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(250, 30);
            this.label42.TabIndex = 18;
            this.label42.Text = "Notes";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.FromName("@window");
            this.label43.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label43.Dock = Wisej.Web.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(515, 255);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(250, 30);
            this.label43.TabIndex = 17;
            this.label43.Text = "Included Angle (°)";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.FromName("@window");
            this.label44.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label44.Dock = Wisej.Web.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(515, 219);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(250, 30);
            this.label44.TabIndex = 16;
            this.label44.Text = "Root Gap (mm)";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.FromName("@window");
            this.label45.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label45.Dock = Wisej.Web.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(515, 183);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(250, 30);
            this.label45.TabIndex = 15;
            this.label45.Text = "Root Face (mm)";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.FromName("@window");
            this.label46.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label46.Dock = Wisej.Web.DockStyle.Fill;
            this.label46.Location = new System.Drawing.Point(515, 147);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(250, 30);
            this.label46.TabIndex = 14;
            this.label46.Text = "Welding Process";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.FromName("@window");
            this.label47.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label47.Dock = Wisej.Web.DockStyle.Fill;
            this.label47.Location = new System.Drawing.Point(515, 111);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(250, 30);
            this.label47.TabIndex = 13;
            this.label47.Text = "Date";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.FromName("@window");
            this.label48.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label48.Dock = Wisej.Web.DockStyle.Fill;
            this.label48.Location = new System.Drawing.Point(515, 75);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(250, 30);
            this.label48.TabIndex = 12;
            this.label48.Text = "Welder ID";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.FromName("@window");
            this.label49.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label49.Dock = Wisej.Web.DockStyle.Fill;
            this.label49.Location = new System.Drawing.Point(515, 399);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(250, 31);
            this.label49.TabIndex = 11;
            this.label49.Text = "Platecast / Heat Number";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.FromName("@window");
            this.label50.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label50.Dock = Wisej.Web.DockStyle.Fill;
            this.label50.Location = new System.Drawing.Point(515, 363);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(250, 30);
            this.label50.TabIndex = 10;
            this.label50.Text = "Thickness (mm)";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.FromName("@window");
            this.label51.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label51.Dock = Wisej.Web.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(3, 399);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(250, 31);
            this.label51.TabIndex = 9;
            this.label51.Text = "Material Grade";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.FromName("@window");
            this.label52.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label52.Dock = Wisej.Web.DockStyle.Fill;
            this.label52.Location = new System.Drawing.Point(3, 363);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(250, 30);
            this.label52.TabIndex = 8;
            this.label52.Text = "Material Standard";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label53.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel17.SetColumnSpan(this.label53, 4);
            this.label53.Dock = Wisej.Web.DockStyle.Fill;
            this.label53.Location = new System.Drawing.Point(3, 327);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(1018, 30);
            this.label53.TabIndex = 7;
            this.label53.Text = "Material Details";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.FromName("@window");
            this.label54.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label54.Dock = Wisej.Web.DockStyle.Fill;
            this.label54.Location = new System.Drawing.Point(3, 291);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(250, 30);
            this.label54.TabIndex = 6;
            this.label54.Text = "Preheat (°)";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.FromName("@window");
            this.label55.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label55.Dock = Wisej.Web.DockStyle.Fill;
            this.label55.Location = new System.Drawing.Point(3, 255);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(250, 30);
            this.label55.TabIndex = 5;
            this.label55.Text = "Welding Position";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.FromName("@window");
            this.label56.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label56.Dock = Wisej.Web.DockStyle.Fill;
            this.label56.Location = new System.Drawing.Point(3, 219);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(250, 30);
            this.label56.TabIndex = 4;
            this.label56.Text = "Joint Type";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.FromName("@window");
            this.label57.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label57.Dock = Wisej.Web.DockStyle.Fill;
            this.label57.Location = new System.Drawing.Point(3, 183);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(250, 30);
            this.label57.TabIndex = 3;
            this.label57.Text = "Joint Design";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.Color.FromName("@window");
            this.label58.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label58.Dock = Wisej.Web.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(3, 147);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(250, 30);
            this.label58.TabIndex = 2;
            this.label58.Text = "Welding Standard";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.Color.FromName("@window");
            this.label59.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label59.Dock = Wisej.Web.DockStyle.Fill;
            this.label59.Location = new System.Drawing.Point(3, 111);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(250, 30);
            this.label59.TabIndex = 1;
            this.label59.Text = "Job Number";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.FromName("@window");
            this.label60.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label60.Dock = Wisej.Web.DockStyle.Fill;
            this.label60.Location = new System.Drawing.Point(3, 75);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(250, 30);
            this.label60.TabIndex = 0;
            this.label60.Text = "WPQR Number";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtSelectPosition
            // 
            this.txtSelectPosition.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectPosition.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectPosition.Location = new System.Drawing.Point(259, 255);
            this.txtSelectPosition.Name = "txtSelectPosition";
            this.txtSelectPosition.ReadOnly = true;
            this.txtSelectPosition.Size = new System.Drawing.Size(250, 30);
            this.txtSelectPosition.TabIndex = 29;
            // 
            // txtSelectPreheat
            // 
            this.txtSelectPreheat.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtSelectPreheat.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSelectPreheat.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtSelectPreheat.Location = new System.Drawing.Point(259, 291);
            this.txtSelectPreheat.Name = "txtSelectPreheat";
            this.txtSelectPreheat.ReadOnly = true;
            this.txtSelectPreheat.Size = new System.Drawing.Size(250, 30);
            this.txtSelectPreheat.TabIndex = 30;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 1;
            this.tableLayoutPanel19.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel19.Controls.Add(this.lblInfoNote, 0, 1);
            this.tableLayoutPanel19.Controls.Add(this.label62, 0, 0);
            this.tableLayoutPanel19.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 2;
            this.tableLayoutPanel19.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel19.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel19.TabIndex = 0;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label62.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label62.CssStyle = "border-radius: 4px;";
            this.label62.Dock = Wisej.Web.DockStyle.Fill;
            this.label62.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label62.Location = new System.Drawing.Point(6, 3);
            this.label62.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(1133, 70);
            this.label62.TabIndex = 0;
            this.label62.Text = "WPQR Welder Qualification Test Selection";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblInfoNote
            // 
            this.lblInfoNote.AutoSize = true;
            this.lblInfoNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblInfoNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblInfoNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblInfoNote.LinkArea = new Wisej.Web.LinkArea(250, 84);
            this.lblInfoNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblInfoNote.Location = new System.Drawing.Point(6, 79);
            this.lblInfoNote.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.lblInfoNote.Name = "lblInfoNote";
            this.lblInfoNote.Size = new System.Drawing.Size(1133, 35);
            this.lblInfoNote.TabIndex = 10;
            this.lblInfoNote.Text = resources.GetString("lblInfoNote.Text");
            this.lblInfoNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfoNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblInfoNote_LinkClicked);
            // 
            // uc_wpqrSelect
            // 
            this.Controls.Add(this.tableLayoutPanel15);
            this.Name = "uc_wpqrSelect";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_wpqrSelect_VisibleChanged);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel30.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel15;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel16;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel18;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel30;
        private Wisej.Web.Button btnSelectBack;
        private Wisej.Web.Button btnSelectHome;
        private Wisej.Web.Button btnSelectNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel17;
        private Wisej.Web.DateTimePicker dtpSelectDate;
        private Wisej.Web.TextBox txtSelectNotes;
        private Wisej.Web.TextBox txtSelectAngle;
        private Wisej.Web.TextBox txtSelectGap;
        private Wisej.Web.TextBox txtSelectFace;
        private Wisej.Web.TextBox txtSelectProcess;
        private Wisej.Web.TextBox txtSelectWelder;
        private Wisej.Web.TextBox txtSelectHeatNo;
        private Wisej.Web.TextBox txtSelectMatThickness;
        private Wisej.Web.TextBox txtSelectMatGrade;
        private Wisej.Web.TextBox txtSelectMatStandard;
        private Wisej.Web.TextBox txtSelectType;
        private Wisej.Web.TextBox txtSelectDesign;
        private Wisej.Web.TextBox txtSelectStandard;
        private Wisej.Web.TextBox txtSelectJob;
        private Wisej.Web.TextBox txtSelectWPQR;
        private Wisej.Web.Label label42;
        private Wisej.Web.Label label43;
        private Wisej.Web.Label label44;
        private Wisej.Web.Label label45;
        private Wisej.Web.Label label46;
        private Wisej.Web.Label label47;
        private Wisej.Web.Label label48;
        private Wisej.Web.Label label49;
        private Wisej.Web.Label label50;
        private Wisej.Web.Label label51;
        private Wisej.Web.Label label52;
        private Wisej.Web.Label label53;
        private Wisej.Web.Label label54;
        private Wisej.Web.Label label55;
        private Wisej.Web.Label label56;
        private Wisej.Web.Label label57;
        private Wisej.Web.Label label58;
        private Wisej.Web.Label label59;
        private Wisej.Web.Label label60;
        private Wisej.Web.TextBox txtSelectPosition;
        private Wisej.Web.TextBox txtSelectPreheat;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel19;
        private Wisej.Web.Label label62;
        private Wisej.Web.ComboBox cboSelectWQ;
        private Wisej.Web.Label label2;
        private Wisej.Web.Label label1;
        private Wisej.Web.LinkLabel lblInfoNote;
    }
}
