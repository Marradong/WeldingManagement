﻿namespace WeldingManagement.UserControls.WPQRControls
{
    partial class uc_wpqrDetails
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_wpqrDetails));
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel4 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel6 = new Wisej.Web.TableLayoutPanel();
            this.btnDetailsBack = new Wisej.Web.Button();
            this.btnDetailsHome = new Wisej.Web.Button();
            this.btnDetailsNext = new Wisej.Web.Button();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.txtDetailsCooling = new Wisej.Web.TextBox();
            this.label8 = new Wisej.Web.Label();
            this.label9 = new Wisej.Web.Label();
            this.label5 = new Wisej.Web.Label();
            this.label4 = new Wisej.Web.Label();
            this.label7 = new Wisej.Web.Label();
            this.label1 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.label11 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.label10 = new Wisej.Web.Label();
            this.label13 = new Wisej.Web.Label();
            this.label24 = new Wisej.Web.Label();
            this.label21 = new Wisej.Web.Label();
            this.label18 = new Wisej.Web.Label();
            this.label22 = new Wisej.Web.Label();
            this.label19 = new Wisej.Web.Label();
            this.label12 = new Wisej.Web.Label();
            this.label20 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.label23 = new Wisej.Web.Label();
            this.label14 = new Wisej.Web.Label();
            this.label15 = new Wisej.Web.Label();
            this.label25 = new Wisej.Web.Label();
            this.label26 = new Wisej.Web.Label();
            this.label27 = new Wisej.Web.Label();
            this.label28 = new Wisej.Web.Label();
            this.txtDetailsSpecification = new Wisej.Web.TextBox();
            this.txtDetailsANo = new Wisej.Web.TextBox();
            this.txtDetailsForm = new Wisej.Web.TextBox();
            this.txtDetailsWMThickness = new Wisej.Web.TextBox();
            this.txtDetailsClassification = new Wisej.Web.TextBox();
            this.txtDetailsFluxClassification = new Wisej.Web.TextBox();
            this.txtDetailsType = new Wisej.Web.TextBox();
            this.txtDetailsFillerOther = new Wisej.Web.TextBox();
            this.txtDetailsFNo = new Wisej.Web.TextBox();
            this.txtDetailsSize = new Wisej.Web.TextBox();
            this.txtDetailsName = new Wisej.Web.TextBox();
            this.txtDetailsPosition = new Wisej.Web.TextBox();
            this.txtDetailsPreheat = new Wisej.Web.TextBox();
            this.txtDetailsPWHT = new Wisej.Web.TextBox();
            this.txtDetailsProgression = new Wisej.Web.TextBox();
            this.txtDetailsPositionOther = new Wisej.Web.TextBox();
            this.txtDetailsInterpass = new Wisej.Web.TextBox();
            this.txtDetailsPreheatOther = new Wisej.Web.TextBox();
            this.txtDetailsTime = new Wisej.Web.TextBox();
            this.txtDetailsHeating = new Wisej.Web.TextBox();
            this.txtDetailsPWHTOther = new Wisej.Web.TextBox();
            this.tableLayoutPanel5 = new Wisej.Web.TableLayoutPanel();
            this.lblInfoNote = new Wisej.Web.LinkLabel();
            this.label17 = new Wisej.Web.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel5, 1, 1);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel6, 0, 0);
            this.tableLayoutPanel4.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel4.TabIndex = 5;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.btnDetailsBack, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.btnDetailsHome, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.btnDetailsNext, 0, 4);
            this.tableLayoutPanel6.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel6.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 5;
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel6.TabIndex = 4;
            // 
            // btnDetailsBack
            // 
            this.btnDetailsBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDetailsBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDetailsBack.Location = new System.Drawing.Point(3, 173);
            this.btnDetailsBack.Name = "btnDetailsBack";
            this.btnDetailsBack.Size = new System.Drawing.Size(95, 79);
            this.btnDetailsBack.TabIndex = 24;
            this.btnDetailsBack.Text = "Back";
            this.btnDetailsBack.Click += new System.EventHandler(this.btnDetailsBack_Click);
            // 
            // btnDetailsHome
            // 
            this.btnDetailsHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDetailsHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDetailsHome.Location = new System.Drawing.Point(3, 258);
            this.btnDetailsHome.Name = "btnDetailsHome";
            this.btnDetailsHome.Size = new System.Drawing.Size(95, 79);
            this.btnDetailsHome.TabIndex = 23;
            this.btnDetailsHome.Text = "Home";
            this.btnDetailsHome.Click += new System.EventHandler(this.btnDetailsHome_Click);
            // 
            // btnDetailsNext
            // 
            this.btnDetailsNext.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDetailsNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDetailsNext.Location = new System.Drawing.Point(3, 343);
            this.btnDetailsNext.Name = "btnDetailsNext";
            this.btnDetailsNext.Size = new System.Drawing.Size(95, 79);
            this.btnDetailsNext.TabIndex = 22;
            this.btnDetailsNext.Text = "Next";
            this.btnDetailsNext.Click += new System.EventHandler(this.btnDetailsNext_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 6;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 16F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 17.3F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 16F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 17.3F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 16F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 17.3F));
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsCooling, 0, 11);
            this.tableLayoutPanel3.Controls.Add(this.label8, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label9, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label5, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.label4, 4, 1);
            this.tableLayoutPanel3.Controls.Add(this.label7, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.label1, 4, 2);
            this.tableLayoutPanel3.Controls.Add(this.label6, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label11, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.label2, 4, 3);
            this.tableLayoutPanel3.Controls.Add(this.label10, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label13, 2, 4);
            this.tableLayoutPanel3.Controls.Add(this.label24, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label21, 0, 11);
            this.tableLayoutPanel3.Controls.Add(this.label18, 0, 10);
            this.tableLayoutPanel3.Controls.Add(this.label22, 2, 11);
            this.tableLayoutPanel3.Controls.Add(this.label19, 2, 10);
            this.tableLayoutPanel3.Controls.Add(this.label12, 4, 10);
            this.tableLayoutPanel3.Controls.Add(this.label20, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.label3, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.label23, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.label14, 2, 8);
            this.tableLayoutPanel3.Controls.Add(this.label15, 4, 8);
            this.tableLayoutPanel3.Controls.Add(this.label25, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label26, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label27, 2, 6);
            this.tableLayoutPanel3.Controls.Add(this.label28, 4, 6);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsSpecification, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsANo, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsForm, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsWMThickness, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsClassification, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsFluxClassification, 3, 2);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsType, 3, 3);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsFillerOther, 3, 4);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsFNo, 5, 1);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsSize, 5, 2);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsName, 5, 3);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsPosition, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsPreheat, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsPWHT, 1, 10);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsProgression, 3, 6);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsPositionOther, 5, 6);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsInterpass, 3, 8);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsPreheatOther, 5, 8);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsTime, 3, 10);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsHeating, 5, 10);
            this.tableLayoutPanel3.Controls.Add(this.txtDetailsPWHTOther, 3, 11);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 12;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel3.TabIndex = 4;
            // 
            // txtDetailsCooling
            // 
            this.txtDetailsCooling.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsCooling.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtDetailsCooling.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDetailsCooling.Location = new System.Drawing.Point(167, 399);
            this.txtDetailsCooling.Name = "txtDetailsCooling";
            this.txtDetailsCooling.Size = new System.Drawing.Size(171, 31);
            this.txtDetailsCooling.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromName("@window");
            this.label8.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label8.Dock = Wisej.Web.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(3, 75);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(158, 30);
            this.label8.TabIndex = 1;
            this.label8.Text = "A-Number";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromName("@window");
            this.label9.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label9.Dock = Wisej.Web.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(3, 39);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(158, 30);
            this.label9.TabIndex = 0;
            this.label9.Text = "Specification";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromName("@window");
            this.label5.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label5.Dock = Wisej.Web.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(344, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(158, 30);
            this.label5.TabIndex = 12;
            this.label5.Text = "Classification";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromName("@window");
            this.label4.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label4.Dock = Wisej.Web.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(685, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 30);
            this.label4.TabIndex = 13;
            this.label4.Text = "F-Number";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromName("@window");
            this.label7.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label7.Dock = Wisej.Web.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(344, 75);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 30);
            this.label7.TabIndex = 2;
            this.label7.Text = "Electrode Flux Classification";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromName("@window");
            this.label1.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(685, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 30);
            this.label1.TabIndex = 16;
            this.label1.Text = "Size (mm)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromName("@window");
            this.label6.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label6.Dock = Wisej.Web.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(3, 111);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 30);
            this.label6.TabIndex = 3;
            this.label6.Text = "Filler Form";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromName("@window");
            this.label11.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label11.Dock = Wisej.Web.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(344, 111);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(158, 30);
            this.label11.TabIndex = 20;
            this.label11.Text = "Flux Type";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromName("@window");
            this.label2.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(685, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(158, 30);
            this.label2.TabIndex = 15;
            this.label2.Text = "Flux Trade Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromName("@window");
            this.label10.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label10.Dock = Wisej.Web.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(3, 147);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(158, 30);
            this.label10.TabIndex = 4;
            this.label10.Text = "Weld Metal Thickness";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromName("@window");
            this.label13.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label13.Dock = Wisej.Web.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(344, 147);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(158, 30);
            this.label13.TabIndex = 8;
            this.label13.Text = "Other";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label24.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel3.SetColumnSpan(this.label24, 6);
            this.label24.Dock = Wisej.Web.DockStyle.Fill;
            this.label24.Location = new System.Drawing.Point(3, 3);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(1018, 30);
            this.label24.TabIndex = 31;
            this.label24.Text = "Filler Metals";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.FromName("@window");
            this.label21.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label21.Dock = Wisej.Web.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(3, 399);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(158, 31);
            this.label21.TabIndex = 27;
            this.label21.Text = "Cooling Rate";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.FromName("@window");
            this.label18.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label18.Dock = Wisej.Web.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(3, 363);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(158, 30);
            this.label18.TabIndex = 24;
            this.label18.Text = "Temperature";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromName("@window");
            this.label22.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label22.Dock = Wisej.Web.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label22.Location = new System.Drawing.Point(344, 399);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(158, 31);
            this.label22.TabIndex = 28;
            this.label22.Text = "Other";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.FromName("@window");
            this.label19.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label19.Dock = Wisej.Web.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(344, 363);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(158, 30);
            this.label19.TabIndex = 25;
            this.label19.Text = "Time";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromName("@window");
            this.label12.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label12.Dock = Wisej.Web.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(685, 363);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(158, 30);
            this.label12.TabIndex = 23;
            this.label12.Text = "Heating Rate";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label20.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel3.SetColumnSpan(this.label20, 6);
            this.label20.Dock = Wisej.Web.DockStyle.Fill;
            this.label20.Location = new System.Drawing.Point(3, 327);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(1018, 30);
            this.label20.TabIndex = 29;
            this.label20.Text = "PWHT";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromName("@window");
            this.label3.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label3.Dock = Wisej.Web.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(3, 291);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 30);
            this.label3.TabIndex = 14;
            this.label3.Text = "Temperature";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label23.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel3.SetColumnSpan(this.label23, 6);
            this.label23.Dock = Wisej.Web.DockStyle.Fill;
            this.label23.Location = new System.Drawing.Point(3, 255);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(1018, 30);
            this.label23.TabIndex = 30;
            this.label23.Text = "Preheat";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromName("@window");
            this.label14.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label14.Dock = Wisej.Web.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(344, 291);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(158, 30);
            this.label14.TabIndex = 9;
            this.label14.Text = "Interpass Temperature";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromName("@window");
            this.label15.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label15.Dock = Wisej.Web.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(685, 291);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(158, 30);
            this.label15.TabIndex = 22;
            this.label15.Text = "Other";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label25.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel3.SetColumnSpan(this.label25, 6);
            this.label25.Dock = Wisej.Web.DockStyle.Fill;
            this.label25.Location = new System.Drawing.Point(3, 183);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(1018, 30);
            this.label25.TabIndex = 32;
            this.label25.Text = "Position";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.FromName("@window");
            this.label26.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label26.Dock = Wisej.Web.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label26.Location = new System.Drawing.Point(3, 219);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(158, 30);
            this.label26.TabIndex = 33;
            this.label26.Text = "Position (s)";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.FromName("@window");
            this.label27.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label27.Dock = Wisej.Web.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label27.Location = new System.Drawing.Point(344, 219);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(158, 30);
            this.label27.TabIndex = 34;
            this.label27.Text = "Weld Progression";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.FromName("@window");
            this.label28.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label28.Dock = Wisej.Web.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label28.Location = new System.Drawing.Point(685, 219);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(158, 30);
            this.label28.TabIndex = 35;
            this.label28.Text = "Other";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDetailsSpecification
            // 
            this.txtDetailsSpecification.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsSpecification.Location = new System.Drawing.Point(167, 39);
            this.txtDetailsSpecification.Name = "txtDetailsSpecification";
            this.txtDetailsSpecification.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsSpecification.TabIndex = 0;
            // 
            // txtDetailsANo
            // 
            this.txtDetailsANo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsANo.Location = new System.Drawing.Point(167, 75);
            this.txtDetailsANo.Name = "txtDetailsANo";
            this.txtDetailsANo.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsANo.TabIndex = 1;
            // 
            // txtDetailsForm
            // 
            this.txtDetailsForm.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsForm.Location = new System.Drawing.Point(167, 111);
            this.txtDetailsForm.Name = "txtDetailsForm";
            this.txtDetailsForm.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsForm.TabIndex = 2;
            // 
            // txtDetailsWMThickness
            // 
            this.txtDetailsWMThickness.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsWMThickness.Location = new System.Drawing.Point(167, 147);
            this.txtDetailsWMThickness.Name = "txtDetailsWMThickness";
            this.txtDetailsWMThickness.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsWMThickness.TabIndex = 3;
            // 
            // txtDetailsClassification
            // 
            this.txtDetailsClassification.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsClassification.Location = new System.Drawing.Point(508, 39);
            this.txtDetailsClassification.Name = "txtDetailsClassification";
            this.txtDetailsClassification.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsClassification.TabIndex = 4;
            // 
            // txtDetailsFluxClassification
            // 
            this.txtDetailsFluxClassification.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsFluxClassification.Location = new System.Drawing.Point(508, 75);
            this.txtDetailsFluxClassification.Name = "txtDetailsFluxClassification";
            this.txtDetailsFluxClassification.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsFluxClassification.TabIndex = 5;
            // 
            // txtDetailsType
            // 
            this.txtDetailsType.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsType.Location = new System.Drawing.Point(508, 111);
            this.txtDetailsType.Name = "txtDetailsType";
            this.txtDetailsType.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsType.TabIndex = 6;
            // 
            // txtDetailsFillerOther
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.txtDetailsFillerOther, 3);
            this.txtDetailsFillerOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsFillerOther.Location = new System.Drawing.Point(508, 147);
            this.txtDetailsFillerOther.Name = "txtDetailsFillerOther";
            this.txtDetailsFillerOther.Size = new System.Drawing.Size(513, 30);
            this.txtDetailsFillerOther.TabIndex = 10;
            // 
            // txtDetailsFNo
            // 
            this.txtDetailsFNo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsFNo.Location = new System.Drawing.Point(849, 39);
            this.txtDetailsFNo.Name = "txtDetailsFNo";
            this.txtDetailsFNo.Size = new System.Drawing.Size(172, 30);
            this.txtDetailsFNo.TabIndex = 7;
            // 
            // txtDetailsSize
            // 
            this.txtDetailsSize.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsSize.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtDetailsSize.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDetailsSize.Location = new System.Drawing.Point(849, 75);
            this.txtDetailsSize.Name = "txtDetailsSize";
            this.txtDetailsSize.Size = new System.Drawing.Size(172, 30);
            this.txtDetailsSize.TabIndex = 8;
            // 
            // txtDetailsName
            // 
            this.txtDetailsName.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsName.Location = new System.Drawing.Point(849, 111);
            this.txtDetailsName.Name = "txtDetailsName";
            this.txtDetailsName.Size = new System.Drawing.Size(172, 30);
            this.txtDetailsName.TabIndex = 9;
            // 
            // txtDetailsPosition
            // 
            this.txtDetailsPosition.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPosition.Location = new System.Drawing.Point(167, 219);
            this.txtDetailsPosition.Name = "txtDetailsPosition";
            this.txtDetailsPosition.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsPosition.TabIndex = 11;
            // 
            // txtDetailsPreheat
            // 
            this.txtDetailsPreheat.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPreheat.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtDetailsPreheat.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDetailsPreheat.Location = new System.Drawing.Point(167, 291);
            this.txtDetailsPreheat.Name = "txtDetailsPreheat";
            this.txtDetailsPreheat.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsPreheat.TabIndex = 14;
            // 
            // txtDetailsPWHT
            // 
            this.txtDetailsPWHT.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPWHT.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtDetailsPWHT.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDetailsPWHT.Location = new System.Drawing.Point(167, 363);
            this.txtDetailsPWHT.Name = "txtDetailsPWHT";
            this.txtDetailsPWHT.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsPWHT.TabIndex = 17;
            // 
            // txtDetailsProgression
            // 
            this.txtDetailsProgression.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsProgression.Location = new System.Drawing.Point(508, 219);
            this.txtDetailsProgression.Name = "txtDetailsProgression";
            this.txtDetailsProgression.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsProgression.TabIndex = 12;
            // 
            // txtDetailsPositionOther
            // 
            this.txtDetailsPositionOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPositionOther.Location = new System.Drawing.Point(849, 219);
            this.txtDetailsPositionOther.Name = "txtDetailsPositionOther";
            this.txtDetailsPositionOther.Size = new System.Drawing.Size(172, 30);
            this.txtDetailsPositionOther.TabIndex = 13;
            // 
            // txtDetailsInterpass
            // 
            this.txtDetailsInterpass.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsInterpass.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtDetailsInterpass.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDetailsInterpass.Location = new System.Drawing.Point(508, 291);
            this.txtDetailsInterpass.Name = "txtDetailsInterpass";
            this.txtDetailsInterpass.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsInterpass.TabIndex = 15;
            // 
            // txtDetailsPreheatOther
            // 
            this.txtDetailsPreheatOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPreheatOther.Location = new System.Drawing.Point(849, 291);
            this.txtDetailsPreheatOther.Name = "txtDetailsPreheatOther";
            this.txtDetailsPreheatOther.Size = new System.Drawing.Size(172, 30);
            this.txtDetailsPreheatOther.TabIndex = 16;
            // 
            // txtDetailsTime
            // 
            this.txtDetailsTime.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsTime.InputType.Mode = Wisej.Web.TextBoxMode.Numeric;
            this.txtDetailsTime.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDetailsTime.Location = new System.Drawing.Point(508, 363);
            this.txtDetailsTime.Name = "txtDetailsTime";
            this.txtDetailsTime.Size = new System.Drawing.Size(171, 30);
            this.txtDetailsTime.TabIndex = 19;
            // 
            // txtDetailsHeating
            // 
            this.txtDetailsHeating.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsHeating.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtDetailsHeating.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtDetailsHeating.Location = new System.Drawing.Point(849, 363);
            this.txtDetailsHeating.Name = "txtDetailsHeating";
            this.txtDetailsHeating.Size = new System.Drawing.Size(172, 30);
            this.txtDetailsHeating.TabIndex = 20;
            // 
            // txtDetailsPWHTOther
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.txtDetailsPWHTOther, 3);
            this.txtDetailsPWHTOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPWHTOther.Location = new System.Drawing.Point(508, 399);
            this.txtDetailsPWHTOther.Name = "txtDetailsPWHTOther";
            this.txtDetailsPWHTOther.Size = new System.Drawing.Size(513, 31);
            this.txtDetailsPWHTOther.TabIndex = 21;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.lblInfoNote, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel5.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // lblInfoNote
            // 
            this.lblInfoNote.AutoSize = true;
            this.lblInfoNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblInfoNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblInfoNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblInfoNote.LinkArea = new Wisej.Web.LinkArea(227, 84);
            this.lblInfoNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblInfoNote.Location = new System.Drawing.Point(6, 79);
            this.lblInfoNote.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.lblInfoNote.Name = "lblInfoNote";
            this.lblInfoNote.Size = new System.Drawing.Size(1133, 35);
            this.lblInfoNote.TabIndex = 13;
            this.lblInfoNote.Text = resources.GetString("lblInfoNote.Text");
            this.lblInfoNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfoNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblInfoNote_LinkClicked);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label17.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label17.CssStyle = "border-radius: 4px;";
            this.label17.Dock = Wisej.Web.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label17.Location = new System.Drawing.Point(6, 3);
            this.label17.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(1133, 70);
            this.label17.TabIndex = 0;
            this.label17.Text = "WPQR Details";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label17.DoubleClick += new System.EventHandler(this.label17_DoubleClick);
            // 
            // uc_wpqrDetails
            // 
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "uc_wpqrDetails";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_wpqrDetails_VisibleChanged);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.TextBox txtDetailsCooling;
        private Wisej.Web.Label label8;
        private Wisej.Web.Label label9;
        private Wisej.Web.Label label5;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label7;
        private Wisej.Web.Label label1;
        private Wisej.Web.Label label6;
        private Wisej.Web.Label label11;
        private Wisej.Web.Label label2;
        private Wisej.Web.Label label10;
        private Wisej.Web.Label label13;
        private Wisej.Web.Label label24;
        private Wisej.Web.Label label21;
        private Wisej.Web.Label label18;
        private Wisej.Web.Label label22;
        private Wisej.Web.Label label19;
        private Wisej.Web.Label label12;
        private Wisej.Web.Label label20;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label23;
        private Wisej.Web.Label label14;
        private Wisej.Web.Label label15;
        private Wisej.Web.Label label25;
        private Wisej.Web.Label label26;
        private Wisej.Web.Label label27;
        private Wisej.Web.Label label28;
        private Wisej.Web.TextBox txtDetailsSpecification;
        private Wisej.Web.TextBox txtDetailsANo;
        private Wisej.Web.TextBox txtDetailsForm;
        private Wisej.Web.TextBox txtDetailsWMThickness;
        private Wisej.Web.TextBox txtDetailsClassification;
        private Wisej.Web.TextBox txtDetailsFluxClassification;
        private Wisej.Web.TextBox txtDetailsType;
        private Wisej.Web.TextBox txtDetailsFillerOther;
        private Wisej.Web.TextBox txtDetailsFNo;
        private Wisej.Web.TextBox txtDetailsSize;
        private Wisej.Web.TextBox txtDetailsName;
        private Wisej.Web.TextBox txtDetailsPosition;
        private Wisej.Web.TextBox txtDetailsPreheat;
        private Wisej.Web.TextBox txtDetailsPWHT;
        private Wisej.Web.TextBox txtDetailsProgression;
        private Wisej.Web.TextBox txtDetailsPositionOther;
        private Wisej.Web.TextBox txtDetailsInterpass;
        private Wisej.Web.TextBox txtDetailsPreheatOther;
        private Wisej.Web.TextBox txtDetailsTime;
        private Wisej.Web.TextBox txtDetailsHeating;
        private Wisej.Web.TextBox txtDetailsPWHTOther;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel5;
        private Wisej.Web.Label label17;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel4;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel6;
        private Wisej.Web.Button btnDetailsBack;
        private Wisej.Web.Button btnDetailsHome;
        private Wisej.Web.Button btnDetailsNext;
        private Wisej.Web.LinkLabel lblInfoNote;
    }
}
