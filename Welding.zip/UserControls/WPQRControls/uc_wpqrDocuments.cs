﻿using ApiClient;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using Welding.DAL;
using WeldingManagement.UserControls.PopupControls;
using Wisej.Web;
using static WeldingManagement.FileManagement;

namespace WeldingManagement.UserControls.WPQRControls
{
    public partial class uc_wpqrDocuments : Wisej.Web.UserControl
    {
        private up_wqFileView up_wqFileView1;

        private Panel overlayPanel;

        public uc_wpqrDocuments()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = System.Drawing.Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on upload screen")]
        public event EventHandler btnUploadCompleteClick;
        private void btnUploadComplete_Click(object sender, EventArgs e)
        {
            UIFormatting.StartLoader(this);

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                UIFormatting.StopLoader(this);
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            if (!wpqr.Attachments.Any(w => w.AttachmentType == AttachmentTypes.Weld_Stamp))
            {
                UIFormatting.StopLoader(this);
                return;
            }

            if (!wpqr.Attachments.Any(w => w.AttachmentType == AttachmentTypes.Certificates))
            {
                UIFormatting.StopLoader(this);
                return;
            }

            if (!wpqr.Attachments.Any(w => w.AttachmentType == AttachmentTypes.WPQR_Sequence))
            {
                UIFormatting.StopLoader(this);
                return;
            }

            if (!wpqr.Attachments.Any(w => w.AttachmentType == AttachmentTypes.WPQR_Preparation))
            {
                UIFormatting.StopLoader(this);
                return;
            }

            Update_Status();

            if (up_wqFileView1 == null)
            {
                up_wqFileView1 = new up_wqFileView();
                this.Controls.Add(up_wqFileView1);
            }

            overlayPanel.Visible = true;

            wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            if (wpqr.Status != Actions.Complete)
            {
                UIFormatting.StopLoader(this);
                return;
            }

            string wpqrPath = TemplateCompiler.CompleteWPQR(wpqr);

            using (FileStream fStream = new FileStream(wpqrPath, FileMode.Open, FileAccess.Read))
            {
                var reader = new BinaryReader(fStream);
                var buffer = reader.ReadBytes((int)fStream.Length);
                var mem = new MemoryStream(buffer);

                up_wqFileView1.pvView_Stream = mem;
                up_wqFileView1.path = wpqrPath;
                up_wqFileView1.title = "Below is a Preview of the Completed WPQR";

                UIFormatting.StopLoader(this);

                up_wqFileView1.ShowPopup(new Point(this.Width / 2 - up_wqFileView1.Width / 2, this.Height / 2 - up_wqFileView1.Height / 2), up_wqFileView1_Closed);
            }

            UIFormatting.StopLoader(this);
        }

        private void up_wqFileView1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            btnUploadCompleteClick?.Invoke(this, new EventArgs());
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on upload screen")]
        public event EventHandler btnUploadHomeClick;
        private void btnUploadHome_Click(object sender, EventArgs e)
        {
            btnUploadHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on upload screen")]
        public event EventHandler btnUploadBackClick;
        private void btnUploadBack_Click(object sender, EventArgs e)
        {
            btnUploadBackClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks create sequence button on upload screen")]
        public event EventHandler btnUploadSequenceClick;
        private void btnUploadSequence_Click(object sender, EventArgs e)
        {
            btnUploadSequenceClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks create preparation button on upload screen")]
        public event EventHandler btnUploadPreparationClick;
        private void btnUploadPreparation_Click(object sender, EventArgs e)
        {
            btnUploadPreparationClick?.Invoke(this, e);
        }
        #endregion

        private void uplUploadSequence_Uploaded(object sender, UploadedEventArgs e)
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            for (int i = 0; i < e.Files.Count; i++)
            {
                StoreFile(e.Files[i], AttachmentTypes.WPQR_Sequence, wpqr.Welder_Qualification.WeldingAction.Job.QuoteNumber, typeof(WPQR), wpqr.WPQRId);
            }

            Load_Action();
        }

        private void uplUploadPreparation_Uploaded(object sender, UploadedEventArgs e)
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            for (int i = 0; i < e.Files.Count; i++)
            {
                StoreFile(e.Files[i], AttachmentTypes.WPQR_Preparation, wpqr.Welder_Qualification.WeldingAction.Job.QuoteNumber, typeof(WPQR), wpqr.WPQRId);
            }

            Load_Action();
        }

        private void uplUploadCertificates_Uploaded(object sender, UploadedEventArgs e)
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            for (int i = 0; i < e.Files.Count; i++)
            {
                StoreFile(e.Files[i], AttachmentTypes.Certificates, wpqr.Welder_Qualification.WeldingAction.Job.QuoteNumber, typeof(WPQR), wpqr.WPQRId);
            }

            Load_Action();
        }

        private void uplUploadStamp_Uploaded(object sender, UploadedEventArgs e)
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            for (int i = 0; i < e.Files.Count; i++)
            {
                StoreFile(e.Files[i], AttachmentTypes.Weld_Stamp, wpqr.Welder_Qualification.WeldingAction.Job.QuoteNumber, typeof(WPQR), wpqr.WPQRId);
            }

            Load_Action();
        }

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            wpqr.Status = Actions.Complete;

            ApiCalls.UpdateWPQR(wpqr.WPQRId, wpqr);

            this.Tag = new Tag(ApiCalls.ReadWPQR(wpqr.WPQRId), TagType.WPQR);
        }

        private void Load_Action()
        {
            uplUploadStamp.Visible = true;
            uplUploadPreparation.Visible = true;
            btnUploadPreparation.Visible = true;
            uplUploadSequence.Visible = true;
            btnUploadSequence.Visible = true;

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            if (wpqr.Attachments.Count <= 0) 
            {
                Attachment wqSeq = ApiCalls.ReadAttachment(wpqr.Welder_Qualification.Datasheet.Attachments.FirstOrDefault(a => a.AttachmentType == AttachmentTypes.WQ_Sequence).AttachmentId);
                wqSeq.AttachmentType = AttachmentTypes.WPQR_Sequence;
                CopyFile(wqSeq, wpqr.Welder_Qualification.WeldingAction.Job.QuoteNumber, typeof(WPQR), wpqr.WPQRId);

                wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);
            }

            lvUpload.Items.Clear();

            foreach (Attachment att in wpqr.Attachments)
            {
                ListViewItem lvItem = new ListViewItem(new string[] { att.ServerPath.Split('\\').Last(), UIFormatting.GetEnumDisplayName(att.AttachmentType) });
                lvItem.Tag = new Tag(att, TagType.Attachment);
                lvUpload.Items.Add(lvItem);

                switch (att.AttachmentType)
                {
                    case AttachmentTypes.WPQR_Preparation:
                        uplUploadPreparation.Visible = false;
                        btnUploadPreparation.Visible = false;
                        break;
                    case AttachmentTypes.WPQR_Sequence:
                        uplUploadSequence.Visible = false;
                        btnUploadSequence.Visible = false;
                        break;
                    case AttachmentTypes.Weld_Stamp:
                        uplUploadStamp.Visible = false;
                        break;
                }
            }

            lvUpload.Refresh();

            UIFormatting.ResizeColumnsFor(lvUpload);

            if (pbUpload != null && pbUpload.Image != null)
            {
                pbUpload.Image.Dispose();
            }

            if (pvUpload != null && pvUpload.PdfStream != null)
            {
                pvUpload.PdfStream = null;
            }

            pvUpload.Visible = true;
            pbUpload.Visible = false;

            tlpUpload.RowStyles[tlpUpload.GetCellPosition(pvUpload).Row].SizeType = SizeType.Percent;
            tlpUpload.RowStyles[tlpUpload.GetCellPosition(pvUpload).Row].Height = 80;

            tlpUpload.RowStyles[tlpUpload.GetCellPosition(pbUpload).Row].SizeType = SizeType.Percent;
            tlpUpload.RowStyles[tlpUpload.GetCellPosition(pbUpload).Row].Height = 0;
        }

        private void uc_wpqrDocuments_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private void lvUpload_Resize(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            UIFormatting.ResizeColumnsFor(lvUpload);
        }

        private void lvUpload_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvUpload.SelectedIndex < 0)
            {
                return;
            }

            Tag itemTag = (Tag)lvUpload.Items[lvUpload.SelectedIndex].Tag;

            ViewAttachment(itemTag, pbUpload, pvUpload, tlpUpload);
        }

        private void btnUploadDelete_Click(object sender, EventArgs e)
        {
            if (lvUpload.SelectedIndex < 0)
            {
                return;
            }

            Tag itemTag = (Tag)lvUpload.Items[lvUpload.SelectedIndex].Tag;

            DeleteAttachment(itemTag, pbUpload, pvUpload);

            Load_Action();
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }
    }
}
