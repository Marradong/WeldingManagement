﻿namespace WeldingManagement.UserControls.WPQRControls
{
    partial class uc_wpqrDocuments
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_wpqrDocuments));
            this.tableLayoutPanel14 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel22 = new Wisej.Web.TableLayoutPanel();
            this.tlpUpload = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.uplUploadStamp = new Wisej.Web.Upload();
            this.uplUploadPreparation = new Wisej.Web.Upload();
            this.btnUploadSequence = new Wisej.Web.Button();
            this.btnUploadPreparation = new Wisej.Web.Button();
            this.uplUploadSequence = new Wisej.Web.Upload();
            this.uplUploadCertificates = new Wisej.Web.Upload();
            this.pvUpload = new Wisej.Web.PdfViewer();
            this.pbUpload = new Wisej.Web.PictureBox();
            this.lvUpload = new Wisej.Web.ListView();
            this.chName = new Wisej.Web.ColumnHeader();
            this.chType = new Wisej.Web.ColumnHeader();
            this.tableLayoutPanel11 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel12 = new Wisej.Web.TableLayoutPanel();
            this.btnUploadDelete = new Wisej.Web.Button();
            this.btnUploadBack = new Wisej.Web.Button();
            this.btnUploadHome = new Wisej.Web.Button();
            this.btnUploadComplete = new Wisej.Web.Button();
            this.tableLayoutPanel15 = new Wisej.Web.TableLayoutPanel();
            this.lblInfoNote = new Wisej.Web.LinkLabel();
            this.label57 = new Wisej.Web.Label();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tlpUpload.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbUpload)).BeginInit();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 3;
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel22, 1, 3);
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel15, 1, 1);
            this.tableLayoutPanel14.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 5;
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel14.TabIndex = 8;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.Controls.Add(this.tlpUpload, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel11, 1, 0);
            this.tableLayoutPanel22.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel22.TabIndex = 1;
            // 
            // tlpUpload
            // 
            this.tlpUpload.ColumnCount = 2;
            this.tlpUpload.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 40F));
            this.tlpUpload.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 60F));
            this.tlpUpload.Controls.Add(this.tableLayoutPanel1, 0, 2);
            this.tlpUpload.Controls.Add(this.pvUpload, 1, 0);
            this.tlpUpload.Controls.Add(this.pbUpload, 1, 1);
            this.tlpUpload.Controls.Add(this.lvUpload, 0, 0);
            this.tlpUpload.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpUpload.Location = new System.Drawing.Point(3, 3);
            this.tlpUpload.Name = "tlpUpload";
            this.tlpUpload.RowCount = 3;
            this.tlpUpload.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 40F));
            this.tlpUpload.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 40F));
            this.tlpUpload.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpUpload.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tlpUpload.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tlpUpload.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tlpUpload.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tlpUpload.Size = new System.Drawing.Size(1024, 433);
            this.tlpUpload.TabIndex = 6;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel1.ColumnCount = 12;
            this.tlpUpload.SetColumnSpan(this.tableLayoutPanel1, 2);
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel1.Controls.Add(this.uplUploadStamp, 10, 0);
            this.tableLayoutPanel1.Controls.Add(this.uplUploadPreparation, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnUploadSequence, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnUploadPreparation, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.uplUploadSequence, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.uplUploadCertificates, 8, 0);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 349);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1018, 81);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // uplUploadStamp
            // 
            this.uplUploadStamp.AllowedFileTypes = ".pdf, .jpg, .jpeg, .png, .bmp";
            this.uplUploadStamp.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.uplUploadStamp.Dock = Wisej.Web.DockStyle.Fill;
            this.uplUploadStamp.HideValue = true;
            this.uplUploadStamp.Location = new System.Drawing.Point(785, 3);
            this.uplUploadStamp.Name = "uplUploadStamp";
            this.uplUploadStamp.Size = new System.Drawing.Size(178, 73);
            this.uplUploadStamp.TabIndex = 12;
            this.uplUploadStamp.Text = "Upload Weld Stamp";
            this.uplUploadStamp.Uploaded += new Wisej.Web.UploadedEventHandler(this.uplUploadStamp_Uploaded);
            // 
            // uplUploadPreparation
            // 
            this.uplUploadPreparation.AllowedFileTypes = ".pdf, .jpg, .jpeg, .png, .bmp";
            this.uplUploadPreparation.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.uplUploadPreparation.Dock = Wisej.Web.DockStyle.Fill;
            this.uplUploadPreparation.HideValue = true;
            this.uplUploadPreparation.Location = new System.Drawing.Point(49, 3);
            this.uplUploadPreparation.Name = "uplUploadPreparation";
            this.uplUploadPreparation.Size = new System.Drawing.Size(86, 73);
            this.uplUploadPreparation.TabIndex = 1;
            this.uplUploadPreparation.Text = "Upload Weld Preparation Image";
            this.uplUploadPreparation.Uploaded += new Wisej.Web.UploadedEventHandler(this.uplUploadPreparation_Uploaded);
            // 
            // btnUploadSequence
            // 
            this.btnUploadSequence.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnUploadSequence.Dock = Wisej.Web.DockStyle.Fill;
            this.btnUploadSequence.Location = new System.Drawing.Point(417, 3);
            this.btnUploadSequence.Name = "btnUploadSequence";
            this.btnUploadSequence.Size = new System.Drawing.Size(86, 73);
            this.btnUploadSequence.TabIndex = 10;
            this.btnUploadSequence.Text = "Create Sequence Drawing";
            this.btnUploadSequence.Click += new System.EventHandler(this.btnUploadSequence_Click);
            // 
            // btnUploadPreparation
            // 
            this.btnUploadPreparation.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnUploadPreparation.Dock = Wisej.Web.DockStyle.Fill;
            this.btnUploadPreparation.Location = new System.Drawing.Point(141, 3);
            this.btnUploadPreparation.Name = "btnUploadPreparation";
            this.btnUploadPreparation.Size = new System.Drawing.Size(86, 73);
            this.btnUploadPreparation.TabIndex = 9;
            this.btnUploadPreparation.Text = "Create Preparation Drawing";
            this.btnUploadPreparation.Click += new System.EventHandler(this.btnUploadPreparation_Click);
            // 
            // uplUploadSequence
            // 
            this.uplUploadSequence.AllowedFileTypes = ".pdf, .jpg, .jpeg, .png, .bmp";
            this.uplUploadSequence.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.uplUploadSequence.Dock = Wisej.Web.DockStyle.Fill;
            this.uplUploadSequence.HideValue = true;
            this.uplUploadSequence.Location = new System.Drawing.Point(325, 3);
            this.uplUploadSequence.Name = "uplUploadSequence";
            this.uplUploadSequence.Size = new System.Drawing.Size(86, 73);
            this.uplUploadSequence.TabIndex = 2;
            this.uplUploadSequence.Text = "Upload Weld Sequence Image";
            this.uplUploadSequence.Uploaded += new Wisej.Web.UploadedEventHandler(this.uplUploadSequence_Uploaded);
            // 
            // uplUploadCertificates
            // 
            this.uplUploadCertificates.AllowedFileTypes = ".pdf";
            this.uplUploadCertificates.AllowMultipleFiles = true;
            this.uplUploadCertificates.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.uplUploadCertificates.Dock = Wisej.Web.DockStyle.Fill;
            this.uplUploadCertificates.HideValue = true;
            this.uplUploadCertificates.Location = new System.Drawing.Point(555, 3);
            this.uplUploadCertificates.Name = "uplUploadCertificates";
            this.uplUploadCertificates.Size = new System.Drawing.Size(178, 73);
            this.uplUploadCertificates.TabIndex = 4;
            this.uplUploadCertificates.Text = "Upload Material & Consumable Certificates";
            this.uplUploadCertificates.Uploaded += new Wisej.Web.UploadedEventHandler(this.uplUploadCertificates_Uploaded);
            // 
            // pvUpload
            // 
            this.pvUpload.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pvUpload.CssStyle = "background-color: rgba(255, 255, 255, 1);";
            this.pvUpload.Dock = Wisej.Web.DockStyle.Fill;
            this.pvUpload.Location = new System.Drawing.Point(412, 3);
            this.pvUpload.Name = "pvUpload";
            this.pvUpload.Size = new System.Drawing.Size(609, 167);
            this.pvUpload.TabIndex = 7;
            // 
            // pbUpload
            // 
            this.pbUpload.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pbUpload.CssStyle = "background-color: rgba(255, 255, 255, 1);";
            this.pbUpload.Dock = Wisej.Web.DockStyle.Fill;
            this.pbUpload.Location = new System.Drawing.Point(412, 176);
            this.pbUpload.Name = "pbUpload";
            this.pbUpload.Size = new System.Drawing.Size(609, 167);
            this.pbUpload.SizeMode = Wisej.Web.PictureBoxSizeMode.Zoom;
            // 
            // lvUpload
            // 
            this.lvUpload.Columns.AddRange(new Wisej.Web.ColumnHeader[] {
            this.chName,
            this.chType});
            this.lvUpload.Dock = Wisej.Web.DockStyle.Fill;
            this.lvUpload.Location = new System.Drawing.Point(3, 3);
            this.lvUpload.Name = "lvUpload";
            this.tlpUpload.SetRowSpan(this.lvUpload, 2);
            this.lvUpload.Size = new System.Drawing.Size(403, 340);
            this.lvUpload.TabIndex = 5;
            this.lvUpload.View = Wisej.Web.View.Details;
            this.lvUpload.SelectedIndexChanged += new System.EventHandler(this.lvUpload_SelectedIndexChanged);
            this.lvUpload.Resize += new System.EventHandler(this.lvUpload_Resize);
            // 
            // chName
            // 
            this.chName.Name = "chName";
            this.chName.Text = "File Name";
            // 
            // chType
            // 
            this.chType.Name = "chType";
            this.chType.Text = "Category";
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.tableLayoutPanel12, 0, 0);
            this.tableLayoutPanel11.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel11.TabIndex = 5;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel12.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.btnUploadDelete, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.btnUploadBack, 0, 2);
            this.tableLayoutPanel12.Controls.Add(this.btnUploadHome, 0, 3);
            this.tableLayoutPanel12.Controls.Add(this.btnUploadComplete, 0, 4);
            this.tableLayoutPanel12.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel12.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 5;
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel12.TabIndex = 4;
            // 
            // btnUploadDelete
            // 
            this.btnUploadDelete.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnUploadDelete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnUploadDelete.Location = new System.Drawing.Point(3, 3);
            this.btnUploadDelete.Name = "btnUploadDelete";
            this.btnUploadDelete.Size = new System.Drawing.Size(95, 79);
            this.btnUploadDelete.TabIndex = 4;
            this.btnUploadDelete.Text = "Delete";
            this.btnUploadDelete.Click += new System.EventHandler(this.btnUploadDelete_Click);
            // 
            // btnUploadBack
            // 
            this.btnUploadBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnUploadBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnUploadBack.Location = new System.Drawing.Point(3, 173);
            this.btnUploadBack.Name = "btnUploadBack";
            this.btnUploadBack.Size = new System.Drawing.Size(95, 79);
            this.btnUploadBack.TabIndex = 2;
            this.btnUploadBack.Text = "Back";
            this.btnUploadBack.Click += new System.EventHandler(this.btnUploadBack_Click);
            // 
            // btnUploadHome
            // 
            this.btnUploadHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnUploadHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnUploadHome.Location = new System.Drawing.Point(3, 258);
            this.btnUploadHome.Name = "btnUploadHome";
            this.btnUploadHome.Size = new System.Drawing.Size(95, 79);
            this.btnUploadHome.TabIndex = 1;
            this.btnUploadHome.Text = "Home";
            this.btnUploadHome.Click += new System.EventHandler(this.btnUploadHome_Click);
            // 
            // btnUploadComplete
            // 
            this.btnUploadComplete.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnUploadComplete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnUploadComplete.Location = new System.Drawing.Point(3, 343);
            this.btnUploadComplete.Name = "btnUploadComplete";
            this.btnUploadComplete.Size = new System.Drawing.Size(95, 79);
            this.btnUploadComplete.TabIndex = 0;
            this.btnUploadComplete.Text = "Complete";
            this.btnUploadComplete.Click += new System.EventHandler(this.btnUploadComplete_Click);
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 1;
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Controls.Add(this.lblInfoNote, 0, 1);
            this.tableLayoutPanel15.Controls.Add(this.label57, 0, 0);
            this.tableLayoutPanel15.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 2;
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel15.TabIndex = 0;
            // 
            // lblInfoNote
            // 
            this.lblInfoNote.AutoSize = true;
            this.lblInfoNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblInfoNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblInfoNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblInfoNote.LinkArea = new Wisej.Web.LinkArea(240, 84);
            this.lblInfoNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblInfoNote.Location = new System.Drawing.Point(6, 79);
            this.lblInfoNote.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.lblInfoNote.Name = "lblInfoNote";
            this.lblInfoNote.Size = new System.Drawing.Size(1133, 35);
            this.lblInfoNote.TabIndex = 15;
            this.lblInfoNote.Text = resources.GetString("lblInfoNote.Text");
            this.lblInfoNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfoNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblInfoNote_LinkClicked);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label57.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label57.CssStyle = "border-radius: 4px;";
            this.label57.Dock = Wisej.Web.DockStyle.Fill;
            this.label57.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label57.Location = new System.Drawing.Point(6, 3);
            this.label57.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(1133, 70);
            this.label57.TabIndex = 0;
            this.label57.Text = "Weld Preparation and Sequence Upload";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uc_wpqrDocuments
            // 
            this.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.Controls.Add(this.tableLayoutPanel14);
            this.Name = "uc_wpqrDocuments";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_wpqrDocuments_VisibleChanged);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tlpUpload.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbUpload)).EndInit();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel14;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel22;
        private Wisej.Web.TableLayoutPanel tlpUpload;
        private Wisej.Web.Upload uplUploadSequence;
        private Wisej.Web.Upload uplUploadPreparation;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel11;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel12;
        private Wisej.Web.Button btnUploadBack;
        private Wisej.Web.Button btnUploadHome;
        private Wisej.Web.Button btnUploadComplete;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel15;
        private Wisej.Web.Label label57;
        private Wisej.Web.Upload uplUploadCertificates;
        private Wisej.Web.PdfViewer pvUpload;
        private Wisej.Web.PictureBox pbUpload;
        private Wisej.Web.ListView lvUpload;
        private Wisej.Web.ColumnHeader chName;
        private Wisej.Web.Button btnUploadDelete;
        private Wisej.Web.ColumnHeader chType;
        private Wisej.Web.Button btnUploadPreparation;
        private Wisej.Web.Button btnUploadSequence;
        private Wisej.Web.Upload uplUploadStamp;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.LinkLabel lblInfoNote;
    }
}
