﻿using ApiClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Drawing;
using System.Linq;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.WPQRControls
{
    public partial class uc_wpqrRun : Wisej.Web.UserControl
    {
        private up_hmSave up_hmSave1;
        private Panel overlayPanel;

        public uc_wpqrRun()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks next button on run screen")]
        public event EventHandler btnRunNextClick;
        private void btnRunNext_Click(object sender, EventArgs e)
        {
            Save_Action();
            Update_Status();

            btnRunNextClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on run screen")]
        public event EventHandler btnRunHomeClick;
        private void btnRunHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnRunHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on run screen")]
        public event EventHandler btnRunBackClick;
        private void btnRunBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnRunBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnRunBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            wpqr.Status = Actions.WPQRDetails;

            ApiCalls.UpdateWPQR(wpqr.WPQRId, wpqr);

            this.Tag = new Tag(ApiCalls.ReadWPQR(wpqr.WPQRId), TagType.WPQR);
        }

        private void Save_Action()
        {
            List<WPQR_Run> wpqr_Runs = (List<WPQR_Run>)dgvWPQRRun.DataSource;

            if (wpqr_Runs == null)
            {
                return;
            }

            for (int i = 0; i < wpqr_Runs.Count; i++)
            {
                ApiCalls.UpdateWPQRRun(wpqr_Runs[i].WPQR_RunId, wpqr_Runs[i]);
            }

            this.Tag = new Tag(ApiCalls.ReadWPQR(((WPQR)((Tag)this.Tag).getTagObject()).WPQRId), TagType.WPQR);
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPQR)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            dgvWPQRRun.DataSource = null;

            dgvWPQRRun.Rows.Clear();

            List<WPQR_Run> wpqr_Runs = wpqr.WPQR_Run.ToList();

            dgvWPQRRun.Columns["dgvcSide"].DataPropertyName = "Side";
            dgvWPQRRun.Columns["dgvcPass"].DataPropertyName = "Pass";
            dgvWPQRRun.Columns["dgvcProcess"].DataPropertyName = "WeldingProcess";
            dgvWPQRRun.Columns["dgvcPosition"].DataPropertyName = "WeldingPosition";
            dgvWPQRRun.Columns["dgvcSize"].DataPropertyName = "FillerDia";
            dgvWPQRRun.Columns["dgvcSpecification"].DataPropertyName = "Specification";
            dgvWPQRRun.Columns["dgvcClassification"].DataPropertyName = "Classification";
            dgvWPQRRun.Columns["dgvcPolarity"].DataPropertyName = "Supply";
            dgvWPQRRun.Columns["dgvcFluxGas"].DataPropertyName = "ShieldGas";
            dgvWPQRRun.Columns["dgvcInput"].DataPropertyName = "HeatInput";
            dgvWPQRRun.Columns["dgvcAmps"].DataPropertyName = "Amps";
            dgvWPQRRun.Columns["dgvcVolts"].DataPropertyName = "Volts";
            dgvWPQRRun.Columns["dgvcSpeed"].DataPropertyName = "WeldSpeed";

            if (wpqr_Runs.Count > 0)
            {
                dgvWPQRRun.DataSource = wpqr_Runs;
            }
            else
            {
                List<WPQR_Run> datasheet_Runs = wpqr.Welder_Qualification.Datasheet.Datasheet_Run
                    .Select(dtr => ApiCalls.CreateWPQRRun(wpqr.WPQRId, new WPQR_Run(wpqr)
                    {
                        Side = dtr.Side,
                        Pass = dtr.Pass,
                        WeldingProcess = wpqr.Welder_Qualification.Datasheet.WeldingProcess,
                        WeldingPosition = wpqr.Welder_Qualification.Datasheet.WeldingPosition,
                        FillerDia = dtr.FillerDia,
                        Specification = wpqr.Welder_Qualification.Datasheet.Consumables.FirstOrDefault().Specification,
                        Classification = wpqr.Welder_Qualification.Datasheet.Consumables.FirstOrDefault().Classification,
                        Supply = dtr.Supply,
                        ShieldGas = dtr.ShieldGas,
                        Volts = dtr.Volts,
                        Amps = dtr.Amps,
                        WeldSpeed = dtr.WeldSpeed,
                        HeatInput = dtr.HeatInput,
                    })).ToList();
                dgvWPQRRun.DataSource = datasheet_Runs;
            }
        }

        private void uc_wpqrRun_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private void dgvWPQRRun_Resize(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            UIFormatting.ResizeColumnsFor(dgvWPQRRun);
        }

        private void btnRunCopy_Click(object sender, EventArgs e)
        {
            if (dgvWPQRRun.SelectedCells.Count != 1)
            {
                return;
            }

            var copyVal = dgvWPQRRun.SelectedCells[0].Value.ToString();
            int rowIdx = dgvWPQRRun.SelectedCells[0].RowIndex;
            int colIdx = dgvWPQRRun.SelectedCells[0].ColumnIndex;


            if (string.IsNullOrEmpty(copyVal))
            {
                return;
            }

            for (int i = rowIdx; i < dgvWPQRRun.Rows.Count; i++)
            {
                dgvWPQRRun.Rows[i].Cells[colIdx].Value = copyVal;
            }

            dgvWPQRRun.Refresh();
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }
    }
}
