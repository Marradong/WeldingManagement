﻿namespace WeldingManagement.UserControls.WPQRControls
{
    partial class uc_wpqrContinued
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_wpqrContinued));
            this.tableLayoutPanel6 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel7 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel9 = new Wisej.Web.TableLayoutPanel();
            this.btnContBack = new Wisej.Web.Button();
            this.btnContHome = new Wisej.Web.Button();
            this.btnContNext = new Wisej.Web.Button();
            this.tableLayoutPanel8 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel4 = new Wisej.Web.TableLayoutPanel();
            this.txtContMaxInput = new Wisej.Web.TextBox();
            this.txtContMinInput = new Wisej.Web.TextBox();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.txtContMaxVolts = new Wisej.Web.TextBox();
            this.txtContMinVolts = new Wisej.Web.TextBox();
            this.tableLayoutPanel5 = new Wisej.Web.TableLayoutPanel();
            this.txtContMaxSpeed = new Wisej.Web.TextBox();
            this.txtContMinSpeed = new Wisej.Web.TextBox();
            this.label50 = new Wisej.Web.Label();
            this.txtContTechniqueOther = new Wisej.Web.TextBox();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.txtContMaxAmps = new Wisej.Web.TextBox();
            this.txtContMinAmps = new Wisej.Web.TextBox();
            this.txtContElectrodes = new Wisej.Web.TextBox();
            this.txtContPass = new Wisej.Web.TextBox();
            this.txtContOscillation = new Wisej.Web.TextBox();
            this.txtContBead = new Wisej.Web.TextBox();
            this.txtContElectricalOther = new Wisej.Web.TextBox();
            this.txtContPolarity = new Wisej.Web.TextBox();
            this.label42 = new Wisej.Web.Label();
            this.label29 = new Wisej.Web.Label();
            this.label30 = new Wisej.Web.Label();
            this.label31 = new Wisej.Web.Label();
            this.label32 = new Wisej.Web.Label();
            this.label33 = new Wisej.Web.Label();
            this.label34 = new Wisej.Web.Label();
            this.label39 = new Wisej.Web.Label();
            this.label40 = new Wisej.Web.Label();
            this.label51 = new Wisej.Web.Label();
            this.txtContShieldComp = new Wisej.Web.TextBox();
            this.txtContShieldFlow = new Wisej.Web.TextBox();
            this.txtContTrailComp = new Wisej.Web.TextBox();
            this.txtContTrailFlow = new Wisej.Web.TextBox();
            this.txtContGasOther = new Wisej.Web.TextBox();
            this.txtContBackComp = new Wisej.Web.TextBox();
            this.txtContBackFlow = new Wisej.Web.TextBox();
            this.txtContTungsten = new Wisej.Web.TextBox();
            this.txtContTransfer = new Wisej.Web.TextBox();
            this.label52 = new Wisej.Web.Label();
            this.label53 = new Wisej.Web.Label();
            this.label54 = new Wisej.Web.Label();
            this.label35 = new Wisej.Web.Label();
            this.label36 = new Wisej.Web.Label();
            this.label37 = new Wisej.Web.Label();
            this.label38 = new Wisej.Web.Label();
            this.label41 = new Wisej.Web.Label();
            this.label43 = new Wisej.Web.Label();
            this.label44 = new Wisej.Web.Label();
            this.label45 = new Wisej.Web.Label();
            this.label46 = new Wisej.Web.Label();
            this.label47 = new Wisej.Web.Label();
            this.label48 = new Wisej.Web.Label();
            this.label49 = new Wisej.Web.Label();
            this.cbContDT = new Wisej.Web.CheckBox();
            this.cbContMacro = new Wisej.Web.CheckBox();
            this.cbContVisual = new Wisej.Web.CheckBox();
            this.cbContNDT = new Wisej.Web.CheckBox();
            this.cbContHardness = new Wisej.Web.CheckBox();
            this.cbContDPI = new Wisej.Web.CheckBox();
            this.cbContBend = new Wisej.Web.CheckBox();
            this.cbContMPI = new Wisej.Web.CheckBox();
            this.cbContTensil = new Wisej.Web.CheckBox();
            this.cbContRT = new Wisej.Web.CheckBox();
            this.cbContImpact = new Wisej.Web.CheckBox();
            this.cbContUT = new Wisej.Web.CheckBox();
            this.txtContCurrent = new Wisej.Web.TextBox();
            this.txtContNotes = new Wisej.Web.TextBox();
            this.tableLayoutPanel13 = new Wisej.Web.TableLayoutPanel();
            this.lblInfoNote = new Wisej.Web.LinkLabel();
            this.label56 = new Wisej.Web.Label();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel6.ColumnCount = 3;
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel7, 1, 3);
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel13, 1, 1);
            this.tableLayoutPanel6.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 5;
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 15F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 77.5F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel6.TabIndex = 6;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel7.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel1, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel8, 0, 0);
            this.tableLayoutPanel7.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(33, 125);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(1145, 470);
            this.tableLayoutPanel7.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel9, 0, 0);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(109, 464);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel9.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.btnContBack, 0, 2);
            this.tableLayoutPanel9.Controls.Add(this.btnContHome, 0, 3);
            this.tableLayoutPanel9.Controls.Add(this.btnContNext, 0, 4);
            this.tableLayoutPanel9.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel9.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 5;
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(103, 458);
            this.tableLayoutPanel9.TabIndex = 4;
            // 
            // btnContBack
            // 
            this.btnContBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnContBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnContBack.Location = new System.Drawing.Point(3, 185);
            this.btnContBack.Name = "btnContBack";
            this.btnContBack.Size = new System.Drawing.Size(95, 85);
            this.btnContBack.TabIndex = 37;
            this.btnContBack.Text = "Back";
            this.btnContBack.Click += new System.EventHandler(this.btnContBack_Click);
            // 
            // btnContHome
            // 
            this.btnContHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnContHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnContHome.Location = new System.Drawing.Point(3, 276);
            this.btnContHome.Name = "btnContHome";
            this.btnContHome.Size = new System.Drawing.Size(95, 85);
            this.btnContHome.TabIndex = 36;
            this.btnContHome.Text = "Home";
            this.btnContHome.Click += new System.EventHandler(this.btnContHome_Click);
            // 
            // btnContNext
            // 
            this.btnContNext.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnContNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnContNext.Location = new System.Drawing.Point(3, 367);
            this.btnContNext.Name = "btnContNext";
            this.btnContNext.Size = new System.Drawing.Size(95, 86);
            this.btnContNext.TabIndex = 35;
            this.btnContNext.Text = "Next";
            this.btnContNext.Click += new System.EventHandler(this.btnContNext_Click);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 6;
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 16F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 17.3F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 16F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 17.3F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 16F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 17.3F));
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel4, 1, 7);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel3, 1, 6);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel5, 3, 9);
            this.tableLayoutPanel8.Controls.Add(this.label50, 0, 11);
            this.tableLayoutPanel8.Controls.Add(this.txtContTechniqueOther, 5, 10);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel2, 5, 5);
            this.tableLayoutPanel8.Controls.Add(this.txtContElectrodes, 3, 10);
            this.tableLayoutPanel8.Controls.Add(this.txtContPass, 1, 10);
            this.tableLayoutPanel8.Controls.Add(this.txtContOscillation, 5, 9);
            this.tableLayoutPanel8.Controls.Add(this.txtContBead, 1, 9);
            this.tableLayoutPanel8.Controls.Add(this.txtContElectricalOther, 3, 7);
            this.tableLayoutPanel8.Controls.Add(this.txtContPolarity, 3, 5);
            this.tableLayoutPanel8.Controls.Add(this.label42, 0, 8);
            this.tableLayoutPanel8.Controls.Add(this.label29, 0, 2);
            this.tableLayoutPanel8.Controls.Add(this.label30, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.label31, 2, 1);
            this.tableLayoutPanel8.Controls.Add(this.label32, 4, 1);
            this.tableLayoutPanel8.Controls.Add(this.label33, 2, 2);
            this.tableLayoutPanel8.Controls.Add(this.label34, 4, 2);
            this.tableLayoutPanel8.Controls.Add(this.label39, 0, 3);
            this.tableLayoutPanel8.Controls.Add(this.label40, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.label51, 0, 4);
            this.tableLayoutPanel8.Controls.Add(this.txtContShieldComp, 1, 1);
            this.tableLayoutPanel8.Controls.Add(this.txtContShieldFlow, 1, 2);
            this.tableLayoutPanel8.Controls.Add(this.txtContTrailComp, 3, 1);
            this.tableLayoutPanel8.Controls.Add(this.txtContTrailFlow, 3, 2);
            this.tableLayoutPanel8.Controls.Add(this.txtContGasOther, 1, 3);
            this.tableLayoutPanel8.Controls.Add(this.txtContBackComp, 5, 1);
            this.tableLayoutPanel8.Controls.Add(this.txtContBackFlow, 5, 2);
            this.tableLayoutPanel8.Controls.Add(this.txtContTungsten, 3, 6);
            this.tableLayoutPanel8.Controls.Add(this.txtContTransfer, 5, 6);
            this.tableLayoutPanel8.Controls.Add(this.label52, 0, 5);
            this.tableLayoutPanel8.Controls.Add(this.label53, 2, 5);
            this.tableLayoutPanel8.Controls.Add(this.label54, 4, 5);
            this.tableLayoutPanel8.Controls.Add(this.label35, 0, 6);
            this.tableLayoutPanel8.Controls.Add(this.label36, 2, 6);
            this.tableLayoutPanel8.Controls.Add(this.label37, 4, 6);
            this.tableLayoutPanel8.Controls.Add(this.label38, 0, 7);
            this.tableLayoutPanel8.Controls.Add(this.label41, 2, 7);
            this.tableLayoutPanel8.Controls.Add(this.label43, 0, 9);
            this.tableLayoutPanel8.Controls.Add(this.label44, 2, 9);
            this.tableLayoutPanel8.Controls.Add(this.label45, 4, 9);
            this.tableLayoutPanel8.Controls.Add(this.label46, 0, 10);
            this.tableLayoutPanel8.Controls.Add(this.label47, 2, 10);
            this.tableLayoutPanel8.Controls.Add(this.label48, 4, 10);
            this.tableLayoutPanel8.Controls.Add(this.label49, 0, 14);
            this.tableLayoutPanel8.Controls.Add(this.cbContDT, 0, 13);
            this.tableLayoutPanel8.Controls.Add(this.cbContMacro, 1, 13);
            this.tableLayoutPanel8.Controls.Add(this.cbContVisual, 1, 12);
            this.tableLayoutPanel8.Controls.Add(this.cbContNDT, 0, 12);
            this.tableLayoutPanel8.Controls.Add(this.cbContHardness, 2, 13);
            this.tableLayoutPanel8.Controls.Add(this.cbContDPI, 2, 12);
            this.tableLayoutPanel8.Controls.Add(this.cbContBend, 3, 13);
            this.tableLayoutPanel8.Controls.Add(this.cbContMPI, 3, 12);
            this.tableLayoutPanel8.Controls.Add(this.cbContTensil, 4, 13);
            this.tableLayoutPanel8.Controls.Add(this.cbContRT, 4, 12);
            this.tableLayoutPanel8.Controls.Add(this.cbContImpact, 5, 13);
            this.tableLayoutPanel8.Controls.Add(this.cbContUT, 5, 12);
            this.tableLayoutPanel8.Controls.Add(this.txtContCurrent, 1, 5);
            this.tableLayoutPanel8.Controls.Add(this.txtContNotes, 1, 14);
            this.tableLayoutPanel8.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 15;
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(1024, 464);
            this.tableLayoutPanel8.TabIndex = 4;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.txtContMaxInput, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.txtContMinInput, 0, 0);
            this.tableLayoutPanel4.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(164, 210);
            this.tableLayoutPanel4.Margin = new Wisej.Web.Padding(0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(177, 30);
            this.tableLayoutPanel4.TabIndex = 2;
            // 
            // txtContMaxInput
            // 
            this.txtContMaxInput.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContMaxInput.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtContMaxInput.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtContMaxInput.Location = new System.Drawing.Point(91, 3);
            this.txtContMaxInput.Name = "txtContMaxInput";
            this.txtContMaxInput.Size = new System.Drawing.Size(83, 24);
            this.txtContMaxInput.TabIndex = 10;
            // 
            // txtContMinInput
            // 
            this.txtContMinInput.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContMinInput.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtContMinInput.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtContMinInput.Location = new System.Drawing.Point(3, 3);
            this.txtContMinInput.Name = "txtContMinInput";
            this.txtContMinInput.Size = new System.Drawing.Size(82, 24);
            this.txtContMinInput.TabIndex = 9;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.txtContMaxVolts, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.txtContMinVolts, 0, 0);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(164, 180);
            this.tableLayoutPanel3.Margin = new Wisej.Web.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(177, 30);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // txtContMaxVolts
            // 
            this.txtContMaxVolts.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContMaxVolts.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtContMaxVolts.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtContMaxVolts.Location = new System.Drawing.Point(91, 3);
            this.txtContMaxVolts.Name = "txtContMaxVolts";
            this.txtContMaxVolts.Size = new System.Drawing.Size(83, 24);
            this.txtContMaxVolts.TabIndex = 9;
            // 
            // txtContMinVolts
            // 
            this.txtContMinVolts.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContMinVolts.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtContMinVolts.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtContMinVolts.Location = new System.Drawing.Point(3, 3);
            this.txtContMinVolts.Name = "txtContMinVolts";
            this.txtContMinVolts.Size = new System.Drawing.Size(82, 24);
            this.txtContMinVolts.TabIndex = 8;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.txtContMaxSpeed, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.txtContMinSpeed, 0, 0);
            this.tableLayoutPanel5.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(505, 270);
            this.tableLayoutPanel5.Margin = new Wisej.Web.Padding(0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(177, 30);
            this.tableLayoutPanel5.TabIndex = 3;
            // 
            // txtContMaxSpeed
            // 
            this.txtContMaxSpeed.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContMaxSpeed.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtContMaxSpeed.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtContMaxSpeed.Location = new System.Drawing.Point(91, 3);
            this.txtContMaxSpeed.Name = "txtContMaxSpeed";
            this.txtContMaxSpeed.Size = new System.Drawing.Size(83, 24);
            this.txtContMaxSpeed.TabIndex = 18;
            // 
            // txtContMinSpeed
            // 
            this.txtContMinSpeed.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContMinSpeed.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtContMinSpeed.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtContMinSpeed.Location = new System.Drawing.Point(3, 3);
            this.txtContMinSpeed.Name = "txtContMinSpeed";
            this.txtContMinSpeed.Size = new System.Drawing.Size(82, 24);
            this.txtContMinSpeed.TabIndex = 17;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label50.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel8.SetColumnSpan(this.label50, 6);
            this.label50.Dock = Wisej.Web.DockStyle.Fill;
            this.label50.Location = new System.Drawing.Point(3, 333);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(1018, 24);
            this.label50.TabIndex = 96;
            this.label50.Text = "Other";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtContTechniqueOther
            // 
            this.txtContTechniqueOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContTechniqueOther.Location = new System.Drawing.Point(849, 303);
            this.txtContTechniqueOther.Name = "txtContTechniqueOther";
            this.txtContTechniqueOther.Size = new System.Drawing.Size(172, 24);
            this.txtContTechniqueOther.TabIndex = 21;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.txtContMaxAmps, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtContMinAmps, 0, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(846, 150);
            this.tableLayoutPanel2.Margin = new Wisej.Web.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(178, 30);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // txtContMaxAmps
            // 
            this.txtContMaxAmps.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContMaxAmps.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtContMaxAmps.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtContMaxAmps.Location = new System.Drawing.Point(92, 3);
            this.txtContMaxAmps.Name = "txtContMaxAmps";
            this.txtContMaxAmps.Size = new System.Drawing.Size(83, 24);
            this.txtContMaxAmps.TabIndex = 13;
            // 
            // txtContMinAmps
            // 
            this.txtContMinAmps.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContMinAmps.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtContMinAmps.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtContMinAmps.Location = new System.Drawing.Point(3, 3);
            this.txtContMinAmps.Name = "txtContMinAmps";
            this.txtContMinAmps.Size = new System.Drawing.Size(83, 24);
            this.txtContMinAmps.TabIndex = 12;
            // 
            // txtContElectrodes
            // 
            this.txtContElectrodes.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContElectrodes.Location = new System.Drawing.Point(508, 303);
            this.txtContElectrodes.Name = "txtContElectrodes";
            this.txtContElectrodes.Size = new System.Drawing.Size(171, 24);
            this.txtContElectrodes.TabIndex = 20;
            // 
            // txtContPass
            // 
            this.txtContPass.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContPass.Location = new System.Drawing.Point(167, 303);
            this.txtContPass.Name = "txtContPass";
            this.txtContPass.Size = new System.Drawing.Size(171, 24);
            this.txtContPass.TabIndex = 19;
            // 
            // txtContOscillation
            // 
            this.txtContOscillation.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContOscillation.Location = new System.Drawing.Point(849, 273);
            this.txtContOscillation.Name = "txtContOscillation";
            this.txtContOscillation.Size = new System.Drawing.Size(172, 24);
            this.txtContOscillation.TabIndex = 18;
            // 
            // txtContBead
            // 
            this.txtContBead.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContBead.Location = new System.Drawing.Point(167, 273);
            this.txtContBead.Name = "txtContBead";
            this.txtContBead.Size = new System.Drawing.Size(171, 24);
            this.txtContBead.TabIndex = 15;
            // 
            // txtContElectricalOther
            // 
            this.tableLayoutPanel8.SetColumnSpan(this.txtContElectricalOther, 3);
            this.txtContElectricalOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContElectricalOther.Location = new System.Drawing.Point(508, 213);
            this.txtContElectricalOther.Name = "txtContElectricalOther";
            this.txtContElectricalOther.Size = new System.Drawing.Size(513, 24);
            this.txtContElectricalOther.TabIndex = 14;
            // 
            // txtContPolarity
            // 
            this.txtContPolarity.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContPolarity.Location = new System.Drawing.Point(508, 153);
            this.txtContPolarity.Name = "txtContPolarity";
            this.txtContPolarity.Size = new System.Drawing.Size(171, 24);
            this.txtContPolarity.TabIndex = 10;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label42.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel8.SetColumnSpan(this.label42, 6);
            this.label42.Dock = Wisej.Web.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(3, 243);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(1018, 24);
            this.label42.TabIndex = 63;
            this.label42.Text = "Technique";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.FromName("@window");
            this.label29.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label29.Dock = Wisej.Web.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label29.Location = new System.Drawing.Point(3, 63);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(158, 24);
            this.label29.TabIndex = 1;
            this.label29.Text = "Shielding Flow Rate";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.FromName("@window");
            this.label30.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label30.Dock = Wisej.Web.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label30.Location = new System.Drawing.Point(3, 33);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(158, 24);
            this.label30.TabIndex = 0;
            this.label30.Text = "Shielding Composition";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.FromName("@window");
            this.label31.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label31.Dock = Wisej.Web.DockStyle.Fill;
            this.label31.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label31.Location = new System.Drawing.Point(344, 33);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(158, 24);
            this.label31.TabIndex = 12;
            this.label31.Text = "Trailing Composition";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.FromName("@window");
            this.label32.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label32.Dock = Wisej.Web.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label32.Location = new System.Drawing.Point(685, 33);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(158, 24);
            this.label32.TabIndex = 13;
            this.label32.Text = "Backing Composition";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.FromName("@window");
            this.label33.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label33.Dock = Wisej.Web.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label33.Location = new System.Drawing.Point(344, 63);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(158, 24);
            this.label33.TabIndex = 2;
            this.label33.Text = "Trailing Flow Rate";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.FromName("@window");
            this.label34.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label34.Dock = Wisej.Web.DockStyle.Fill;
            this.label34.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label34.Location = new System.Drawing.Point(685, 63);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(158, 24);
            this.label34.TabIndex = 16;
            this.label34.Text = "Backing Flow Rate";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.FromName("@window");
            this.label39.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label39.Dock = Wisej.Web.DockStyle.Fill;
            this.label39.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label39.Location = new System.Drawing.Point(3, 93);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(158, 24);
            this.label39.TabIndex = 8;
            this.label39.Text = "Other";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label40.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel8.SetColumnSpan(this.label40, 6);
            this.label40.Dock = Wisej.Web.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(3, 3);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(1018, 24);
            this.label40.TabIndex = 31;
            this.label40.Text = "Gas";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label51.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel8.SetColumnSpan(this.label51, 6);
            this.label51.Dock = Wisej.Web.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(3, 123);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(1018, 24);
            this.label51.TabIndex = 32;
            this.label51.Text = "Electrical Data";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtContShieldComp
            // 
            this.txtContShieldComp.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContShieldComp.Location = new System.Drawing.Point(167, 33);
            this.txtContShieldComp.Name = "txtContShieldComp";
            this.txtContShieldComp.Size = new System.Drawing.Size(171, 24);
            this.txtContShieldComp.TabIndex = 0;
            // 
            // txtContShieldFlow
            // 
            this.txtContShieldFlow.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContShieldFlow.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtContShieldFlow.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtContShieldFlow.Location = new System.Drawing.Point(167, 63);
            this.txtContShieldFlow.Name = "txtContShieldFlow";
            this.txtContShieldFlow.Size = new System.Drawing.Size(171, 24);
            this.txtContShieldFlow.TabIndex = 1;
            // 
            // txtContTrailComp
            // 
            this.txtContTrailComp.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContTrailComp.Location = new System.Drawing.Point(508, 33);
            this.txtContTrailComp.Name = "txtContTrailComp";
            this.txtContTrailComp.Size = new System.Drawing.Size(171, 24);
            this.txtContTrailComp.TabIndex = 2;
            // 
            // txtContTrailFlow
            // 
            this.txtContTrailFlow.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContTrailFlow.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtContTrailFlow.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtContTrailFlow.Location = new System.Drawing.Point(508, 63);
            this.txtContTrailFlow.Name = "txtContTrailFlow";
            this.txtContTrailFlow.Size = new System.Drawing.Size(171, 24);
            this.txtContTrailFlow.TabIndex = 3;
            // 
            // txtContGasOther
            // 
            this.tableLayoutPanel8.SetColumnSpan(this.txtContGasOther, 5);
            this.txtContGasOther.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContGasOther.Location = new System.Drawing.Point(167, 93);
            this.txtContGasOther.Name = "txtContGasOther";
            this.txtContGasOther.Size = new System.Drawing.Size(854, 24);
            this.txtContGasOther.TabIndex = 6;
            // 
            // txtContBackComp
            // 
            this.txtContBackComp.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContBackComp.Location = new System.Drawing.Point(849, 33);
            this.txtContBackComp.Name = "txtContBackComp";
            this.txtContBackComp.Size = new System.Drawing.Size(172, 24);
            this.txtContBackComp.TabIndex = 4;
            // 
            // txtContBackFlow
            // 
            this.txtContBackFlow.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContBackFlow.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtContBackFlow.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtContBackFlow.Location = new System.Drawing.Point(849, 63);
            this.txtContBackFlow.Name = "txtContBackFlow";
            this.txtContBackFlow.Size = new System.Drawing.Size(172, 24);
            this.txtContBackFlow.TabIndex = 5;
            // 
            // txtContTungsten
            // 
            this.txtContTungsten.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContTungsten.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtContTungsten.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtContTungsten.Location = new System.Drawing.Point(508, 183);
            this.txtContTungsten.Name = "txtContTungsten";
            this.txtContTungsten.Size = new System.Drawing.Size(171, 24);
            this.txtContTungsten.TabIndex = 11;
            // 
            // txtContTransfer
            // 
            this.txtContTransfer.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContTransfer.Location = new System.Drawing.Point(849, 183);
            this.txtContTransfer.Name = "txtContTransfer";
            this.txtContTransfer.Size = new System.Drawing.Size(172, 24);
            this.txtContTransfer.TabIndex = 13;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.FromName("@window");
            this.label52.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label52.Dock = Wisej.Web.DockStyle.Fill;
            this.label52.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label52.Location = new System.Drawing.Point(3, 153);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(158, 24);
            this.label52.TabIndex = 33;
            this.label52.Text = "Current";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.FromName("@window");
            this.label53.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label53.Dock = Wisej.Web.DockStyle.Fill;
            this.label53.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label53.Location = new System.Drawing.Point(344, 153);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(158, 24);
            this.label53.TabIndex = 34;
            this.label53.Text = "Polarity";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.FromName("@window");
            this.label54.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label54.Dock = Wisej.Web.DockStyle.Fill;
            this.label54.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label54.Location = new System.Drawing.Point(685, 153);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(158, 24);
            this.label54.TabIndex = 35;
            this.label54.Text = "Amps (Min/Max)";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.FromName("@window");
            this.label35.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label35.Dock = Wisej.Web.DockStyle.Fill;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label35.Location = new System.Drawing.Point(3, 183);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(158, 24);
            this.label35.TabIndex = 58;
            this.label35.Text = "Volts (Min/Max)";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.FromName("@window");
            this.label36.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label36.Dock = Wisej.Web.DockStyle.Fill;
            this.label36.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label36.Location = new System.Drawing.Point(344, 183);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(158, 24);
            this.label36.TabIndex = 59;
            this.label36.Text = "Tungsten Electrode Size";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.FromName("@window");
            this.label37.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label37.Dock = Wisej.Web.DockStyle.Fill;
            this.label37.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label37.Location = new System.Drawing.Point(685, 183);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(158, 24);
            this.label37.TabIndex = 60;
            this.label37.Text = "Mode of Metal Transfer";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.FromName("@window");
            this.label38.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label38.Dock = Wisej.Web.DockStyle.Fill;
            this.label38.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label38.Location = new System.Drawing.Point(3, 213);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(158, 24);
            this.label38.TabIndex = 61;
            this.label38.Text = "Heat Input";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.FromName("@window");
            this.label41.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label41.Dock = Wisej.Web.DockStyle.Fill;
            this.label41.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label41.Location = new System.Drawing.Point(344, 213);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(158, 24);
            this.label41.TabIndex = 62;
            this.label41.Text = "Other";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.FromName("@window");
            this.label43.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label43.Dock = Wisej.Web.DockStyle.Fill;
            this.label43.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label43.Location = new System.Drawing.Point(3, 273);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(158, 24);
            this.label43.TabIndex = 64;
            this.label43.Text = "String / Weave Bead";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.FromName("@window");
            this.label44.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label44.Dock = Wisej.Web.DockStyle.Fill;
            this.label44.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label44.Location = new System.Drawing.Point(344, 273);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(158, 24);
            this.label44.TabIndex = 65;
            this.label44.Text = "Travel Speed";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.FromName("@window");
            this.label45.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label45.Dock = Wisej.Web.DockStyle.Fill;
            this.label45.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label45.Location = new System.Drawing.Point(685, 273);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(158, 24);
            this.label45.TabIndex = 66;
            this.label45.Text = "Oscillation";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.FromName("@window");
            this.label46.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label46.Dock = Wisej.Web.DockStyle.Fill;
            this.label46.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label46.Location = new System.Drawing.Point(3, 303);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(158, 24);
            this.label46.TabIndex = 67;
            this.label46.Text = "Multi / Single Pass";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.FromName("@window");
            this.label47.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label47.Dock = Wisej.Web.DockStyle.Fill;
            this.label47.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label47.Location = new System.Drawing.Point(344, 303);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(158, 24);
            this.label47.TabIndex = 68;
            this.label47.Text = "Single / Multiple Electrodes";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.FromName("@window");
            this.label48.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label48.Dock = Wisej.Web.DockStyle.Fill;
            this.label48.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label48.Location = new System.Drawing.Point(685, 303);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(158, 24);
            this.label48.TabIndex = 69;
            this.label48.Text = "Other";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.FromName("@window");
            this.label49.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label49.Dock = Wisej.Web.DockStyle.Fill;
            this.label49.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label49.Location = new System.Drawing.Point(3, 423);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(158, 38);
            this.label49.TabIndex = 82;
            this.label49.Text = "Notes";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbContDT
            // 
            this.cbContDT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContDT.BackColor = System.Drawing.Color.FromName("@window");
            this.cbContDT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContDT.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbContDT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContDT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContDT.Location = new System.Drawing.Point(3, 393);
            this.cbContDT.Name = "cbContDT";
            this.cbContDT.Size = new System.Drawing.Size(158, 24);
            this.cbContDT.TabIndex = 28;
            this.cbContDT.Text = "DT";
            this.cbContDT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContMacro
            // 
            this.cbContMacro.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContMacro.BackColor = System.Drawing.Color.FromName("@window");
            this.cbContMacro.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContMacro.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbContMacro.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContMacro.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContMacro.Location = new System.Drawing.Point(167, 393);
            this.cbContMacro.Name = "cbContMacro";
            this.cbContMacro.Size = new System.Drawing.Size(171, 24);
            this.cbContMacro.TabIndex = 29;
            this.cbContMacro.Text = "Macro";
            this.cbContMacro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContVisual
            // 
            this.cbContVisual.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContVisual.BackColor = System.Drawing.Color.FromName("@window");
            this.cbContVisual.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContVisual.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbContVisual.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContVisual.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContVisual.Location = new System.Drawing.Point(167, 363);
            this.cbContVisual.Name = "cbContVisual";
            this.cbContVisual.Size = new System.Drawing.Size(171, 24);
            this.cbContVisual.TabIndex = 23;
            this.cbContVisual.Text = "Visual";
            this.cbContVisual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContNDT
            // 
            this.cbContNDT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContNDT.BackColor = System.Drawing.Color.FromName("@window");
            this.cbContNDT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContNDT.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbContNDT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContNDT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContNDT.Location = new System.Drawing.Point(3, 363);
            this.cbContNDT.Name = "cbContNDT";
            this.cbContNDT.Size = new System.Drawing.Size(158, 24);
            this.cbContNDT.TabIndex = 22;
            this.cbContNDT.Text = "NDT";
            this.cbContNDT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContHardness
            // 
            this.cbContHardness.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContHardness.BackColor = System.Drawing.Color.FromName("@window");
            this.cbContHardness.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContHardness.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbContHardness.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContHardness.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContHardness.Location = new System.Drawing.Point(344, 393);
            this.cbContHardness.Name = "cbContHardness";
            this.cbContHardness.Size = new System.Drawing.Size(158, 24);
            this.cbContHardness.TabIndex = 30;
            this.cbContHardness.Text = "Hardness";
            this.cbContHardness.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContDPI
            // 
            this.cbContDPI.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContDPI.BackColor = System.Drawing.Color.FromName("@window");
            this.cbContDPI.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContDPI.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbContDPI.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContDPI.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContDPI.Location = new System.Drawing.Point(344, 363);
            this.cbContDPI.Name = "cbContDPI";
            this.cbContDPI.Size = new System.Drawing.Size(158, 24);
            this.cbContDPI.TabIndex = 24;
            this.cbContDPI.Text = "DPI";
            this.cbContDPI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContBend
            // 
            this.cbContBend.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContBend.BackColor = System.Drawing.Color.FromName("@window");
            this.cbContBend.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContBend.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbContBend.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContBend.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContBend.Location = new System.Drawing.Point(508, 393);
            this.cbContBend.Name = "cbContBend";
            this.cbContBend.Size = new System.Drawing.Size(171, 24);
            this.cbContBend.TabIndex = 31;
            this.cbContBend.Text = "Bend";
            this.cbContBend.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContMPI
            // 
            this.cbContMPI.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContMPI.BackColor = System.Drawing.Color.FromName("@window");
            this.cbContMPI.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContMPI.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbContMPI.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContMPI.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContMPI.Location = new System.Drawing.Point(508, 363);
            this.cbContMPI.Name = "cbContMPI";
            this.cbContMPI.Size = new System.Drawing.Size(171, 24);
            this.cbContMPI.TabIndex = 25;
            this.cbContMPI.Text = "MPI";
            this.cbContMPI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContTensil
            // 
            this.cbContTensil.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContTensil.BackColor = System.Drawing.Color.FromName("@window");
            this.cbContTensil.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContTensil.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbContTensil.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContTensil.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContTensil.Location = new System.Drawing.Point(685, 393);
            this.cbContTensil.Name = "cbContTensil";
            this.cbContTensil.Size = new System.Drawing.Size(158, 24);
            this.cbContTensil.TabIndex = 32;
            this.cbContTensil.Text = "Tensil";
            this.cbContTensil.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContRT
            // 
            this.cbContRT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContRT.BackColor = System.Drawing.Color.FromName("@window");
            this.cbContRT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContRT.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbContRT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContRT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContRT.Location = new System.Drawing.Point(685, 363);
            this.cbContRT.Name = "cbContRT";
            this.cbContRT.Size = new System.Drawing.Size(158, 24);
            this.cbContRT.TabIndex = 26;
            this.cbContRT.Text = "RT";
            this.cbContRT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContImpact
            // 
            this.cbContImpact.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContImpact.BackColor = System.Drawing.Color.FromName("@window");
            this.cbContImpact.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContImpact.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbContImpact.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContImpact.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContImpact.Location = new System.Drawing.Point(849, 393);
            this.cbContImpact.Name = "cbContImpact";
            this.cbContImpact.Size = new System.Drawing.Size(172, 24);
            this.cbContImpact.TabIndex = 33;
            this.cbContImpact.Text = "Impact";
            this.cbContImpact.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbContUT
            // 
            this.cbContUT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbContUT.BackColor = System.Drawing.Color.FromName("@window");
            this.cbContUT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbContUT.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbContUT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbContUT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbContUT.Location = new System.Drawing.Point(849, 363);
            this.cbContUT.Name = "cbContUT";
            this.cbContUT.Size = new System.Drawing.Size(172, 24);
            this.cbContUT.TabIndex = 27;
            this.cbContUT.Text = "UT";
            this.cbContUT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtContCurrent
            // 
            this.txtContCurrent.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContCurrent.Location = new System.Drawing.Point(167, 153);
            this.txtContCurrent.Name = "txtContCurrent";
            this.txtContCurrent.Size = new System.Drawing.Size(171, 24);
            this.txtContCurrent.TabIndex = 7;
            // 
            // txtContNotes
            // 
            this.tableLayoutPanel8.SetColumnSpan(this.txtContNotes, 5);
            this.txtContNotes.Dock = Wisej.Web.DockStyle.Fill;
            this.txtContNotes.Location = new System.Drawing.Point(167, 423);
            this.txtContNotes.Multiline = true;
            this.txtContNotes.Name = "txtContNotes";
            this.txtContNotes.Size = new System.Drawing.Size(854, 38);
            this.txtContNotes.TabIndex = 34;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel13.Controls.Add(this.lblInfoNote, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.label56, 0, 0);
            this.tableLayoutPanel13.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(1145, 86);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // lblInfoNote
            // 
            this.lblInfoNote.AutoSize = true;
            this.lblInfoNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblInfoNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblInfoNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblInfoNote.LinkArea = new Wisej.Web.LinkArea(227, 84);
            this.lblInfoNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblInfoNote.Location = new System.Drawing.Point(6, 58);
            this.lblInfoNote.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.lblInfoNote.Name = "lblInfoNote";
            this.lblInfoNote.Size = new System.Drawing.Size(1133, 25);
            this.lblInfoNote.TabIndex = 14;
            this.lblInfoNote.Text = resources.GetString("lblInfoNote.Text");
            this.lblInfoNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfoNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblInfoNote_LinkClicked);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label56.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label56.CssStyle = "border-radius: 4px;";
            this.label56.Dock = Wisej.Web.DockStyle.Fill;
            this.label56.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label56.Location = new System.Drawing.Point(6, 3);
            this.label56.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(1133, 49);
            this.label56.TabIndex = 0;
            this.label56.Text = "WPQR Details";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label56.DoubleClick += new System.EventHandler(this.label56_DoubleClick);
            // 
            // uc_wpqrContinued
            // 
            this.Controls.Add(this.tableLayoutPanel6);
            this.Name = "uc_wpqrContinued";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_wpqrContinued_VisibleChanged);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel6;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel7;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel8;
        private Wisej.Web.Label label50;
        private Wisej.Web.TextBox txtContTechniqueOther;
        private Wisej.Web.TextBox txtContElectrodes;
        private Wisej.Web.TextBox txtContPass;
        private Wisej.Web.TextBox txtContOscillation;
        private Wisej.Web.TextBox txtContMinSpeed;
        private Wisej.Web.TextBox txtContBead;
        private Wisej.Web.TextBox txtContElectricalOther;
        private Wisej.Web.TextBox txtContMinInput;
        private Wisej.Web.TextBox txtContMinAmps;
        private Wisej.Web.TextBox txtContPolarity;
        private Wisej.Web.Label label42;
        private Wisej.Web.Label label29;
        private Wisej.Web.Label label30;
        private Wisej.Web.Label label31;
        private Wisej.Web.Label label32;
        private Wisej.Web.Label label33;
        private Wisej.Web.Label label34;
        private Wisej.Web.Label label39;
        private Wisej.Web.Label label40;
        private Wisej.Web.Label label51;
        private Wisej.Web.TextBox txtContShieldComp;
        private Wisej.Web.TextBox txtContShieldFlow;
        private Wisej.Web.TextBox txtContTrailComp;
        private Wisej.Web.TextBox txtContTrailFlow;
        private Wisej.Web.TextBox txtContGasOther;
        private Wisej.Web.TextBox txtContBackComp;
        private Wisej.Web.TextBox txtContBackFlow;
        private Wisej.Web.TextBox txtContMinVolts;
        private Wisej.Web.TextBox txtContTungsten;
        private Wisej.Web.TextBox txtContTransfer;
        private Wisej.Web.Label label52;
        private Wisej.Web.Label label53;
        private Wisej.Web.Label label54;
        private Wisej.Web.Label label35;
        private Wisej.Web.Label label36;
        private Wisej.Web.Label label37;
        private Wisej.Web.Label label38;
        private Wisej.Web.Label label41;
        private Wisej.Web.Label label43;
        private Wisej.Web.Label label44;
        private Wisej.Web.Label label45;
        private Wisej.Web.Label label46;
        private Wisej.Web.Label label47;
        private Wisej.Web.Label label48;
        private Wisej.Web.Label label49;
        private Wisej.Web.CheckBox cbContDT;
        private Wisej.Web.CheckBox cbContMacro;
        private Wisej.Web.CheckBox cbContVisual;
        private Wisej.Web.CheckBox cbContNDT;
        private Wisej.Web.CheckBox cbContHardness;
        private Wisej.Web.CheckBox cbContDPI;
        private Wisej.Web.CheckBox cbContBend;
        private Wisej.Web.CheckBox cbContMPI;
        private Wisej.Web.CheckBox cbContTensil;
        private Wisej.Web.CheckBox cbContRT;
        private Wisej.Web.CheckBox cbContImpact;
        private Wisej.Web.CheckBox cbContUT;
        private Wisej.Web.TextBox txtContCurrent;
        private Wisej.Web.TextBox txtContNotes;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel13;
        private Wisej.Web.Label label56;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel9;
        private Wisej.Web.Button btnContBack;
        private Wisej.Web.Button btnContHome;
        private Wisej.Web.Button btnContNext;
        private Wisej.Web.LinkLabel lblInfoNote;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.TextBox txtContMaxAmps;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel4;
        private Wisej.Web.TextBox txtContMaxInput;
        private Wisej.Web.TextBox txtContMaxVolts;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel5;
        private Wisej.Web.TextBox txtContMaxSpeed;
    }
}
