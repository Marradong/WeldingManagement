﻿namespace WeldingManagement
{
    partial class fbRequest
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fbRequest));
            this.Boards = new Wisej.Web.TabControl();
            this.tabInfo = new Wisej.Web.TabPage();
            this.tableLayoutPanel15 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel16 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel18 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel30 = new Wisej.Web.TableLayoutPanel();
            this.btnInfoBack = new Wisej.Web.Button();
            this.btnInfoHome = new Wisej.Web.Button();
            this.btnInfoNext = new Wisej.Web.Button();
            this.tableLayoutPanel17 = new Wisej.Web.TableLayoutPanel();
            this.rbInfoComplex = new Wisej.Web.RadioButton();
            this.rbInfoStandard = new Wisej.Web.RadioButton();
            this.rbInfoLow = new Wisej.Web.RadioButton();
            this.txtInfoManager = new Wisej.Web.TextBox();
            this.label48 = new Wisej.Web.Label();
            this.label60 = new Wisej.Web.Label();
            this.txtInfoJob = new Wisej.Web.TextBox();
            this.label1 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.label4 = new Wisej.Web.Label();
            this.label7 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.label5 = new Wisej.Web.Label();
            this.label8 = new Wisej.Web.Label();
            this.label11 = new Wisej.Web.Label();
            this.label12 = new Wisej.Web.Label();
            this.label10 = new Wisej.Web.Label();
            this.label9 = new Wisej.Web.Label();
            this.label15 = new Wisej.Web.Label();
            this.label14 = new Wisej.Web.Label();
            this.label13 = new Wisej.Web.Label();
            this.label16 = new Wisej.Web.Label();
            this.label17 = new Wisej.Web.Label();
            this.label18 = new Wisej.Web.Label();
            this.label19 = new Wisej.Web.Label();
            this.label20 = new Wisej.Web.Label();
            this.label21 = new Wisej.Web.Label();
            this.label22 = new Wisej.Web.Label();
            this.label23 = new Wisej.Web.Label();
            this.label24 = new Wisej.Web.Label();
            this.label25 = new Wisej.Web.Label();
            this.label26 = new Wisej.Web.Label();
            this.label27 = new Wisej.Web.Label();
            this.label28 = new Wisej.Web.Label();
            this.label29 = new Wisej.Web.Label();
            this.tableLayoutPanel19 = new Wisej.Web.TableLayoutPanel();
            this.label61 = new Wisej.Web.Label();
            this.label62 = new Wisej.Web.Label();
            this.tabDetails = new Wisej.Web.TabPage();
            this.tableLayoutPanel20 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel21 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.WHT = new Wisej.Web.CheckBox();
            this.cbDetailsRecord = new Wisej.Web.CheckBox();
            this.cbDetailsHistory = new Wisej.Web.CheckBox();
            this.cbDetailsSymbols = new Wisej.Web.CheckBox();
            this.cbDetailsDrawing = new Wisej.Web.CheckBox();
            this.txtDetailsClient = new Wisej.Web.TextBox();
            this.txtDetailsJoint = new Wisej.Web.TextBox();
            this.txtDetailsSuggested = new Wisej.Web.TextBox();
            this.txtDetailsNominal = new Wisej.Web.TextBox();
            this.txtDetailsProcess = new Wisej.Web.TextBox();
            this.txtDetailsDate = new Wisej.Web.TextBox();
            this.txtDetailsDrawing = new Wisej.Web.TextBox();
            this.txtDetailsMatGrade = new Wisej.Web.TextBox();
            this.txtDetailsMatStandard = new Wisej.Web.TextBox();
            this.txtDetailsStandard = new Wisej.Web.TextBox();
            this.txtDetailsComponent = new Wisej.Web.TextBox();
            this.txtDetailsJob = new Wisej.Web.TextBox();
            this.label42 = new Wisej.Web.Label();
            this.label43 = new Wisej.Web.Label();
            this.label44 = new Wisej.Web.Label();
            this.label45 = new Wisej.Web.Label();
            this.label46 = new Wisej.Web.Label();
            this.label47 = new Wisej.Web.Label();
            this.label30 = new Wisej.Web.Label();
            this.label51 = new Wisej.Web.Label();
            this.label52 = new Wisej.Web.Label();
            this.label54 = new Wisej.Web.Label();
            this.label55 = new Wisej.Web.Label();
            this.label58 = new Wisej.Web.Label();
            this.label59 = new Wisej.Web.Label();
            this.label31 = new Wisej.Web.Label();
            this.txtDetailsPosition = new Wisej.Web.TextBox();
            this.txtDetailsQuality = new Wisej.Web.TextBox();
            this.cbDetailsFabrication = new Wisej.Web.CheckBox();
            this.cbDetailsIssued = new Wisej.Web.CheckBox();
            this.cbDetailsPhotos = new Wisej.Web.CheckBox();
            this.cbDetailsParent = new Wisej.Web.CheckBox();
            this.cbDetailsNDT = new Wisej.Web.CheckBox();
            this.tableLayoutPanel23 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel31 = new Wisej.Web.TableLayoutPanel();
            this.btnDetailsBack = new Wisej.Web.Button();
            this.btnDetailsHome = new Wisej.Web.Button();
            this.btnDetailsNext = new Wisej.Web.Button();
            this.tableLayoutPanel24 = new Wisej.Web.TableLayoutPanel();
            this.label77 = new Wisej.Web.Label();
            this.label78 = new Wisej.Web.Label();
            this.tabDocuments = new Wisej.Web.TabPage();
            this.tableLayoutPanel14 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel22 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel25 = new Wisej.Web.TableLayoutPanel();
            this.uplDocumentsProvide = new Wisej.Web.Upload();
            this.lvDocuments = new Wisej.Web.ListView();
            this.tableLayoutPanel26 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel27 = new Wisej.Web.TableLayoutPanel();
            this.btnDocumentsBack = new Wisej.Web.Button();
            this.btnDocumentsHome = new Wisej.Web.Button();
            this.btnDocumentsComplete = new Wisej.Web.Button();
            this.tableLayoutPanel28 = new Wisej.Web.TableLayoutPanel();
            this.label76 = new Wisej.Web.Label();
            this.label79 = new Wisej.Web.Label();
            this.tabTechnical = new Wisej.Web.TabPage();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel4 = new Wisej.Web.TableLayoutPanel();
            this.txtTechnicalDate = new Wisej.Web.TextBox();
            this.txtTechnicalExtra = new Wisej.Web.TextBox();
            this.txtTechnicalConsiderations = new Wisej.Web.TextBox();
            this.txtTechnicalReviewer = new Wisej.Web.TextBox();
            this.label37 = new Wisej.Web.Label();
            this.label50 = new Wisej.Web.Label();
            this.label53 = new Wisej.Web.Label();
            this.label56 = new Wisej.Web.Label();
            this.tableLayoutPanel5 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel6 = new Wisej.Web.TableLayoutPanel();
            this.btnTechnicalHome = new Wisej.Web.Button();
            this.btnTechnicalComplete = new Wisej.Web.Button();
            this.tableLayoutPanel7 = new Wisej.Web.TableLayoutPanel();
            this.label57 = new Wisej.Web.Label();
            this.label63 = new Wisej.Web.Label();
            this.tabOperational = new Wisej.Web.TabPage();
            this.tableLayoutPanel8 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel9 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel10 = new Wisej.Web.TableLayoutPanel();
            this.label71 = new Wisej.Web.Label();
            this.label36 = new Wisej.Web.Label();
            this.label35 = new Wisej.Web.Label();
            this.label34 = new Wisej.Web.Label();
            this.label33 = new Wisej.Web.Label();
            this.label32 = new Wisej.Web.Label();
            this.txtOperationThird = new Wisej.Web.TextBox();
            this.txtOperationEquipment = new Wisej.Web.TextBox();
            this.txtOperationFacilities = new Wisej.Web.TextBox();
            this.txtOperationStaff = new Wisej.Web.TextBox();
            this.txtOperationDate = new Wisej.Web.TextBox();
            this.txtOperationReviewer = new Wisej.Web.TextBox();
            this.label38 = new Wisej.Web.Label();
            this.label67 = new Wisej.Web.Label();
            this.cbOperationStaff = new Wisej.Web.CheckBox();
            this.cbOperationFacilities = new Wisej.Web.CheckBox();
            this.cbOperationEquipment = new Wisej.Web.CheckBox();
            this.cbOperationWPS = new Wisej.Web.CheckBox();
            this.cbOperationThird = new Wisej.Web.CheckBox();
            this.cbOperationWelders = new Wisej.Web.CheckBox();
            this.cbOperationSub = new Wisej.Web.CheckBox();
            this.cbOperationStorage = new Wisej.Web.CheckBox();
            this.cbOperationPWHT = new Wisej.Web.CheckBox();
            this.txtOperationWPS = new Wisej.Web.TextBox();
            this.txtOperationWelders = new Wisej.Web.TextBox();
            this.txtOperationSub = new Wisej.Web.TextBox();
            this.txtOperationStorage = new Wisej.Web.TextBox();
            this.txtOperationPWHT = new Wisej.Web.TextBox();
            this.txtOperationGeneral = new Wisej.Web.TextBox();
            this.txtOperationExtra = new Wisej.Web.TextBox();
            this.label39 = new Wisej.Web.Label();
            this.label40 = new Wisej.Web.Label();
            this.label41 = new Wisej.Web.Label();
            this.label49 = new Wisej.Web.Label();
            this.label64 = new Wisej.Web.Label();
            this.label65 = new Wisej.Web.Label();
            this.label66 = new Wisej.Web.Label();
            this.label70 = new Wisej.Web.Label();
            this.tableLayoutPanel11 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel12 = new Wisej.Web.TableLayoutPanel();
            this.btnOperationHome = new Wisej.Web.Button();
            this.btnOperationComplete = new Wisej.Web.Button();
            this.tableLayoutPanel13 = new Wisej.Web.TableLayoutPanel();
            this.label68 = new Wisej.Web.Label();
            this.label69 = new Wisej.Web.Label();
            this.Boards.SuspendLayout();
            this.tabInfo.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.tabDetails.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.tabDocuments.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.tabTechnical.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tabOperational.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.SuspendLayout();
            // 
            // Boards
            // 
            this.Boards.Alignment = Wisej.Web.TabAlignment.Top;
            this.Boards.BorderStyle = Wisej.Web.BorderStyle.None;
            this.Boards.Controls.Add(this.tabInfo);
            this.Boards.Controls.Add(this.tabDetails);
            this.Boards.Controls.Add(this.tabDocuments);
            this.Boards.Controls.Add(this.tabTechnical);
            this.Boards.Controls.Add(this.tabOperational);
            this.Boards.Display = Wisej.Web.Display.Label;
            this.Boards.Dock = Wisej.Web.DockStyle.Fill;
            this.Boards.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Boards.Location = new System.Drawing.Point(0, 0);
            this.Boards.Name = "Boards";
            this.Boards.Orientation = Wisej.Web.Orientation.Horizontal;
            this.Boards.PageInsets = new Wisej.Web.Padding(0, 35, 0, 0);
            this.Boards.SelectedIndex = 0;
            this.Boards.Size = new System.Drawing.Size(1212, 650);
            this.Boards.TabIndex = 3;
            this.Boards.TabStop = false;
            this.Boards.Selecting += new Wisej.Web.TabControlCancelEventHandler(this.Boards_Selecting);
            // 
            // tabInfo
            // 
            this.tabInfo.Controls.Add(this.tableLayoutPanel15);
            this.tabInfo.Location = new System.Drawing.Point(0, 35);
            this.tabInfo.Name = "tabInfo";
            this.tabInfo.Size = new System.Drawing.Size(1212, 615);
            this.tabInfo.Text = "Info";
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 3;
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.Controls.Add(this.tableLayoutPanel16, 1, 3);
            this.tableLayoutPanel15.Controls.Add(this.tableLayoutPanel19, 1, 1);
            this.tableLayoutPanel15.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 5;
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel15.TabIndex = 2;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel16.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel18, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel17, 0, 0);
            this.tableLayoutPanel16.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel16.TabIndex = 1;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 1;
            this.tableLayoutPanel18.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Controls.Add(this.tableLayoutPanel30, 0, 0);
            this.tableLayoutPanel18.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel18.TabIndex = 5;
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel30.ColumnCount = 1;
            this.tableLayoutPanel30.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel30.Controls.Add(this.btnInfoBack, 0, 2);
            this.tableLayoutPanel30.Controls.Add(this.btnInfoHome, 0, 3);
            this.tableLayoutPanel30.Controls.Add(this.btnInfoNext, 0, 4);
            this.tableLayoutPanel30.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel30.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 5;
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel30.TabIndex = 4;
            // 
            // btnInfoBack
            // 
            this.btnInfoBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoBack.Location = new System.Drawing.Point(3, 173);
            this.btnInfoBack.Name = "btnInfoBack";
            this.btnInfoBack.Size = new System.Drawing.Size(95, 79);
            this.btnInfoBack.TabIndex = 3;
            this.btnInfoBack.Text = "Back";
            this.btnInfoBack.Click += new System.EventHandler(this.btnInfoBack_Click);
            // 
            // btnInfoHome
            // 
            this.btnInfoHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoHome.Location = new System.Drawing.Point(3, 258);
            this.btnInfoHome.Name = "btnInfoHome";
            this.btnInfoHome.Size = new System.Drawing.Size(95, 79);
            this.btnInfoHome.TabIndex = 1;
            this.btnInfoHome.Text = "Home";
            this.btnInfoHome.Click += new System.EventHandler(this.btnInfoHome_Click);
            // 
            // btnInfoNext
            // 
            this.btnInfoNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoNext.Location = new System.Drawing.Point(3, 343);
            this.btnInfoNext.Name = "btnInfoNext";
            this.btnInfoNext.Size = new System.Drawing.Size(95, 79);
            this.btnInfoNext.TabIndex = 0;
            this.btnInfoNext.Text = "Next";
            this.btnInfoNext.Click += new System.EventHandler(this.btnInfoNext_Click);
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 4;
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 15F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel17.Controls.Add(this.rbInfoComplex, 3, 8);
            this.tableLayoutPanel17.Controls.Add(this.rbInfoStandard, 2, 8);
            this.tableLayoutPanel17.Controls.Add(this.rbInfoLow, 1, 8);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoManager, 3, 0);
            this.tableLayoutPanel17.Controls.Add(this.label48, 2, 0);
            this.tableLayoutPanel17.Controls.Add(this.label60, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.txtInfoJob, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel17.Controls.Add(this.label2, 1, 1);
            this.tableLayoutPanel17.Controls.Add(this.label3, 2, 1);
            this.tableLayoutPanel17.Controls.Add(this.label4, 3, 1);
            this.tableLayoutPanel17.Controls.Add(this.label7, 0, 2);
            this.tableLayoutPanel17.Controls.Add(this.label6, 1, 2);
            this.tableLayoutPanel17.Controls.Add(this.label5, 2, 2);
            this.tableLayoutPanel17.Controls.Add(this.label8, 3, 2);
            this.tableLayoutPanel17.Controls.Add(this.label11, 0, 3);
            this.tableLayoutPanel17.Controls.Add(this.label12, 1, 3);
            this.tableLayoutPanel17.Controls.Add(this.label10, 2, 3);
            this.tableLayoutPanel17.Controls.Add(this.label9, 3, 3);
            this.tableLayoutPanel17.Controls.Add(this.label15, 0, 4);
            this.tableLayoutPanel17.Controls.Add(this.label14, 1, 4);
            this.tableLayoutPanel17.Controls.Add(this.label13, 2, 4);
            this.tableLayoutPanel17.Controls.Add(this.label16, 3, 4);
            this.tableLayoutPanel17.Controls.Add(this.label17, 0, 5);
            this.tableLayoutPanel17.Controls.Add(this.label18, 1, 5);
            this.tableLayoutPanel17.Controls.Add(this.label19, 2, 5);
            this.tableLayoutPanel17.Controls.Add(this.label20, 3, 5);
            this.tableLayoutPanel17.Controls.Add(this.label21, 0, 6);
            this.tableLayoutPanel17.Controls.Add(this.label22, 1, 6);
            this.tableLayoutPanel17.Controls.Add(this.label23, 2, 6);
            this.tableLayoutPanel17.Controls.Add(this.label24, 3, 6);
            this.tableLayoutPanel17.Controls.Add(this.label25, 0, 7);
            this.tableLayoutPanel17.Controls.Add(this.label26, 1, 7);
            this.tableLayoutPanel17.Controls.Add(this.label27, 2, 7);
            this.tableLayoutPanel17.Controls.Add(this.label28, 3, 7);
            this.tableLayoutPanel17.Controls.Add(this.label29, 0, 8);
            this.tableLayoutPanel17.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 9;
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel17.TabIndex = 4;
            // 
            // rbInfoComplex
            // 
            this.rbInfoComplex.Dock = Wisej.Web.DockStyle.Fill;
            this.rbInfoComplex.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbInfoComplex.Location = new System.Drawing.Point(668, 398);
            this.rbInfoComplex.Name = "rbInfoComplex";
            this.rbInfoComplex.Size = new System.Drawing.Size(353, 32);
            this.rbInfoComplex.TabIndex = 70;
            this.rbInfoComplex.TabStop = true;
            this.rbInfoComplex.Text = "Complex";
            // 
            // rbInfoStandard
            // 
            this.rbInfoStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.rbInfoStandard.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbInfoStandard.Location = new System.Drawing.Point(412, 398);
            this.rbInfoStandard.Name = "rbInfoStandard";
            this.rbInfoStandard.Size = new System.Drawing.Size(250, 32);
            this.rbInfoStandard.TabIndex = 69;
            this.rbInfoStandard.TabStop = true;
            this.rbInfoStandard.Text = "Standard";
            // 
            // rbInfoLow
            // 
            this.rbInfoLow.Dock = Wisej.Web.DockStyle.Fill;
            this.rbInfoLow.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbInfoLow.Location = new System.Drawing.Point(156, 398);
            this.rbInfoLow.Name = "rbInfoLow";
            this.rbInfoLow.Size = new System.Drawing.Size(250, 32);
            this.rbInfoLow.TabIndex = 68;
            this.rbInfoLow.TabStop = true;
            this.rbInfoLow.Text = "Low";
            // 
            // txtInfoManager
            // 
            this.txtInfoManager.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoManager.Location = new System.Drawing.Point(668, 3);
            this.txtInfoManager.Name = "txtInfoManager";
            this.txtInfoManager.Size = new System.Drawing.Size(353, 28);
            this.txtInfoManager.TabIndex = 36;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = Wisej.Web.DockStyle.Fill;
            this.label48.Location = new System.Drawing.Point(412, 3);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(250, 28);
            this.label48.TabIndex = 12;
            this.label48.Text = "Client Manger EID";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Dock = Wisej.Web.DockStyle.Fill;
            this.label60.Location = new System.Drawing.Point(3, 3);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(147, 28);
            this.label60.TabIndex = 0;
            this.label60.Text = "Job Number";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtInfoJob
            // 
            this.txtInfoJob.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoJob.Location = new System.Drawing.Point(156, 3);
            this.txtInfoJob.Name = "txtInfoJob";
            this.txtInfoJob.Size = new System.Drawing.Size(250, 28);
            this.txtInfoJob.TabIndex = 38;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 28);
            this.label1.TabIndex = 39;
            this.label1.Text = "Aspect";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(156, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(250, 28);
            this.label2.TabIndex = 40;
            this.label2.Text = "Low";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label3.Dock = Wisej.Web.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(412, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(250, 28);
            this.label3.TabIndex = 41;
            this.label3.Text = "Standard";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label4.Dock = Wisej.Web.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(668, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(353, 28);
            this.label4.TabIndex = 42;
            this.label4.Text = "Complex";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = Wisej.Web.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(3, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(147, 62);
            this.label7.TabIndex = 45;
            this.label7.Text = "Services";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = Wisej.Web.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(156, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(250, 62);
            this.label6.TabIndex = 44;
            this.label6.Text = "General structural static loading components.";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = Wisej.Web.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(412, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(250, 62);
            this.label5.TabIndex = 43;
            this.label5.Text = "Structural components with dynamic loading.";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = Wisej.Web.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(668, 71);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(353, 62);
            this.label8.TabIndex = 46;
            this.label8.Text = resources.GetString("label8.Text");
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = Wisej.Web.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(3, 139);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(147, 35);
            this.label11.TabIndex = 49;
            this.label11.Text = "Failure of the weld";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = Wisej.Web.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(156, 139);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(250, 35);
            this.label12.TabIndex = 50;
            this.label12.Text = "Not impair the intended use of the construction";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = Wisej.Web.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(412, 139);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(250, 35);
            this.label10.TabIndex = 48;
            this.label10.Text = "Impair the intended use of the construction and the operational unit";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = Wisej.Web.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(668, 139);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(353, 35);
            this.label9.TabIndex = 47;
            this.label9.Text = "Total product Failure";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = Wisej.Web.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(3, 180);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(147, 35);
            this.label15.TabIndex = 53;
            this.label15.Text = "Safety impact if weld fails";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = Wisej.Web.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(156, 180);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(250, 35);
            this.label14.TabIndex = 52;
            this.label14.Text = "No Adverse Impact";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = Wisej.Web.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(412, 180);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(250, 35);
            this.label13.TabIndex = 51;
            this.label13.Text = "Normal Safety Risk";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = Wisej.Web.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(668, 180);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(353, 35);
            this.label16.TabIndex = 54;
            this.label16.Text = "Major Risk to Human Life";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = Wisej.Web.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(3, 221);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(147, 35);
            this.label17.TabIndex = 55;
            this.label17.Text = "Financial consequence";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = Wisej.Web.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(156, 221);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(250, 35);
            this.label18.TabIndex = 56;
            this.label18.Text = "Minor Financial consequences";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = Wisej.Web.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(412, 221);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(250, 35);
            this.label19.TabIndex = 57;
            this.label19.Text = "Not Extreme";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = Wisej.Web.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label20.Location = new System.Drawing.Point(668, 221);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(353, 35);
            this.label20.TabIndex = 58;
            this.label20.Text = "Successive significant financial consequences";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = Wisej.Web.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(3, 262);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(147, 62);
            this.label21.TabIndex = 59;
            this.label21.Text = "Manufacturing technique";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = Wisej.Web.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label22.Location = new System.Drawing.Point(156, 262);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(250, 62);
            this.label22.TabIndex = 60;
            this.label22.Text = "Simple materials and techniques";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Dock = Wisej.Web.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label23.Location = new System.Drawing.Point(412, 262);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(250, 62);
            this.label23.TabIndex = 61;
            this.label23.Text = "Conventional without reliant on high performance materials";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = Wisej.Web.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label24.Location = new System.Drawing.Point(668, 262);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(353, 62);
            this.label24.TabIndex = 62;
            this.label24.Text = "Complex range of materials including high performance metals with high control re" +
    "quired.  Standard materials such as structural boiler steels and aluminum alloys" +
    " with enhanced control.";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = Wisej.Web.DockStyle.Fill;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label25.Location = new System.Drawing.Point(3, 330);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(147, 62);
            this.label25.TabIndex = 63;
            this.label25.Text = "Examples";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = Wisej.Web.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label26.Location = new System.Drawing.Point(156, 330);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(250, 62);
            this.label26.TabIndex = 64;
            this.label26.Text = "-  General structural static loading components";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = Wisej.Web.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label27.Location = new System.Drawing.Point(412, 330);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(250, 62);
            this.label27.TabIndex = 65;
            this.label27.Text = "-  Pressure piping – lower hazard\r\n-  Structural steel, platforms, handrails, sta" +
    "irs and ladders \r\n-  Brackets\r\n-  Office and storage shelving\r\n-  Mobile equipme" +
    "nt";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = Wisej.Web.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label28.Location = new System.Drawing.Point(668, 330);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(353, 62);
            this.label28.TabIndex = 66;
            this.label28.Text = resources.GetString("label28.Text");
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = Wisej.Web.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label29.Location = new System.Drawing.Point(3, 398);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(147, 32);
            this.label29.TabIndex = 67;
            this.label29.Text = "Indicated complexity";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 1;
            this.tableLayoutPanel19.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel19.Controls.Add(this.label61, 0, 1);
            this.tableLayoutPanel19.Controls.Add(this.label62, 0, 0);
            this.tableLayoutPanel19.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 2;
            this.tableLayoutPanel19.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel19.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel19.TabIndex = 0;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label61.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label61.Dock = Wisej.Web.DockStyle.Fill;
            this.label61.Location = new System.Drawing.Point(3, 79);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(1139, 35);
            this.label61.TabIndex = 1;
            this.label61.Text = "Notes";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label62.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label62.Dock = Wisej.Web.DockStyle.Fill;
            this.label62.Location = new System.Drawing.Point(3, 3);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(1139, 70);
            this.label62.TabIndex = 0;
            this.label62.Text = "Welding Scope of Work";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabDetails
            // 
            this.tabDetails.Controls.Add(this.tableLayoutPanel20);
            this.tabDetails.Location = new System.Drawing.Point(0, 35);
            this.tabDetails.Name = "tabDetails";
            this.tabDetails.Size = new System.Drawing.Size(1212, 615);
            this.tabDetails.Text = "Details";
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.ColumnCount = 3;
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel21, 1, 3);
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel24, 1, 1);
            this.tableLayoutPanel20.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 5;
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel20.TabIndex = 3;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel21.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel1, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel23, 1, 0);
            this.tableLayoutPanel21.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel21.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.WHT, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.cbDetailsRecord, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.cbDetailsHistory, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.cbDetailsSymbols, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.cbDetailsDrawing, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsClient, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsJoint, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsSuggested, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsNominal, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsProcess, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsDate, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsDrawing, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsMatGrade, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsMatStandard, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsStandard, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsComponent, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsJob, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label42, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.label43, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.label44, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.label45, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.label46, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label47, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label30, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label51, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label52, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label54, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label55, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label58, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label59, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label31, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsPosition, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsQuality, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.cbDetailsFabrication, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.cbDetailsIssued, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.cbDetailsPhotos, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.cbDetailsParent, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.cbDetailsNDT, 2, 11);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 12;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel1.TabIndex = 6;
            // 
            // WHT
            // 
            this.WHT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tableLayoutPanel1.SetColumnSpan(this.WHT, 2);
            this.WHT.Dock = Wisej.Web.DockStyle.Fill;
            this.WHT.Location = new System.Drawing.Point(3, 387);
            this.WHT.Name = "WHT";
            this.WHT.Size = new System.Drawing.Size(506, 43);
            this.WHT.TabIndex = 47;
            this.WHT.Text = "PWHT requirements (steel tempering temperature must be known if applicable)";
            // 
            // cbDetailsRecord
            // 
            this.cbDetailsRecord.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tableLayoutPanel1.SetColumnSpan(this.cbDetailsRecord, 2);
            this.cbDetailsRecord.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDetailsRecord.Location = new System.Drawing.Point(3, 359);
            this.cbDetailsRecord.Name = "cbDetailsRecord";
            this.cbDetailsRecord.Size = new System.Drawing.Size(506, 22);
            this.cbDetailsRecord.TabIndex = 46;
            this.cbDetailsRecord.Text = "Welding repair record if applicable";
            // 
            // cbDetailsHistory
            // 
            this.cbDetailsHistory.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tableLayoutPanel1.SetColumnSpan(this.cbDetailsHistory, 2);
            this.cbDetailsHistory.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDetailsHistory.Location = new System.Drawing.Point(3, 331);
            this.cbDetailsHistory.Name = "cbDetailsHistory";
            this.cbDetailsHistory.Size = new System.Drawing.Size(506, 22);
            this.cbDetailsHistory.TabIndex = 45;
            this.cbDetailsHistory.Text = "History of thermal treatment of material";
            // 
            // cbDetailsSymbols
            // 
            this.cbDetailsSymbols.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tableLayoutPanel1.SetColumnSpan(this.cbDetailsSymbols, 2);
            this.cbDetailsSymbols.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDetailsSymbols.Location = new System.Drawing.Point(3, 284);
            this.cbDetailsSymbols.Name = "cbDetailsSymbols";
            this.cbDetailsSymbols.Size = new System.Drawing.Size(506, 41);
            this.cbDetailsSymbols.TabIndex = 44;
            this.cbDetailsSymbols.Text = "Welding symbols & welding sizes/location & description of previous & new repair";
            // 
            // cbDetailsDrawing
            // 
            this.cbDetailsDrawing.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tableLayoutPanel1.SetColumnSpan(this.cbDetailsDrawing, 2);
            this.cbDetailsDrawing.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDetailsDrawing.Location = new System.Drawing.Point(3, 237);
            this.cbDetailsDrawing.Name = "cbDetailsDrawing";
            this.cbDetailsDrawing.Size = new System.Drawing.Size(506, 41);
            this.cbDetailsDrawing.TabIndex = 43;
            this.cbDetailsDrawing.Text = "Drawing or sketch of items for welding showing size & weight of welding component" +
    "s";
            // 
            // txtDetailsClient
            // 
            this.txtDetailsClient.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsClient.Location = new System.Drawing.Point(771, 190);
            this.txtDetailsClient.Name = "txtDetailsClient";
            this.txtDetailsClient.Size = new System.Drawing.Size(250, 41);
            this.txtDetailsClient.TabIndex = 42;
            // 
            // txtDetailsJoint
            // 
            this.txtDetailsJoint.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsJoint.Location = new System.Drawing.Point(771, 162);
            this.txtDetailsJoint.Name = "txtDetailsJoint";
            this.txtDetailsJoint.Size = new System.Drawing.Size(250, 22);
            this.txtDetailsJoint.TabIndex = 41;
            // 
            // txtDetailsSuggested
            // 
            this.txtDetailsSuggested.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsSuggested.Location = new System.Drawing.Point(771, 134);
            this.txtDetailsSuggested.Name = "txtDetailsSuggested";
            this.txtDetailsSuggested.Size = new System.Drawing.Size(250, 22);
            this.txtDetailsSuggested.TabIndex = 40;
            // 
            // txtDetailsNominal
            // 
            this.txtDetailsNominal.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsNominal.Location = new System.Drawing.Point(771, 87);
            this.txtDetailsNominal.Name = "txtDetailsNominal";
            this.txtDetailsNominal.Size = new System.Drawing.Size(250, 41);
            this.txtDetailsNominal.TabIndex = 39;
            // 
            // txtDetailsProcess
            // 
            this.txtDetailsProcess.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsProcess.Location = new System.Drawing.Point(771, 59);
            this.txtDetailsProcess.Name = "txtDetailsProcess";
            this.txtDetailsProcess.Size = new System.Drawing.Size(250, 22);
            this.txtDetailsProcess.TabIndex = 38;
            // 
            // txtDetailsDate
            // 
            this.txtDetailsDate.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsDate.Location = new System.Drawing.Point(771, 31);
            this.txtDetailsDate.Name = "txtDetailsDate";
            this.txtDetailsDate.Size = new System.Drawing.Size(250, 22);
            this.txtDetailsDate.TabIndex = 37;
            // 
            // txtDetailsDrawing
            // 
            this.txtDetailsDrawing.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsDrawing.Location = new System.Drawing.Point(771, 3);
            this.txtDetailsDrawing.Name = "txtDetailsDrawing";
            this.txtDetailsDrawing.Size = new System.Drawing.Size(250, 22);
            this.txtDetailsDrawing.TabIndex = 36;
            // 
            // txtDetailsMatGrade
            // 
            this.txtDetailsMatGrade.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsMatGrade.Location = new System.Drawing.Point(259, 134);
            this.txtDetailsMatGrade.Name = "txtDetailsMatGrade";
            this.txtDetailsMatGrade.Size = new System.Drawing.Size(250, 22);
            this.txtDetailsMatGrade.TabIndex = 33;
            // 
            // txtDetailsMatStandard
            // 
            this.txtDetailsMatStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsMatStandard.Location = new System.Drawing.Point(259, 87);
            this.txtDetailsMatStandard.Name = "txtDetailsMatStandard";
            this.txtDetailsMatStandard.Size = new System.Drawing.Size(250, 41);
            this.txtDetailsMatStandard.TabIndex = 32;
            // 
            // txtDetailsStandard
            // 
            this.txtDetailsStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsStandard.Location = new System.Drawing.Point(259, 59);
            this.txtDetailsStandard.Name = "txtDetailsStandard";
            this.txtDetailsStandard.Size = new System.Drawing.Size(250, 22);
            this.txtDetailsStandard.TabIndex = 26;
            // 
            // txtDetailsComponent
            // 
            this.txtDetailsComponent.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsComponent.Location = new System.Drawing.Point(259, 31);
            this.txtDetailsComponent.Name = "txtDetailsComponent";
            this.txtDetailsComponent.Size = new System.Drawing.Size(250, 22);
            this.txtDetailsComponent.TabIndex = 25;
            // 
            // txtDetailsJob
            // 
            this.txtDetailsJob.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsJob.Location = new System.Drawing.Point(259, 3);
            this.txtDetailsJob.Name = "txtDetailsJob";
            this.txtDetailsJob.Size = new System.Drawing.Size(250, 22);
            this.txtDetailsJob.TabIndex = 24;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = Wisej.Web.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(515, 190);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(250, 41);
            this.label42.TabIndex = 18;
            this.label42.Text = "Client specified Inspection and Testing requirements";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Dock = Wisej.Web.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(515, 162);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(250, 22);
            this.label43.TabIndex = 17;
            this.label43.Text = "Joint Configeration";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = Wisej.Web.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(515, 134);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(250, 22);
            this.label44.TabIndex = 16;
            this.label44.Text = "Suggested welding process";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = Wisej.Web.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(515, 87);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(250, 41);
            this.label45.TabIndex = 15;
            this.label45.Text = "Nominal tensile strength of welds";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Dock = Wisej.Web.DockStyle.Fill;
            this.label46.Location = new System.Drawing.Point(515, 59);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(250, 22);
            this.label46.TabIndex = 14;
            this.label46.Text = "Welding Category";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Dock = Wisej.Web.DockStyle.Fill;
            this.label47.Location = new System.Drawing.Point(515, 31);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(250, 22);
            this.label47.TabIndex = 13;
            this.label47.Text = "Date";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = Wisej.Web.DockStyle.Fill;
            this.label30.Location = new System.Drawing.Point(515, 3);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(250, 22);
            this.label30.TabIndex = 12;
            this.label30.Text = "Drawing Number";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Dock = Wisej.Web.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(3, 134);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(250, 22);
            this.label51.TabIndex = 9;
            this.label51.Text = "Material Grade";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Dock = Wisej.Web.DockStyle.Fill;
            this.label52.Location = new System.Drawing.Point(3, 87);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(250, 41);
            this.label52.TabIndex = 8;
            this.label52.Text = "Material Standard";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Dock = Wisej.Web.DockStyle.Fill;
            this.label54.Location = new System.Drawing.Point(3, 190);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(250, 41);
            this.label54.TabIndex = 6;
            this.label54.Text = "Quality & acceptance requirements for welds";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Dock = Wisej.Web.DockStyle.Fill;
            this.label55.Location = new System.Drawing.Point(3, 162);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(250, 22);
            this.label55.TabIndex = 5;
            this.label55.Text = "Welding Position";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Dock = Wisej.Web.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(3, 59);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(250, 22);
            this.label58.TabIndex = 2;
            this.label58.Text = "Welding Standard";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Dock = Wisej.Web.DockStyle.Fill;
            this.label59.Location = new System.Drawing.Point(3, 31);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(250, 22);
            this.label59.TabIndex = 1;
            this.label59.Text = "Component Description";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = Wisej.Web.DockStyle.Fill;
            this.label31.Location = new System.Drawing.Point(3, 3);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(250, 22);
            this.label31.TabIndex = 0;
            this.label31.Text = "Job Number";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDetailsPosition
            // 
            this.txtDetailsPosition.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPosition.Location = new System.Drawing.Point(259, 162);
            this.txtDetailsPosition.Name = "txtDetailsPosition";
            this.txtDetailsPosition.Size = new System.Drawing.Size(250, 22);
            this.txtDetailsPosition.TabIndex = 29;
            // 
            // txtDetailsQuality
            // 
            this.txtDetailsQuality.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsQuality.Location = new System.Drawing.Point(259, 190);
            this.txtDetailsQuality.Name = "txtDetailsQuality";
            this.txtDetailsQuality.Size = new System.Drawing.Size(250, 41);
            this.txtDetailsQuality.TabIndex = 30;
            // 
            // cbDetailsFabrication
            // 
            this.cbDetailsFabrication.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tableLayoutPanel1.SetColumnSpan(this.cbDetailsFabrication, 2);
            this.cbDetailsFabrication.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDetailsFabrication.Location = new System.Drawing.Point(515, 237);
            this.cbDetailsFabrication.Name = "cbDetailsFabrication";
            this.cbDetailsFabrication.Size = new System.Drawing.Size(506, 41);
            this.cbDetailsFabrication.TabIndex = 48;
            this.cbDetailsFabrication.Text = "Welding/Fabrication specifications";
            // 
            // cbDetailsIssued
            // 
            this.cbDetailsIssued.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tableLayoutPanel1.SetColumnSpan(this.cbDetailsIssued, 2);
            this.cbDetailsIssued.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDetailsIssued.Location = new System.Drawing.Point(515, 284);
            this.cbDetailsIssued.Name = "cbDetailsIssued";
            this.cbDetailsIssued.Size = new System.Drawing.Size(506, 41);
            this.cbDetailsIssued.TabIndex = 49;
            this.cbDetailsIssued.Text = "Client issued welding procedures";
            // 
            // cbDetailsPhotos
            // 
            this.cbDetailsPhotos.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tableLayoutPanel1.SetColumnSpan(this.cbDetailsPhotos, 2);
            this.cbDetailsPhotos.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDetailsPhotos.Location = new System.Drawing.Point(515, 331);
            this.cbDetailsPhotos.Name = "cbDetailsPhotos";
            this.cbDetailsPhotos.Size = new System.Drawing.Size(506, 22);
            this.cbDetailsPhotos.TabIndex = 50;
            this.cbDetailsPhotos.Text = "Photos of components for welding";
            // 
            // cbDetailsParent
            // 
            this.cbDetailsParent.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tableLayoutPanel1.SetColumnSpan(this.cbDetailsParent, 2);
            this.cbDetailsParent.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDetailsParent.Location = new System.Drawing.Point(515, 359);
            this.cbDetailsParent.Name = "cbDetailsParent";
            this.cbDetailsParent.Size = new System.Drawing.Size(506, 22);
            this.cbDetailsParent.TabIndex = 51;
            this.cbDetailsParent.Text = "Parent material specifications";
            // 
            // cbDetailsNDT
            // 
            this.cbDetailsNDT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tableLayoutPanel1.SetColumnSpan(this.cbDetailsNDT, 2);
            this.cbDetailsNDT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbDetailsNDT.Location = new System.Drawing.Point(515, 387);
            this.cbDetailsNDT.Name = "cbDetailsNDT";
            this.cbDetailsNDT.Size = new System.Drawing.Size(506, 43);
            this.cbDetailsNDT.TabIndex = 52;
            this.cbDetailsNDT.Text = "Client NDT and heat treatment procedures/standards";
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 1;
            this.tableLayoutPanel23.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Controls.Add(this.tableLayoutPanel31, 0, 0);
            this.tableLayoutPanel23.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel23.TabIndex = 5;
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel31.ColumnCount = 1;
            this.tableLayoutPanel31.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel31.Controls.Add(this.btnDetailsBack, 0, 2);
            this.tableLayoutPanel31.Controls.Add(this.btnDetailsHome, 0, 3);
            this.tableLayoutPanel31.Controls.Add(this.btnDetailsNext, 0, 4);
            this.tableLayoutPanel31.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel31.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 5;
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel31.TabIndex = 4;
            // 
            // btnDetailsBack
            // 
            this.btnDetailsBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDetailsBack.Location = new System.Drawing.Point(3, 173);
            this.btnDetailsBack.Name = "btnDetailsBack";
            this.btnDetailsBack.Size = new System.Drawing.Size(95, 79);
            this.btnDetailsBack.TabIndex = 3;
            this.btnDetailsBack.Text = "Back";
            this.btnDetailsBack.Click += new System.EventHandler(this.btnDetailsBack_Click);
            // 
            // btnDetailsHome
            // 
            this.btnDetailsHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDetailsHome.Location = new System.Drawing.Point(3, 258);
            this.btnDetailsHome.Name = "btnDetailsHome";
            this.btnDetailsHome.Size = new System.Drawing.Size(95, 79);
            this.btnDetailsHome.TabIndex = 1;
            this.btnDetailsHome.Text = "Home";
            this.btnDetailsHome.Click += new System.EventHandler(this.btnDetailsHome_Click);
            // 
            // btnDetailsNext
            // 
            this.btnDetailsNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDetailsNext.Location = new System.Drawing.Point(3, 343);
            this.btnDetailsNext.Name = "btnDetailsNext";
            this.btnDetailsNext.Size = new System.Drawing.Size(95, 79);
            this.btnDetailsNext.TabIndex = 0;
            this.btnDetailsNext.Text = "Next";
            this.btnDetailsNext.Click += new System.EventHandler(this.btnDetailsNext_Click);
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 1;
            this.tableLayoutPanel24.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel24.Controls.Add(this.label77, 0, 1);
            this.tableLayoutPanel24.Controls.Add(this.label78, 0, 0);
            this.tableLayoutPanel24.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 2;
            this.tableLayoutPanel24.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel24.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel24.TabIndex = 0;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label77.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label77.Dock = Wisej.Web.DockStyle.Fill;
            this.label77.Location = new System.Drawing.Point(3, 79);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(1139, 35);
            this.label77.TabIndex = 1;
            this.label77.Text = "Notes";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label78.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label78.Dock = Wisej.Web.DockStyle.Fill;
            this.label78.Location = new System.Drawing.Point(3, 3);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(1139, 70);
            this.label78.TabIndex = 0;
            this.label78.Text = "Welding Scope of Work";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabDocuments
            // 
            this.tabDocuments.Controls.Add(this.tableLayoutPanel14);
            this.tabDocuments.Location = new System.Drawing.Point(0, 35);
            this.tabDocuments.Name = "tabDocuments";
            this.tabDocuments.Size = new System.Drawing.Size(1212, 615);
            this.tabDocuments.Text = "Documents";
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 3;
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel22, 1, 3);
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel28, 1, 1);
            this.tableLayoutPanel14.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 5;
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel14.TabIndex = 5;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel25, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel26, 1, 0);
            this.tableLayoutPanel22.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel22.TabIndex = 1;
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 3;
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel25.Controls.Add(this.uplDocumentsProvide, 1, 1);
            this.tableLayoutPanel25.Controls.Add(this.lvDocuments, 0, 0);
            this.tableLayoutPanel25.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 2;
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 80F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel25.TabIndex = 6;
            // 
            // uplDocumentsProvide
            // 
            this.uplDocumentsProvide.Dock = Wisej.Web.DockStyle.Fill;
            this.uplDocumentsProvide.HideValue = true;
            this.uplDocumentsProvide.Location = new System.Drawing.Point(344, 349);
            this.uplDocumentsProvide.Name = "uplDocumentsProvide";
            this.uplDocumentsProvide.Size = new System.Drawing.Size(335, 81);
            this.uplDocumentsProvide.TabIndex = 1;
            this.uplDocumentsProvide.Text = "Provide Documentation";
            this.uplDocumentsProvide.Uploaded += new Wisej.Web.UploadedEventHandler(this.uplDocumentsProvide_Uploaded);
            // 
            // lvDocuments
            // 
            this.tableLayoutPanel25.SetColumnSpan(this.lvDocuments, 3);
            this.lvDocuments.Dock = Wisej.Web.DockStyle.Fill;
            this.lvDocuments.Location = new System.Drawing.Point(3, 3);
            this.lvDocuments.Name = "lvDocuments";
            this.lvDocuments.Size = new System.Drawing.Size(1018, 340);
            this.lvDocuments.TabIndex = 0;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 1;
            this.tableLayoutPanel26.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Controls.Add(this.tableLayoutPanel27, 0, 0);
            this.tableLayoutPanel26.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel26.TabIndex = 5;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel27.ColumnCount = 1;
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel27.Controls.Add(this.btnDocumentsBack, 0, 2);
            this.tableLayoutPanel27.Controls.Add(this.btnDocumentsHome, 0, 3);
            this.tableLayoutPanel27.Controls.Add(this.btnDocumentsComplete, 0, 4);
            this.tableLayoutPanel27.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 5;
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel27.TabIndex = 4;
            // 
            // btnDocumentsBack
            // 
            this.btnDocumentsBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDocumentsBack.Location = new System.Drawing.Point(3, 173);
            this.btnDocumentsBack.Name = "btnDocumentsBack";
            this.btnDocumentsBack.Size = new System.Drawing.Size(95, 79);
            this.btnDocumentsBack.TabIndex = 2;
            this.btnDocumentsBack.Text = "Back";
            this.btnDocumentsBack.Click += new System.EventHandler(this.btnDocumentsBack_Click);
            // 
            // btnDocumentsHome
            // 
            this.btnDocumentsHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDocumentsHome.Location = new System.Drawing.Point(3, 258);
            this.btnDocumentsHome.Name = "btnDocumentsHome";
            this.btnDocumentsHome.Size = new System.Drawing.Size(95, 79);
            this.btnDocumentsHome.TabIndex = 1;
            this.btnDocumentsHome.Text = "Home";
            this.btnDocumentsHome.Click += new System.EventHandler(this.btnDocumentsHome_Click);
            // 
            // btnDocumentsComplete
            // 
            this.btnDocumentsComplete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDocumentsComplete.Location = new System.Drawing.Point(3, 343);
            this.btnDocumentsComplete.Name = "btnDocumentsComplete";
            this.btnDocumentsComplete.Size = new System.Drawing.Size(95, 79);
            this.btnDocumentsComplete.TabIndex = 0;
            this.btnDocumentsComplete.Text = "Complete";
            this.btnDocumentsComplete.Click += new System.EventHandler(this.btnDocumentsComplete_Click);
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.ColumnCount = 1;
            this.tableLayoutPanel28.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel28.Controls.Add(this.label76, 0, 1);
            this.tableLayoutPanel28.Controls.Add(this.label79, 0, 0);
            this.tableLayoutPanel28.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 2;
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel28.TabIndex = 0;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label76.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label76.Dock = Wisej.Web.DockStyle.Fill;
            this.label76.Location = new System.Drawing.Point(3, 79);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(1139, 35);
            this.label76.TabIndex = 1;
            this.label76.Text = "Notes";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label79.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label79.Dock = Wisej.Web.DockStyle.Fill;
            this.label79.Location = new System.Drawing.Point(3, 3);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(1139, 70);
            this.label79.TabIndex = 0;
            this.label79.Text = "Welding Scope of Work Provided Documentation";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabTechnical
            // 
            this.tabTechnical.Controls.Add(this.tableLayoutPanel2);
            this.tabTechnical.Location = new System.Drawing.Point(0, 35);
            this.tabTechnical.Name = "tabTechnical";
            this.tabTechnical.Size = new System.Drawing.Size(1212, 615);
            this.tabTechnical.Text = "Technical";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel7, 1, 1);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel2.TabIndex = 4;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel5, 1, 0);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 4;
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalDate, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalExtra, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalConsiderations, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalReviewer, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label37, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label50, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label53, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label56, 0, 0);
            this.tableLayoutPanel4.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 3;
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 40F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 40F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel4.TabIndex = 6;
            // 
            // txtTechnicalDate
            // 
            this.txtTechnicalDate.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalDate.Location = new System.Drawing.Point(771, 3);
            this.txtTechnicalDate.Name = "txtTechnicalDate";
            this.txtTechnicalDate.Size = new System.Drawing.Size(250, 42);
            this.txtTechnicalDate.TabIndex = 37;
            // 
            // txtTechnicalExtra
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.txtTechnicalExtra, 3);
            this.txtTechnicalExtra.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalExtra.Location = new System.Drawing.Point(259, 243);
            this.txtTechnicalExtra.Name = "txtTechnicalExtra";
            this.txtTechnicalExtra.Size = new System.Drawing.Size(762, 187);
            this.txtTechnicalExtra.TabIndex = 26;
            // 
            // txtTechnicalConsiderations
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.txtTechnicalConsiderations, 3);
            this.txtTechnicalConsiderations.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalConsiderations.Location = new System.Drawing.Point(259, 51);
            this.txtTechnicalConsiderations.Name = "txtTechnicalConsiderations";
            this.txtTechnicalConsiderations.Size = new System.Drawing.Size(762, 186);
            this.txtTechnicalConsiderations.TabIndex = 25;
            // 
            // txtTechnicalReviewer
            // 
            this.txtTechnicalReviewer.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalReviewer.Location = new System.Drawing.Point(259, 3);
            this.txtTechnicalReviewer.Name = "txtTechnicalReviewer";
            this.txtTechnicalReviewer.Size = new System.Drawing.Size(250, 42);
            this.txtTechnicalReviewer.TabIndex = 24;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Dock = Wisej.Web.DockStyle.Fill;
            this.label37.Location = new System.Drawing.Point(515, 3);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(250, 42);
            this.label37.TabIndex = 13;
            this.label37.Text = "Date";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Dock = Wisej.Web.DockStyle.Fill;
            this.label50.Location = new System.Drawing.Point(3, 243);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(250, 187);
            this.label50.TabIndex = 2;
            this.label50.Text = "Extra costs to consider";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Dock = Wisej.Web.DockStyle.Fill;
            this.label53.Location = new System.Drawing.Point(3, 51);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(250, 186);
            this.label53.TabIndex = 1;
            this.label53.Text = "Technical Considerations";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Dock = Wisej.Web.DockStyle.Fill;
            this.label56.Location = new System.Drawing.Point(3, 3);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(250, 42);
            this.label56.TabIndex = 0;
            this.label56.Text = "Technical Reviewer EID";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel6, 0, 0);
            this.tableLayoutPanel5.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel5.TabIndex = 5;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.btnTechnicalHome, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.btnTechnicalComplete, 0, 4);
            this.tableLayoutPanel6.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 5;
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel6.TabIndex = 4;
            // 
            // btnTechnicalHome
            // 
            this.btnTechnicalHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnTechnicalHome.Location = new System.Drawing.Point(3, 258);
            this.btnTechnicalHome.Name = "btnTechnicalHome";
            this.btnTechnicalHome.Size = new System.Drawing.Size(95, 79);
            this.btnTechnicalHome.TabIndex = 1;
            this.btnTechnicalHome.Text = "Home";
            this.btnTechnicalHome.Click += new System.EventHandler(this.btnTechnicalHome_Click);
            // 
            // btnTechnicalComplete
            // 
            this.btnTechnicalComplete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnTechnicalComplete.Location = new System.Drawing.Point(3, 343);
            this.btnTechnicalComplete.Name = "btnTechnicalComplete";
            this.btnTechnicalComplete.Size = new System.Drawing.Size(95, 79);
            this.btnTechnicalComplete.TabIndex = 0;
            this.btnTechnicalComplete.Text = "Complete";
            this.btnTechnicalComplete.Click += new System.EventHandler(this.btnTechnicalComplete_Click);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.label57, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.label63, 0, 0);
            this.tableLayoutPanel7.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel7.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel7.TabIndex = 0;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label57.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label57.Dock = Wisej.Web.DockStyle.Fill;
            this.label57.Location = new System.Drawing.Point(3, 79);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(1139, 35);
            this.label57.TabIndex = 1;
            this.label57.Text = "Notes";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label63.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label63.Dock = Wisej.Web.DockStyle.Fill;
            this.label63.Location = new System.Drawing.Point(3, 3);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(1139, 70);
            this.label63.TabIndex = 0;
            this.label63.Text = "Technical Review";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabOperational
            // 
            this.tabOperational.Controls.Add(this.tableLayoutPanel8);
            this.tabOperational.Location = new System.Drawing.Point(0, 35);
            this.tabOperational.Name = "tabOperational";
            this.tabOperational.Size = new System.Drawing.Size(1212, 615);
            this.tabOperational.Text = "Operational";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 3;
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel9, 1, 3);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel13, 1, 1);
            this.tableLayoutPanel8.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 5;
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel8.TabIndex = 4;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel9.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel9.Controls.Add(this.tableLayoutPanel10, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.tableLayoutPanel11, 1, 0);
            this.tableLayoutPanel9.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel9.TabIndex = 1;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 4;
            this.tableLayoutPanel10.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 30F));
            this.tableLayoutPanel10.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 30F));
            this.tableLayoutPanel10.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 30F));
            this.tableLayoutPanel10.Controls.Add(this.label71, 2, 1);
            this.tableLayoutPanel10.Controls.Add(this.label36, 0, 2);
            this.tableLayoutPanel10.Controls.Add(this.label35, 0, 12);
            this.tableLayoutPanel10.Controls.Add(this.label34, 0, 11);
            this.tableLayoutPanel10.Controls.Add(this.label33, 3, 1);
            this.tableLayoutPanel10.Controls.Add(this.label32, 0, 1);
            this.tableLayoutPanel10.Controls.Add(this.txtOperationThird, 3, 5);
            this.tableLayoutPanel10.Controls.Add(this.txtOperationEquipment, 3, 4);
            this.tableLayoutPanel10.Controls.Add(this.txtOperationFacilities, 3, 3);
            this.tableLayoutPanel10.Controls.Add(this.txtOperationStaff, 3, 2);
            this.tableLayoutPanel10.Controls.Add(this.txtOperationDate, 3, 0);
            this.tableLayoutPanel10.Controls.Add(this.txtOperationReviewer, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.label38, 2, 0);
            this.tableLayoutPanel10.Controls.Add(this.label67, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.cbOperationStaff, 2, 2);
            this.tableLayoutPanel10.Controls.Add(this.cbOperationFacilities, 2, 3);
            this.tableLayoutPanel10.Controls.Add(this.cbOperationEquipment, 2, 4);
            this.tableLayoutPanel10.Controls.Add(this.cbOperationWPS, 2, 6);
            this.tableLayoutPanel10.Controls.Add(this.cbOperationThird, 2, 5);
            this.tableLayoutPanel10.Controls.Add(this.cbOperationWelders, 2, 7);
            this.tableLayoutPanel10.Controls.Add(this.cbOperationSub, 2, 8);
            this.tableLayoutPanel10.Controls.Add(this.cbOperationStorage, 2, 9);
            this.tableLayoutPanel10.Controls.Add(this.cbOperationPWHT, 2, 10);
            this.tableLayoutPanel10.Controls.Add(this.txtOperationWPS, 3, 6);
            this.tableLayoutPanel10.Controls.Add(this.txtOperationWelders, 3, 7);
            this.tableLayoutPanel10.Controls.Add(this.txtOperationSub, 3, 8);
            this.tableLayoutPanel10.Controls.Add(this.txtOperationStorage, 3, 9);
            this.tableLayoutPanel10.Controls.Add(this.txtOperationPWHT, 3, 10);
            this.tableLayoutPanel10.Controls.Add(this.txtOperationGeneral, 1, 11);
            this.tableLayoutPanel10.Controls.Add(this.txtOperationExtra, 1, 12);
            this.tableLayoutPanel10.Controls.Add(this.label39, 0, 3);
            this.tableLayoutPanel10.Controls.Add(this.label40, 0, 4);
            this.tableLayoutPanel10.Controls.Add(this.label41, 0, 5);
            this.tableLayoutPanel10.Controls.Add(this.label49, 0, 6);
            this.tableLayoutPanel10.Controls.Add(this.label64, 0, 7);
            this.tableLayoutPanel10.Controls.Add(this.label65, 0, 8);
            this.tableLayoutPanel10.Controls.Add(this.label66, 0, 9);
            this.tableLayoutPanel10.Controls.Add(this.label70, 0, 10);
            this.tableLayoutPanel10.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 13;
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel10.TabIndex = 6;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label71.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label71.Dock = Wisej.Web.DockStyle.Fill;
            this.label71.Location = new System.Drawing.Point(617, 36);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(96, 27);
            this.label71.TabIndex = 72;
            this.label71.Text = "No / Yes";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.tableLayoutPanel10.SetColumnSpan(this.label36, 2);
            this.label36.Dock = Wisej.Web.DockStyle.Fill;
            this.label36.Location = new System.Drawing.Point(3, 69);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(608, 27);
            this.label36.TabIndex = 63;
            this.label36.Text = "Trained staff available";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = Wisej.Web.DockStyle.Fill;
            this.label35.Location = new System.Drawing.Point(3, 399);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(301, 31);
            this.label35.TabIndex = 62;
            this.label35.Text = "Extra Costs to Consider";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = Wisej.Web.DockStyle.Fill;
            this.label34.Location = new System.Drawing.Point(3, 366);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(301, 27);
            this.label34.TabIndex = 61;
            this.label34.Text = "General Comments";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label33.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label33.Dock = Wisej.Web.DockStyle.Fill;
            this.label33.Location = new System.Drawing.Point(719, 36);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(302, 27);
            this.label33.TabIndex = 53;
            this.label33.Text = "Comments";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label32.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel10.SetColumnSpan(this.label32, 2);
            this.label32.Dock = Wisej.Web.DockStyle.Fill;
            this.label32.Location = new System.Drawing.Point(3, 36);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(608, 27);
            this.label32.TabIndex = 52;
            this.label32.Text = "Items to Consider";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtOperationThird
            // 
            this.txtOperationThird.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationThird.Location = new System.Drawing.Point(719, 168);
            this.txtOperationThird.Name = "txtOperationThird";
            this.txtOperationThird.Size = new System.Drawing.Size(302, 27);
            this.txtOperationThird.TabIndex = 41;
            // 
            // txtOperationEquipment
            // 
            this.txtOperationEquipment.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationEquipment.Location = new System.Drawing.Point(719, 135);
            this.txtOperationEquipment.Name = "txtOperationEquipment";
            this.txtOperationEquipment.Size = new System.Drawing.Size(302, 27);
            this.txtOperationEquipment.TabIndex = 40;
            // 
            // txtOperationFacilities
            // 
            this.txtOperationFacilities.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationFacilities.Location = new System.Drawing.Point(719, 102);
            this.txtOperationFacilities.Name = "txtOperationFacilities";
            this.txtOperationFacilities.Size = new System.Drawing.Size(302, 27);
            this.txtOperationFacilities.TabIndex = 39;
            // 
            // txtOperationStaff
            // 
            this.txtOperationStaff.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationStaff.Location = new System.Drawing.Point(719, 69);
            this.txtOperationStaff.Name = "txtOperationStaff";
            this.txtOperationStaff.Size = new System.Drawing.Size(302, 27);
            this.txtOperationStaff.TabIndex = 38;
            // 
            // txtOperationDate
            // 
            this.txtOperationDate.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationDate.Location = new System.Drawing.Point(719, 3);
            this.txtOperationDate.Name = "txtOperationDate";
            this.txtOperationDate.Size = new System.Drawing.Size(302, 27);
            this.txtOperationDate.TabIndex = 37;
            // 
            // txtOperationReviewer
            // 
            this.txtOperationReviewer.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationReviewer.Location = new System.Drawing.Point(310, 3);
            this.txtOperationReviewer.Name = "txtOperationReviewer";
            this.txtOperationReviewer.Size = new System.Drawing.Size(301, 27);
            this.txtOperationReviewer.TabIndex = 24;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = Wisej.Web.DockStyle.Fill;
            this.label38.Location = new System.Drawing.Point(617, 3);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(96, 27);
            this.label38.TabIndex = 13;
            this.label38.Text = "Date";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Dock = Wisej.Web.DockStyle.Fill;
            this.label67.Location = new System.Drawing.Point(3, 3);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(301, 27);
            this.label67.TabIndex = 0;
            this.label67.Text = "Operational Reviewer EID";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbOperationStaff
            // 
            this.cbOperationStaff.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationStaff.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationStaff.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationStaff.Location = new System.Drawing.Point(617, 69);
            this.cbOperationStaff.Name = "cbOperationStaff";
            this.cbOperationStaff.Size = new System.Drawing.Size(96, 27);
            this.cbOperationStaff.TabIndex = 44;
            // 
            // cbOperationFacilities
            // 
            this.cbOperationFacilities.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationFacilities.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationFacilities.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationFacilities.Location = new System.Drawing.Point(617, 102);
            this.cbOperationFacilities.Name = "cbOperationFacilities";
            this.cbOperationFacilities.Size = new System.Drawing.Size(96, 27);
            this.cbOperationFacilities.TabIndex = 48;
            // 
            // cbOperationEquipment
            // 
            this.cbOperationEquipment.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationEquipment.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationEquipment.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationEquipment.Location = new System.Drawing.Point(617, 135);
            this.cbOperationEquipment.Name = "cbOperationEquipment";
            this.cbOperationEquipment.Size = new System.Drawing.Size(96, 27);
            this.cbOperationEquipment.TabIndex = 45;
            // 
            // cbOperationWPS
            // 
            this.cbOperationWPS.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationWPS.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationWPS.Location = new System.Drawing.Point(617, 201);
            this.cbOperationWPS.Name = "cbOperationWPS";
            this.cbOperationWPS.Size = new System.Drawing.Size(96, 27);
            this.cbOperationWPS.TabIndex = 47;
            // 
            // cbOperationThird
            // 
            this.cbOperationThird.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationThird.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationThird.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationThird.Location = new System.Drawing.Point(617, 168);
            this.cbOperationThird.Name = "cbOperationThird";
            this.cbOperationThird.Size = new System.Drawing.Size(96, 27);
            this.cbOperationThird.TabIndex = 46;
            // 
            // cbOperationWelders
            // 
            this.cbOperationWelders.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationWelders.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationWelders.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationWelders.Location = new System.Drawing.Point(617, 234);
            this.cbOperationWelders.Name = "cbOperationWelders";
            this.cbOperationWelders.Size = new System.Drawing.Size(96, 27);
            this.cbOperationWelders.TabIndex = 49;
            // 
            // cbOperationSub
            // 
            this.cbOperationSub.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationSub.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationSub.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationSub.Location = new System.Drawing.Point(617, 267);
            this.cbOperationSub.Name = "cbOperationSub";
            this.cbOperationSub.Size = new System.Drawing.Size(96, 27);
            this.cbOperationSub.TabIndex = 50;
            // 
            // cbOperationStorage
            // 
            this.cbOperationStorage.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationStorage.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationStorage.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationStorage.Location = new System.Drawing.Point(617, 300);
            this.cbOperationStorage.Name = "cbOperationStorage";
            this.cbOperationStorage.Size = new System.Drawing.Size(96, 27);
            this.cbOperationStorage.TabIndex = 51;
            // 
            // cbOperationPWHT
            // 
            this.cbOperationPWHT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationPWHT.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationPWHT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationPWHT.Location = new System.Drawing.Point(617, 333);
            this.cbOperationPWHT.Name = "cbOperationPWHT";
            this.cbOperationPWHT.Size = new System.Drawing.Size(96, 27);
            this.cbOperationPWHT.TabIndex = 43;
            // 
            // txtOperationWPS
            // 
            this.txtOperationWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationWPS.Location = new System.Drawing.Point(719, 201);
            this.txtOperationWPS.Name = "txtOperationWPS";
            this.txtOperationWPS.Size = new System.Drawing.Size(302, 27);
            this.txtOperationWPS.TabIndex = 56;
            // 
            // txtOperationWelders
            // 
            this.txtOperationWelders.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationWelders.Location = new System.Drawing.Point(719, 234);
            this.txtOperationWelders.Name = "txtOperationWelders";
            this.txtOperationWelders.Size = new System.Drawing.Size(302, 27);
            this.txtOperationWelders.TabIndex = 57;
            // 
            // txtOperationSub
            // 
            this.txtOperationSub.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationSub.Location = new System.Drawing.Point(719, 267);
            this.txtOperationSub.Name = "txtOperationSub";
            this.txtOperationSub.Size = new System.Drawing.Size(302, 27);
            this.txtOperationSub.TabIndex = 55;
            // 
            // txtOperationStorage
            // 
            this.txtOperationStorage.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationStorage.Location = new System.Drawing.Point(719, 300);
            this.txtOperationStorage.Name = "txtOperationStorage";
            this.txtOperationStorage.Size = new System.Drawing.Size(302, 27);
            this.txtOperationStorage.TabIndex = 54;
            // 
            // txtOperationPWHT
            // 
            this.txtOperationPWHT.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationPWHT.Location = new System.Drawing.Point(719, 333);
            this.txtOperationPWHT.Name = "txtOperationPWHT";
            this.txtOperationPWHT.Size = new System.Drawing.Size(302, 27);
            this.txtOperationPWHT.TabIndex = 58;
            // 
            // txtOperationGeneral
            // 
            this.tableLayoutPanel10.SetColumnSpan(this.txtOperationGeneral, 3);
            this.txtOperationGeneral.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationGeneral.Location = new System.Drawing.Point(310, 366);
            this.txtOperationGeneral.Name = "txtOperationGeneral";
            this.txtOperationGeneral.Size = new System.Drawing.Size(711, 27);
            this.txtOperationGeneral.TabIndex = 59;
            // 
            // txtOperationExtra
            // 
            this.tableLayoutPanel10.SetColumnSpan(this.txtOperationExtra, 3);
            this.txtOperationExtra.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationExtra.Location = new System.Drawing.Point(310, 399);
            this.txtOperationExtra.Name = "txtOperationExtra";
            this.txtOperationExtra.Size = new System.Drawing.Size(711, 31);
            this.txtOperationExtra.TabIndex = 60;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.tableLayoutPanel10.SetColumnSpan(this.label39, 2);
            this.label39.Dock = Wisej.Web.DockStyle.Fill;
            this.label39.Location = new System.Drawing.Point(3, 102);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(608, 27);
            this.label39.TabIndex = 64;
            this.label39.Text = "Facilities available";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.tableLayoutPanel10.SetColumnSpan(this.label40, 2);
            this.label40.Dock = Wisej.Web.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(3, 135);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(608, 27);
            this.label40.TabIndex = 65;
            this.label40.Text = "Equipment available";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.tableLayoutPanel10.SetColumnSpan(this.label41, 2);
            this.label41.Dock = Wisej.Web.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(3, 168);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(608, 27);
            this.label41.TabIndex = 66;
            this.label41.Text = "Third party involvement ";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.tableLayoutPanel10.SetColumnSpan(this.label49, 2);
            this.label49.Dock = Wisej.Web.DockStyle.Fill;
            this.label49.Location = new System.Drawing.Point(3, 201);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(608, 27);
            this.label49.TabIndex = 67;
            this.label49.Text = "Qualified WPS available";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.tableLayoutPanel10.SetColumnSpan(this.label64, 2);
            this.label64.Dock = Wisej.Web.DockStyle.Fill;
            this.label64.Location = new System.Drawing.Point(3, 234);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(608, 27);
            this.label64.TabIndex = 68;
            this.label64.Text = "Qualified/Certified Welders Available";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.tableLayoutPanel10.SetColumnSpan(this.label65, 2);
            this.label65.Dock = Wisej.Web.DockStyle.Fill;
            this.label65.Location = new System.Drawing.Point(3, 267);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(608, 27);
            this.label65.TabIndex = 69;
            this.label65.Text = "Subcontractors to be used";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.tableLayoutPanel10.SetColumnSpan(this.label66, 2);
            this.label66.Dock = Wisej.Web.DockStyle.Fill;
            this.label66.Location = new System.Drawing.Point(3, 300);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(608, 27);
            this.label66.TabIndex = 70;
            this.label66.Text = "Dedicated storage of parent material & welding consumables required";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.tableLayoutPanel10.SetColumnSpan(this.label70, 2);
            this.label70.Dock = Wisej.Web.DockStyle.Fill;
            this.label70.Location = new System.Drawing.Point(3, 333);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(608, 27);
            this.label70.TabIndex = 71;
            this.label70.Text = "Post-Weld Heat treatment required";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.tableLayoutPanel12, 0, 0);
            this.tableLayoutPanel11.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel11.TabIndex = 5;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.btnOperationHome, 0, 3);
            this.tableLayoutPanel12.Controls.Add(this.btnOperationComplete, 0, 4);
            this.tableLayoutPanel12.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 5;
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel12.TabIndex = 4;
            // 
            // btnOperationHome
            // 
            this.btnOperationHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnOperationHome.Location = new System.Drawing.Point(3, 258);
            this.btnOperationHome.Name = "btnOperationHome";
            this.btnOperationHome.Size = new System.Drawing.Size(95, 79);
            this.btnOperationHome.TabIndex = 1;
            this.btnOperationHome.Text = "Home";
            this.btnOperationHome.Click += new System.EventHandler(this.btnOperationHome_Click);
            // 
            // btnOperationComplete
            // 
            this.btnOperationComplete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnOperationComplete.Location = new System.Drawing.Point(3, 343);
            this.btnOperationComplete.Name = "btnOperationComplete";
            this.btnOperationComplete.Size = new System.Drawing.Size(95, 79);
            this.btnOperationComplete.TabIndex = 0;
            this.btnOperationComplete.Text = "Complete";
            this.btnOperationComplete.Click += new System.EventHandler(this.btnOperationComplete_Click);
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel13.Controls.Add(this.label68, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.label69, 0, 0);
            this.tableLayoutPanel13.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label68.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label68.Dock = Wisej.Web.DockStyle.Fill;
            this.label68.Location = new System.Drawing.Point(3, 79);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(1139, 35);
            this.label68.TabIndex = 1;
            this.label68.Text = "Notes";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label69.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label69.Dock = Wisej.Web.DockStyle.Fill;
            this.label69.Location = new System.Drawing.Point(3, 3);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(1139, 70);
            this.label69.TabIndex = 0;
            this.label69.Text = "Operational Review";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fbRequest
            // 
            this.Controls.Add(this.Boards);
            this.Name = "fbRequest";
            this.Size = new System.Drawing.Size(1212, 650);
            this.Boards.ResumeLayout(false);
            this.tabInfo.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel30.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            this.tabDetails.ResumeLayout(false);
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel31.ResumeLayout(false);
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel24.PerformLayout();
            this.tabDocuments.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel28.PerformLayout();
            this.tabTechnical.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tabOperational.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TabControl Boards;
        private Wisej.Web.TabPage tabInfo;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel15;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel16;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel18;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel30;
        private Wisej.Web.Button btnInfoBack;
        private Wisej.Web.Button btnInfoHome;
        private Wisej.Web.Button btnInfoNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel17;
        private Wisej.Web.TextBox txtInfoManager;
        private Wisej.Web.Label label48;
        private Wisej.Web.Label label60;
        private Wisej.Web.TextBox txtInfoJob;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel19;
        private Wisej.Web.Label label61;
        private Wisej.Web.Label label62;
        private Wisej.Web.TabPage tabDetails;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel20;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel21;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel23;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel31;
        private Wisej.Web.Button btnDetailsBack;
        private Wisej.Web.Button btnDetailsHome;
        private Wisej.Web.Button btnDetailsNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel24;
        private Wisej.Web.Label label77;
        private Wisej.Web.Label label78;
        private Wisej.Web.Label label1;
        private Wisej.Web.Label label2;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label7;
        private Wisej.Web.Label label6;
        private Wisej.Web.Label label5;
        private Wisej.Web.Label label8;
        private Wisej.Web.Label label11;
        private Wisej.Web.Label label12;
        private Wisej.Web.Label label10;
        private Wisej.Web.Label label9;
        private Wisej.Web.Label label15;
        private Wisej.Web.Label label14;
        private Wisej.Web.Label label13;
        private Wisej.Web.Label label16;
        private Wisej.Web.Label label17;
        private Wisej.Web.Label label18;
        private Wisej.Web.Label label19;
        private Wisej.Web.Label label20;
        private Wisej.Web.Label label21;
        private Wisej.Web.Label label22;
        private Wisej.Web.Label label23;
        private Wisej.Web.Label label24;
        private Wisej.Web.Label label25;
        private Wisej.Web.Label label26;
        private Wisej.Web.Label label27;
        private Wisej.Web.Label label28;
        private Wisej.Web.Label label29;
        private Wisej.Web.RadioButton rbInfoComplex;
        private Wisej.Web.RadioButton rbInfoStandard;
        private Wisej.Web.RadioButton rbInfoLow;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TextBox txtDetailsJoint;
        private Wisej.Web.TextBox txtDetailsSuggested;
        private Wisej.Web.TextBox txtDetailsNominal;
        private Wisej.Web.TextBox txtDetailsProcess;
        private Wisej.Web.TextBox txtDetailsDate;
        private Wisej.Web.TextBox txtDetailsDrawing;
        private Wisej.Web.TextBox txtDetailsMatGrade;
        private Wisej.Web.TextBox txtDetailsMatStandard;
        private Wisej.Web.TextBox txtDetailsStandard;
        private Wisej.Web.TextBox txtDetailsComponent;
        private Wisej.Web.TextBox txtDetailsJob;
        private Wisej.Web.Label label42;
        private Wisej.Web.Label label43;
        private Wisej.Web.Label label44;
        private Wisej.Web.Label label45;
        private Wisej.Web.Label label46;
        private Wisej.Web.Label label47;
        private Wisej.Web.Label label30;
        private Wisej.Web.Label label51;
        private Wisej.Web.Label label52;
        private Wisej.Web.Label label54;
        private Wisej.Web.Label label55;
        private Wisej.Web.Label label58;
        private Wisej.Web.Label label59;
        private Wisej.Web.Label label31;
        private Wisej.Web.TextBox txtDetailsPosition;
        private Wisej.Web.TextBox txtDetailsQuality;
        private Wisej.Web.CheckBox WHT;
        private Wisej.Web.CheckBox cbDetailsRecord;
        private Wisej.Web.CheckBox cbDetailsHistory;
        private Wisej.Web.CheckBox cbDetailsSymbols;
        private Wisej.Web.CheckBox cbDetailsDrawing;
        private Wisej.Web.TextBox txtDetailsClient;
        private Wisej.Web.CheckBox cbDetailsFabrication;
        private Wisej.Web.CheckBox cbDetailsIssued;
        private Wisej.Web.CheckBox cbDetailsPhotos;
        private Wisej.Web.CheckBox cbDetailsParent;
        private Wisej.Web.CheckBox cbDetailsNDT;
        private Wisej.Web.TabPage tabTechnical;
        private Wisej.Web.TabPage tabOperational;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel4;
        private Wisej.Web.TextBox txtTechnicalDate;
        private Wisej.Web.TextBox txtTechnicalExtra;
        private Wisej.Web.TextBox txtTechnicalConsiderations;
        private Wisej.Web.TextBox txtTechnicalReviewer;
        private Wisej.Web.Label label37;
        private Wisej.Web.Label label50;
        private Wisej.Web.Label label53;
        private Wisej.Web.Label label56;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel5;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel6;
        private Wisej.Web.Button btnTechnicalHome;
        private Wisej.Web.Button btnTechnicalComplete;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel7;
        private Wisej.Web.Label label57;
        private Wisej.Web.Label label63;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel8;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel9;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel10;
        private Wisej.Web.CheckBox cbOperationWPS;
        private Wisej.Web.CheckBox cbOperationThird;
        private Wisej.Web.CheckBox cbOperationEquipment;
        private Wisej.Web.CheckBox cbOperationStaff;
        private Wisej.Web.CheckBox cbOperationPWHT;
        private Wisej.Web.TextBox txtOperationThird;
        private Wisej.Web.TextBox txtOperationEquipment;
        private Wisej.Web.TextBox txtOperationFacilities;
        private Wisej.Web.TextBox txtOperationStaff;
        private Wisej.Web.TextBox txtOperationDate;
        private Wisej.Web.TextBox txtOperationReviewer;
        private Wisej.Web.Label label38;
        private Wisej.Web.Label label67;
        private Wisej.Web.CheckBox cbOperationFacilities;
        private Wisej.Web.CheckBox cbOperationWelders;
        private Wisej.Web.CheckBox cbOperationSub;
        private Wisej.Web.CheckBox cbOperationStorage;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel11;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel12;
        private Wisej.Web.Button btnOperationHome;
        private Wisej.Web.Button btnOperationComplete;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel13;
        private Wisej.Web.Label label68;
        private Wisej.Web.Label label69;
        private Wisej.Web.Label label33;
        private Wisej.Web.Label label32;
        private Wisej.Web.Label label35;
        private Wisej.Web.Label label34;
        private Wisej.Web.TextBox txtOperationWPS;
        private Wisej.Web.TextBox txtOperationWelders;
        private Wisej.Web.TextBox txtOperationSub;
        private Wisej.Web.TextBox txtOperationStorage;
        private Wisej.Web.TextBox txtOperationPWHT;
        private Wisej.Web.TextBox txtOperationGeneral;
        private Wisej.Web.TextBox txtOperationExtra;
        private Wisej.Web.Label label36;
        private Wisej.Web.Label label39;
        private Wisej.Web.Label label40;
        private Wisej.Web.Label label41;
        private Wisej.Web.Label label49;
        private Wisej.Web.Label label64;
        private Wisej.Web.Label label65;
        private Wisej.Web.Label label66;
        private Wisej.Web.Label label70;
        private Wisej.Web.Label label71;
        private Wisej.Web.TabPage tabDocuments;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel14;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel22;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel25;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel26;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel27;
        private Wisej.Web.Button btnDocumentsHome;
        private Wisej.Web.Button btnDocumentsComplete;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel28;
        private Wisej.Web.Label label76;
        private Wisej.Web.Label label79;
        private Wisej.Web.Button btnDocumentsBack;
        private Wisej.Web.Upload uplDocumentsProvide;
        private Wisej.Web.ListView lvDocuments;
    }
}
