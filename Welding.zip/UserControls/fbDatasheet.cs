﻿using Microsoft.Ajax.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using Wisej.Web;

namespace WeldingManagement
{
    public partial class fbDatasheet : Wisej.Web.UserControl
    {
        #region Drawing

        private Boolean mouseMoving = false;
        private Point start;
        private Point current;
        private Rectangle window;
        private int weldCounter = 0;
        private List<WeldingShape> drawnShapes = new List<WeldingShape>();

        private Font GetScaledFont(Graphics pG, string pText, SizeF pTargetSize)
        {
            float fontSize = 10; // Initial font size
            Font font = new Font("Arial", fontSize);

            // Increase font size until it fits within the target size
            while (pG.MeasureString(pText, font).Width < pTargetSize.Width && pG.MeasureString(pText, font).Height < pTargetSize.Height)
            {
                fontSize += 1;
                font = new Font("Arial", fontSize);
            }

            // Return the last font size that fits within the target size
            return new Font("Arial", fontSize - 1);
        }

        private void drawRectangle(Graphics pG, Rectangle pRect, float pAngle, Point initialClickPoint)
        {
            Pen pen = new Pen(Color.Black);
            SolidBrush brush = new SolidBrush(Color.White);

            GraphicsState originalState = pG.Save();

            //Translation Rotation Translation
            pG.TranslateTransform(initialClickPoint.X, initialClickPoint.Y);
            pG.RotateTransform(pAngle);
            pG.TranslateTransform(-initialClickPoint.X, -initialClickPoint.Y);

            pG.FillRectangle(brush, pRect);
            pG.DrawRectangle(pen, pRect);

            // Restore the original state of the graphics object
            pG.Restore(originalState);

            pen.Dispose();
            brush.Dispose();
        }

        private void drawEllipse(Graphics pG, Rectangle pRect, float pAngle, string pRunId, Point initialClickPoint)
        {
            Pen pen = new Pen(Color.Black);
            SolidBrush brush = new SolidBrush(Color.White);

            GraphicsState originalState = pG.Save();

            //Translation Rotation Translation
            pG.TranslateTransform(initialClickPoint.X, initialClickPoint.Y);
            pG.RotateTransform(pAngle);
            pG.TranslateTransform(-initialClickPoint.X, -initialClickPoint.Y);


            // Draw previously drawn ellipse
            pG.FillEllipse(brush, pRect);
            pG.DrawEllipse(pen, pRect);

            // scale font based on ellipse size
            Font font = GetScaledFont(pG, pRunId, pRect.Size);
            // determine string size
            SizeF textSize = pG.MeasureString(pRunId, font);
            // place string in the centre of the ellipse
            PointF textLocation = new PointF(pRect.Left + (pRect.Width-textSize.Width)/2,
                pRect.Top + (pRect.Height-textSize.Height)/2);
            // Draw label
            pG.DrawString(pRunId, font, Brushes.Black, textLocation);

            // Restore the original state of the graphics object
            pG.Restore(originalState);


            pen.Dispose();
            brush.Dispose();
        }

            #endregion

        #region FlipBoard
        bool IsDesignMode = (LicenseManager.UsageMode == LicenseUsageMode.Designtime);
        bool checkCancel = true;

        [Category("Board")]
        [Description("Number to display")]
        private void Boards_Selecting(object sender, TabControlCancelEventArgs e)
        {
            e.Cancel = checkCancel;
            checkCancel = true;
        }

        private BoardId showBoard = BoardId.Info;
        public BoardId ShowBoard
        {
            get
            {
                return showBoard;
            }
            set
            {
                showBoard = value;
                checkCancel = false;

                //Change Boards
                Boards.SelectedIndex = (int)showBoard;
                Boards.Refresh();

                //Exectute Board Show Code
                switch (ShowBoard)
                {
                    case BoardId.Info:

                        string LoggedIn = "True";
                        if (LoggedIn == "True")
                        {
                            Boards.SelectedIndex = (int)BoardId.Info;
                            Boards.Refresh();
                        }
                        else
                        {
                            //txtUserName.Text = txtEmpId.Text = txtPassword.Text = "";
                            //if (txtUserName.Text == "")
                            //    txtUserName.Text = Environment.UserName;

                            Boards.SelectedIndex = (int)BoardId.Info;
                        }

                        break;
                    case BoardId.Run:
                        break;
                }
            }
        }

        public enum BoardId
        {
            Info = 0,
            Run = 1,
            Drawing = 2
        }

        public fbDatasheet()
        {
            InitializeComponent();


            Boards.BorderStyle = Wisej.Web.BorderStyle.None;
            Boards.ItemSize = new Size(1, 1); //Hide Tabs - they are not selectable
            Boards.SizeMode = TabSizeMode.Fixed;

            foreach (TabPage tab in Boards.TabPages)
            {
                tab.Text = "";
                tab.BackColor = Color.White;
            }
        }
        #endregion

        #region Info
        private void btnInfoNext_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Run;
            this.Refresh();

            // Save Data
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on info screen")]
        public event EventHandler btnInfoHomeClick;
        protected void btnInfoHome_Click(object sender, EventArgs e)
        {
            btnInfoHomeClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on info screen")]
        public event EventHandler btnInfoBackClick;
        private void btnInfoBack_Click(object sender, EventArgs e)
        {
            btnInfoBackClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }
        #endregion

        #region Run
        private void btnRunNext_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Drawing;
            this.Refresh();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on run screen")]
        public event EventHandler btnRunHomeClick;
        private void btnRunHome_Click(object sender, EventArgs e)
        {
            btnRunHomeClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        private void btnRunBack_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Info;
            this.Refresh();

            // Save Data
        }

        private void btnRunAdd_Click(object sender, EventArgs e)
        {
            // Create Datasheet_Run and associate it to datasheet object
        }
        #endregion

        #region Attachments
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on attachments screen")]
        public event EventHandler btnAttachmentsCompleteClick;
        private void btnDrawingComplete_Click(object sender, EventArgs e)
        {
            btnAttachmentsCompleteClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on attachments screen")]
        public event EventHandler btnAttachmentsHomeClick;
        private void btnDrawingHome_Click(object sender, EventArgs e)
        {
            btnAttachmentsHomeClick?.Invoke(this, e);

            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        private void btnDrawingBack_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        private void btnDrawingUndo_Click(object sender, EventArgs e)
        {
            if (drawnShapes.Count > 0) 
            { 
                if (drawnShapes[drawnShapes.Count - 1].shapeType == ShapeType.Ellipse) 
                {
                    weldCounter = drawnShapes[drawnShapes.Count - 1].RunId - 1;
                }
                drawnShapes.RemoveAt(drawnShapes.Count - 1);
                pDrawingWeldSequence.Invalidate();
            }
        }
        #endregion

        private void pDrawingWeldSequence_MouseDown(object sender, MouseEventArgs e)
        {
            mouseMoving = true;
            start.X = e.X;
            start.Y = e.Y;
            current.X = e.X;
            current.Y = e.Y;
            pDrawingWeldSequence.Invalidate();
        }

        private void pDrawingWeldSequence_MouseUp(object sender, MouseEventArgs e)
        {
            mouseMoving = false;

            if (window == null) 
                return;

            float rotateAng = 0;
            float.TryParse(txtDrawingRotation.Text, out rotateAng);

            if (rbDrawingRectangle.Checked)
            {
                WeldingShape newRect = new WeldingShape(ShapeType.Rectangle, window, start, rotateAng);
                drawnShapes.Add(newRect);
            }
            else if (rbDrawingWeld.Checked)
            {
                weldCounter++;
                WeldingShape newEllipse = new WeldingShape(ShapeType.Ellipse, window, start, rotateAng, weldCounter);
                drawnShapes.Add(newEllipse);
            }
            else if (rbDrawingBevel.Checked)
            {

            }
            else if (rbDrawingGroove.Checked)
            {

            }
            else if (rbDrawingFlange.Checked)
            {

            }

            window = new Rectangle();
        }

        private void pDrawingWeldSequence_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseMoving)
            {
                current.X = e.X;
                current.Y = e.Y;
                pDrawingWeldSequence.Invalidate();
            }
        }

        private void pDrawingWeldSequence_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen pen = new Pen(Color.Black);
            SolidBrush brush = new SolidBrush(Color.White);

            foreach (WeldingShape shape in drawnShapes)
            {
                if (shape.shapeType == ShapeType.Rectangle) 
                {
                    drawRectangle(g, shape.BoundingBox, shape.Rotation, shape.ClickPoint);
                }
                else if (shape.shapeType == ShapeType.Ellipse) 
                {
                    drawEllipse(g, shape.BoundingBox, shape.Rotation, shape.RunId.ToString(), shape.ClickPoint);
                }
            }
            
            if (mouseMoving)
            {
                int X = Math.Min(start.X, current.X);
                int Y = Math.Min(start.Y, current.Y);

                float rotateAng = 0;
                float.TryParse(txtDrawingRotation.Text, out rotateAng);

                window = new Rectangle(X, Y, Math.Abs(start.X - current.X), Math.Abs(start.Y - current.Y));

                if (rbDrawingRectangle.Checked)
                {
                    drawRectangle(g, window, rotateAng, start);
                }
                else if (rbDrawingWeld.Checked)
                {
                    drawEllipse(g, window, rotateAng, (weldCounter + 1).ToString(), start);
                }
                else if (rbDrawingBevel.Checked)
                {

                }
                else if (rbDrawingGroove.Checked)
                {

                }
                else if (rbDrawingFlange.Checked)
                {

                }

                pen.Dispose();
            }
        }

        private void pDrawingShapePreview_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen pen = new Pen(Color.Black);

            float rotateAng = 0;
            float.TryParse(txtDrawingRotation.Text, out rotateAng);

            float rotateRad = (float)(rotateAng * Math.PI / 180);

            int height, width;

            float boundingWidth, boundingHeight, scaleX, scaleY;

            if (rbDrawingRectangle.Checked)
            {
                height = pDrawingShapePreview.Height - 20;
                width = pDrawingShapePreview.Width - 20;

                boundingWidth = (float)(Math.Abs(height * Math.Sin(rotateRad)) + Math.Abs(width * Math.Cos(rotateRad)));
                boundingHeight = (float)(Math.Abs(width * Math.Sin(rotateRad)) + Math.Abs(height * Math.Cos(rotateRad)));

                scaleX = (float)(width / boundingWidth);
                scaleY = (float)(height / boundingHeight);

                using (Matrix matrix = new Matrix())
                {
                    matrix.Scale(scaleX, scaleY, MatrixOrder.Append);
                    matrix.Translate(((float)boundingWidth - width) / 2, ((float)boundingHeight - height) / 2);
                    matrix.RotateAt(rotateAng, new Point(pDrawingShapePreview.Width/ 2, pDrawingShapePreview.Height/ 2));
                    g.Transform = matrix;
                    g.DrawRectangle(pen, 10, 10, width, height);
                    g.ResetTransform();
                }
            }
            else if (rbDrawingWeld.Checked)
            {
                height = (pDrawingShapePreview.Height/2);
                width = pDrawingShapePreview.Width - 20;

                boundingWidth = (float)(Math.Abs(height * Math.Sin(rotateRad)) + Math.Abs(width * Math.Cos(rotateRad)));
                boundingHeight = (float)(Math.Abs(width * Math.Sin(rotateRad)) + Math.Abs(height * Math.Cos(rotateRad)));

                scaleX = (float)(width / boundingWidth);
                scaleY = (float)(height / boundingHeight);

                using (Matrix matrix = new Matrix())
                {
                    matrix.RotateAt(rotateAng, new Point(pDrawingShapePreview.Width / 2, pDrawingShapePreview.Height / 2));
                    matrix.Scale(scaleX, scaleY, MatrixOrder.Append);
                    matrix.Translate(((float)boundingWidth - width) / 2, ((float)boundingHeight - height) / 2, MatrixOrder.Append);
                    g.Transform = matrix;
                    g.DrawEllipse(pen, 10, pDrawingShapePreview.Height / 2 - height / 2, width, height);
                    g.ResetTransform();
                }
            }
            else if (rbDrawingBevel.Checked)
            {

            }
            else if (rbDrawingGroove.Checked)
            {

            }
            else if (rbDrawingFlange.Checked)
            {

            }
        }

        private void txtDrawingRotation_TextChanged(object sender, EventArgs e)
        {
            pDrawingShapePreview.Invalidate();
        }

        private void rbDrawingRectangle_CheckedChanged(object sender, EventArgs e)
        {
            pDrawingShapePreview.Invalidate();
        }

        private void rbDrawingCircle_CheckedChanged(object sender, EventArgs e)
        {
            pDrawingShapePreview.Invalidate();
        }

        private void rbDrawingBevel_CheckedChanged(object sender, EventArgs e)
        {
            pDrawingShapePreview.Invalidate();
        }

        private void rbDrawingGroove_CheckedChanged(object sender, EventArgs e)
        {
            pDrawingShapePreview.Invalidate();

        }

        private void rbDrawingFlange_CheckedChanged(object sender, EventArgs e)
        {
            pDrawingShapePreview.Invalidate();
        }

        private void uplDrawingUpload_Uploaded(object sender, UploadedEventArgs e)
        {
            //TODO
        }
    }
}
