﻿using System;
using System.ComponentModel;
using System.Drawing;
using Wisej.Web;

namespace WeldingManagement
{
    public partial class fbWPQR : Wisej.Web.UserControl
    {
        #region FlipBoard
        bool IsDesignMode = (LicenseManager.UsageMode == LicenseUsageMode.Designtime);
        bool checkCancel = true;

        [Category("Board")]
        [Description("Number to display")]

        private void Boards_Selecting(object sender, TabControlCancelEventArgs e)
        {
            e.Cancel = checkCancel;
            checkCancel = true;
        }

        private BoardId showBoard = BoardId.Info;
        public BoardId ShowBoard
        {
            get
            {
                return showBoard;
            }
            set
            {
                showBoard = value;
                checkCancel = false;

                //Change Boards
                Boards.SelectedIndex = (int)showBoard;
                Boards.Refresh();

                //Exectute Board Show Code
                switch (ShowBoard)
                {
                    case BoardId.Info:

                        string LoggedIn = "True";
                        if (LoggedIn == "True")
                        {
                            Boards.SelectedIndex = (int)BoardId.Info;
                            Boards.Refresh();
                        }
                        else
                        {
                            //txtUserName.Text = txtEmpId.Text = txtPassword.Text = "";
                            //if (txtUserName.Text == "")
                            //    txtUserName.Text = Environment.UserName;

                            Boards.SelectedIndex = (int)BoardId.Info;
                        }

                        break;
                    case BoardId.Run:
                        break;
                }
            }
        }

        public enum BoardId
        {
            Info = 0,
            Run = 1,
            Details = 2,
            Continued = 3,
            Upload = 4
        }

        public fbWPQR()
        {
            InitializeComponent();

            Boards.BorderStyle = Wisej.Web.BorderStyle.None;
            Boards.ItemSize = new Size(1, 1); //Hide Tabs - they are not selectable
            Boards.SizeMode = TabSizeMode.Fixed;

            foreach (TabPage tab in Boards.TabPages)
            {
                tab.Text = "";
                tab.BackColor = Color.White;
            }
        }

        #endregion region

        #region Info
        private void btnInfoNext_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Run;
            this.Refresh();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on info screen")]
        public event EventHandler btnInfoHomeClick;
        private void btnInfoHome_Click(object sender, EventArgs e)
        {
            btnInfoHomeClick?.Invoke(this, e);
            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on info screen")]
        public event EventHandler btnInfoBackClick;
        private void btnInfoBack_Click(object sender, EventArgs e)
        {
            btnInfoBackClick?.Invoke(this, e);
            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }
        #endregion

        #region Run
        private void btnRunNext_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Details;
            this.Refresh();

            // Save
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on run screen")]
        public event EventHandler btnRunHomeClick;
        private void btnRunHome_Click(object sender, EventArgs e)
        {
            btnRunHomeClick?.Invoke(this, e);
            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        private void btnRunBack_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Info;
            this.Refresh();

            // Save
        }
        #endregion

        #region Details
        private void btnDetailsNext_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Continued;
            this.Refresh();

            // Save
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on details screen")]
        public event EventHandler btnDetailsHomeClick;
        private void btnDetailsHome_Click(object sender, EventArgs e)
        {
            btnDetailsHomeClick?.Invoke(this, e);
            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        private void btnDetailsBack_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Run;
            this.Refresh();

            // Save
        }

        #endregion

        #region Details Continued
        private void btnContNext_Click(object sender, EventArgs e)
        {
            // Navigate to Attachments and Save
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on details continued screen")]
        public event EventHandler btnContHomeClick;
        private void btnContHome_Click(object sender, EventArgs e)
        {
            btnContHomeClick?.Invoke(this, e);
            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        private void btnContBack_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Details;
            this.Refresh();

            // Save
        }
        #endregion

        #region Upload
        private void btnUploadBack_Click(object sender, EventArgs e)
        {
            this.ShowBoard = BoardId.Continued;
            this.Refresh();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on upload screen")]
        public event EventHandler btnUploadHomeClick;
        private void btnUploadHome_Click(object sender, EventArgs e)
        {
            btnUploadHomeClick?.Invoke(this, e);
            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on upload screen")]
        public event EventHandler btnUploadCompleteClick;
        private void btnUploadComplete_Click(object sender, EventArgs e)
        {
            btnUploadCompleteClick?.Invoke(this, e);
            this.ShowBoard = BoardId.Info;
            this.Refresh();
        }

        private void uplUploadPreparation_Uploaded(object sender, UploadedEventArgs e)
        {

        }

        private void uplUploadSequence_Uploaded(object sender, UploadedEventArgs e)
        {

        }
        #endregion
    }
}
