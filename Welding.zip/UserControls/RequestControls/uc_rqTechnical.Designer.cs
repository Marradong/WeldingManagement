﻿namespace WeldingManagement.UserControls.RequestControls
{
    partial class uc_rqTechnical
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel4 = new Wisej.Web.TableLayoutPanel();
            this.dtpDetailsDate = new Wisej.Web.DateTimePicker();
            this.txtTechnicalClient = new Wisej.Web.TextBox();
            this.txtTechnicalJoint = new Wisej.Web.TextBox();
            this.txtTechnicalSuggested = new Wisej.Web.TextBox();
            this.txtTechnicalNominal = new Wisej.Web.TextBox();
            this.txtTechnicalCategory = new Wisej.Web.TextBox();
            this.txtTechnicalMatGrade = new Wisej.Web.TextBox();
            this.txtTechnicalMatStandard = new Wisej.Web.TextBox();
            this.txtTechnicalStandard = new Wisej.Web.TextBox();
            this.txtTechnicalComponent = new Wisej.Web.TextBox();
            this.label42 = new Wisej.Web.Label();
            this.label43 = new Wisej.Web.Label();
            this.label44 = new Wisej.Web.Label();
            this.label45 = new Wisej.Web.Label();
            this.label46 = new Wisej.Web.Label();
            this.label47 = new Wisej.Web.Label();
            this.label51 = new Wisej.Web.Label();
            this.label52 = new Wisej.Web.Label();
            this.label54 = new Wisej.Web.Label();
            this.label55 = new Wisej.Web.Label();
            this.label58 = new Wisej.Web.Label();
            this.label59 = new Wisej.Web.Label();
            this.txtTechnicalPosition = new Wisej.Web.TextBox();
            this.txtTechnicalQuality = new Wisej.Web.TextBox();
            this.txtTechnicalDrawing = new Wisej.Web.TextBox();
            this.label30 = new Wisej.Web.Label();
            this.txtTechnicalJob = new Wisej.Web.TextBox();
            this.label31 = new Wisej.Web.Label();
            this.label1 = new Wisej.Web.Label();
            this.dtpTechnicalDate = new Wisej.Web.DateTimePicker();
            this.txtTechnicalExtra = new Wisej.Web.TextBox();
            this.txtTechnicalConsiderations = new Wisej.Web.TextBox();
            this.txtTechnicalReviewer = new Wisej.Web.TextBox();
            this.label37 = new Wisej.Web.Label();
            this.label50 = new Wisej.Web.Label();
            this.label53 = new Wisej.Web.Label();
            this.label56 = new Wisej.Web.Label();
            this.tableLayoutPanel5 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel6 = new Wisej.Web.TableLayoutPanel();
            this.btnTechnicalDocuments = new Wisej.Web.Button();
            this.btnTechnicalBack = new Wisej.Web.Button();
            this.btnTechnicalHome = new Wisej.Web.Button();
            this.btnTechnicalNext = new Wisej.Web.Button();
            this.tableLayoutPanel7 = new Wisej.Web.TableLayoutPanel();
            this.label57 = new Wisej.Web.Label();
            this.label63 = new Wisej.Web.Label();
            this.styleSheet1 = new Wisej.Web.StyleSheet(this.components);
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel7, 1, 1);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel2.TabIndex = 5;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel5, 1, 0);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 4;
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel4.Controls.Add(this.dtpDetailsDate, 3, 5);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalClient, 3, 10);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalJoint, 3, 9);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalSuggested, 3, 8);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalNominal, 3, 7);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalCategory, 3, 6);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalMatGrade, 1, 8);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalMatStandard, 1, 6);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalStandard, 1, 7);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalComponent, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.label42, 2, 10);
            this.tableLayoutPanel4.Controls.Add(this.label43, 2, 9);
            this.tableLayoutPanel4.Controls.Add(this.label44, 2, 8);
            this.tableLayoutPanel4.Controls.Add(this.label45, 2, 7);
            this.tableLayoutPanel4.Controls.Add(this.label46, 2, 6);
            this.tableLayoutPanel4.Controls.Add(this.label47, 2, 5);
            this.tableLayoutPanel4.Controls.Add(this.label51, 0, 8);
            this.tableLayoutPanel4.Controls.Add(this.label52, 0, 7);
            this.tableLayoutPanel4.Controls.Add(this.label54, 0, 10);
            this.tableLayoutPanel4.Controls.Add(this.label55, 0, 9);
            this.tableLayoutPanel4.Controls.Add(this.label58, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.label59, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalPosition, 1, 9);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalQuality, 1, 10);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalDrawing, 3, 4);
            this.tableLayoutPanel4.Controls.Add(this.label30, 2, 4);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalJob, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.label31, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.label1, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.dtpTechnicalDate, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalExtra, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalConsiderations, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.txtTechnicalReviewer, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label37, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label50, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label53, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label56, 0, 0);
            this.tableLayoutPanel4.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 11;
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel4.TabIndex = 6;
            // 
            // dtpDetailsDate
            // 
            this.dtpDetailsDate.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.dtpDetailsDate.Dock = Wisej.Web.DockStyle.Fill;
            this.dtpDetailsDate.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpDetailsDate.Location = new System.Drawing.Point(771, 198);
            this.dtpDetailsDate.Name = "dtpDetailsDate";
            this.dtpDetailsDate.ReadOnly = true;
            this.dtpDetailsDate.Size = new System.Drawing.Size(250, 33);
            this.dtpDetailsDate.TabIndex = 77;
            this.dtpDetailsDate.Value = new System.DateTime(2024, 2, 6, 13, 21, 27, 859);
            // 
            // txtTechnicalClient
            // 
            this.txtTechnicalClient.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.txtTechnicalClient.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalClient.Location = new System.Drawing.Point(771, 393);
            this.txtTechnicalClient.Name = "txtTechnicalClient";
            this.txtTechnicalClient.ReadOnly = true;
            this.txtTechnicalClient.Size = new System.Drawing.Size(250, 37);
            this.txtTechnicalClient.TabIndex = 76;
            // 
            // txtTechnicalJoint
            // 
            this.txtTechnicalJoint.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.txtTechnicalJoint.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalJoint.Location = new System.Drawing.Point(771, 354);
            this.txtTechnicalJoint.Name = "txtTechnicalJoint";
            this.txtTechnicalJoint.ReadOnly = true;
            this.txtTechnicalJoint.Size = new System.Drawing.Size(250, 33);
            this.txtTechnicalJoint.TabIndex = 75;
            // 
            // txtTechnicalSuggested
            // 
            this.txtTechnicalSuggested.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.txtTechnicalSuggested.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalSuggested.Location = new System.Drawing.Point(771, 315);
            this.txtTechnicalSuggested.Name = "txtTechnicalSuggested";
            this.txtTechnicalSuggested.ReadOnly = true;
            this.txtTechnicalSuggested.Size = new System.Drawing.Size(250, 33);
            this.txtTechnicalSuggested.TabIndex = 74;
            // 
            // txtTechnicalNominal
            // 
            this.txtTechnicalNominal.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.txtTechnicalNominal.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalNominal.Location = new System.Drawing.Point(771, 276);
            this.txtTechnicalNominal.Name = "txtTechnicalNominal";
            this.txtTechnicalNominal.ReadOnly = true;
            this.txtTechnicalNominal.Size = new System.Drawing.Size(250, 33);
            this.txtTechnicalNominal.TabIndex = 73;
            // 
            // txtTechnicalCategory
            // 
            this.txtTechnicalCategory.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.txtTechnicalCategory.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalCategory.Location = new System.Drawing.Point(771, 237);
            this.txtTechnicalCategory.Name = "txtTechnicalCategory";
            this.txtTechnicalCategory.ReadOnly = true;
            this.txtTechnicalCategory.Size = new System.Drawing.Size(250, 33);
            this.txtTechnicalCategory.TabIndex = 72;
            // 
            // txtTechnicalMatGrade
            // 
            this.txtTechnicalMatGrade.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.txtTechnicalMatGrade.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalMatGrade.Location = new System.Drawing.Point(259, 315);
            this.txtTechnicalMatGrade.Name = "txtTechnicalMatGrade";
            this.txtTechnicalMatGrade.ReadOnly = true;
            this.txtTechnicalMatGrade.Size = new System.Drawing.Size(250, 33);
            this.txtTechnicalMatGrade.TabIndex = 71;
            // 
            // txtTechnicalMatStandard
            // 
            this.txtTechnicalMatStandard.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.txtTechnicalMatStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalMatStandard.Location = new System.Drawing.Point(259, 237);
            this.txtTechnicalMatStandard.Name = "txtTechnicalMatStandard";
            this.txtTechnicalMatStandard.ReadOnly = true;
            this.txtTechnicalMatStandard.Size = new System.Drawing.Size(250, 33);
            this.txtTechnicalMatStandard.TabIndex = 70;
            // 
            // txtTechnicalStandard
            // 
            this.txtTechnicalStandard.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.txtTechnicalStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalStandard.Location = new System.Drawing.Point(259, 276);
            this.txtTechnicalStandard.Name = "txtTechnicalStandard";
            this.txtTechnicalStandard.ReadOnly = true;
            this.txtTechnicalStandard.Size = new System.Drawing.Size(250, 33);
            this.txtTechnicalStandard.TabIndex = 67;
            // 
            // txtTechnicalComponent
            // 
            this.txtTechnicalComponent.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.txtTechnicalComponent.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalComponent.Location = new System.Drawing.Point(259, 198);
            this.txtTechnicalComponent.Name = "txtTechnicalComponent";
            this.txtTechnicalComponent.ReadOnly = true;
            this.txtTechnicalComponent.Size = new System.Drawing.Size(250, 33);
            this.txtTechnicalComponent.TabIndex = 66;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.FromName("@window");
            this.label42.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label42.Dock = Wisej.Web.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(515, 393);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(250, 37);
            this.label42.TabIndex = 65;
            this.label42.Text = "Client specified Inspection and Testing requirements";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.FromName("@window");
            this.label43.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label43.Dock = Wisej.Web.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(515, 354);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(250, 33);
            this.label43.TabIndex = 64;
            this.label43.Text = "Joint Configeration";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.FromName("@window");
            this.label44.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label44.Dock = Wisej.Web.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(515, 315);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(250, 33);
            this.label44.TabIndex = 63;
            this.label44.Text = "Suggested welding process";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.FromName("@window");
            this.label45.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label45.Dock = Wisej.Web.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(515, 276);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(250, 33);
            this.label45.TabIndex = 62;
            this.label45.Text = "Nominal tensile strength of welds";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.FromName("@window");
            this.label46.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label46.Dock = Wisej.Web.DockStyle.Fill;
            this.label46.Location = new System.Drawing.Point(515, 237);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(250, 33);
            this.label46.TabIndex = 61;
            this.label46.Text = "Welding Category";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.FromName("@window");
            this.label47.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label47.Dock = Wisej.Web.DockStyle.Fill;
            this.label47.Location = new System.Drawing.Point(515, 198);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(250, 33);
            this.label47.TabIndex = 60;
            this.label47.Text = "Date";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.FromName("@window");
            this.label51.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label51.Dock = Wisej.Web.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(3, 315);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(250, 33);
            this.label51.TabIndex = 59;
            this.label51.Text = "Material Grade";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.FromName("@window");
            this.label52.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label52.Dock = Wisej.Web.DockStyle.Fill;
            this.label52.Location = new System.Drawing.Point(3, 276);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(250, 33);
            this.label52.TabIndex = 58;
            this.label52.Text = "Material Standard";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.FromName("@window");
            this.label54.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label54.Dock = Wisej.Web.DockStyle.Fill;
            this.label54.Location = new System.Drawing.Point(3, 393);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(250, 37);
            this.label54.TabIndex = 57;
            this.label54.Text = "Quality & acceptance requirements for welds";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.FromName("@window");
            this.label55.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label55.Dock = Wisej.Web.DockStyle.Fill;
            this.label55.Location = new System.Drawing.Point(3, 354);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(250, 33);
            this.label55.TabIndex = 56;
            this.label55.Text = "Welding Position";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.Color.FromName("@window");
            this.label58.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label58.Dock = Wisej.Web.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(3, 237);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(250, 33);
            this.label58.TabIndex = 55;
            this.label58.Text = "Welding Standard";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.Color.FromName("@window");
            this.label59.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label59.Dock = Wisej.Web.DockStyle.Fill;
            this.label59.Location = new System.Drawing.Point(3, 198);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(250, 33);
            this.label59.TabIndex = 54;
            this.label59.Text = "Component Description";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtTechnicalPosition
            // 
            this.txtTechnicalPosition.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.txtTechnicalPosition.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalPosition.Location = new System.Drawing.Point(259, 354);
            this.txtTechnicalPosition.Name = "txtTechnicalPosition";
            this.txtTechnicalPosition.ReadOnly = true;
            this.txtTechnicalPosition.Size = new System.Drawing.Size(250, 33);
            this.txtTechnicalPosition.TabIndex = 68;
            // 
            // txtTechnicalQuality
            // 
            this.txtTechnicalQuality.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.txtTechnicalQuality.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalQuality.Location = new System.Drawing.Point(259, 393);
            this.txtTechnicalQuality.Name = "txtTechnicalQuality";
            this.txtTechnicalQuality.ReadOnly = true;
            this.txtTechnicalQuality.Size = new System.Drawing.Size(250, 37);
            this.txtTechnicalQuality.TabIndex = 69;
            // 
            // txtTechnicalDrawing
            // 
            this.txtTechnicalDrawing.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.txtTechnicalDrawing.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalDrawing.Location = new System.Drawing.Point(771, 159);
            this.txtTechnicalDrawing.Name = "txtTechnicalDrawing";
            this.txtTechnicalDrawing.ReadOnly = true;
            this.txtTechnicalDrawing.Size = new System.Drawing.Size(250, 33);
            this.txtTechnicalDrawing.TabIndex = 37;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.FromName("@window");
            this.label30.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label30.Dock = Wisej.Web.DockStyle.Fill;
            this.label30.Location = new System.Drawing.Point(515, 159);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(250, 33);
            this.label30.TabIndex = 31;
            this.label30.Text = "Drawing Number";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtTechnicalJob
            // 
            this.txtTechnicalJob.BackColor = System.Drawing.Color.FromName("@switchUndetermined");
            this.txtTechnicalJob.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalJob.Location = new System.Drawing.Point(259, 159);
            this.txtTechnicalJob.Name = "txtTechnicalJob";
            this.txtTechnicalJob.ReadOnly = true;
            this.txtTechnicalJob.Size = new System.Drawing.Size(250, 33);
            this.txtTechnicalJob.TabIndex = 30;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.FromName("@window");
            this.label31.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label31.Dock = Wisej.Web.DockStyle.Fill;
            this.label31.Location = new System.Drawing.Point(3, 159);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(250, 33);
            this.label31.TabIndex = 29;
            this.label31.Text = "Job / Quote Number";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel4.SetColumnSpan(this.label1, 4);
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1018, 33);
            this.label1.TabIndex = 28;
            this.label1.Text = "Request Details - Read Only";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtpTechnicalDate
            // 
            this.dtpTechnicalDate.Dock = Wisej.Web.DockStyle.Fill;
            this.dtpTechnicalDate.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpTechnicalDate.Location = new System.Drawing.Point(771, 3);
            this.dtpTechnicalDate.Name = "dtpTechnicalDate";
            this.dtpTechnicalDate.Size = new System.Drawing.Size(250, 33);
            this.dtpTechnicalDate.TabIndex = 2;
            this.dtpTechnicalDate.Value = new System.DateTime(2024, 2, 6, 14, 17, 22, 924);
            // 
            // txtTechnicalExtra
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.txtTechnicalExtra, 3);
            this.txtTechnicalExtra.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalExtra.Location = new System.Drawing.Point(259, 81);
            this.txtTechnicalExtra.Multiline = true;
            this.txtTechnicalExtra.Name = "txtTechnicalExtra";
            this.txtTechnicalExtra.Size = new System.Drawing.Size(762, 33);
            this.txtTechnicalExtra.TabIndex = 1;
            // 
            // txtTechnicalConsiderations
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.txtTechnicalConsiderations, 3);
            this.txtTechnicalConsiderations.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalConsiderations.Location = new System.Drawing.Point(259, 42);
            this.txtTechnicalConsiderations.Multiline = true;
            this.txtTechnicalConsiderations.Name = "txtTechnicalConsiderations";
            this.txtTechnicalConsiderations.Size = new System.Drawing.Size(762, 33);
            this.txtTechnicalConsiderations.TabIndex = 0;
            // 
            // txtTechnicalReviewer
            // 
            this.txtTechnicalReviewer.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTechnicalReviewer.Location = new System.Drawing.Point(259, 3);
            this.txtTechnicalReviewer.Name = "txtTechnicalReviewer";
            this.txtTechnicalReviewer.ReadOnly = true;
            this.txtTechnicalReviewer.Size = new System.Drawing.Size(250, 33);
            this.txtTechnicalReviewer.TabIndex = 24;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.FromName("@window");
            this.label37.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label37.Dock = Wisej.Web.DockStyle.Fill;
            this.label37.Location = new System.Drawing.Point(515, 3);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(250, 33);
            this.label37.TabIndex = 13;
            this.label37.Text = "Date";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.FromName("@window");
            this.label50.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label50.Dock = Wisej.Web.DockStyle.Fill;
            this.label50.Location = new System.Drawing.Point(3, 81);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(250, 33);
            this.label50.TabIndex = 2;
            this.label50.Text = "Extra costs to consider";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.FromName("@window");
            this.label53.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label53.Dock = Wisej.Web.DockStyle.Fill;
            this.label53.Location = new System.Drawing.Point(3, 42);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(250, 33);
            this.label53.TabIndex = 1;
            this.label53.Text = "Technical Considerations";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.FromName("@window");
            this.label56.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label56.Dock = Wisej.Web.DockStyle.Fill;
            this.label56.Location = new System.Drawing.Point(3, 3);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(250, 33);
            this.label56.TabIndex = 0;
            this.label56.Text = "Technical Reviewer EID";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel6, 0, 0);
            this.tableLayoutPanel5.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel5.TabIndex = 5;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.btnTechnicalDocuments, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.btnTechnicalBack, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.btnTechnicalHome, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.btnTechnicalNext, 0, 4);
            this.tableLayoutPanel6.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel6.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 5;
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel6.TabIndex = 4;
            // 
            // btnTechnicalDocuments
            // 
            this.btnTechnicalDocuments.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnTechnicalDocuments.Dock = Wisej.Web.DockStyle.Fill;
            this.btnTechnicalDocuments.Location = new System.Drawing.Point(3, 3);
            this.btnTechnicalDocuments.Name = "btnTechnicalDocuments";
            this.btnTechnicalDocuments.Size = new System.Drawing.Size(95, 79);
            this.btnTechnicalDocuments.TabIndex = 5;
            this.btnTechnicalDocuments.Text = "View Linked Documents";
            this.btnTechnicalDocuments.Click += new System.EventHandler(this.btnTechnicalDocuments_Click);
            // 
            // btnTechnicalBack
            // 
            this.btnTechnicalBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnTechnicalBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnTechnicalBack.Location = new System.Drawing.Point(3, 173);
            this.btnTechnicalBack.Name = "btnTechnicalBack";
            this.btnTechnicalBack.Size = new System.Drawing.Size(95, 79);
            this.btnTechnicalBack.TabIndex = 4;
            this.btnTechnicalBack.Text = "Back";
            this.btnTechnicalBack.Click += new System.EventHandler(this.btnTechnicalBack_Click);
            // 
            // btnTechnicalHome
            // 
            this.btnTechnicalHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnTechnicalHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnTechnicalHome.Location = new System.Drawing.Point(3, 258);
            this.btnTechnicalHome.Name = "btnTechnicalHome";
            this.btnTechnicalHome.Size = new System.Drawing.Size(95, 79);
            this.btnTechnicalHome.TabIndex = 1;
            this.btnTechnicalHome.Text = "Home";
            this.btnTechnicalHome.Click += new System.EventHandler(this.btnTechnicalHome_Click);
            // 
            // btnTechnicalNext
            // 
            this.btnTechnicalNext.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnTechnicalNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnTechnicalNext.Location = new System.Drawing.Point(3, 343);
            this.btnTechnicalNext.Name = "btnTechnicalNext";
            this.btnTechnicalNext.Size = new System.Drawing.Size(95, 79);
            this.btnTechnicalNext.TabIndex = 0;
            this.btnTechnicalNext.Text = "Next";
            this.btnTechnicalNext.Click += new System.EventHandler(this.btnTechnicalNext_Click);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.label57, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.label63, 0, 0);
            this.tableLayoutPanel7.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel7.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel7.TabIndex = 0;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label57.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label57.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.label57.Dock = Wisej.Web.DockStyle.Fill;
            this.label57.Location = new System.Drawing.Point(6, 79);
            this.label57.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(1133, 35);
            this.label57.TabIndex = 1;
            this.label57.Text = "Notes";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label63.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label63.CssStyle = "border-radius: 4px;";
            this.label63.Dock = Wisej.Web.DockStyle.Fill;
            this.label63.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label63.Location = new System.Drawing.Point(6, 3);
            this.label63.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(1133, 70);
            this.label63.TabIndex = 0;
            this.label63.Text = "Technical Review";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uc_rqTechnical
            // 
            this.Controls.Add(this.tableLayoutPanel2);
            this.Name = "uc_rqTechnical";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_rqTechnical_VisibleChanged);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel4;
        private Wisej.Web.TextBox txtTechnicalExtra;
        private Wisej.Web.TextBox txtTechnicalConsiderations;
        private Wisej.Web.TextBox txtTechnicalReviewer;
        private Wisej.Web.Label label37;
        private Wisej.Web.Label label50;
        private Wisej.Web.Label label53;
        private Wisej.Web.Label label56;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel5;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel6;
        private Wisej.Web.Button btnTechnicalHome;
        private Wisej.Web.Button btnTechnicalNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel7;
        private Wisej.Web.Label label57;
        private Wisej.Web.Label label63;
        private Wisej.Web.Button btnTechnicalBack;
        private Wisej.Web.DateTimePicker dtpTechnicalDate;
        private Wisej.Web.Label label1;
        private Wisej.Web.Label label31;
        private Wisej.Web.TextBox txtTechnicalJob;
        private Wisej.Web.Label label30;
        private Wisej.Web.TextBox txtTechnicalDrawing;
        private Wisej.Web.DateTimePicker dtpDetailsDate;
        private Wisej.Web.TextBox txtTechnicalClient;
        private Wisej.Web.TextBox txtTechnicalJoint;
        private Wisej.Web.TextBox txtTechnicalSuggested;
        private Wisej.Web.TextBox txtTechnicalNominal;
        private Wisej.Web.TextBox txtTechnicalCategory;
        private Wisej.Web.TextBox txtTechnicalMatGrade;
        private Wisej.Web.TextBox txtTechnicalMatStandard;
        private Wisej.Web.TextBox txtTechnicalStandard;
        private Wisej.Web.TextBox txtTechnicalComponent;
        private Wisej.Web.Label label42;
        private Wisej.Web.Label label43;
        private Wisej.Web.Label label44;
        private Wisej.Web.Label label45;
        private Wisej.Web.Label label46;
        private Wisej.Web.Label label47;
        private Wisej.Web.Label label51;
        private Wisej.Web.Label label52;
        private Wisej.Web.Label label54;
        private Wisej.Web.Label label55;
        private Wisej.Web.Label label58;
        private Wisej.Web.Label label59;
        private Wisej.Web.TextBox txtTechnicalPosition;
        private Wisej.Web.TextBox txtTechnicalQuality;
        private Wisej.Web.Button btnTechnicalDocuments;
        private Wisej.Web.StyleSheet styleSheet1;
    }
}
