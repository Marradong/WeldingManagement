﻿using ApiClient;
using PeopleEF;
using QAWebApi;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using Welding.DAL;
using WeldingManagement.UserControls.PopupControls;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.RequestControls
{
    public partial class uc_rqOperational : Wisej.Web.UserControl
    {
        private up_hmSave up_hmSave1;
        private up_rqFilesView up_rqFilesView1;
        private Panel overlayPanel;

        public uc_rqOperational()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on operational screen")]
        public event EventHandler btnOperationCompleteClick;
        private void btnOperationComplete_Click(object sender, EventArgs e)
        {
            Save_Action();
            Update_Status();

            btnOperationCompleteClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on operational screen")]
        public event EventHandler btnOperationHomeClick;
        private void btnOperationHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnOperationHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on operational screen")]
        public event EventHandler btnOperationBackClick;
        private void btnOperationBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnOperationBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnOperationBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiClient.ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                nwf.Status = Actions.ManagerReview;

                ApiClient.ApiCalls.UpdateNewWeldingForm(nwf.NewWeldingFormId, nwf);

                this.Tag = new Tag(ApiClient.ApiCalls.ReadNewWeldingForm(nwf.NewWeldingFormId), TagType.New_Welding_Form);
            }
        }

        private void Save_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiClient.ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                if (nwf.OperationalReview == null)
                {
                    // Create a new welding form to act as a DTO
                    Person linkedPerson = QAWebApiClient.ApiCalls.GetPerson(txtOperationReviewer.Text);

                    if (linkedPerson != null)
                    {
                        OperationalReview operationalReview = new OperationalReview(nwf.NewWeldingFormId, nwf);

                        operationalReview.OperationalReviewerEID = linkedPerson.EmployeeNumber;

                        operationalReview.NewWeldingForm.OperationalReview.Date = dtpOperationalDate.Value;

                        operationalReview.TrainedStaff = cbOperationStaff.Checked;
                        operationalReview.Facilities = cbOperationFacilities.Checked;
                        operationalReview.Equipment = cbOperationEquipment.Checked;
                        operationalReview.ThirdParty = cbOperationThird.Checked;
                        operationalReview.WPS = cbOperationWPS.Checked;
                        operationalReview.WPQR = cbOperationWPQR.Checked;
                        operationalReview.Welders = cbOperationWelders.Checked;
                        operationalReview.SubContractors = cbOperationSub.Checked;
                        operationalReview.Storage = cbOperationStorage.Checked;
                        operationalReview.PWHT = cbOperationPWHT.Checked;

                        if (txtOperationStaff.Text != null)
                            operationalReview.TrainedStaffComments = txtOperationStaff.Text;

                        if (txtOperationFacilities.Text != null)
                            operationalReview.FacilitiesComments = txtOperationFacilities.Text;

                        if (txtOperationEquipment.Text != null)
                            operationalReview.EquipmentComments = txtOperationEquipment.Text;

                        if (txtOperationThird.Text != null)
                            operationalReview.ThirdPartyComments = txtOperationThird.Text;

                        //if (txtOperationWPS.Text != null)
                        //    operationalReview.WPSComments = txtOperationWPS.Text;

                        if (cbOperationWPS.Checked)
                        {
                            List<object> relatedWPSs = mscboOperationWPS.Get_OuputDataList();

                            if (relatedWPSs.Count > 0)
                            {
                                foreach (object wps in relatedWPSs)
                                {
                                    ApiClient.ApiCalls.CreateWPSNumberList(operationalReview.OperationalReviewId, new WPSNumberList(operationalReview) { WPSNumber = (string)wps });
                                }
                            }
                        }
                        else if ((!cbOperationWPS.Checked) && nudOperationWPS.Visible)
                        {
                            operationalReview.WPSAmount = (short)nudOperationWPS.Value;
                        }

                        //if (txtOperationWPQR.Text != null)
                        //    operationalReview.WPQRComments = txtOperationWPQR.Text;

                        if (cbOperationWPQR.Checked)
                        {
                            List<object> relatedWPQRs = mscboOperationWPQR.Get_OuputDataList();

                            if (relatedWPQRs.Count > 0)
                            {
                                foreach (object wpqr in relatedWPQRs)
                                {
                                    ApiClient.ApiCalls.CreateWPQRNumberList(operationalReview.OperationalReviewId, new WPQRNumberList(operationalReview) { WPQRNumber = (string)wpqr });
                                }
                            }
                        }
                        else if ((!cbOperationWPQR.Checked) && nudOperationWPQR.Visible)
                        {
                            operationalReview.WPQRAmount = (short)nudOperationWPQR.Value;
                        }

                        if (txtOperationSub.Text != null)
                            operationalReview.SubComments = txtOperationSub.Text;

                        if (txtOperationStorage.Text != null)
                            operationalReview.StorageComments = txtOperationStorage.Text;

                        if (txtOperationPWHT.Text != null)
                            operationalReview.PWHTComments = txtOperationPWHT.Text;

                        if (txtOperationGeneral.Text != null)
                            operationalReview.GeneralComments = txtOperationGeneral.Text;

                        if (txtOperationExtra.Text != null)
                            operationalReview.ExtraCosts = txtOperationExtra.Text;

                        operationalReview = ApiClient.ApiCalls.CreateOperationalReview(nwf.NewWeldingFormId, operationalReview);

                        //if (txtOperationWelders.Text != null)
                        //    operationalReview.WeldersComments = txtOperationWelders.Text;

                        if (cbOperationWelders.Checked)
                        {
                            List<object> relatedWelders = mscboOperationWelders.Get_OuputDataList();

                            if (relatedWelders.Count > 0)
                            {
                                foreach (object eNumber in relatedWelders)
                                {
                                    ApiClient.ApiCalls.CreateENumberList(operationalReview.OperationalReviewId, new ENumberList(operationalReview) { ENumber = (string)eNumber });
                                }
                            }
                        }
                        else if ((!cbOperationWelders.Checked) && nudOperationWelders.Visible)
                        {
                            operationalReview.WeldersAmount = (short)nudOperationWelders.Value;
                        }

                        ApiClient.ApiCalls.UpdateOperationalReview(operationalReview.OperationalReviewId, operationalReview);
                    }
                }
                else
                {
                    nwf.OperationalReview.Date = dtpOperationalDate.Value;

                    nwf.OperationalReview.TrainedStaff = cbOperationStaff.Checked;
                    nwf.OperationalReview.Facilities = cbOperationFacilities.Checked;
                    nwf.OperationalReview.Equipment = cbOperationEquipment.Checked;
                    nwf.OperationalReview.ThirdParty = cbOperationThird.Checked;
                    nwf.OperationalReview.WPS = cbOperationWPS.Checked;
                    nwf.OperationalReview.WPQR = cbOperationWPQR.Checked;
                    nwf.OperationalReview.Welders = cbOperationWelders.Checked;
                    nwf.OperationalReview.SubContractors = cbOperationSub.Checked;
                    nwf.OperationalReview.Storage = cbOperationStorage.Checked;
                    nwf.OperationalReview.PWHT = cbOperationPWHT.Checked;

                    if (txtOperationStaff.Text != null)
                        nwf.OperationalReview.TrainedStaffComments = txtOperationStaff.Text;

                    if (txtOperationFacilities.Text != null)
                        nwf.OperationalReview.FacilitiesComments = txtOperationFacilities.Text;

                    if (txtOperationEquipment.Text != null)
                        nwf.OperationalReview.EquipmentComments = txtOperationEquipment.Text;

                    if (txtOperationThird.Text != null)
                        nwf.OperationalReview.ThirdPartyComments = txtOperationThird.Text;

                    //if (txtOperationWPS.Text != null)
                    //    nwf.OperationalReview.WPSComments = txtOperationWPS.Text;

                    if (cbOperationWPS.Checked)
                    {
                        List<object> relatedWPSs = mscboOperationWPS.Get_OuputDataList();

                        if (relatedWPSs.Count > 0)
                        {
                            ApiClient.ApiCalls.DeleteWPSNumberLists(nwf.OperationalReview.OperationalReviewId);

                            foreach (object wpqr in relatedWPSs)
                            {
                                ApiClient.ApiCalls.CreateWPSNumberList(nwf.OperationalReview.OperationalReviewId, new WPSNumberList(nwf.OperationalReview) { WPSNumber = (string)wpqr });
                            }
                        }
                    }
                    else
                    {
                        nwf.OperationalReview.WPSAmount = (short)nudOperationWPS.Value;
                    }

                    //if (txtOperationWPQR.Text != null)
                    //    nwf.OperationalReview.WPQRComments = txtOperationWPQR.Text;

                    if (cbOperationWPQR.Checked)
                    {
                        List<object> relatedWPQRs = mscboOperationWPQR.Get_OuputDataList();

                        if (relatedWPQRs.Count > 0)
                        {
                            ApiClient.ApiCalls.DeleteWPQRNumberLists(nwf.OperationalReview.OperationalReviewId);

                            foreach (object wpqr in relatedWPQRs)
                            {
                                ApiClient.ApiCalls.CreateWPQRNumberList(nwf.OperationalReview.OperationalReviewId, new WPQRNumberList(nwf.OperationalReview) { WPQRNumber = (string)wpqr });
                            }
                        }
                    }
                    else
                    {
                        nwf.OperationalReview.WPQRAmount = (short)nudOperationWPQR.Value;
                    }

                    //if (txtOperationWelders.Text != null)
                    //    nwf.OperationalReview.WeldersComments = txtOperationWelders.Text;

                    if (cbOperationWelders.Checked)
                    {
                        List<object> relatedWelders = mscboOperationWelders.Get_OuputDataList();

                        if (relatedWelders.Count > 0)
                        {
                            ApiClient.ApiCalls.DeleteENumberLists(nwf.OperationalReview.OperationalReviewId);

                            foreach (object eNumber in relatedWelders)
                            {
                                ApiClient.ApiCalls.CreateENumberList(nwf.OperationalReview.OperationalReviewId, new ENumberList(nwf.OperationalReview) { ENumber = (string)eNumber });
                            }
                        }
                    }
                    else
                    {
                        nwf.OperationalReview.WeldersAmount = (short)nudOperationWelders.Value;
                    }

                    if (txtOperationSub.Text != null)
                        nwf.OperationalReview.SubComments = txtOperationSub.Text;

                    if (txtOperationStorage.Text != null)
                        nwf.OperationalReview.StorageComments = txtOperationStorage.Text;

                    if (txtOperationPWHT.Text != null)
                        nwf.OperationalReview.PWHTComments = txtOperationPWHT.Text;

                    if (txtOperationGeneral.Text != null)
                        nwf.OperationalReview.GeneralComments = txtOperationGeneral.Text;

                    if (txtOperationExtra.Text != null)
                        nwf.OperationalReview.ExtraCosts = txtOperationExtra.Text;

                    ApiClient.ApiCalls.UpdateOperationalReview(nwf.NewWeldingFormId, nwf.OperationalReview);
                }

                this.Tag = new Tag(ApiClient.ApiCalls.ReadNewWeldingForm(nwf.NewWeldingFormId), TagType.New_Welding_Form);
            }
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiClient.ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                txtOperationReviewer.Text = Application.Cookies["EmployeeNumber"];

                object[] eNumbers = QAWebApiClient.ApiCalls.GetPeople().Select(ppl => ppl.EmployeeNumber).ToArray();
                object[] wpqrs = ApiClient.ApiCalls.ReadWPQRs().Select(ppl => ppl.WPQRNumber).ToArray();
                object[] wpss = ApiClient.ApiCalls.ReadWPSs().Select(ppl => ppl.WPSNumber).ToArray();

                mscboOperationWelders.Set_InputDataList(eNumbers);
                mscboOperationWPQR.Set_InputDataList(wpqrs);
                mscboOperationWPS.Set_InputDataList(wpss);

                if (nwf.OperationalReview != null)
                {
                    dtpOperationalDate.Value = nwf.OperationalReview.Date ?? DateTime.Now;

                    cbOperationStaff.Checked = nwf.OperationalReview.TrainedStaff == true;
                    cbOperationFacilities.Checked = nwf.OperationalReview.Facilities == true;
                    cbOperationEquipment.Checked = nwf.OperationalReview.Equipment == true;
                    cbOperationThird.Checked = nwf.OperationalReview.ThirdParty == true;
                    cbOperationWPS.Checked = nwf.OperationalReview.WPS == true;
                    cbOperationWPQR.Checked = nwf.OperationalReview.WPQR == true;
                    cbOperationWelders.Checked = nwf.OperationalReview.Welders == true;
                    cbOperationSub.Checked = nwf.OperationalReview.SubContractors == true;
                    cbOperationStorage.Checked = nwf.OperationalReview.Storage == true;
                    cbOperationPWHT.Checked = nwf.OperationalReview.PWHT == true;

                    txtOperationStaff.Text = nwf.OperationalReview.TrainedStaffComments?.ToString() ?? "";
                    txtOperationFacilities.Text = nwf.OperationalReview.FacilitiesComments?.ToString() ?? "";
                    txtOperationEquipment.Text = nwf.OperationalReview.EquipmentComments?.ToString() ?? "";
                    txtOperationThird.Text = nwf.OperationalReview.ThirdPartyComments?.ToString() ?? "";

                    //REDUNDANT - txtOperationWPS.Text = nwf.OperationalReview.WPSComments?.ToString() ?? "";
                    if (cbOperationWPS.Checked)
                    {
                        List<object> relatedWPSs = nwf.OperationalReview.WPSNumberLists.Select(wps => wps.WPSNumber).ToList<object>();
                        mscboOperationWPS.Set_OuputDataList(relatedWPSs);
                    }
                    else
                    {
                        nudOperationWPS.Value = (decimal)nwf.OperationalReview.WPSAmount;
                    }

                    //REDUNDANT - txtOperationWPQR.Text = nwf.OperationalReview.WPQRComments?.ToString() ?? "";
                    if (cbOperationWPQR.Checked)
                    {
                        List<object> relatedWPQRNumberLists = nwf.OperationalReview.WPQRNumberLists.Select(wpqr => wpqr.WPQRNumber).ToList<object>();
                        mscboOperationWPQR.Set_OuputDataList(relatedWPQRNumberLists);
                    }
                    else
                    {
                        nudOperationWPQR.Value = (decimal)nwf.OperationalReview.WPQRAmount;
                    }

                    //txtOperationWelders.Text = nwf.OperationalReview.WeldersComments?.ToString() ?? "";
                    if (cbOperationWelders.Checked)
                    {
                        List<object> relatedWelders = nwf.OperationalReview.ENumberLists.Select(wpqr => wpqr.ENumber).ToList<object>();
                        mscboOperationWelders.Set_OuputDataList(relatedWelders);
                    }
                    else
                    {
                        nudOperationWelders.Value = (decimal)nwf.OperationalReview.WeldersAmount;
                    }

                    txtOperationSub.Text = nwf.OperationalReview.SubComments?.ToString() ?? "";
                    txtOperationStorage.Text = nwf.OperationalReview.StorageComments?.ToString() ?? "";
                    txtOperationPWHT.Text = nwf.OperationalReview.PWHTComments?.ToString() ?? "";

                    txtOperationGeneral.Text = nwf.OperationalReview.GeneralComments?.ToString() ?? "";
                    txtOperationExtra.Text = nwf.OperationalReview.ExtraCosts?.ToString() ?? "";
                }

                Change_Visible();

                Change_Image();
            }
        }

        private void uc_rqOperational_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible)
            {
                if (this.Tag != null)
                {
                    Load_Action();
                }
            }
        }

        #region Checkbox Logic - Path & Input Selection

        #region Checkbox Events
        private void cbOperationWPS_CheckedChanged(object sender, EventArgs e)
        {
            Change_Visible();

            Change_Image();
        }

        private void cbOperationWPQR_CheckedChanged(object sender, EventArgs e)
        {
            Change_Visible();

            Change_Image();
        }

        private void cbOperationWelders_CheckedChanged(object sender, EventArgs e)
        {
            Change_Visible();

            Change_Image();
        }

        #endregion

        #region Input Selection

        private void Change_Welders_Input()
        {
            int mscboWdth = 0;
            int nudWdth = 0;
            int rowHgt = 20;

            if (cbOperationWelders.Checked)
            {
                mscboWdth = 100;

                lblOperationWelders.Text = "List of Qualified Welders Available";
            }
            else
            {
                nudWdth = 100;
                rowHgt = 10;

                lblOperationWelders.Text = "Number of Welders to be Qualified";
            }

            tlpOperationForm.RowStyles[tlpOperationForm.GetCellPosition(lblOperationWelders).Row].SizeType = SizeType.Percent;
            tlpOperationForm.RowStyles[tlpOperationForm.GetCellPosition(lblOperationWelders).Row].Height = rowHgt;

            tlpOperationWelders.ColumnStyles[tlpOperationWelders.GetCellPosition(mscboOperationWelders).Column].SizeType = SizeType.Percent;
            tlpOperationWelders.ColumnStyles[tlpOperationWelders.GetCellPosition(mscboOperationWelders).Column].Width = mscboWdth;

            tlpOperationWelders.ColumnStyles[tlpOperationWelders.GetCellPosition(nudOperationWelders).Column].SizeType = SizeType.Percent;
            tlpOperationWelders.ColumnStyles[tlpOperationWelders.GetCellPosition(nudOperationWelders).Column].Width = nudWdth;
        }

        private void Change_WPQR_Input()
        {
            int mscboWdth = 0;
            int nudWdth = 0;
            int rowHgt = 20;

            if (cbOperationWPQR.Checked)
            {
                mscboWdth = 100;

                lblOperationWPQR.Text = "List of WPQRs Available";
            }
            else
            {
                nudWdth = 100;
                rowHgt = 10;

                lblOperationWPQR.Text = "Number of WPQRs to be Developed";
            }

            tlpOperationForm.RowStyles[tlpOperationForm.GetCellPosition(lblOperationWPQR).Row].SizeType = SizeType.Percent;
            tlpOperationForm.RowStyles[tlpOperationForm.GetCellPosition(lblOperationWPQR).Row].Height = rowHgt;

            tlpOperationWPQR.ColumnStyles[tlpOperationWPQR.GetCellPosition(mscboOperationWPQR).Column].SizeType = SizeType.Percent;
            tlpOperationWPQR.ColumnStyles[tlpOperationWPQR.GetCellPosition(mscboOperationWPQR).Column].Width = mscboWdth;

            tlpOperationWPQR.ColumnStyles[tlpOperationWPQR.GetCellPosition(nudOperationWPQR).Column].SizeType = SizeType.Percent;
            tlpOperationWPQR.ColumnStyles[tlpOperationWPQR.GetCellPosition(nudOperationWPQR).Column].Width = nudWdth;
        }

        private void Change_WPS_Input()
        {
            int mscboWdth = 0;
            int nudWdth = 0;
            int rowHgt = 20;

            if (cbOperationWPS.Checked)
            {
                mscboWdth = 100;

                lblOperationWPS.Text = "List of WPSs Available";
            }
            else
            {
                nudWdth = 100;
                rowHgt = 10;

                lblOperationWPS.Text = "Number of WPSs to be Developed";
            }

            tlpOperationForm.RowStyles[tlpOperationForm.GetCellPosition(lblOperationWPS).Row].SizeType = SizeType.Percent;
            tlpOperationForm.RowStyles[tlpOperationForm.GetCellPosition(lblOperationWPS).Row].Height = rowHgt;

            tlpOperationWPS.ColumnStyles[tlpOperationWPS.GetCellPosition(mscboOperationWPS).Column].SizeType = SizeType.Percent;
            tlpOperationWPS.ColumnStyles[tlpOperationWPS.GetCellPosition(mscboOperationWPS).Column].Width = mscboWdth;

            tlpOperationWPS.ColumnStyles[tlpOperationWPS.GetCellPosition(nudOperationWPS).Column].SizeType = SizeType.Percent;
            tlpOperationWPS.ColumnStyles[tlpOperationWPS.GetCellPosition(nudOperationWPS).Column].Width = nudWdth;
        }

        private void Change_Visible()
        {
            if (!cbOperationWPS.Checked)
            {
                tlpOperationWPQR.Visible = nudOperationWPQR.Visible = mscboOperationWPQR.Visible = cbOperationWPQR.Visible = lblOperationWPQR.Visible = true;

                Change_WPQR_Input();
            }
            else
            {
                tlpOperationWPQR.Visible = nudOperationWPQR.Visible = mscboOperationWPQR.Visible = cbOperationWPQR.Visible = lblOperationWPQR.Visible = false;

                tlpOperationForm.RowStyles[tlpOperationForm.GetCellPosition(lblOperationWPQR).Row].SizeType = SizeType.Percent;
                tlpOperationForm.RowStyles[tlpOperationForm.GetCellPosition(lblOperationWPQR).Row].Height = 0;
            }

            Change_Welders_Input();

            Change_WPS_Input();
        }

        #endregion

        #region Path Selection
        private void Change_Image()
        {
            if (cbOperationWPS.Checked && cbOperationWelders.Checked)
            {
                pbOperationPath.Image = Properties.Resources.WPSandWELDER;
            }
            else if (cbOperationWPS.Checked && !cbOperationWelders.Checked)
            {
                pbOperationPath.Image = Properties.Resources.WPSandNOWELDER;
            }
            else if (!cbOperationWPS.Checked && cbOperationWPQR.Checked && !cbOperationWelders.Checked)
            {
                pbOperationPath.Image = Properties.Resources.NOWPSandNOWELDER;
            }
            else if (!cbOperationWPS.Checked && cbOperationWPQR.Checked && cbOperationWelders.Checked)
            {
                pbOperationPath.Image = Properties.Resources.NOWPS;
            }
            else if (!cbOperationWPS.Checked && !cbOperationWPQR.Checked)
            {
                pbOperationPath.Image = Properties.Resources.NOWPQR;
            }

            pbOperationPath.Refresh();
        }
        #endregion

        #endregion

        private void btnOperationDocuments_Click(object sender, EventArgs e)
        {
            if (up_rqFilesView1 == null)
            {
                up_rqFilesView1 = new up_rqFilesView();
                this.Controls.Add(up_rqFilesView1);
            }

            overlayPanel.Visible = true;

            up_rqFilesView1.Tag = this.Tag;

            up_rqFilesView1.ShowPopup(new Point(this.Width / 2 - up_rqFilesView1.Width / 2, this.Height / 2 - up_rqFilesView1.Height / 2), up_rqFilesView_Closed);
        }

        private void up_rqFilesView_Closed(UserControl up)
        {
            overlayPanel.Visible = false;
        }
    }
}
