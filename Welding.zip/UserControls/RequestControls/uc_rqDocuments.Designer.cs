﻿namespace WeldingManagement.UserControls.RequestControls
{
    partial class uc_rqDocuments
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel14 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel22 = new Wisej.Web.TableLayoutPanel();
            this.tlpDocuments = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.uplDocumentsProvide = new Wisej.Web.Upload();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.rbDocumentsNDT = new Wisej.Web.RadioButton();
            this.rbDocumentsPWHT = new Wisej.Web.RadioButton();
            this.rbDocumentsParent = new Wisej.Web.RadioButton();
            this.rbDocumentsRecord = new Wisej.Web.RadioButton();
            this.rbDocumentsPhotos = new Wisej.Web.RadioButton();
            this.rbDocumentsHistory = new Wisej.Web.RadioButton();
            this.rbDocumentsIssued = new Wisej.Web.RadioButton();
            this.rbDocumentsSymbols = new Wisej.Web.RadioButton();
            this.rbDocumentsFabrication = new Wisej.Web.RadioButton();
            this.rbDocumentsDrawing = new Wisej.Web.RadioButton();
            this.pbDocuments = new Wisej.Web.PictureBox();
            this.lvDocuments = new Wisej.Web.ListView();
            this.chName = new Wisej.Web.ColumnHeader();
            this.chType = new Wisej.Web.ColumnHeader();
            this.pvDocuments = new Wisej.Web.PdfViewer();
            this.tableLayoutPanel26 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel27 = new Wisej.Web.TableLayoutPanel();
            this.btnDocumentsDelete = new Wisej.Web.Button();
            this.btnDocumentsBack = new Wisej.Web.Button();
            this.btnDocumentsHome = new Wisej.Web.Button();
            this.btnDocumentsComplete = new Wisej.Web.Button();
            this.tableLayoutPanel28 = new Wisej.Web.TableLayoutPanel();
            this.label76 = new Wisej.Web.Label();
            this.label79 = new Wisej.Web.Label();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tlpDocuments.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDocuments)).BeginInit();
            this.tableLayoutPanel26.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel14.ColumnCount = 3;
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel22, 1, 3);
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel28, 1, 1);
            this.tableLayoutPanel14.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 5;
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel14.TabIndex = 6;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.Controls.Add(this.tlpDocuments, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel26, 1, 0);
            this.tableLayoutPanel22.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel22.TabIndex = 1;
            // 
            // tlpDocuments
            // 
            this.tlpDocuments.ColumnCount = 3;
            this.tlpDocuments.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tlpDocuments.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tlpDocuments.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tlpDocuments.Controls.Add(this.tableLayoutPanel2, 0, 2);
            this.tlpDocuments.Controls.Add(this.tableLayoutPanel1, 2, 0);
            this.tlpDocuments.Controls.Add(this.pbDocuments, 1, 1);
            this.tlpDocuments.Controls.Add(this.lvDocuments, 0, 0);
            this.tlpDocuments.Controls.Add(this.pvDocuments, 1, 0);
            this.tlpDocuments.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpDocuments.Location = new System.Drawing.Point(3, 3);
            this.tlpDocuments.Name = "tlpDocuments";
            this.tlpDocuments.RowCount = 3;
            this.tlpDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 40F));
            this.tlpDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 40F));
            this.tlpDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tlpDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tlpDocuments.Size = new System.Drawing.Size(1024, 433);
            this.tlpDocuments.TabIndex = 6;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tlpDocuments.SetColumnSpan(this.tableLayoutPanel2, 3);
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel2.Controls.Add(this.uplDocumentsProvide, 1, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 349);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1018, 81);
            this.tableLayoutPanel2.TabIndex = 7;
            // 
            // uplDocumentsProvide
            // 
            this.uplDocumentsProvide.AllowedFileTypes = ".pdf, .jpg, .jpeg, .png, .bmp";
            this.uplDocumentsProvide.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.uplDocumentsProvide.Dock = Wisej.Web.DockStyle.Fill;
            this.uplDocumentsProvide.HideValue = true;
            this.uplDocumentsProvide.Location = new System.Drawing.Point(87, 3);
            this.uplDocumentsProvide.Name = "uplDocumentsProvide";
            this.uplDocumentsProvide.Size = new System.Drawing.Size(840, 73);
            this.uplDocumentsProvide.TabIndex = 2;
            this.uplDocumentsProvide.Text = "Provide Documentation";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.rbDocumentsNDT, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.rbDocumentsPWHT, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.rbDocumentsParent, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.rbDocumentsRecord, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.rbDocumentsPhotos, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.rbDocumentsHistory, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.rbDocumentsIssued, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.rbDocumentsSymbols, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.rbDocumentsFabrication, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.rbDocumentsDrawing, 0, 0);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(685, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tlpDocuments.SetRowSpan(this.tableLayoutPanel1, 2);
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(336, 340);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // rbDocumentsNDT
            // 
            this.rbDocumentsNDT.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDocumentsNDT.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDocumentsNDT.Font = new System.Drawing.Font("default", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.rbDocumentsNDT.Location = new System.Drawing.Point(3, 300);
            this.rbDocumentsNDT.Name = "rbDocumentsNDT";
            this.rbDocumentsNDT.Size = new System.Drawing.Size(328, 35);
            this.rbDocumentsNDT.TabIndex = 9;
            this.rbDocumentsNDT.TabStop = true;
            this.rbDocumentsNDT.Text = "Client NDT and heat treatment procedures/standards";
            this.rbDocumentsNDT.CheckedChanged += new System.EventHandler(this.rbDocumentsDrawing_CheckedChanged);
            // 
            // rbDocumentsPWHT
            // 
            this.rbDocumentsPWHT.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDocumentsPWHT.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDocumentsPWHT.Font = new System.Drawing.Font("default", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.rbDocumentsPWHT.Location = new System.Drawing.Point(3, 267);
            this.rbDocumentsPWHT.Name = "rbDocumentsPWHT";
            this.rbDocumentsPWHT.Size = new System.Drawing.Size(328, 27);
            this.rbDocumentsPWHT.TabIndex = 8;
            this.rbDocumentsPWHT.TabStop = true;
            this.rbDocumentsPWHT.Text = "PWHT requirements (steel tempering temperature must be known if applicable)";
            this.rbDocumentsPWHT.CheckedChanged += new System.EventHandler(this.rbDocumentsDrawing_CheckedChanged);
            // 
            // rbDocumentsParent
            // 
            this.rbDocumentsParent.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDocumentsParent.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDocumentsParent.Font = new System.Drawing.Font("default", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.rbDocumentsParent.Location = new System.Drawing.Point(3, 234);
            this.rbDocumentsParent.Name = "rbDocumentsParent";
            this.rbDocumentsParent.Size = new System.Drawing.Size(328, 27);
            this.rbDocumentsParent.TabIndex = 7;
            this.rbDocumentsParent.TabStop = true;
            this.rbDocumentsParent.Text = "Parent material specifications";
            this.rbDocumentsParent.CheckedChanged += new System.EventHandler(this.rbDocumentsDrawing_CheckedChanged);
            // 
            // rbDocumentsRecord
            // 
            this.rbDocumentsRecord.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDocumentsRecord.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDocumentsRecord.Font = new System.Drawing.Font("default", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.rbDocumentsRecord.Location = new System.Drawing.Point(3, 201);
            this.rbDocumentsRecord.Name = "rbDocumentsRecord";
            this.rbDocumentsRecord.Size = new System.Drawing.Size(328, 27);
            this.rbDocumentsRecord.TabIndex = 6;
            this.rbDocumentsRecord.TabStop = true;
            this.rbDocumentsRecord.Text = "Welding repair record if applicable";
            this.rbDocumentsRecord.CheckedChanged += new System.EventHandler(this.rbDocumentsDrawing_CheckedChanged);
            // 
            // rbDocumentsPhotos
            // 
            this.rbDocumentsPhotos.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDocumentsPhotos.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDocumentsPhotos.Font = new System.Drawing.Font("default", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.rbDocumentsPhotos.Location = new System.Drawing.Point(3, 168);
            this.rbDocumentsPhotos.Name = "rbDocumentsPhotos";
            this.rbDocumentsPhotos.Size = new System.Drawing.Size(328, 27);
            this.rbDocumentsPhotos.TabIndex = 5;
            this.rbDocumentsPhotos.TabStop = true;
            this.rbDocumentsPhotos.Text = "Photos of components for welding";
            this.rbDocumentsPhotos.CheckedChanged += new System.EventHandler(this.rbDocumentsDrawing_CheckedChanged);
            // 
            // rbDocumentsHistory
            // 
            this.rbDocumentsHistory.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDocumentsHistory.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDocumentsHistory.Font = new System.Drawing.Font("default", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.rbDocumentsHistory.Location = new System.Drawing.Point(3, 135);
            this.rbDocumentsHistory.Name = "rbDocumentsHistory";
            this.rbDocumentsHistory.Size = new System.Drawing.Size(328, 27);
            this.rbDocumentsHistory.TabIndex = 4;
            this.rbDocumentsHistory.TabStop = true;
            this.rbDocumentsHistory.Text = "History of thermal treatment of material";
            this.rbDocumentsHistory.CheckedChanged += new System.EventHandler(this.rbDocumentsDrawing_CheckedChanged);
            // 
            // rbDocumentsIssued
            // 
            this.rbDocumentsIssued.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDocumentsIssued.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDocumentsIssued.Font = new System.Drawing.Font("default", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.rbDocumentsIssued.Location = new System.Drawing.Point(3, 102);
            this.rbDocumentsIssued.Name = "rbDocumentsIssued";
            this.rbDocumentsIssued.Size = new System.Drawing.Size(328, 27);
            this.rbDocumentsIssued.TabIndex = 3;
            this.rbDocumentsIssued.TabStop = true;
            this.rbDocumentsIssued.Text = "Client issued welding procedures";
            this.rbDocumentsIssued.CheckedChanged += new System.EventHandler(this.rbDocumentsDrawing_CheckedChanged);
            // 
            // rbDocumentsSymbols
            // 
            this.rbDocumentsSymbols.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDocumentsSymbols.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDocumentsSymbols.Font = new System.Drawing.Font("default", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.rbDocumentsSymbols.Location = new System.Drawing.Point(3, 69);
            this.rbDocumentsSymbols.Name = "rbDocumentsSymbols";
            this.rbDocumentsSymbols.Size = new System.Drawing.Size(328, 27);
            this.rbDocumentsSymbols.TabIndex = 2;
            this.rbDocumentsSymbols.TabStop = true;
            this.rbDocumentsSymbols.Text = "Welding symbols & welding sizes/location & description of previous & new repair";
            this.rbDocumentsSymbols.CheckedChanged += new System.EventHandler(this.rbDocumentsDrawing_CheckedChanged);
            // 
            // rbDocumentsFabrication
            // 
            this.rbDocumentsFabrication.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDocumentsFabrication.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDocumentsFabrication.Font = new System.Drawing.Font("default", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.rbDocumentsFabrication.Location = new System.Drawing.Point(3, 36);
            this.rbDocumentsFabrication.Name = "rbDocumentsFabrication";
            this.rbDocumentsFabrication.Size = new System.Drawing.Size(328, 27);
            this.rbDocumentsFabrication.TabIndex = 1;
            this.rbDocumentsFabrication.TabStop = true;
            this.rbDocumentsFabrication.Text = "Welding/Fabrication specifications";
            this.rbDocumentsFabrication.CheckedChanged += new System.EventHandler(this.rbDocumentsDrawing_CheckedChanged);
            // 
            // rbDocumentsDrawing
            // 
            this.rbDocumentsDrawing.BackColor = System.Drawing.Color.FromName("@window");
            this.rbDocumentsDrawing.Dock = Wisej.Web.DockStyle.Fill;
            this.rbDocumentsDrawing.Font = new System.Drawing.Font("default", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.rbDocumentsDrawing.Location = new System.Drawing.Point(3, 3);
            this.rbDocumentsDrawing.Name = "rbDocumentsDrawing";
            this.rbDocumentsDrawing.Size = new System.Drawing.Size(328, 27);
            this.rbDocumentsDrawing.TabIndex = 0;
            this.rbDocumentsDrawing.TabStop = true;
            this.rbDocumentsDrawing.Text = "Drawing or sketch of items for welding showing size & weight of welding component" +
    "s";
            this.rbDocumentsDrawing.CheckedChanged += new System.EventHandler(this.rbDocumentsDrawing_CheckedChanged);
            // 
            // pbDocuments
            // 
            this.pbDocuments.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pbDocuments.CssStyle = "background-color: rgba(255, 255, 255, 1);";
            this.pbDocuments.Dock = Wisej.Web.DockStyle.Fill;
            this.pbDocuments.Location = new System.Drawing.Point(344, 176);
            this.pbDocuments.Name = "pbDocuments";
            this.pbDocuments.Size = new System.Drawing.Size(335, 167);
            this.pbDocuments.SizeMode = Wisej.Web.PictureBoxSizeMode.Zoom;
            // 
            // lvDocuments
            // 
            this.lvDocuments.Columns.AddRange(new Wisej.Web.ColumnHeader[] {
            this.chName,
            this.chType});
            this.lvDocuments.Dock = Wisej.Web.DockStyle.Fill;
            this.lvDocuments.Location = new System.Drawing.Point(3, 3);
            this.lvDocuments.Name = "lvDocuments";
            this.tlpDocuments.SetRowSpan(this.lvDocuments, 2);
            this.lvDocuments.Size = new System.Drawing.Size(335, 340);
            this.lvDocuments.TabIndex = 4;
            this.lvDocuments.View = Wisej.Web.View.Details;
            this.lvDocuments.SelectedIndexChanged += new System.EventHandler(this.lvDocuments_SelectedIndexChanged);
            this.lvDocuments.Resize += new System.EventHandler(this.lvDocuments_Resize);
            // 
            // chName
            // 
            this.chName.Name = "chName";
            this.chName.Text = "File Name";
            // 
            // chType
            // 
            this.chType.Name = "chType";
            this.chType.Text = "Category";
            // 
            // pvDocuments
            // 
            this.pvDocuments.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pvDocuments.CssStyle = "background-color: rgba(255, 255, 255, 1);";
            this.pvDocuments.Dock = Wisej.Web.DockStyle.Fill;
            this.pvDocuments.Location = new System.Drawing.Point(344, 3);
            this.pvDocuments.Name = "pvDocuments";
            this.pvDocuments.Size = new System.Drawing.Size(335, 167);
            this.pvDocuments.TabIndex = 3;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 1;
            this.tableLayoutPanel26.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Controls.Add(this.tableLayoutPanel27, 0, 0);
            this.tableLayoutPanel26.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel26.TabIndex = 5;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel27.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel27.ColumnCount = 1;
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel27.Controls.Add(this.btnDocumentsDelete, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.btnDocumentsBack, 0, 2);
            this.tableLayoutPanel27.Controls.Add(this.btnDocumentsHome, 0, 3);
            this.tableLayoutPanel27.Controls.Add(this.btnDocumentsComplete, 0, 4);
            this.tableLayoutPanel27.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel27.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 5;
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel27.TabIndex = 4;
            // 
            // btnDocumentsDelete
            // 
            this.btnDocumentsDelete.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDocumentsDelete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDocumentsDelete.Location = new System.Drawing.Point(3, 3);
            this.btnDocumentsDelete.Name = "btnDocumentsDelete";
            this.btnDocumentsDelete.Size = new System.Drawing.Size(95, 79);
            this.btnDocumentsDelete.TabIndex = 3;
            this.btnDocumentsDelete.Text = "Delete Attachment";
            this.btnDocumentsDelete.Click += new System.EventHandler(this.btnDocumentsDelete_Click);
            // 
            // btnDocumentsBack
            // 
            this.btnDocumentsBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDocumentsBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDocumentsBack.Location = new System.Drawing.Point(3, 173);
            this.btnDocumentsBack.Name = "btnDocumentsBack";
            this.btnDocumentsBack.Size = new System.Drawing.Size(95, 79);
            this.btnDocumentsBack.TabIndex = 2;
            this.btnDocumentsBack.Text = "Back";
            this.btnDocumentsBack.Click += new System.EventHandler(this.btnDocumentsBack_Click);
            // 
            // btnDocumentsHome
            // 
            this.btnDocumentsHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDocumentsHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDocumentsHome.Location = new System.Drawing.Point(3, 258);
            this.btnDocumentsHome.Name = "btnDocumentsHome";
            this.btnDocumentsHome.Size = new System.Drawing.Size(95, 79);
            this.btnDocumentsHome.TabIndex = 1;
            this.btnDocumentsHome.Text = "Home";
            this.btnDocumentsHome.Click += new System.EventHandler(this.btnDocumentsHome_Click);
            // 
            // btnDocumentsComplete
            // 
            this.btnDocumentsComplete.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDocumentsComplete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDocumentsComplete.Location = new System.Drawing.Point(3, 343);
            this.btnDocumentsComplete.Name = "btnDocumentsComplete";
            this.btnDocumentsComplete.Size = new System.Drawing.Size(95, 79);
            this.btnDocumentsComplete.TabIndex = 0;
            this.btnDocumentsComplete.Text = "Complete";
            this.btnDocumentsComplete.Click += new System.EventHandler(this.btnDocumentsComplete_Click);
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.ColumnCount = 1;
            this.tableLayoutPanel28.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel28.Controls.Add(this.label76, 0, 1);
            this.tableLayoutPanel28.Controls.Add(this.label79, 0, 0);
            this.tableLayoutPanel28.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 2;
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel28.TabIndex = 0;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label76.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label76.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.label76.Dock = Wisej.Web.DockStyle.Fill;
            this.label76.Location = new System.Drawing.Point(6, 79);
            this.label76.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(1133, 35);
            this.label76.TabIndex = 1;
            this.label76.Text = "Notes";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label79.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label79.CssStyle = "border-radius: 4px;";
            this.label79.Dock = Wisej.Web.DockStyle.Fill;
            this.label79.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label79.Location = new System.Drawing.Point(6, 3);
            this.label79.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(1133, 70);
            this.label79.TabIndex = 0;
            this.label79.Text = "Welding Scope of Work Provided Documentation";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uc_rqDocuments
            // 
            this.Controls.Add(this.tableLayoutPanel14);
            this.Name = "uc_rqDocuments";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_rqDocuments_VisibleChanged);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tlpDocuments.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDocuments)).EndInit();
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel28.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel14;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel22;
        private Wisej.Web.TableLayoutPanel tlpDocuments;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel26;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel27;
        private Wisej.Web.Button btnDocumentsBack;
        private Wisej.Web.Button btnDocumentsHome;
        private Wisej.Web.Button btnDocumentsComplete;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel28;
        private Wisej.Web.Label label76;
        private Wisej.Web.Label label79;
        private Wisej.Web.PdfViewer pvDocuments;
        private Wisej.Web.ListView lvDocuments;
        private Wisej.Web.ColumnHeader chName;
        private Wisej.Web.Button btnDocumentsDelete;
        private Wisej.Web.PictureBox pbDocuments;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.RadioButton rbDocumentsNDT;
        private Wisej.Web.RadioButton rbDocumentsPWHT;
        private Wisej.Web.RadioButton rbDocumentsParent;
        private Wisej.Web.RadioButton rbDocumentsRecord;
        private Wisej.Web.RadioButton rbDocumentsPhotos;
        private Wisej.Web.RadioButton rbDocumentsHistory;
        private Wisej.Web.RadioButton rbDocumentsIssued;
        private Wisej.Web.RadioButton rbDocumentsSymbols;
        private Wisej.Web.RadioButton rbDocumentsFabrication;
        private Wisej.Web.RadioButton rbDocumentsDrawing;
        private Wisej.Web.ColumnHeader chType;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.Upload uplDocumentsProvide;
    }
}
