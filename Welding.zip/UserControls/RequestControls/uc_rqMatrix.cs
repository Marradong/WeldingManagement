﻿using ApiClient;
using PeopleEF;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.RequestControls
{
    public partial class uc_rqMatrix : Wisej.Web.UserControl
    {
        private up_hmSave up_hmSave1;
        private Panel overlayPanel;

        public uc_rqMatrix()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks next button on matrix screen")]
        public event EventHandler btnMatrixNextClick;
        private void btnMatrixNext_Click(object sender, EventArgs e)
        {
            Save_Action();
            Update_Status();

            btnMatrixNextClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on matrix screen")]
        public event EventHandler btnMatrixHomeClick;
        private void btnMatrixHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnMatrixHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on matrix screen")]
        public event EventHandler btnMatrixBackClick;
        private void btnMatrixBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnMatrixBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnMatrixBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                txtMatrixManager.Text = Application.Cookies["EmployeeNumber"];

                if (nwf != null)
                {
                    txtMatrixJob.Text = nwf.WeldingAction.Job.JobNo != null ? nwf.WeldingAction.Job.JobNo?.ToString() ?? "" : nwf.WeldingAction.Job.QuoteNumber?.ToString() ?? "";

                    rbMatrixComplex.Checked = (nwf.MatrixOutput == WeldingComplexityMatrix.Complex);
                    rbMatrixStandard.Checked = (nwf.MatrixOutput == WeldingComplexityMatrix.Standard);
                    rbMatrixLow.Checked = (nwf.MatrixOutput == WeldingComplexityMatrix.Low);
                }
                else
                {
                    Clear_Controls();
                }
            }
        }

        private void Clear_Controls()
        {
            txtMatrixJob.Text = "";
            rbMatrixComplex.Checked = false;
            rbMatrixStandard.Checked = false;
            rbMatrixLow.Checked = false;
        }

        private void uc_rqMatrix_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible)
            {
                if (this.Tag != null)
                {
                    Load_Action();
                }
            }
        }

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                nwf.Status = Actions.WeldingScope;

                ApiCalls.UpdateNewWeldingForm(nwf.NewWeldingFormId, nwf);

                this.Tag = new Tag(ApiCalls.ReadNewWeldingForm(nwf.NewWeldingFormId), TagType.New_Welding_Form);
            }
        }

        private void Save_Action() 
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                if (rbMatrixLow.Checked == true)
                {
                    nwf.MatrixOutput = WeldingComplexityMatrix.Low;
                }

                if (rbMatrixStandard.Checked == true)
                {
                    nwf.MatrixOutput = WeldingComplexityMatrix.Standard;
                }

                if (rbMatrixComplex.Checked == true)
                {
                    nwf.MatrixOutput = WeldingComplexityMatrix.Complex;
                }

                // Update NewWeldingForm using api
                ApiCalls.UpdateNewWeldingForm(nwf.NewWeldingFormId, nwf);

                this.Tag = new Tag(ApiCalls.ReadNewWeldingForm(nwf.NewWeldingFormId), TagType.New_Welding_Form);
            }
        }
    }
}
