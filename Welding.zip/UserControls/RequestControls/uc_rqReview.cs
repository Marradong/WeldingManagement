﻿using ApiClient;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.RequestControls
{
    public partial class uc_rqReview : Wisej.Web.UserControl
    {
        private up_hmSave up_hmSave1;
        private Panel overlayPanel;

        public uc_rqReview()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on manager screen")]
        public event EventHandler btnManagerCompleteClick;
        private void btnManagerComplete_Click(object sender, EventArgs e)
        {
            if (cbManagerAdditional.CheckState != CheckState.Indeterminate)
            {
                Save_Action();
                Update_Status();

                btnManagerCompleteClick?.Invoke(this, e);
            }

        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on manager screen")]
        public event EventHandler btnManagerHomeClick;
        private void btnManagerHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnManagerHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on manager screen")]
        public event EventHandler btnManagerBackClick;
        private void btnManagerBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnManagerBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnManagerBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                nwf.Status = Actions.Complete;

                ApiCalls.UpdateNewWeldingForm(nwf.NewWeldingFormId, nwf);

                this.Tag = new Tag(ApiCalls.ReadNewWeldingForm(nwf.NewWeldingFormId), TagType.New_Welding_Form);
            }
        }

        private void Save_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                if (cbManagerAdditional.CheckState == CheckState.Checked)
                {
                    nwf.CoverCosts = true;
                }
                else if (cbManagerAdditional.CheckState == CheckState.Unchecked)
                {
                    nwf.CoverCosts = false;
                }

                nwf.CoverCosts = cbManagerAdditional.Checked;
                nwf.ManagerReviewDate = DateTime.Now;

                ApiCalls.UpdateNewWeldingForm(nwf.NewWeldingFormId, nwf);

                this.Tag = new Tag(ApiCalls.ReadNewWeldingForm(nwf.NewWeldingFormId), TagType.New_Welding_Form);
            }
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                cbManagerStaff.Checked = nwf.OperationalReview.TrainedStaff == true;
                cbManagerFacilities.Checked = nwf.OperationalReview.Facilities == true;
                cbManagerEquipment.Checked = nwf.OperationalReview.Equipment == true;
                cbManagerThird.Checked = nwf.OperationalReview.ThirdParty == true;
                cbManagerWPS.Checked = nwf.OperationalReview.WPS == true;
                cbManagerWPQR.Checked = nwf.OperationalReview.WPQR == true;
                cbManagerWelders.Checked = nwf.OperationalReview.Welders == true;
                cbManagerSub.Checked = nwf.OperationalReview.SubContractors == true;
                cbManagerStorage.Checked = nwf.OperationalReview.Storage == true;
                cbManagerPWHT.Checked = nwf.OperationalReview.PWHT == true;

                txtManagerStaff.Text = nwf.OperationalReview.TrainedStaffComments?.ToString() ?? "";
                txtManagerFacilities.Text = nwf.OperationalReview.FacilitiesComments?.ToString() ?? "";
                txtManagerEquipment.Text = nwf.OperationalReview.EquipmentComments?.ToString() ?? "";
                txtManagerThird.Text = nwf.OperationalReview.ThirdPartyComments?.ToString() ?? "";

                // REDUNDANT - txtManagerWPS.Text = wa.NewWeldingForm.OperationalReview.WPSComments?.ToString() ?? "";
                if (cbManagerWPS.Checked)
                {
                    string wpss = "";

                    foreach (string obj in nwf.OperationalReview.WPSNumberLists.Select(wps => wps.WPSNumber))
                    {
                        wpss += $"{obj}, ";
                    }

                    if (!wpss.Equals(""))
                    {
                        wpss = wpss.Remove(wpss.Length - 2);
                    }

                    txtManagerWPS.Text = wpss;
                }
                else
                {
                    txtManagerWPS.Text = nwf.OperationalReview.WPSAmount.ToString();
                }

                // REDUNDANT - txtManagerWPQR.Text = wa.NewWeldingForm.OperationalReview.WPQRComments?.ToString() ?? "";
                if (cbManagerWPQR.Checked)
                {
                    string wpqrs = "";

                    foreach (string obj in nwf.OperationalReview.WPQRNumberLists.Select(wps => wps.WPQRNumber))
                    {
                        wpqrs += $"{obj}, ";
                    }

                    if (!wpqrs.Equals(""))
                    {
                        wpqrs = wpqrs.Remove(wpqrs.Length - 2);
                    }

                    txtManagerWPQR.Text = wpqrs;
                }
                else
                {
                    txtManagerWPQR.Text = nwf.OperationalReview.WPQRAmount.ToString();
                }

                // REDUNDANT - txtManagerWelders.Text = wa.NewWeldingForm.OperationalReview.WeldersComments?.ToString() ?? "";
                if (cbManagerWelders.Checked)
                {
                    string welders = "";

                    foreach (string obj in nwf.OperationalReview.ENumberLists.Select(ppl => ppl.ENumber))
                    {
                        welders += $"{obj}, ";
                    }

                    if (!welders.Equals(""))
                    {
                        welders = welders.Remove(welders.Length - 2);
                    }

                    txtManagerWelders.Text = welders;
                }
                else
                {
                    txtManagerWelders.Text = nwf.OperationalReview.WeldersAmount.ToString();
                }

                Change_Visible();

                txtManagerSub.Text = nwf.OperationalReview.SubComments?.ToString() ?? "";
                txtManagerStorage.Text = nwf.OperationalReview.StorageComments?.ToString() ?? "";
                txtManagerPWHT.Text = nwf.OperationalReview.PWHTComments?.ToString() ?? "";

                txtManagerConsiderations.Text = nwf.TechnicalReview.Considerations?.ToString() ?? "";
                txtManagerGeneral.Text = nwf.OperationalReview.GeneralComments?.ToString() ?? "";
                txtManagerExtra.Text = "Technical Review Costs: " + (nwf.TechnicalReview.ExtraCosts?.ToString() ?? "N/A") + "\nOperational Review Costs: " + (nwf.OperationalReview.ExtraCosts?.ToString() ?? "N/A");

                if (nwf.CoverCosts == null)
                {
                    cbManagerAdditional.CheckState = CheckState.Indeterminate;
                }
                else
                {
                    cbManagerAdditional.CheckState = nwf.CoverCosts == true ? CheckState.Checked : CheckState.Unchecked;
                }

                if (cbManagerWPS.Checked && cbManagerWelders.Checked)
                {
                    pbManagerPath.Image = Properties.Resources.WPSandWELDER;
                }
                else if (cbManagerWPS.Checked && !cbManagerWelders.Checked)
                {
                    pbManagerPath.Image = Properties.Resources.WPSandNOWELDER;
                }
                else if (!cbManagerWPS.Checked && cbManagerWPQR.Checked && !cbManagerWelders.Checked)
                {
                    pbManagerPath.Image = Properties.Resources.NOWPSandNOWELDER;
                }
                else if (!cbManagerWPS.Checked && cbManagerWPQR.Checked && cbManagerWelders.Checked)
                {
                    pbManagerPath.Image = Properties.Resources.NOWPS;
                }
                else if (!cbManagerWPS.Checked && !cbManagerWPQR.Checked)
                {
                    pbManagerPath.Image = Properties.Resources.NOWPQR;
                }

                pbManagerPath.Refresh();
            }
        }

        private void uc_rqReview_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible)
            {
                if (this.Tag != null)
                {
                    Load_Action();
                }
            }
        }

        private void Change_Visible()
        {
            float height;

            if (!cbManagerWPS.Checked)
            {
                txtManagerWPQR.Visible = cbManagerWPQR.Visible = lblManagerWPQR.Visible = true;
                height = (float)6.6;
            }
            else
            {
                txtManagerWPQR.Visible = cbManagerWPQR.Visible = lblManagerWPQR.Visible = false;
                height = 0;
            }

            tlpManagerForm.RowStyles[tlpManagerForm.GetCellPosition(lblManagerWPQR).Row].SizeType = SizeType.Percent;
            tlpManagerForm.RowStyles[tlpManagerForm.GetCellPosition(lblManagerWPQR).Row].Height = height;
        }
    }
}
