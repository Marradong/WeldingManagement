﻿namespace WeldingManagement.UserControls.RequestControls
{
    partial class uc_rqReview
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel8 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel9 = new Wisej.Web.TableLayoutPanel();
            this.tlpManagerForm = new Wisej.Web.TableLayoutPanel();
            this.label1 = new Wisej.Web.Label();
            this.pbManagerPath = new Wisej.Web.PictureBox();
            this.label4 = new Wisej.Web.Label();
            this.cbManagerAdditional = new Wisej.Web.CheckBox();
            this.label3 = new Wisej.Web.Label();
            this.txtManagerConsiderations = new Wisej.Web.TextBox();
            this.label2 = new Wisej.Web.Label();
            this.txtManagerWPQR = new Wisej.Web.TextBox();
            this.cbManagerWPQR = new Wisej.Web.CheckBox();
            this.lblManagerWelders = new Wisej.Web.Label();
            this.label71 = new Wisej.Web.Label();
            this.label36 = new Wisej.Web.Label();
            this.label35 = new Wisej.Web.Label();
            this.label34 = new Wisej.Web.Label();
            this.label33 = new Wisej.Web.Label();
            this.label32 = new Wisej.Web.Label();
            this.txtManagerThird = new Wisej.Web.TextBox();
            this.txtManagerEquipment = new Wisej.Web.TextBox();
            this.txtManagerFacilities = new Wisej.Web.TextBox();
            this.txtManagerStaff = new Wisej.Web.TextBox();
            this.cbManagerStaff = new Wisej.Web.CheckBox();
            this.cbManagerFacilities = new Wisej.Web.CheckBox();
            this.cbManagerEquipment = new Wisej.Web.CheckBox();
            this.cbManagerWPS = new Wisej.Web.CheckBox();
            this.cbManagerThird = new Wisej.Web.CheckBox();
            this.cbManagerWelders = new Wisej.Web.CheckBox();
            this.cbManagerSub = new Wisej.Web.CheckBox();
            this.cbManagerStorage = new Wisej.Web.CheckBox();
            this.cbManagerPWHT = new Wisej.Web.CheckBox();
            this.txtManagerWPS = new Wisej.Web.TextBox();
            this.txtManagerWelders = new Wisej.Web.TextBox();
            this.txtManagerSub = new Wisej.Web.TextBox();
            this.txtManagerStorage = new Wisej.Web.TextBox();
            this.txtManagerPWHT = new Wisej.Web.TextBox();
            this.txtManagerGeneral = new Wisej.Web.TextBox();
            this.txtManagerExtra = new Wisej.Web.TextBox();
            this.label39 = new Wisej.Web.Label();
            this.label40 = new Wisej.Web.Label();
            this.label41 = new Wisej.Web.Label();
            this.lblManagerWPS = new Wisej.Web.Label();
            this.lblManagerWPQR = new Wisej.Web.Label();
            this.label65 = new Wisej.Web.Label();
            this.label66 = new Wisej.Web.Label();
            this.label70 = new Wisej.Web.Label();
            this.tableLayoutPanel11 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel12 = new Wisej.Web.TableLayoutPanel();
            this.btnManagerBack = new Wisej.Web.Button();
            this.btnManagerHome = new Wisej.Web.Button();
            this.btnManagerComplete = new Wisej.Web.Button();
            this.tableLayoutPanel13 = new Wisej.Web.TableLayoutPanel();
            this.label68 = new Wisej.Web.Label();
            this.label69 = new Wisej.Web.Label();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tlpManagerForm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbManagerPath)).BeginInit();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel8.ColumnCount = 3;
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel9, 1, 3);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel13, 1, 1);
            this.tableLayoutPanel8.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 5;
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel8.TabIndex = 6;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel9.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel9.Controls.Add(this.tlpManagerForm, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.tableLayoutPanel11, 1, 0);
            this.tableLayoutPanel9.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel9.TabIndex = 1;
            // 
            // tlpManagerForm
            // 
            this.tlpManagerForm.ColumnCount = 4;
            this.tlpManagerForm.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 30F));
            this.tlpManagerForm.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 30F));
            this.tlpManagerForm.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpManagerForm.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 30F));
            this.tlpManagerForm.Controls.Add(this.label1, 3, 14);
            this.tlpManagerForm.Controls.Add(this.pbManagerPath, 3, 1);
            this.tlpManagerForm.Controls.Add(this.label4, 3, 0);
            this.tlpManagerForm.Controls.Add(this.cbManagerAdditional, 2, 14);
            this.tlpManagerForm.Controls.Add(this.label3, 0, 14);
            this.tlpManagerForm.Controls.Add(this.txtManagerConsiderations, 1, 11);
            this.tlpManagerForm.Controls.Add(this.label2, 0, 11);
            this.tlpManagerForm.Controls.Add(this.txtManagerWPQR, 1, 6);
            this.tlpManagerForm.Controls.Add(this.cbManagerWPQR, 2, 6);
            this.tlpManagerForm.Controls.Add(this.lblManagerWelders, 0, 7);
            this.tlpManagerForm.Controls.Add(this.label71, 2, 0);
            this.tlpManagerForm.Controls.Add(this.label36, 0, 1);
            this.tlpManagerForm.Controls.Add(this.label35, 0, 13);
            this.tlpManagerForm.Controls.Add(this.label34, 0, 12);
            this.tlpManagerForm.Controls.Add(this.label33, 1, 0);
            this.tlpManagerForm.Controls.Add(this.label32, 0, 0);
            this.tlpManagerForm.Controls.Add(this.txtManagerThird, 1, 4);
            this.tlpManagerForm.Controls.Add(this.txtManagerEquipment, 1, 3);
            this.tlpManagerForm.Controls.Add(this.txtManagerFacilities, 1, 2);
            this.tlpManagerForm.Controls.Add(this.txtManagerStaff, 1, 1);
            this.tlpManagerForm.Controls.Add(this.cbManagerStaff, 2, 1);
            this.tlpManagerForm.Controls.Add(this.cbManagerFacilities, 2, 2);
            this.tlpManagerForm.Controls.Add(this.cbManagerEquipment, 2, 3);
            this.tlpManagerForm.Controls.Add(this.cbManagerWPS, 2, 5);
            this.tlpManagerForm.Controls.Add(this.cbManagerThird, 2, 4);
            this.tlpManagerForm.Controls.Add(this.cbManagerWelders, 2, 7);
            this.tlpManagerForm.Controls.Add(this.cbManagerSub, 2, 8);
            this.tlpManagerForm.Controls.Add(this.cbManagerStorage, 2, 9);
            this.tlpManagerForm.Controls.Add(this.cbManagerPWHT, 2, 10);
            this.tlpManagerForm.Controls.Add(this.txtManagerWPS, 1, 5);
            this.tlpManagerForm.Controls.Add(this.txtManagerWelders, 1, 7);
            this.tlpManagerForm.Controls.Add(this.txtManagerSub, 1, 8);
            this.tlpManagerForm.Controls.Add(this.txtManagerStorage, 1, 9);
            this.tlpManagerForm.Controls.Add(this.txtManagerPWHT, 1, 10);
            this.tlpManagerForm.Controls.Add(this.txtManagerGeneral, 1, 12);
            this.tlpManagerForm.Controls.Add(this.txtManagerExtra, 1, 13);
            this.tlpManagerForm.Controls.Add(this.label39, 0, 2);
            this.tlpManagerForm.Controls.Add(this.label40, 0, 3);
            this.tlpManagerForm.Controls.Add(this.label41, 0, 4);
            this.tlpManagerForm.Controls.Add(this.lblManagerWPS, 0, 5);
            this.tlpManagerForm.Controls.Add(this.lblManagerWPQR, 0, 6);
            this.tlpManagerForm.Controls.Add(this.label65, 0, 8);
            this.tlpManagerForm.Controls.Add(this.label66, 0, 9);
            this.tlpManagerForm.Controls.Add(this.label70, 0, 10);
            this.tlpManagerForm.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpManagerForm.Location = new System.Drawing.Point(3, 3);
            this.tlpManagerForm.Name = "tlpManagerForm";
            this.tlpManagerForm.RowCount = 15;
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6.6F));
            this.tlpManagerForm.Size = new System.Drawing.Size(1024, 433);
            this.tlpManagerForm.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromName("@window");
            this.label1.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(719, 395);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 35);
            this.label1.TabIndex = 82;
            // 
            // pbManagerPath
            // 
            this.pbManagerPath.BackColor = System.Drawing.Color.FromName("@window");
            this.pbManagerPath.BackgroundImageLayout = Wisej.Web.ImageLayout.Zoom;
            this.pbManagerPath.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pbManagerPath.Dock = Wisej.Web.DockStyle.Fill;
            this.pbManagerPath.Location = new System.Drawing.Point(719, 31);
            this.pbManagerPath.Name = "pbManagerPath";
            this.tlpManagerForm.SetRowSpan(this.pbManagerPath, 10);
            this.pbManagerPath.Size = new System.Drawing.Size(302, 274);
            this.pbManagerPath.SizeMode = Wisej.Web.PictureBoxSizeMode.Zoom;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label4.Dock = Wisej.Web.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(719, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(302, 22);
            this.label4.TabIndex = 81;
            this.label4.Text = "Current Action Path";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbManagerAdditional
            // 
            this.cbManagerAdditional.Appearance = Wisej.Web.Appearance.Switch;
            this.cbManagerAdditional.BackColor = System.Drawing.Color.FromName("@window");
            this.cbManagerAdditional.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbManagerAdditional.CheckState = Wisej.Web.CheckState.Indeterminate;
            this.cbManagerAdditional.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbManagerAdditional.Dock = Wisej.Web.DockStyle.Fill;
            this.cbManagerAdditional.Location = new System.Drawing.Point(617, 395);
            this.cbManagerAdditional.Name = "cbManagerAdditional";
            this.cbManagerAdditional.Size = new System.Drawing.Size(96, 35);
            this.cbManagerAdditional.TabIndex = 0;
            this.cbManagerAdditional.ThreeState = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromName("@window");
            this.label3.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.tlpManagerForm.SetColumnSpan(this.label3, 2);
            this.label3.Dock = Wisej.Web.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 395);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(608, 35);
            this.label3.TabIndex = 79;
            this.label3.Text = "Will the job / company cover the additional welding costs?";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtManagerConsiderations
            // 
            this.txtManagerConsiderations.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.tlpManagerForm.SetColumnSpan(this.txtManagerConsiderations, 3);
            this.txtManagerConsiderations.Dock = Wisej.Web.DockStyle.Fill;
            this.txtManagerConsiderations.Location = new System.Drawing.Point(310, 311);
            this.txtManagerConsiderations.Multiline = true;
            this.txtManagerConsiderations.Name = "txtManagerConsiderations";
            this.txtManagerConsiderations.ReadOnly = true;
            this.txtManagerConsiderations.Size = new System.Drawing.Size(711, 22);
            this.txtManagerConsiderations.TabIndex = 78;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromName("@window");
            this.label2.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 311);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(301, 22);
            this.label2.TabIndex = 77;
            this.label2.Text = "Technical Considerations";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtManagerWPQR
            // 
            this.txtManagerWPQR.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtManagerWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.txtManagerWPQR.Location = new System.Drawing.Point(310, 171);
            this.txtManagerWPQR.Name = "txtManagerWPQR";
            this.txtManagerWPQR.ReadOnly = true;
            this.txtManagerWPQR.Size = new System.Drawing.Size(301, 22);
            this.txtManagerWPQR.TabIndex = 76;
            // 
            // cbManagerWPQR
            // 
            this.cbManagerWPQR.Appearance = Wisej.Web.Appearance.Switch;
            this.cbManagerWPQR.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.cbManagerWPQR.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbManagerWPQR.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbManagerWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.cbManagerWPQR.Location = new System.Drawing.Point(617, 171);
            this.cbManagerWPQR.Name = "cbManagerWPQR";
            this.cbManagerWPQR.ReadOnly = true;
            this.cbManagerWPQR.Size = new System.Drawing.Size(96, 22);
            this.cbManagerWPQR.TabIndex = 75;
            // 
            // lblManagerWelders
            // 
            this.lblManagerWelders.AutoSize = true;
            this.lblManagerWelders.BackColor = System.Drawing.Color.FromName("@window");
            this.lblManagerWelders.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.lblManagerWelders.Dock = Wisej.Web.DockStyle.Fill;
            this.lblManagerWelders.Location = new System.Drawing.Point(3, 199);
            this.lblManagerWelders.Name = "lblManagerWelders";
            this.lblManagerWelders.Size = new System.Drawing.Size(301, 22);
            this.lblManagerWelders.TabIndex = 74;
            this.lblManagerWelders.Text = "Qualified/Certified Welders Available";
            this.lblManagerWelders.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label71.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label71.Dock = Wisej.Web.DockStyle.Fill;
            this.label71.Location = new System.Drawing.Point(617, 3);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(96, 22);
            this.label71.TabIndex = 72;
            this.label71.Text = "No / Yes";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.FromName("@window");
            this.label36.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label36.Dock = Wisej.Web.DockStyle.Fill;
            this.label36.Location = new System.Drawing.Point(3, 31);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(301, 22);
            this.label36.TabIndex = 63;
            this.label36.Text = "Trained staff available";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.FromName("@window");
            this.label35.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label35.Dock = Wisej.Web.DockStyle.Fill;
            this.label35.Location = new System.Drawing.Point(3, 367);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(301, 22);
            this.label35.TabIndex = 62;
            this.label35.Text = "Extra Costs to Consider";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.FromName("@window");
            this.label34.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label34.Dock = Wisej.Web.DockStyle.Fill;
            this.label34.Location = new System.Drawing.Point(3, 339);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(301, 22);
            this.label34.TabIndex = 61;
            this.label34.Text = "Operational General Comments";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label33.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label33.Dock = Wisej.Web.DockStyle.Fill;
            this.label33.Location = new System.Drawing.Point(310, 3);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(301, 22);
            this.label33.TabIndex = 53;
            this.label33.Text = "Comments";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label32.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label32.Dock = Wisej.Web.DockStyle.Fill;
            this.label32.Location = new System.Drawing.Point(3, 3);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(301, 22);
            this.label32.TabIndex = 52;
            this.label32.Text = "Items to Consider";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtManagerThird
            // 
            this.txtManagerThird.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtManagerThird.Dock = Wisej.Web.DockStyle.Fill;
            this.txtManagerThird.Location = new System.Drawing.Point(310, 115);
            this.txtManagerThird.Name = "txtManagerThird";
            this.txtManagerThird.ReadOnly = true;
            this.txtManagerThird.Size = new System.Drawing.Size(301, 22);
            this.txtManagerThird.TabIndex = 41;
            // 
            // txtManagerEquipment
            // 
            this.txtManagerEquipment.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtManagerEquipment.Dock = Wisej.Web.DockStyle.Fill;
            this.txtManagerEquipment.Location = new System.Drawing.Point(310, 87);
            this.txtManagerEquipment.Name = "txtManagerEquipment";
            this.txtManagerEquipment.ReadOnly = true;
            this.txtManagerEquipment.Size = new System.Drawing.Size(301, 22);
            this.txtManagerEquipment.TabIndex = 40;
            // 
            // txtManagerFacilities
            // 
            this.txtManagerFacilities.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtManagerFacilities.Dock = Wisej.Web.DockStyle.Fill;
            this.txtManagerFacilities.Location = new System.Drawing.Point(310, 59);
            this.txtManagerFacilities.Name = "txtManagerFacilities";
            this.txtManagerFacilities.ReadOnly = true;
            this.txtManagerFacilities.Size = new System.Drawing.Size(301, 22);
            this.txtManagerFacilities.TabIndex = 39;
            // 
            // txtManagerStaff
            // 
            this.txtManagerStaff.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtManagerStaff.Dock = Wisej.Web.DockStyle.Fill;
            this.txtManagerStaff.Location = new System.Drawing.Point(310, 31);
            this.txtManagerStaff.Name = "txtManagerStaff";
            this.txtManagerStaff.ReadOnly = true;
            this.txtManagerStaff.Size = new System.Drawing.Size(301, 22);
            this.txtManagerStaff.TabIndex = 38;
            // 
            // cbManagerStaff
            // 
            this.cbManagerStaff.Appearance = Wisej.Web.Appearance.Switch;
            this.cbManagerStaff.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.cbManagerStaff.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbManagerStaff.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbManagerStaff.Dock = Wisej.Web.DockStyle.Fill;
            this.cbManagerStaff.Location = new System.Drawing.Point(617, 31);
            this.cbManagerStaff.Name = "cbManagerStaff";
            this.cbManagerStaff.ReadOnly = true;
            this.cbManagerStaff.Size = new System.Drawing.Size(96, 22);
            this.cbManagerStaff.TabIndex = 44;
            // 
            // cbManagerFacilities
            // 
            this.cbManagerFacilities.Appearance = Wisej.Web.Appearance.Switch;
            this.cbManagerFacilities.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.cbManagerFacilities.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbManagerFacilities.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbManagerFacilities.Dock = Wisej.Web.DockStyle.Fill;
            this.cbManagerFacilities.Location = new System.Drawing.Point(617, 59);
            this.cbManagerFacilities.Name = "cbManagerFacilities";
            this.cbManagerFacilities.ReadOnly = true;
            this.cbManagerFacilities.Size = new System.Drawing.Size(96, 22);
            this.cbManagerFacilities.TabIndex = 48;
            // 
            // cbManagerEquipment
            // 
            this.cbManagerEquipment.Appearance = Wisej.Web.Appearance.Switch;
            this.cbManagerEquipment.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.cbManagerEquipment.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbManagerEquipment.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbManagerEquipment.Dock = Wisej.Web.DockStyle.Fill;
            this.cbManagerEquipment.Location = new System.Drawing.Point(617, 87);
            this.cbManagerEquipment.Name = "cbManagerEquipment";
            this.cbManagerEquipment.ReadOnly = true;
            this.cbManagerEquipment.Size = new System.Drawing.Size(96, 22);
            this.cbManagerEquipment.TabIndex = 45;
            // 
            // cbManagerWPS
            // 
            this.cbManagerWPS.Appearance = Wisej.Web.Appearance.Switch;
            this.cbManagerWPS.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.cbManagerWPS.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbManagerWPS.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbManagerWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.cbManagerWPS.Location = new System.Drawing.Point(617, 143);
            this.cbManagerWPS.Name = "cbManagerWPS";
            this.cbManagerWPS.ReadOnly = true;
            this.cbManagerWPS.Size = new System.Drawing.Size(96, 22);
            this.cbManagerWPS.TabIndex = 47;
            // 
            // cbManagerThird
            // 
            this.cbManagerThird.Appearance = Wisej.Web.Appearance.Switch;
            this.cbManagerThird.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.cbManagerThird.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbManagerThird.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbManagerThird.Dock = Wisej.Web.DockStyle.Fill;
            this.cbManagerThird.Location = new System.Drawing.Point(617, 115);
            this.cbManagerThird.Name = "cbManagerThird";
            this.cbManagerThird.ReadOnly = true;
            this.cbManagerThird.Size = new System.Drawing.Size(96, 22);
            this.cbManagerThird.TabIndex = 46;
            // 
            // cbManagerWelders
            // 
            this.cbManagerWelders.Appearance = Wisej.Web.Appearance.Switch;
            this.cbManagerWelders.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.cbManagerWelders.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbManagerWelders.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbManagerWelders.Dock = Wisej.Web.DockStyle.Fill;
            this.cbManagerWelders.Location = new System.Drawing.Point(617, 199);
            this.cbManagerWelders.Name = "cbManagerWelders";
            this.cbManagerWelders.ReadOnly = true;
            this.cbManagerWelders.Size = new System.Drawing.Size(96, 22);
            this.cbManagerWelders.TabIndex = 49;
            // 
            // cbManagerSub
            // 
            this.cbManagerSub.Appearance = Wisej.Web.Appearance.Switch;
            this.cbManagerSub.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.cbManagerSub.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbManagerSub.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbManagerSub.Dock = Wisej.Web.DockStyle.Fill;
            this.cbManagerSub.Location = new System.Drawing.Point(617, 227);
            this.cbManagerSub.Name = "cbManagerSub";
            this.cbManagerSub.ReadOnly = true;
            this.cbManagerSub.Size = new System.Drawing.Size(96, 22);
            this.cbManagerSub.TabIndex = 50;
            // 
            // cbManagerStorage
            // 
            this.cbManagerStorage.Appearance = Wisej.Web.Appearance.Switch;
            this.cbManagerStorage.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.cbManagerStorage.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbManagerStorage.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbManagerStorage.Dock = Wisej.Web.DockStyle.Fill;
            this.cbManagerStorage.Location = new System.Drawing.Point(617, 255);
            this.cbManagerStorage.Name = "cbManagerStorage";
            this.cbManagerStorage.ReadOnly = true;
            this.cbManagerStorage.Size = new System.Drawing.Size(96, 22);
            this.cbManagerStorage.TabIndex = 51;
            // 
            // cbManagerPWHT
            // 
            this.cbManagerPWHT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbManagerPWHT.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.cbManagerPWHT.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbManagerPWHT.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbManagerPWHT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbManagerPWHT.Location = new System.Drawing.Point(617, 283);
            this.cbManagerPWHT.Name = "cbManagerPWHT";
            this.cbManagerPWHT.ReadOnly = true;
            this.cbManagerPWHT.Size = new System.Drawing.Size(96, 22);
            this.cbManagerPWHT.TabIndex = 43;
            // 
            // txtManagerWPS
            // 
            this.txtManagerWPS.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtManagerWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.txtManagerWPS.Location = new System.Drawing.Point(310, 143);
            this.txtManagerWPS.Name = "txtManagerWPS";
            this.txtManagerWPS.ReadOnly = true;
            this.txtManagerWPS.Size = new System.Drawing.Size(301, 22);
            this.txtManagerWPS.TabIndex = 56;
            // 
            // txtManagerWelders
            // 
            this.txtManagerWelders.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtManagerWelders.Dock = Wisej.Web.DockStyle.Fill;
            this.txtManagerWelders.Location = new System.Drawing.Point(310, 199);
            this.txtManagerWelders.Name = "txtManagerWelders";
            this.txtManagerWelders.ReadOnly = true;
            this.txtManagerWelders.Size = new System.Drawing.Size(301, 22);
            this.txtManagerWelders.TabIndex = 57;
            // 
            // txtManagerSub
            // 
            this.txtManagerSub.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtManagerSub.Dock = Wisej.Web.DockStyle.Fill;
            this.txtManagerSub.Location = new System.Drawing.Point(310, 227);
            this.txtManagerSub.Name = "txtManagerSub";
            this.txtManagerSub.ReadOnly = true;
            this.txtManagerSub.Size = new System.Drawing.Size(301, 22);
            this.txtManagerSub.TabIndex = 55;
            // 
            // txtManagerStorage
            // 
            this.txtManagerStorage.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtManagerStorage.Dock = Wisej.Web.DockStyle.Fill;
            this.txtManagerStorage.Location = new System.Drawing.Point(310, 255);
            this.txtManagerStorage.Name = "txtManagerStorage";
            this.txtManagerStorage.ReadOnly = true;
            this.txtManagerStorage.Size = new System.Drawing.Size(301, 22);
            this.txtManagerStorage.TabIndex = 54;
            // 
            // txtManagerPWHT
            // 
            this.txtManagerPWHT.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.txtManagerPWHT.Dock = Wisej.Web.DockStyle.Fill;
            this.txtManagerPWHT.Location = new System.Drawing.Point(310, 283);
            this.txtManagerPWHT.Name = "txtManagerPWHT";
            this.txtManagerPWHT.ReadOnly = true;
            this.txtManagerPWHT.Size = new System.Drawing.Size(301, 22);
            this.txtManagerPWHT.TabIndex = 58;
            // 
            // txtManagerGeneral
            // 
            this.txtManagerGeneral.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.tlpManagerForm.SetColumnSpan(this.txtManagerGeneral, 3);
            this.txtManagerGeneral.Dock = Wisej.Web.DockStyle.Fill;
            this.txtManagerGeneral.Location = new System.Drawing.Point(310, 339);
            this.txtManagerGeneral.Multiline = true;
            this.txtManagerGeneral.Name = "txtManagerGeneral";
            this.txtManagerGeneral.ReadOnly = true;
            this.txtManagerGeneral.Size = new System.Drawing.Size(711, 22);
            this.txtManagerGeneral.TabIndex = 59;
            // 
            // txtManagerExtra
            // 
            this.txtManagerExtra.BackColor = System.Drawing.Color.FromName("@controlLight");
            this.tlpManagerForm.SetColumnSpan(this.txtManagerExtra, 3);
            this.txtManagerExtra.Dock = Wisej.Web.DockStyle.Fill;
            this.txtManagerExtra.Location = new System.Drawing.Point(310, 367);
            this.txtManagerExtra.Multiline = true;
            this.txtManagerExtra.Name = "txtManagerExtra";
            this.txtManagerExtra.ReadOnly = true;
            this.txtManagerExtra.Size = new System.Drawing.Size(711, 22);
            this.txtManagerExtra.TabIndex = 60;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.FromName("@window");
            this.label39.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label39.Dock = Wisej.Web.DockStyle.Fill;
            this.label39.Location = new System.Drawing.Point(3, 59);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(301, 22);
            this.label39.TabIndex = 64;
            this.label39.Text = "Facilities available";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.FromName("@window");
            this.label40.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label40.Dock = Wisej.Web.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(3, 87);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(301, 22);
            this.label40.TabIndex = 65;
            this.label40.Text = "Equipment available";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.FromName("@window");
            this.label41.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label41.Dock = Wisej.Web.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(3, 115);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(301, 22);
            this.label41.TabIndex = 66;
            this.label41.Text = "Third party involvement ";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblManagerWPS
            // 
            this.lblManagerWPS.AutoSize = true;
            this.lblManagerWPS.BackColor = System.Drawing.Color.FromName("@window");
            this.lblManagerWPS.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.lblManagerWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.lblManagerWPS.Location = new System.Drawing.Point(3, 143);
            this.lblManagerWPS.Name = "lblManagerWPS";
            this.lblManagerWPS.Size = new System.Drawing.Size(301, 22);
            this.lblManagerWPS.TabIndex = 67;
            this.lblManagerWPS.Text = "Qualified WPS available";
            this.lblManagerWPS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblManagerWPQR
            // 
            this.lblManagerWPQR.AutoSize = true;
            this.lblManagerWPQR.BackColor = System.Drawing.Color.FromName("@window");
            this.lblManagerWPQR.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.lblManagerWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.lblManagerWPQR.Location = new System.Drawing.Point(3, 171);
            this.lblManagerWPQR.Name = "lblManagerWPQR";
            this.lblManagerWPQR.Size = new System.Drawing.Size(301, 22);
            this.lblManagerWPQR.TabIndex = 68;
            this.lblManagerWPQR.Text = "Qualified WPQR Available";
            this.lblManagerWPQR.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.Color.FromName("@window");
            this.label65.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label65.Dock = Wisej.Web.DockStyle.Fill;
            this.label65.Location = new System.Drawing.Point(3, 227);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(301, 22);
            this.label65.TabIndex = 69;
            this.label65.Text = "Subcontractors to be used";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.BackColor = System.Drawing.Color.FromName("@window");
            this.label66.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label66.Dock = Wisej.Web.DockStyle.Fill;
            this.label66.Location = new System.Drawing.Point(3, 255);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(301, 22);
            this.label66.TabIndex = 70;
            this.label66.Text = "Dedicated storage of parent material & welding consumables required";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.Color.FromName("@window");
            this.label70.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label70.Dock = Wisej.Web.DockStyle.Fill;
            this.label70.Location = new System.Drawing.Point(3, 283);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(301, 22);
            this.label70.TabIndex = 71;
            this.label70.Text = "Post-Weld Heat treatment required";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.tableLayoutPanel12, 0, 0);
            this.tableLayoutPanel11.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel11.TabIndex = 5;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel12.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.btnManagerBack, 0, 2);
            this.tableLayoutPanel12.Controls.Add(this.btnManagerHome, 0, 3);
            this.tableLayoutPanel12.Controls.Add(this.btnManagerComplete, 0, 4);
            this.tableLayoutPanel12.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel12.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 5;
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel12.TabIndex = 4;
            // 
            // btnManagerBack
            // 
            this.btnManagerBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnManagerBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnManagerBack.Location = new System.Drawing.Point(3, 173);
            this.btnManagerBack.Name = "btnManagerBack";
            this.btnManagerBack.Size = new System.Drawing.Size(95, 79);
            this.btnManagerBack.TabIndex = 3;
            this.btnManagerBack.Text = "Back";
            this.btnManagerBack.Click += new System.EventHandler(this.btnManagerBack_Click);
            // 
            // btnManagerHome
            // 
            this.btnManagerHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnManagerHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnManagerHome.Location = new System.Drawing.Point(3, 258);
            this.btnManagerHome.Name = "btnManagerHome";
            this.btnManagerHome.Size = new System.Drawing.Size(95, 79);
            this.btnManagerHome.TabIndex = 2;
            this.btnManagerHome.Text = "Home";
            this.btnManagerHome.Click += new System.EventHandler(this.btnManagerHome_Click);
            // 
            // btnManagerComplete
            // 
            this.btnManagerComplete.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnManagerComplete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnManagerComplete.Location = new System.Drawing.Point(3, 343);
            this.btnManagerComplete.Name = "btnManagerComplete";
            this.btnManagerComplete.Size = new System.Drawing.Size(95, 79);
            this.btnManagerComplete.TabIndex = 1;
            this.btnManagerComplete.Text = "Complete";
            this.btnManagerComplete.Click += new System.EventHandler(this.btnManagerComplete_Click);
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel13.Controls.Add(this.label68, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.label69, 0, 0);
            this.tableLayoutPanel13.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label68.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label68.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.label68.Dock = Wisej.Web.DockStyle.Fill;
            this.label68.Location = new System.Drawing.Point(6, 79);
            this.label68.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(1133, 35);
            this.label68.TabIndex = 1;
            this.label68.Text = "Notes";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label69.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label69.CssStyle = "border-radius: 4px;";
            this.label69.Dock = Wisej.Web.DockStyle.Fill;
            this.label69.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label69.Location = new System.Drawing.Point(6, 3);
            this.label69.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(1133, 70);
            this.label69.TabIndex = 0;
            this.label69.Text = "Manager Review";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uc_rqReview
            // 
            this.Controls.Add(this.tableLayoutPanel8);
            this.Name = "uc_rqReview";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_rqReview_VisibleChanged);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tlpManagerForm.ResumeLayout(false);
            this.tlpManagerForm.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbManagerPath)).EndInit();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel8;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel9;
        private Wisej.Web.TableLayoutPanel tlpManagerForm;
        private Wisej.Web.TextBox txtManagerWPQR;
        private Wisej.Web.CheckBox cbManagerWPQR;
        private Wisej.Web.Label lblManagerWelders;
        private Wisej.Web.Label label71;
        private Wisej.Web.Label label36;
        private Wisej.Web.Label label35;
        private Wisej.Web.Label label34;
        private Wisej.Web.Label label33;
        private Wisej.Web.Label label32;
        private Wisej.Web.TextBox txtManagerThird;
        private Wisej.Web.TextBox txtManagerEquipment;
        private Wisej.Web.TextBox txtManagerFacilities;
        private Wisej.Web.TextBox txtManagerStaff;
        private Wisej.Web.CheckBox cbManagerStaff;
        private Wisej.Web.CheckBox cbManagerFacilities;
        private Wisej.Web.CheckBox cbManagerEquipment;
        private Wisej.Web.CheckBox cbManagerWPS;
        private Wisej.Web.CheckBox cbManagerThird;
        private Wisej.Web.CheckBox cbManagerWelders;
        private Wisej.Web.CheckBox cbManagerSub;
        private Wisej.Web.CheckBox cbManagerStorage;
        private Wisej.Web.CheckBox cbManagerPWHT;
        private Wisej.Web.TextBox txtManagerWPS;
        private Wisej.Web.TextBox txtManagerSub;
        private Wisej.Web.TextBox txtManagerStorage;
        private Wisej.Web.TextBox txtManagerPWHT;
        private Wisej.Web.TextBox txtManagerGeneral;
        private Wisej.Web.TextBox txtManagerExtra;
        private Wisej.Web.Label label39;
        private Wisej.Web.Label label40;
        private Wisej.Web.Label label41;
        private Wisej.Web.Label lblManagerWPS;
        private Wisej.Web.Label lblManagerWPQR;
        private Wisej.Web.Label label65;
        private Wisej.Web.Label label66;
        private Wisej.Web.Label label70;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel11;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel12;
        private Wisej.Web.Button btnManagerBack;
        private Wisej.Web.Button btnManagerHome;
        private Wisej.Web.Button btnManagerComplete;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel13;
        private Wisej.Web.Label label68;
        private Wisej.Web.Label label69;
        private Wisej.Web.TextBox txtManagerConsiderations;
        private Wisej.Web.Label label2;
        private Wisej.Web.Label label3;
        private Wisej.Web.CheckBox cbManagerAdditional;
        private Wisej.Web.Label label4;
        private Wisej.Web.PictureBox pbManagerPath;
        private Wisej.Web.TextBox txtManagerWelders;
        private Wisej.Web.Label label1;
    }
}
