﻿namespace WeldingManagement.UserControls.RequestControls
{
    partial class uc_rqMatrix
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_rqMatrix));
            this.tableLayoutPanel15 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel16 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel18 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel30 = new Wisej.Web.TableLayoutPanel();
            this.btnMatrixBack = new Wisej.Web.Button();
            this.btnMatrixHome = new Wisej.Web.Button();
            this.btnMatrixNext = new Wisej.Web.Button();
            this.tableLayoutPanel17 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.label8 = new Wisej.Web.Label();
            this.label9 = new Wisej.Web.Label();
            this.label16 = new Wisej.Web.Label();
            this.label20 = new Wisej.Web.Label();
            this.label24 = new Wisej.Web.Label();
            this.label28 = new Wisej.Web.Label();
            this.tableLayoutPanel4 = new Wisej.Web.TableLayoutPanel();
            this.label5 = new Wisej.Web.Label();
            this.label10 = new Wisej.Web.Label();
            this.label13 = new Wisej.Web.Label();
            this.label19 = new Wisej.Web.Label();
            this.label23 = new Wisej.Web.Label();
            this.label27 = new Wisej.Web.Label();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.label7 = new Wisej.Web.Label();
            this.label11 = new Wisej.Web.Label();
            this.label15 = new Wisej.Web.Label();
            this.label17 = new Wisej.Web.Label();
            this.label21 = new Wisej.Web.Label();
            this.label25 = new Wisej.Web.Label();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.label6 = new Wisej.Web.Label();
            this.label12 = new Wisej.Web.Label();
            this.label14 = new Wisej.Web.Label();
            this.label18 = new Wisej.Web.Label();
            this.label22 = new Wisej.Web.Label();
            this.label26 = new Wisej.Web.Label();
            this.rbMatrixComplex = new Wisej.Web.RadioButton();
            this.rbMatrixStandard = new Wisej.Web.RadioButton();
            this.rbMatrixLow = new Wisej.Web.RadioButton();
            this.txtMatrixManager = new Wisej.Web.TextBox();
            this.label48 = new Wisej.Web.Label();
            this.label60 = new Wisej.Web.Label();
            this.txtMatrixJob = new Wisej.Web.TextBox();
            this.label1 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.label4 = new Wisej.Web.Label();
            this.label29 = new Wisej.Web.Label();
            this.tableLayoutPanel19 = new Wisej.Web.TableLayoutPanel();
            this.label61 = new Wisej.Web.Label();
            this.label62 = new Wisej.Web.Label();
            this.tableLayoutPanel15.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel15.ColumnCount = 3;
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel15.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.Controls.Add(this.tableLayoutPanel16, 1, 3);
            this.tableLayoutPanel15.Controls.Add(this.tableLayoutPanel19, 1, 1);
            this.tableLayoutPanel15.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 5;
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel15.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel15.TabIndex = 3;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel16.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel18, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel17, 0, 0);
            this.tableLayoutPanel16.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel16.TabIndex = 1;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 1;
            this.tableLayoutPanel18.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Controls.Add(this.tableLayoutPanel30, 0, 0);
            this.tableLayoutPanel18.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel18.TabIndex = 5;
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel30.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel30.ColumnCount = 1;
            this.tableLayoutPanel30.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel30.Controls.Add(this.btnMatrixBack, 0, 2);
            this.tableLayoutPanel30.Controls.Add(this.btnMatrixHome, 0, 3);
            this.tableLayoutPanel30.Controls.Add(this.btnMatrixNext, 0, 4);
            this.tableLayoutPanel30.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel30.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel30.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 5;
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel30.TabIndex = 4;
            // 
            // btnMatrixBack
            // 
            this.btnMatrixBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnMatrixBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnMatrixBack.Location = new System.Drawing.Point(3, 173);
            this.btnMatrixBack.Name = "btnMatrixBack";
            this.btnMatrixBack.Size = new System.Drawing.Size(95, 79);
            this.btnMatrixBack.TabIndex = 3;
            this.btnMatrixBack.Text = "Back";
            this.btnMatrixBack.Click += new System.EventHandler(this.btnMatrixBack_Click);
            // 
            // btnMatrixHome
            // 
            this.btnMatrixHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnMatrixHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnMatrixHome.Location = new System.Drawing.Point(3, 258);
            this.btnMatrixHome.Name = "btnMatrixHome";
            this.btnMatrixHome.Size = new System.Drawing.Size(95, 79);
            this.btnMatrixHome.TabIndex = 1;
            this.btnMatrixHome.Text = "Home";
            this.btnMatrixHome.Click += new System.EventHandler(this.btnMatrixHome_Click);
            // 
            // btnMatrixNext
            // 
            this.btnMatrixNext.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnMatrixNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnMatrixNext.Location = new System.Drawing.Point(3, 343);
            this.btnMatrixNext.Name = "btnMatrixNext";
            this.btnMatrixNext.Size = new System.Drawing.Size(95, 79);
            this.btnMatrixNext.TabIndex = 0;
            this.btnMatrixNext.Text = "Next";
            this.btnMatrixNext.Click += new System.EventHandler(this.btnMatrixNext_Click);
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 4;
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 15F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel17.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel17.Controls.Add(this.tableLayoutPanel3, 3, 2);
            this.tableLayoutPanel17.Controls.Add(this.tableLayoutPanel4, 2, 2);
            this.tableLayoutPanel17.Controls.Add(this.tableLayoutPanel1, 0, 2);
            this.tableLayoutPanel17.Controls.Add(this.tableLayoutPanel2, 1, 2);
            this.tableLayoutPanel17.Controls.Add(this.rbMatrixComplex, 3, 3);
            this.tableLayoutPanel17.Controls.Add(this.rbMatrixStandard, 2, 3);
            this.tableLayoutPanel17.Controls.Add(this.rbMatrixLow, 1, 3);
            this.tableLayoutPanel17.Controls.Add(this.txtMatrixManager, 3, 0);
            this.tableLayoutPanel17.Controls.Add(this.label48, 2, 0);
            this.tableLayoutPanel17.Controls.Add(this.label60, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.txtMatrixJob, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel17.Controls.Add(this.label2, 1, 1);
            this.tableLayoutPanel17.Controls.Add(this.label3, 2, 1);
            this.tableLayoutPanel17.Controls.Add(this.label4, 3, 1);
            this.tableLayoutPanel17.Controls.Add(this.label29, 0, 3);
            this.tableLayoutPanel17.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 4;
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel17.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel17.TabIndex = 4;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel3.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label9, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label16, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label20, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label24, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label28, 0, 5);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(668, 69);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 6;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(353, 327);
            this.tableLayoutPanel3.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = Wisej.Web.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(3, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(345, 61);
            this.label8.TabIndex = 46;
            this.label8.Text = resources.GetString("label8.Text");
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = Wisej.Web.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(3, 70);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(345, 34);
            this.label9.TabIndex = 47;
            this.label9.Text = "Total product Failure";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = Wisej.Web.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(3, 110);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(345, 34);
            this.label16.TabIndex = 54;
            this.label16.Text = "Major Risk to Human Life";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = Wisej.Web.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label20.Location = new System.Drawing.Point(3, 150);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(345, 34);
            this.label20.TabIndex = 58;
            this.label20.Text = "Successive significant financial consequences";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = Wisej.Web.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label24.Location = new System.Drawing.Point(3, 190);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(345, 61);
            this.label24.TabIndex = 62;
            this.label24.Text = "Complex range of materials including high performance metals with high control re" +
    "quired.  Standard materials such as structural boiler steels and aluminum alloys" +
    " with enhanced control.";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = Wisej.Web.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label28.Location = new System.Drawing.Point(3, 257);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(345, 65);
            this.label28.TabIndex = 66;
            this.label28.Text = resources.GetString("label28.Text");
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel4.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label10, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label13, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label19, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label23, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.label27, 0, 5);
            this.tableLayoutPanel4.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(412, 69);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 6;
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(250, 327);
            this.tableLayoutPanel4.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = Wisej.Web.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(3, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(242, 61);
            this.label5.TabIndex = 43;
            this.label5.Text = "Structural components with dynamic loading.";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = Wisej.Web.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(3, 70);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(242, 34);
            this.label10.TabIndex = 48;
            this.label10.Text = "Impair the intended use of the construction and the operational unit";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = Wisej.Web.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(3, 110);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(242, 34);
            this.label13.TabIndex = 51;
            this.label13.Text = "Normal Safety Risk";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = Wisej.Web.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(3, 150);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(242, 34);
            this.label19.TabIndex = 57;
            this.label19.Text = "Not Extreme";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Dock = Wisej.Web.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label23.Location = new System.Drawing.Point(3, 190);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(242, 61);
            this.label23.TabIndex = 61;
            this.label23.Text = "Conventional without reliant on high performance materials";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = Wisej.Web.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label27.Location = new System.Drawing.Point(3, 257);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(242, 65);
            this.label27.TabIndex = 65;
            this.label27.Text = "-  Pressure piping – lower hazard\r\n-  Structural steel, platforms, handrails, sta" +
    "irs and ladders \r\n-  Brackets\r\n-  Office and storage shelving\r\n-  Mobile equipme" +
    "nt";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel1.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label17, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label21, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label25, 0, 5);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 69);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(147, 327);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = Wisej.Web.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(3, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(139, 61);
            this.label7.TabIndex = 45;
            this.label7.Text = "Services";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = Wisej.Web.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(3, 70);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(139, 34);
            this.label11.TabIndex = 49;
            this.label11.Text = "Failure of the weld";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = Wisej.Web.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(3, 110);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(139, 34);
            this.label15.TabIndex = 53;
            this.label15.Text = "Safety impact if weld fails";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = Wisej.Web.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(3, 150);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(139, 34);
            this.label17.TabIndex = 55;
            this.label17.Text = "Financial consequence";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = Wisej.Web.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(3, 190);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(139, 61);
            this.label21.TabIndex = 59;
            this.label21.Text = "Manufacturing technique";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = Wisej.Web.DockStyle.Fill;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label25.Location = new System.Drawing.Point(3, 257);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(139, 65);
            this.label25.TabIndex = 63;
            this.label25.Text = "Examples";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel2.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label12, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label14, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label18, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label22, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label26, 0, 5);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(156, 69);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 6;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(250, 327);
            this.tableLayoutPanel2.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = Wisej.Web.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(3, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(242, 61);
            this.label6.TabIndex = 44;
            this.label6.Text = "General structural static loading components.";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = Wisej.Web.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(3, 70);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(242, 34);
            this.label12.TabIndex = 50;
            this.label12.Text = "Not impair the intended use of the construction";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = Wisej.Web.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(3, 110);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(242, 34);
            this.label14.TabIndex = 52;
            this.label14.Text = "No Adverse Impact";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = Wisej.Web.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(3, 150);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(242, 34);
            this.label18.TabIndex = 56;
            this.label18.Text = "Minor Financial consequences";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = Wisej.Web.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label22.Location = new System.Drawing.Point(3, 190);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(242, 61);
            this.label22.TabIndex = 60;
            this.label22.Text = "Simple materials and techniques";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = Wisej.Web.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label26.Location = new System.Drawing.Point(3, 257);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(242, 65);
            this.label26.TabIndex = 64;
            this.label26.Text = "-  General structural static loading components";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rbMatrixComplex
            // 
            this.rbMatrixComplex.BackColor = System.Drawing.Color.FromName("@window");
            this.rbMatrixComplex.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.rbMatrixComplex.Dock = Wisej.Web.DockStyle.Fill;
            this.rbMatrixComplex.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbMatrixComplex.Location = new System.Drawing.Point(668, 402);
            this.rbMatrixComplex.Name = "rbMatrixComplex";
            this.rbMatrixComplex.Size = new System.Drawing.Size(353, 28);
            this.rbMatrixComplex.TabIndex = 70;
            this.rbMatrixComplex.TabStop = true;
            this.rbMatrixComplex.Text = "Complex";
            // 
            // rbMatrixStandard
            // 
            this.rbMatrixStandard.BackColor = System.Drawing.Color.FromName("@window");
            this.rbMatrixStandard.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.rbMatrixStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.rbMatrixStandard.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbMatrixStandard.Location = new System.Drawing.Point(412, 402);
            this.rbMatrixStandard.Name = "rbMatrixStandard";
            this.rbMatrixStandard.Size = new System.Drawing.Size(250, 28);
            this.rbMatrixStandard.TabIndex = 69;
            this.rbMatrixStandard.TabStop = true;
            this.rbMatrixStandard.Text = "Standard";
            // 
            // rbMatrixLow
            // 
            this.rbMatrixLow.BackColor = System.Drawing.Color.FromName("@window");
            this.rbMatrixLow.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.rbMatrixLow.Dock = Wisej.Web.DockStyle.Fill;
            this.rbMatrixLow.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbMatrixLow.Location = new System.Drawing.Point(156, 402);
            this.rbMatrixLow.Name = "rbMatrixLow";
            this.rbMatrixLow.Size = new System.Drawing.Size(250, 28);
            this.rbMatrixLow.TabIndex = 68;
            this.rbMatrixLow.TabStop = true;
            this.rbMatrixLow.Text = "Low";
            // 
            // txtMatrixManager
            // 
            this.txtMatrixManager.Dock = Wisej.Web.DockStyle.Fill;
            this.txtMatrixManager.Location = new System.Drawing.Point(668, 3);
            this.txtMatrixManager.Name = "txtMatrixManager";
            this.txtMatrixManager.ReadOnly = true;
            this.txtMatrixManager.Size = new System.Drawing.Size(353, 27);
            this.txtMatrixManager.TabIndex = 36;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.FromName("@window");
            this.label48.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label48.Dock = Wisej.Web.DockStyle.Fill;
            this.label48.Location = new System.Drawing.Point(412, 3);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(250, 27);
            this.label48.TabIndex = 12;
            this.label48.Text = "Client Manger EID";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.FromName("@window");
            this.label60.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label60.Dock = Wisej.Web.DockStyle.Fill;
            this.label60.Location = new System.Drawing.Point(3, 3);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(147, 27);
            this.label60.TabIndex = 0;
            this.label60.Text = "Job / Quote Number";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMatrixJob
            // 
            this.txtMatrixJob.Dock = Wisej.Web.DockStyle.Fill;
            this.txtMatrixJob.Location = new System.Drawing.Point(156, 3);
            this.txtMatrixJob.Name = "txtMatrixJob";
            this.txtMatrixJob.ReadOnly = true;
            this.txtMatrixJob.Size = new System.Drawing.Size(250, 27);
            this.txtMatrixJob.TabIndex = 38;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 27);
            this.label1.TabIndex = 39;
            this.label1.Text = "Aspect";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(156, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(250, 27);
            this.label2.TabIndex = 40;
            this.label2.Text = "Low";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label3.Dock = Wisej.Web.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(412, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(250, 27);
            this.label3.TabIndex = 41;
            this.label3.Text = "Standard";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label4.Dock = Wisej.Web.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(668, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(353, 27);
            this.label4.TabIndex = 42;
            this.label4.Text = "Complex";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.FromName("@window");
            this.label29.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label29.Dock = Wisej.Web.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label29.Location = new System.Drawing.Point(3, 402);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(147, 28);
            this.label29.TabIndex = 67;
            this.label29.Text = "Indicated complexity";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 1;
            this.tableLayoutPanel19.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel19.Controls.Add(this.label61, 0, 1);
            this.tableLayoutPanel19.Controls.Add(this.label62, 0, 0);
            this.tableLayoutPanel19.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 2;
            this.tableLayoutPanel19.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel19.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel19.TabIndex = 0;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label61.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label61.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.label61.Dock = Wisej.Web.DockStyle.Fill;
            this.label61.Location = new System.Drawing.Point(6, 79);
            this.label61.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(1133, 35);
            this.label61.TabIndex = 1;
            this.label61.Text = "Notes";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label62.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label62.CssStyle = "border-radius: 4px;";
            this.label62.Dock = Wisej.Web.DockStyle.Fill;
            this.label62.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label62.Location = new System.Drawing.Point(6, 3);
            this.label62.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(1133, 70);
            this.label62.TabIndex = 0;
            this.label62.Text = "Welding Scope of Work";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uc_rqMatrix
            // 
            this.Controls.Add(this.tableLayoutPanel15);
            this.Name = "uc_rqMatrix";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_rqMatrix_VisibleChanged);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel30.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel15;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel16;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel18;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel30;
        private Wisej.Web.Button btnMatrixBack;
        private Wisej.Web.Button btnMatrixHome;
        private Wisej.Web.Button btnMatrixNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel17;
        private Wisej.Web.RadioButton rbMatrixComplex;
        private Wisej.Web.RadioButton rbMatrixStandard;
        private Wisej.Web.RadioButton rbMatrixLow;
        private Wisej.Web.TextBox txtMatrixManager;
        private Wisej.Web.Label label48;
        private Wisej.Web.Label label60;
        private Wisej.Web.TextBox txtMatrixJob;
        private Wisej.Web.Label label1;
        private Wisej.Web.Label label2;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label7;
        private Wisej.Web.Label label6;
        private Wisej.Web.Label label5;
        private Wisej.Web.Label label8;
        private Wisej.Web.Label label11;
        private Wisej.Web.Label label12;
        private Wisej.Web.Label label10;
        private Wisej.Web.Label label9;
        private Wisej.Web.Label label15;
        private Wisej.Web.Label label14;
        private Wisej.Web.Label label13;
        private Wisej.Web.Label label16;
        private Wisej.Web.Label label17;
        private Wisej.Web.Label label18;
        private Wisej.Web.Label label19;
        private Wisej.Web.Label label20;
        private Wisej.Web.Label label21;
        private Wisej.Web.Label label22;
        private Wisej.Web.Label label23;
        private Wisej.Web.Label label24;
        private Wisej.Web.Label label25;
        private Wisej.Web.Label label26;
        private Wisej.Web.Label label27;
        private Wisej.Web.Label label28;
        private Wisej.Web.Label label29;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel19;
        private Wisej.Web.Label label61;
        private Wisej.Web.Label label62;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel4;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
    }
}
