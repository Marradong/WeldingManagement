﻿using ApiClient;
using PeopleEF;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using Welding.DAL;
using WeldingManagement.UserControls.PopupControls;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.RequestControls
{
    public partial class uc_rqTechnical : Wisej.Web.UserControl
    {
        private up_hmSave up_hmSave1;
        private up_rqFilesView up_rqFilesView1;
        private Panel overlayPanel;

        public uc_rqTechnical()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on technical screen")]
        public event EventHandler btnTechnicalNextClick;
        private void btnTechnicalNext_Click(object sender, EventArgs e)
        {
            Save_Action();
            Update_Status();

            btnTechnicalNextClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on technical screen")]
        public event EventHandler btnTechnicalHomeClick;
        private void btnTechnicalHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnTechnicalHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on technical screen")]
        public event EventHandler btnTechnicalBackClick;
        private void btnTechnicalBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnTechnicalBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnTechnicalBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                nwf.Status = Actions.OperationalReview;

                ApiCalls.UpdateNewWeldingForm(nwf.NewWeldingFormId, nwf);

                this.Tag = new Tag(ApiCalls.ReadNewWeldingForm(nwf.NewWeldingFormId), TagType.New_Welding_Form);
            }
        }

        private void Save_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                if (nwf.TechnicalReview == null)
                {
                    // Create a new welding form to act as a DTO
                    Person linkedPerson = QAWebApiClient.ApiCalls.GetPerson(txtTechnicalReviewer.Text);

                    if (linkedPerson != null)
                    {
                        TechnicalReview technicalReview = new TechnicalReview(nwf.NewWeldingFormId, nwf);

                        technicalReview.TechnicalReviewerEID = linkedPerson.EmployeeNumber;
                        technicalReview.Date = dtpTechnicalDate.Value;

                        if (txtTechnicalConsiderations.Text != null)
                            technicalReview.Considerations = txtTechnicalConsiderations.Text;

                        if (txtTechnicalExtra.Text != null)
                            technicalReview.ExtraCosts = txtTechnicalExtra.Text;

                        ApiCalls.CreateTechnicalReview(nwf.NewWeldingFormId, technicalReview);
                    }
                }
                else
                {
                    if (txtTechnicalConsiderations.Text != null)
                        nwf.TechnicalReview.Considerations = txtTechnicalConsiderations.Text;

                    if (txtTechnicalExtra.Text != null)
                        nwf.TechnicalReview.ExtraCosts = txtTechnicalExtra.Text;

                    nwf.TechnicalReview.Date = dtpTechnicalDate.Value;

                    ApiCalls.UpdateTechnicalReview(nwf.TechnicalReview.TechnicalReviewId, nwf.TechnicalReview);
                }

                this.Tag = new Tag(ApiCalls.ReadNewWeldingForm(nwf.NewWeldingFormId), TagType.New_Welding_Form);
            }
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                txtTechnicalReviewer.Text = Application.Cookies["EmployeeNumber"];

                if (nwf.TechnicalReview != null)
                {
                    txtTechnicalConsiderations.Text = nwf.TechnicalReview.Considerations?.ToString() ?? "";
                    txtTechnicalExtra.Text = nwf.TechnicalReview.ExtraCosts?.ToString() ?? "";
                    dtpTechnicalDate.Value = nwf.TechnicalReview.Date ?? DateTime.Now;
                }
                else
                {
                    txtTechnicalConsiderations.Text = "";
                    txtTechnicalExtra.Text = "";
                    dtpTechnicalDate.Value = DateTime.Now;
                }

                txtTechnicalJob.Text = nwf.WeldingAction.Job.JobNo != null ? nwf.WeldingAction.Job.JobNo.ToString() : nwf.WeldingAction.Job.QuoteNumber?.ToString();

                txtTechnicalDrawing.Text = nwf.DrawingNumber?.ToString() ?? "";
                txtTechnicalComponent.Text = nwf.ComponentDescription?.ToString() ?? "";
                dtpDetailsDate.Value = nwf.Date ?? DateTime.Now;
                txtTechnicalStandard.Text = nwf.WeldingStandard?.ToString() ?? "";
                txtTechnicalCategory.Text = nwf.WeldingCategory?.ToString() ?? "";
                txtTechnicalMatStandard.Text = nwf.MaterialStd?.ToString() ?? "";
                txtTechnicalNominal.Text = nwf.NominalStrength?.ToString() ?? "";
                txtTechnicalMatGrade.Text = nwf.MaterialGrd?.ToString() ?? "";
                txtTechnicalSuggested.Text = nwf.SuggestedProcess?.ToString() ?? "";
                txtTechnicalPosition.Text = nwf.WeldPosition?.ToString() ?? "";
                txtTechnicalJoint.Text = nwf.JointConfiguration?.ToString() ?? "";
                txtTechnicalQuality.Text = nwf.QualityReqs?.ToString() ?? "";
                txtTechnicalClient.Text = nwf.ClientReqs?.ToString() ?? "";
            }
        }

        private void uc_rqTechnical_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible)
            {
                if (this.Tag != null)
                {
                    Load_Action();
                }
            }
        }

        private void btnTechnicalDocuments_Click(object sender, EventArgs e)
        {
            if (up_rqFilesView1 == null)
            {
                up_rqFilesView1 = new up_rqFilesView();
                this.Controls.Add(up_rqFilesView1);
            }

            overlayPanel.Visible = true;

            up_rqFilesView1.Tag = this.Tag;

            up_rqFilesView1.ShowPopup(new Point(this.Width / 2 - up_rqFilesView1.Width / 2, this.Height / 2 - up_rqFilesView1.Height / 2), up_rqFilesView_Closed);
        }

        private void up_rqFilesView_Closed(UserControl up)
        {
            overlayPanel.Visible = false;
        }
    }
}
