﻿namespace WeldingManagement.UserControls.RequestControls
{
    partial class uc_rqOperational
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel8 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel9 = new Wisej.Web.TableLayoutPanel();
            this.tlpOperationForm = new Wisej.Web.TableLayoutPanel();
            this.tlpOperationWPS = new Wisej.Web.TableLayoutPanel();
            this.nudOperationWPS = new Wisej.Web.NumericUpDown();
            this.mscboOperationWPS = new WeldingManagement.UserControls.MultiSelectComboBox();
            this.tlpOperationWPQR = new Wisej.Web.TableLayoutPanel();
            this.nudOperationWPQR = new Wisej.Web.NumericUpDown();
            this.mscboOperationWPQR = new WeldingManagement.UserControls.MultiSelectComboBox();
            this.tlpOperationWelders = new Wisej.Web.TableLayoutPanel();
            this.nudOperationWelders = new Wisej.Web.NumericUpDown();
            this.mscboOperationWelders = new WeldingManagement.UserControls.MultiSelectComboBox();
            this.label2 = new Wisej.Web.Label();
            this.pbOperationPath = new Wisej.Web.PictureBox();
            this.cbOperationWPQR = new Wisej.Web.CheckBox();
            this.lblOperationWelders = new Wisej.Web.Label();
            this.dtpOperationalDate = new Wisej.Web.DateTimePicker();
            this.label71 = new Wisej.Web.Label();
            this.label36 = new Wisej.Web.Label();
            this.label35 = new Wisej.Web.Label();
            this.label34 = new Wisej.Web.Label();
            this.label33 = new Wisej.Web.Label();
            this.label32 = new Wisej.Web.Label();
            this.txtOperationThird = new Wisej.Web.TextBox();
            this.txtOperationEquipment = new Wisej.Web.TextBox();
            this.txtOperationFacilities = new Wisej.Web.TextBox();
            this.txtOperationStaff = new Wisej.Web.TextBox();
            this.txtOperationReviewer = new Wisej.Web.TextBox();
            this.label38 = new Wisej.Web.Label();
            this.label67 = new Wisej.Web.Label();
            this.cbOperationStaff = new Wisej.Web.CheckBox();
            this.cbOperationFacilities = new Wisej.Web.CheckBox();
            this.cbOperationEquipment = new Wisej.Web.CheckBox();
            this.cbOperationWPS = new Wisej.Web.CheckBox();
            this.cbOperationThird = new Wisej.Web.CheckBox();
            this.cbOperationWelders = new Wisej.Web.CheckBox();
            this.cbOperationSub = new Wisej.Web.CheckBox();
            this.cbOperationStorage = new Wisej.Web.CheckBox();
            this.cbOperationPWHT = new Wisej.Web.CheckBox();
            this.txtOperationSub = new Wisej.Web.TextBox();
            this.txtOperationStorage = new Wisej.Web.TextBox();
            this.txtOperationPWHT = new Wisej.Web.TextBox();
            this.txtOperationGeneral = new Wisej.Web.TextBox();
            this.txtOperationExtra = new Wisej.Web.TextBox();
            this.label39 = new Wisej.Web.Label();
            this.label40 = new Wisej.Web.Label();
            this.label41 = new Wisej.Web.Label();
            this.lblOperationWPS = new Wisej.Web.Label();
            this.lblOperationWPQR = new Wisej.Web.Label();
            this.label65 = new Wisej.Web.Label();
            this.label66 = new Wisej.Web.Label();
            this.label70 = new Wisej.Web.Label();
            this.tableLayoutPanel11 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel12 = new Wisej.Web.TableLayoutPanel();
            this.btnOperationDocuments = new Wisej.Web.Button();
            this.btnOperationBack = new Wisej.Web.Button();
            this.btnOperationHome = new Wisej.Web.Button();
            this.btnOperationComplete = new Wisej.Web.Button();
            this.tableLayoutPanel13 = new Wisej.Web.TableLayoutPanel();
            this.label68 = new Wisej.Web.Label();
            this.label69 = new Wisej.Web.Label();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tlpOperationForm.SuspendLayout();
            this.tlpOperationWPS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudOperationWPS)).BeginInit();
            this.tlpOperationWPQR.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudOperationWPQR)).BeginInit();
            this.tlpOperationWelders.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudOperationWelders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOperationPath)).BeginInit();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel8.ColumnCount = 3;
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel8.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel9, 1, 3);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel13, 1, 1);
            this.tableLayoutPanel8.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 5;
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel8.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel8.TabIndex = 5;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel9.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel9.Controls.Add(this.tlpOperationForm, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.tableLayoutPanel11, 1, 0);
            this.tableLayoutPanel9.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel9.TabIndex = 1;
            // 
            // tlpOperationForm
            // 
            this.tlpOperationForm.ColumnCount = 4;
            this.tlpOperationForm.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 30F));
            this.tlpOperationForm.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 30F));
            this.tlpOperationForm.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpOperationForm.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 30F));
            this.tlpOperationForm.Controls.Add(this.tlpOperationWPS, 1, 6);
            this.tlpOperationForm.Controls.Add(this.tlpOperationWPQR, 1, 7);
            this.tlpOperationForm.Controls.Add(this.tlpOperationWelders, 1, 8);
            this.tlpOperationForm.Controls.Add(this.label2, 3, 1);
            this.tlpOperationForm.Controls.Add(this.pbOperationPath, 3, 2);
            this.tlpOperationForm.Controls.Add(this.cbOperationWPQR, 2, 7);
            this.tlpOperationForm.Controls.Add(this.lblOperationWelders, 0, 8);
            this.tlpOperationForm.Controls.Add(this.dtpOperationalDate, 3, 0);
            this.tlpOperationForm.Controls.Add(this.label71, 2, 1);
            this.tlpOperationForm.Controls.Add(this.label36, 0, 2);
            this.tlpOperationForm.Controls.Add(this.label35, 0, 13);
            this.tlpOperationForm.Controls.Add(this.label34, 0, 12);
            this.tlpOperationForm.Controls.Add(this.label33, 1, 1);
            this.tlpOperationForm.Controls.Add(this.label32, 0, 1);
            this.tlpOperationForm.Controls.Add(this.txtOperationThird, 1, 5);
            this.tlpOperationForm.Controls.Add(this.txtOperationEquipment, 1, 4);
            this.tlpOperationForm.Controls.Add(this.txtOperationFacilities, 1, 3);
            this.tlpOperationForm.Controls.Add(this.txtOperationStaff, 1, 2);
            this.tlpOperationForm.Controls.Add(this.txtOperationReviewer, 1, 0);
            this.tlpOperationForm.Controls.Add(this.label38, 2, 0);
            this.tlpOperationForm.Controls.Add(this.label67, 0, 0);
            this.tlpOperationForm.Controls.Add(this.cbOperationStaff, 2, 2);
            this.tlpOperationForm.Controls.Add(this.cbOperationFacilities, 2, 3);
            this.tlpOperationForm.Controls.Add(this.cbOperationEquipment, 2, 4);
            this.tlpOperationForm.Controls.Add(this.cbOperationWPS, 2, 6);
            this.tlpOperationForm.Controls.Add(this.cbOperationThird, 2, 5);
            this.tlpOperationForm.Controls.Add(this.cbOperationWelders, 2, 8);
            this.tlpOperationForm.Controls.Add(this.cbOperationSub, 2, 9);
            this.tlpOperationForm.Controls.Add(this.cbOperationStorage, 2, 10);
            this.tlpOperationForm.Controls.Add(this.cbOperationPWHT, 2, 11);
            this.tlpOperationForm.Controls.Add(this.txtOperationSub, 1, 9);
            this.tlpOperationForm.Controls.Add(this.txtOperationStorage, 1, 10);
            this.tlpOperationForm.Controls.Add(this.txtOperationPWHT, 1, 11);
            this.tlpOperationForm.Controls.Add(this.txtOperationGeneral, 1, 12);
            this.tlpOperationForm.Controls.Add(this.txtOperationExtra, 1, 13);
            this.tlpOperationForm.Controls.Add(this.label39, 0, 3);
            this.tlpOperationForm.Controls.Add(this.label40, 0, 4);
            this.tlpOperationForm.Controls.Add(this.label41, 0, 5);
            this.tlpOperationForm.Controls.Add(this.lblOperationWPS, 0, 6);
            this.tlpOperationForm.Controls.Add(this.lblOperationWPQR, 0, 7);
            this.tlpOperationForm.Controls.Add(this.label65, 0, 9);
            this.tlpOperationForm.Controls.Add(this.label66, 0, 10);
            this.tlpOperationForm.Controls.Add(this.label70, 0, 11);
            this.tlpOperationForm.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpOperationForm.Location = new System.Drawing.Point(3, 3);
            this.tlpOperationForm.Name = "tlpOperationForm";
            this.tlpOperationForm.RowCount = 14;
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpOperationForm.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpOperationForm.Size = new System.Drawing.Size(1024, 433);
            this.tlpOperationForm.TabIndex = 6;
            // 
            // tlpOperationWPS
            // 
            this.tlpOperationWPS.ColumnCount = 2;
            this.tlpOperationWPS.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpOperationWPS.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpOperationWPS.Controls.Add(this.nudOperationWPS, 1, 0);
            this.tlpOperationWPS.Controls.Add(this.mscboOperationWPS, 0, 0);
            this.tlpOperationWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpOperationWPS.Location = new System.Drawing.Point(307, 150);
            this.tlpOperationWPS.Margin = new Wisej.Web.Padding(0);
            this.tlpOperationWPS.Name = "tlpOperationWPS";
            this.tlpOperationWPS.RowCount = 1;
            this.tlpOperationWPS.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpOperationWPS.Size = new System.Drawing.Size(307, 50);
            this.tlpOperationWPS.TabIndex = 88;
            // 
            // nudOperationWPS
            // 
            this.nudOperationWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.nudOperationWPS.Location = new System.Drawing.Point(156, 3);
            this.nudOperationWPS.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudOperationWPS.Name = "nudOperationWPS";
            this.nudOperationWPS.Size = new System.Drawing.Size(148, 44);
            this.nudOperationWPS.TabIndex = 9;
            this.nudOperationWPS.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            this.nudOperationWPS.UpDownAlign = Wisej.Web.HorizontalAlignment.Center;
            this.nudOperationWPS.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // mscboOperationWPS
            // 
            this.mscboOperationWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.mscboOperationWPS.Location = new System.Drawing.Point(3, 3);
            this.mscboOperationWPS.Name = "mscboOperationWPS";
            this.mscboOperationWPS.Size = new System.Drawing.Size(147, 44);
            this.mscboOperationWPS.TabIndex = 10;
            // 
            // tlpOperationWPQR
            // 
            this.tlpOperationWPQR.ColumnCount = 2;
            this.tlpOperationWPQR.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpOperationWPQR.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpOperationWPQR.Controls.Add(this.nudOperationWPQR, 1, 0);
            this.tlpOperationWPQR.Controls.Add(this.mscboOperationWPQR, 0, 0);
            this.tlpOperationWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpOperationWPQR.Location = new System.Drawing.Point(307, 200);
            this.tlpOperationWPQR.Margin = new Wisej.Web.Padding(0);
            this.tlpOperationWPQR.Name = "tlpOperationWPQR";
            this.tlpOperationWPQR.RowCount = 1;
            this.tlpOperationWPQR.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpOperationWPQR.Size = new System.Drawing.Size(307, 50);
            this.tlpOperationWPQR.TabIndex = 87;
            // 
            // nudOperationWPQR
            // 
            this.nudOperationWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.nudOperationWPQR.Location = new System.Drawing.Point(156, 3);
            this.nudOperationWPQR.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudOperationWPQR.Name = "nudOperationWPQR";
            this.nudOperationWPQR.Size = new System.Drawing.Size(148, 44);
            this.nudOperationWPQR.TabIndex = 12;
            this.nudOperationWPQR.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            this.nudOperationWPQR.UpDownAlign = Wisej.Web.HorizontalAlignment.Center;
            this.nudOperationWPQR.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // mscboOperationWPQR
            // 
            this.mscboOperationWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.mscboOperationWPQR.Location = new System.Drawing.Point(3, 3);
            this.mscboOperationWPQR.Name = "mscboOperationWPQR";
            this.mscboOperationWPQR.Size = new System.Drawing.Size(147, 44);
            this.mscboOperationWPQR.TabIndex = 13;
            // 
            // tlpOperationWelders
            // 
            this.tlpOperationWelders.ColumnCount = 2;
            this.tlpOperationWelders.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpOperationWelders.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpOperationWelders.Controls.Add(this.nudOperationWelders, 1, 0);
            this.tlpOperationWelders.Controls.Add(this.mscboOperationWelders, 0, 0);
            this.tlpOperationWelders.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpOperationWelders.Location = new System.Drawing.Point(307, 250);
            this.tlpOperationWelders.Margin = new Wisej.Web.Padding(0);
            this.tlpOperationWelders.Name = "tlpOperationWelders";
            this.tlpOperationWelders.RowCount = 1;
            this.tlpOperationWelders.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpOperationWelders.Size = new System.Drawing.Size(307, 50);
            this.tlpOperationWelders.TabIndex = 86;
            // 
            // nudOperationWelders
            // 
            this.nudOperationWelders.Dock = Wisej.Web.DockStyle.Fill;
            this.nudOperationWelders.Location = new System.Drawing.Point(156, 3);
            this.nudOperationWelders.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudOperationWelders.Name = "nudOperationWelders";
            this.nudOperationWelders.Size = new System.Drawing.Size(148, 44);
            this.nudOperationWelders.TabIndex = 15;
            this.nudOperationWelders.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            this.nudOperationWelders.UpDownAlign = Wisej.Web.HorizontalAlignment.Center;
            this.nudOperationWelders.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // mscboOperationWelders
            // 
            this.mscboOperationWelders.Dock = Wisej.Web.DockStyle.Fill;
            this.mscboOperationWelders.Location = new System.Drawing.Point(3, 3);
            this.mscboOperationWelders.Name = "mscboOperationWelders";
            this.mscboOperationWelders.Size = new System.Drawing.Size(147, 44);
            this.mscboOperationWelders.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(719, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(302, 19);
            this.label2.TabIndex = 78;
            this.label2.Text = "Current Action Path";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbOperationPath
            // 
            this.pbOperationPath.BackColor = System.Drawing.Color.FromName("@window");
            this.pbOperationPath.BackgroundImageLayout = Wisej.Web.ImageLayout.Zoom;
            this.pbOperationPath.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pbOperationPath.Dock = Wisej.Web.DockStyle.Fill;
            this.pbOperationPath.Location = new System.Drawing.Point(719, 53);
            this.pbOperationPath.Name = "pbOperationPath";
            this.tlpOperationForm.SetRowSpan(this.pbOperationPath, 10);
            this.pbOperationPath.Size = new System.Drawing.Size(302, 319);
            this.pbOperationPath.SizeMode = Wisej.Web.PictureBoxSizeMode.Zoom;
            // 
            // cbOperationWPQR
            // 
            this.cbOperationWPQR.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationWPQR.BackColor = System.Drawing.Color.FromName("@window");
            this.cbOperationWPQR.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationWPQR.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbOperationWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationWPQR.Location = new System.Drawing.Point(617, 203);
            this.cbOperationWPQR.Name = "cbOperationWPQR";
            this.cbOperationWPQR.Size = new System.Drawing.Size(96, 44);
            this.cbOperationWPQR.TabIndex = 11;
            this.cbOperationWPQR.CheckedChanged += new System.EventHandler(this.cbOperationWPQR_CheckedChanged);
            // 
            // lblOperationWelders
            // 
            this.lblOperationWelders.AutoSize = true;
            this.lblOperationWelders.BackColor = System.Drawing.Color.FromName("@window");
            this.lblOperationWelders.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.lblOperationWelders.Dock = Wisej.Web.DockStyle.Fill;
            this.lblOperationWelders.Location = new System.Drawing.Point(3, 253);
            this.lblOperationWelders.Name = "lblOperationWelders";
            this.lblOperationWelders.Size = new System.Drawing.Size(301, 44);
            this.lblOperationWelders.TabIndex = 74;
            this.lblOperationWelders.Text = "Qualified/Certified Welders Available";
            this.lblOperationWelders.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dtpOperationalDate
            // 
            this.dtpOperationalDate.Dock = Wisej.Web.DockStyle.Fill;
            this.dtpOperationalDate.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpOperationalDate.Location = new System.Drawing.Point(719, 3);
            this.dtpOperationalDate.Name = "dtpOperationalDate";
            this.dtpOperationalDate.Size = new System.Drawing.Size(302, 19);
            this.dtpOperationalDate.TabIndex = 73;
            this.dtpOperationalDate.Value = new System.DateTime(2024, 2, 19, 11, 44, 16, 923);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label71.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label71.Dock = Wisej.Web.DockStyle.Fill;
            this.label71.Location = new System.Drawing.Point(617, 28);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(96, 19);
            this.label71.TabIndex = 72;
            this.label71.Text = "No / Yes";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.FromName("@window");
            this.label36.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label36.Dock = Wisej.Web.DockStyle.Fill;
            this.label36.Location = new System.Drawing.Point(3, 53);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(301, 19);
            this.label36.TabIndex = 63;
            this.label36.Text = "Trained staff available";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.FromName("@window");
            this.label35.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label35.Dock = Wisej.Web.DockStyle.Fill;
            this.label35.Location = new System.Drawing.Point(3, 403);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(301, 27);
            this.label35.TabIndex = 62;
            this.label35.Text = "Extra Costs to Consider";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.FromName("@window");
            this.label34.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label34.Dock = Wisej.Web.DockStyle.Fill;
            this.label34.Location = new System.Drawing.Point(3, 378);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(301, 19);
            this.label34.TabIndex = 61;
            this.label34.Text = "General Comments";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label33.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label33.Dock = Wisej.Web.DockStyle.Fill;
            this.label33.Location = new System.Drawing.Point(310, 28);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(301, 19);
            this.label33.TabIndex = 53;
            this.label33.Text = "Comments";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label32.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label32.Dock = Wisej.Web.DockStyle.Fill;
            this.label32.Location = new System.Drawing.Point(3, 28);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(301, 19);
            this.label32.TabIndex = 52;
            this.label32.Text = "Items to Consider";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtOperationThird
            // 
            this.txtOperationThird.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationThird.Location = new System.Drawing.Point(310, 128);
            this.txtOperationThird.Name = "txtOperationThird";
            this.txtOperationThird.Size = new System.Drawing.Size(301, 19);
            this.txtOperationThird.TabIndex = 7;
            // 
            // txtOperationEquipment
            // 
            this.txtOperationEquipment.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationEquipment.Location = new System.Drawing.Point(310, 103);
            this.txtOperationEquipment.Name = "txtOperationEquipment";
            this.txtOperationEquipment.Size = new System.Drawing.Size(301, 19);
            this.txtOperationEquipment.TabIndex = 5;
            // 
            // txtOperationFacilities
            // 
            this.txtOperationFacilities.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationFacilities.Location = new System.Drawing.Point(310, 78);
            this.txtOperationFacilities.Name = "txtOperationFacilities";
            this.txtOperationFacilities.Size = new System.Drawing.Size(301, 19);
            this.txtOperationFacilities.TabIndex = 3;
            // 
            // txtOperationStaff
            // 
            this.txtOperationStaff.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationStaff.Location = new System.Drawing.Point(310, 53);
            this.txtOperationStaff.Name = "txtOperationStaff";
            this.txtOperationStaff.Size = new System.Drawing.Size(301, 19);
            this.txtOperationStaff.TabIndex = 1;
            // 
            // txtOperationReviewer
            // 
            this.txtOperationReviewer.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationReviewer.Location = new System.Drawing.Point(310, 3);
            this.txtOperationReviewer.Name = "txtOperationReviewer";
            this.txtOperationReviewer.ReadOnly = true;
            this.txtOperationReviewer.Size = new System.Drawing.Size(301, 19);
            this.txtOperationReviewer.TabIndex = 24;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.FromName("@window");
            this.label38.Dock = Wisej.Web.DockStyle.Fill;
            this.label38.Location = new System.Drawing.Point(617, 3);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(96, 19);
            this.label38.TabIndex = 13;
            this.label38.Text = "Date";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.BackColor = System.Drawing.Color.FromName("@window");
            this.label67.Dock = Wisej.Web.DockStyle.Fill;
            this.label67.Location = new System.Drawing.Point(3, 3);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(301, 19);
            this.label67.TabIndex = 0;
            this.label67.Text = "Operational Reviewer EID";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbOperationStaff
            // 
            this.cbOperationStaff.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationStaff.BackColor = System.Drawing.Color.FromName("@window");
            this.cbOperationStaff.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationStaff.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbOperationStaff.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationStaff.Location = new System.Drawing.Point(617, 53);
            this.cbOperationStaff.Name = "cbOperationStaff";
            this.cbOperationStaff.Size = new System.Drawing.Size(96, 19);
            this.cbOperationStaff.TabIndex = 0;
            // 
            // cbOperationFacilities
            // 
            this.cbOperationFacilities.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationFacilities.BackColor = System.Drawing.Color.FromName("@window");
            this.cbOperationFacilities.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationFacilities.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbOperationFacilities.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationFacilities.Location = new System.Drawing.Point(617, 78);
            this.cbOperationFacilities.Name = "cbOperationFacilities";
            this.cbOperationFacilities.Size = new System.Drawing.Size(96, 19);
            this.cbOperationFacilities.TabIndex = 2;
            // 
            // cbOperationEquipment
            // 
            this.cbOperationEquipment.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationEquipment.BackColor = System.Drawing.Color.FromName("@window");
            this.cbOperationEquipment.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationEquipment.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbOperationEquipment.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationEquipment.Location = new System.Drawing.Point(617, 103);
            this.cbOperationEquipment.Name = "cbOperationEquipment";
            this.cbOperationEquipment.Size = new System.Drawing.Size(96, 19);
            this.cbOperationEquipment.TabIndex = 4;
            // 
            // cbOperationWPS
            // 
            this.cbOperationWPS.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationWPS.BackColor = System.Drawing.Color.FromName("@window");
            this.cbOperationWPS.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationWPS.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbOperationWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationWPS.Location = new System.Drawing.Point(617, 153);
            this.cbOperationWPS.Name = "cbOperationWPS";
            this.cbOperationWPS.Size = new System.Drawing.Size(96, 44);
            this.cbOperationWPS.TabIndex = 8;
            this.cbOperationWPS.CheckedChanged += new System.EventHandler(this.cbOperationWPS_CheckedChanged);
            // 
            // cbOperationThird
            // 
            this.cbOperationThird.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationThird.BackColor = System.Drawing.Color.FromName("@window");
            this.cbOperationThird.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationThird.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbOperationThird.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationThird.Location = new System.Drawing.Point(617, 128);
            this.cbOperationThird.Name = "cbOperationThird";
            this.cbOperationThird.Size = new System.Drawing.Size(96, 19);
            this.cbOperationThird.TabIndex = 6;
            // 
            // cbOperationWelders
            // 
            this.cbOperationWelders.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationWelders.BackColor = System.Drawing.Color.FromName("@window");
            this.cbOperationWelders.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationWelders.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbOperationWelders.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationWelders.Location = new System.Drawing.Point(617, 253);
            this.cbOperationWelders.Name = "cbOperationWelders";
            this.cbOperationWelders.Size = new System.Drawing.Size(96, 44);
            this.cbOperationWelders.TabIndex = 14;
            this.cbOperationWelders.CheckedChanged += new System.EventHandler(this.cbOperationWelders_CheckedChanged);
            // 
            // cbOperationSub
            // 
            this.cbOperationSub.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationSub.BackColor = System.Drawing.Color.FromName("@window");
            this.cbOperationSub.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationSub.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbOperationSub.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationSub.Location = new System.Drawing.Point(617, 303);
            this.cbOperationSub.Name = "cbOperationSub";
            this.cbOperationSub.Size = new System.Drawing.Size(96, 19);
            this.cbOperationSub.TabIndex = 17;
            // 
            // cbOperationStorage
            // 
            this.cbOperationStorage.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationStorage.BackColor = System.Drawing.Color.FromName("@window");
            this.cbOperationStorage.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationStorage.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbOperationStorage.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationStorage.Location = new System.Drawing.Point(617, 328);
            this.cbOperationStorage.Name = "cbOperationStorage";
            this.cbOperationStorage.Size = new System.Drawing.Size(96, 19);
            this.cbOperationStorage.TabIndex = 19;
            // 
            // cbOperationPWHT
            // 
            this.cbOperationPWHT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbOperationPWHT.BackColor = System.Drawing.Color.FromName("@window");
            this.cbOperationPWHT.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbOperationPWHT.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbOperationPWHT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbOperationPWHT.Location = new System.Drawing.Point(617, 353);
            this.cbOperationPWHT.Name = "cbOperationPWHT";
            this.cbOperationPWHT.Size = new System.Drawing.Size(96, 19);
            this.cbOperationPWHT.TabIndex = 21;
            // 
            // txtOperationSub
            // 
            this.txtOperationSub.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationSub.Location = new System.Drawing.Point(310, 303);
            this.txtOperationSub.Name = "txtOperationSub";
            this.txtOperationSub.Size = new System.Drawing.Size(301, 19);
            this.txtOperationSub.TabIndex = 18;
            // 
            // txtOperationStorage
            // 
            this.txtOperationStorage.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationStorage.Location = new System.Drawing.Point(310, 328);
            this.txtOperationStorage.Name = "txtOperationStorage";
            this.txtOperationStorage.Size = new System.Drawing.Size(301, 19);
            this.txtOperationStorage.TabIndex = 20;
            // 
            // txtOperationPWHT
            // 
            this.txtOperationPWHT.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationPWHT.Location = new System.Drawing.Point(310, 353);
            this.txtOperationPWHT.Name = "txtOperationPWHT";
            this.txtOperationPWHT.Size = new System.Drawing.Size(301, 19);
            this.txtOperationPWHT.TabIndex = 22;
            // 
            // txtOperationGeneral
            // 
            this.tlpOperationForm.SetColumnSpan(this.txtOperationGeneral, 3);
            this.txtOperationGeneral.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationGeneral.Location = new System.Drawing.Point(310, 378);
            this.txtOperationGeneral.Multiline = true;
            this.txtOperationGeneral.Name = "txtOperationGeneral";
            this.txtOperationGeneral.Size = new System.Drawing.Size(711, 19);
            this.txtOperationGeneral.TabIndex = 23;
            // 
            // txtOperationExtra
            // 
            this.tlpOperationForm.SetColumnSpan(this.txtOperationExtra, 3);
            this.txtOperationExtra.Dock = Wisej.Web.DockStyle.Fill;
            this.txtOperationExtra.Location = new System.Drawing.Point(310, 403);
            this.txtOperationExtra.Multiline = true;
            this.txtOperationExtra.Name = "txtOperationExtra";
            this.txtOperationExtra.Size = new System.Drawing.Size(711, 27);
            this.txtOperationExtra.TabIndex = 24;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.FromName("@window");
            this.label39.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label39.Dock = Wisej.Web.DockStyle.Fill;
            this.label39.Location = new System.Drawing.Point(3, 78);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(301, 19);
            this.label39.TabIndex = 64;
            this.label39.Text = "Facilities available";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.FromName("@window");
            this.label40.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label40.Dock = Wisej.Web.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(3, 103);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(301, 19);
            this.label40.TabIndex = 65;
            this.label40.Text = "Equipment available";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.FromName("@window");
            this.label41.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label41.Dock = Wisej.Web.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(3, 128);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(301, 19);
            this.label41.TabIndex = 66;
            this.label41.Text = "Third party involvement ";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblOperationWPS
            // 
            this.lblOperationWPS.AutoSize = true;
            this.lblOperationWPS.BackColor = System.Drawing.Color.FromName("@window");
            this.lblOperationWPS.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.lblOperationWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.lblOperationWPS.Location = new System.Drawing.Point(3, 153);
            this.lblOperationWPS.Name = "lblOperationWPS";
            this.lblOperationWPS.Size = new System.Drawing.Size(301, 44);
            this.lblOperationWPS.TabIndex = 67;
            this.lblOperationWPS.Text = "Qualified WPS available";
            this.lblOperationWPS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblOperationWPQR
            // 
            this.lblOperationWPQR.AutoSize = true;
            this.lblOperationWPQR.BackColor = System.Drawing.Color.FromName("@window");
            this.lblOperationWPQR.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.lblOperationWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.lblOperationWPQR.Location = new System.Drawing.Point(3, 203);
            this.lblOperationWPQR.Name = "lblOperationWPQR";
            this.lblOperationWPQR.Size = new System.Drawing.Size(301, 44);
            this.lblOperationWPQR.TabIndex = 68;
            this.lblOperationWPQR.Text = "Qualified WPQR Available";
            this.lblOperationWPQR.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.Color.FromName("@window");
            this.label65.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label65.Dock = Wisej.Web.DockStyle.Fill;
            this.label65.Location = new System.Drawing.Point(3, 303);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(301, 19);
            this.label65.TabIndex = 69;
            this.label65.Text = "Subcontractors to be used";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.BackColor = System.Drawing.Color.FromName("@window");
            this.label66.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label66.Dock = Wisej.Web.DockStyle.Fill;
            this.label66.Location = new System.Drawing.Point(3, 328);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(301, 19);
            this.label66.TabIndex = 70;
            this.label66.Text = "Dedicated storage of parent material & welding consumables required";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.Color.FromName("@window");
            this.label70.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label70.Dock = Wisej.Web.DockStyle.Fill;
            this.label70.Location = new System.Drawing.Point(3, 353);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(301, 19);
            this.label70.TabIndex = 71;
            this.label70.Text = "Post-Weld Heat treatment required";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.tableLayoutPanel12, 0, 0);
            this.tableLayoutPanel11.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel11.TabIndex = 5;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel12.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.btnOperationDocuments, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.btnOperationBack, 0, 2);
            this.tableLayoutPanel12.Controls.Add(this.btnOperationHome, 0, 3);
            this.tableLayoutPanel12.Controls.Add(this.btnOperationComplete, 0, 4);
            this.tableLayoutPanel12.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel12.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 5;
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel12.TabIndex = 4;
            // 
            // btnOperationDocuments
            // 
            this.btnOperationDocuments.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnOperationDocuments.Dock = Wisej.Web.DockStyle.Fill;
            this.btnOperationDocuments.Location = new System.Drawing.Point(3, 3);
            this.btnOperationDocuments.Name = "btnOperationDocuments";
            this.btnOperationDocuments.Size = new System.Drawing.Size(95, 79);
            this.btnOperationDocuments.TabIndex = 28;
            this.btnOperationDocuments.Text = "View Linked Documents";
            this.btnOperationDocuments.Click += new System.EventHandler(this.btnOperationDocuments_Click);
            // 
            // btnOperationBack
            // 
            this.btnOperationBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnOperationBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnOperationBack.Location = new System.Drawing.Point(3, 173);
            this.btnOperationBack.Name = "btnOperationBack";
            this.btnOperationBack.Size = new System.Drawing.Size(95, 79);
            this.btnOperationBack.TabIndex = 27;
            this.btnOperationBack.Text = "Back";
            this.btnOperationBack.Click += new System.EventHandler(this.btnOperationBack_Click);
            // 
            // btnOperationHome
            // 
            this.btnOperationHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnOperationHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnOperationHome.Location = new System.Drawing.Point(3, 258);
            this.btnOperationHome.Name = "btnOperationHome";
            this.btnOperationHome.Size = new System.Drawing.Size(95, 79);
            this.btnOperationHome.TabIndex = 26;
            this.btnOperationHome.Text = "Home";
            this.btnOperationHome.Click += new System.EventHandler(this.btnOperationHome_Click);
            // 
            // btnOperationComplete
            // 
            this.btnOperationComplete.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnOperationComplete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnOperationComplete.Location = new System.Drawing.Point(3, 343);
            this.btnOperationComplete.Name = "btnOperationComplete";
            this.btnOperationComplete.Size = new System.Drawing.Size(95, 79);
            this.btnOperationComplete.TabIndex = 25;
            this.btnOperationComplete.Text = "Complete";
            this.btnOperationComplete.Click += new System.EventHandler(this.btnOperationComplete_Click);
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel13.Controls.Add(this.label68, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.label69, 0, 0);
            this.tableLayoutPanel13.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel13.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label68.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label68.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.label68.Dock = Wisej.Web.DockStyle.Fill;
            this.label68.Location = new System.Drawing.Point(6, 79);
            this.label68.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(1133, 35);
            this.label68.TabIndex = 1;
            this.label68.Text = "Notes";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label69.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label69.CssStyle = "border-radius: 4px;";
            this.label69.Dock = Wisej.Web.DockStyle.Fill;
            this.label69.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label69.Location = new System.Drawing.Point(6, 3);
            this.label69.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(1133, 70);
            this.label69.TabIndex = 0;
            this.label69.Text = "Operational Review";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uc_rqOperational
            // 
            this.Controls.Add(this.tableLayoutPanel8);
            this.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.Name = "uc_rqOperational";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_rqOperational_VisibleChanged);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tlpOperationForm.ResumeLayout(false);
            this.tlpOperationForm.PerformLayout();
            this.tlpOperationWPS.ResumeLayout(false);
            this.tlpOperationWPS.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudOperationWPS)).EndInit();
            this.tlpOperationWPQR.ResumeLayout(false);
            this.tlpOperationWPQR.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudOperationWPQR)).EndInit();
            this.tlpOperationWelders.ResumeLayout(false);
            this.tlpOperationWelders.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudOperationWelders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOperationPath)).EndInit();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel8;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel9;
        private Wisej.Web.TableLayoutPanel tlpOperationForm;
        private Wisej.Web.Label label71;
        private Wisej.Web.Label label36;
        private Wisej.Web.Label label35;
        private Wisej.Web.Label label34;
        private Wisej.Web.Label label33;
        private Wisej.Web.Label label32;
        private Wisej.Web.TextBox txtOperationThird;
        private Wisej.Web.TextBox txtOperationEquipment;
        private Wisej.Web.TextBox txtOperationFacilities;
        private Wisej.Web.TextBox txtOperationStaff;
        private Wisej.Web.TextBox txtOperationReviewer;
        private Wisej.Web.Label label38;
        private Wisej.Web.Label label67;
        private Wisej.Web.CheckBox cbOperationStaff;
        private Wisej.Web.CheckBox cbOperationFacilities;
        private Wisej.Web.CheckBox cbOperationEquipment;
        private Wisej.Web.CheckBox cbOperationWPS;
        private Wisej.Web.CheckBox cbOperationThird;
        private Wisej.Web.CheckBox cbOperationWelders;
        private Wisej.Web.CheckBox cbOperationSub;
        private Wisej.Web.CheckBox cbOperationStorage;
        private Wisej.Web.CheckBox cbOperationPWHT;
        private Wisej.Web.TextBox txtOperationSub;
        private Wisej.Web.TextBox txtOperationStorage;
        private Wisej.Web.TextBox txtOperationPWHT;
        private Wisej.Web.TextBox txtOperationGeneral;
        private Wisej.Web.TextBox txtOperationExtra;
        private Wisej.Web.Label label39;
        private Wisej.Web.Label label40;
        private Wisej.Web.Label label41;
        private Wisej.Web.Label lblOperationWPS;
        private Wisej.Web.Label lblOperationWPQR;
        private Wisej.Web.Label label65;
        private Wisej.Web.Label label66;
        private Wisej.Web.Label label70;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel11;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel12;
        private Wisej.Web.Button btnOperationBack;
        private Wisej.Web.Button btnOperationHome;
        private Wisej.Web.Button btnOperationComplete;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel13;
        private Wisej.Web.Label label68;
        private Wisej.Web.Label label69;
        private Wisej.Web.DateTimePicker dtpOperationalDate;
        private Wisej.Web.CheckBox cbOperationWPQR;
        private Wisej.Web.Label lblOperationWelders;
        private Wisej.Web.Label label2;
        private Wisej.Web.PictureBox pbOperationPath;
        private Wisej.Web.TableLayoutPanel tlpOperationWelders;
        private Wisej.Web.NumericUpDown nudOperationWelders;
        private MultiSelectComboBox mscboOperationWelders;
        private Wisej.Web.TableLayoutPanel tlpOperationWPQR;
        private Wisej.Web.NumericUpDown nudOperationWPQR;
        private MultiSelectComboBox mscboOperationWPQR;
        private Wisej.Web.TableLayoutPanel tlpOperationWPS;
        private Wisej.Web.NumericUpDown nudOperationWPS;
        private MultiSelectComboBox mscboOperationWPS;
        private Wisej.Web.Button btnOperationDocuments;
    }
}
