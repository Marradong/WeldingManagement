﻿using ApiClient;
using System;
using System.ComponentModel;
using System.Drawing;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.RequestControls
{
    public partial class uc_rqDetails : Wisej.Web.UserControl
    {
        private up_hmSave up_hmSave1;
        private Panel overlayPanel;

        public uc_rqDetails()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks next button on details screen")]
        public event EventHandler btnDetailsNextClick;
        private void btnDetailsNext_Click(object sender, EventArgs e)
        {
            Save_Action();
            Update_Status();

            btnDetailsNextClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on details screen")]
        public event EventHandler btnDetailsHomeClick;
        private void btnDetailsHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnDetailsHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks bacl button on details screen")]
        public event EventHandler btnDetailsBackClick;
        private void btnDetailsBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnDetailsBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnDetailsBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                nwf.Status = Actions.ProvideDocumentation;

                ApiCalls.UpdateNewWeldingForm(nwf.NewWeldingFormId, nwf);

                this.Tag = new Tag(ApiCalls.ReadNewWeldingForm(nwf.NewWeldingFormId), TagType.New_Welding_Form);
            }
        }

        private void Save_Action() 
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                if (txtDetailsDrawing.Text != null)
                    nwf.DrawingNumber = txtDetailsDrawing.Text;
                if (txtDetailsComponent.Text != null)
                    nwf.ComponentDescription = txtDetailsComponent.Text;
                if (txtDetailsStandard.Text != null)
                    nwf.WeldingStandard = txtDetailsStandard.Text;
                if (txtDetailsCategory.Text != null)
                    nwf.WeldingCategory = txtDetailsCategory.Text;
                if (txtDetailsMatStandard.Text != null)
                    nwf.MaterialStd = txtDetailsMatStandard.Text;
                if (txtDetailsNominal.Text != null)
                    nwf.NominalStrength = txtDetailsNominal.Text;
                if (txtDetailsMatGrade.Text != null)
                    nwf.MaterialGrd = txtDetailsMatGrade.Text;
                if (txtDetailsSuggested.Text != null)
                    nwf.SuggestedProcess = txtDetailsSuggested.Text;
                if (txtDetailsPosition.Text != null)
                    nwf.WeldPosition = txtDetailsPosition.Text;
                if (txtDetailsJoint.Text != null)
                    nwf.JointConfiguration = txtDetailsJoint.Text;
                if (txtDetailsQuality.Text != null)
                    nwf.QualityReqs = txtDetailsQuality.Text;
                if (txtDetailsClient.Text != null)
                    nwf.ClientReqs = txtDetailsClient.Text;

                nwf.Date = dtpDetailsDate.Value;

                ApiCalls.UpdateNewWeldingForm(nwf.NewWeldingFormId, nwf);

                this.Tag = new Tag(ApiCalls.ReadNewWeldingForm(nwf.NewWeldingFormId), TagType.New_Welding_Form);
            }
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                txtDetailsJob.Text = nwf.WeldingAction.Job.JobNo != null ? nwf.WeldingAction.Job.JobNo.ToString() : nwf.WeldingAction.Job.QuoteNumber?.ToString();

                txtDetailsDrawing.Text = nwf.DrawingNumber?.ToString() ?? "";
                txtDetailsComponent.Text = nwf.ComponentDescription?.ToString() ?? "";
                dtpDetailsDate.Value = nwf.Date ?? DateTime.Now;
                txtDetailsStandard.Text = nwf.WeldingStandard?.ToString() ?? "";
                txtDetailsCategory.Text = nwf.WeldingCategory?.ToString() ?? "";
                txtDetailsMatStandard.Text = nwf.MaterialStd?.ToString() ?? "";
                txtDetailsNominal.Text = nwf.NominalStrength?.ToString() ?? "";
                txtDetailsMatGrade.Text = nwf.MaterialGrd?.ToString() ?? "";
                txtDetailsSuggested.Text = nwf.SuggestedProcess?.ToString() ?? "";
                txtDetailsPosition.Text = nwf.WeldPosition?.ToString() ?? "";
                txtDetailsJoint.Text = nwf.JointConfiguration?.ToString() ?? "";
                txtDetailsQuality.Text = nwf.QualityReqs?.ToString() ?? "";
                txtDetailsClient.Text = nwf.ClientReqs?.ToString() ?? "";
            }
        }

        private void uc_rqDetails_VisibleChanged(object sender, EventArgs e)
        {
            if(this.Visible)
            {
                if (this.Tag != null)
                {
                    Load_Action();
                }
            }
        }
    }
}
