﻿using ApiClient;
using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.FileManagement;

namespace WeldingManagement.UserControls.RequestControls
{
    public partial class uc_rqDocuments : Wisej.Web.UserControl
    {
        public uc_rqDocuments()
        {
            InitializeComponent();
        }

        #region Navigation Events

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on documents screen")]
        public event EventHandler btnDocumentsCompleteClick;
        private void btnDocumentsComplete_Click(object sender, EventArgs e)
        {
            Update_Status();

            btnDocumentsCompleteClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on documents screen")]
        public event EventHandler btnDocumentsHomeClick;
        private void btnDocumentsHome_Click(object sender, EventArgs e)
        {
            btnDocumentsHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on documents screen")]
        public event EventHandler btnDocumentsBackClick;
        private void btnDocumentsBack_Click(object sender, EventArgs e)
        {
            btnDocumentsBackClick?.Invoke(this, e);
        }

        #endregion

        private void uplDocumentsProvide_Uploaded(object sender, UploadedEventArgs e)
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                for (int i = 0; i < e.Files.Count; i++)
                {
                    AttachmentTypes attType = AttachmentTypes.Other;

                    if (rbDocumentsDrawing.Checked)
                    {
                        nwf.DrawingProvided = true;
                        rbDocumentsDrawing.Checked = false;
                        attType = AttachmentTypes.Component_Drawing;
                    }
                    else if (rbDocumentsFabrication.Checked)
                    {
                        nwf.SpecificationsProvided = true;
                        rbDocumentsFabrication.Checked = false;
                        attType = AttachmentTypes.Fabrication_Specification;
                    }
                    else if (rbDocumentsSymbols.Checked)
                    {
                        nwf.SymbolsProvided = true;
                        rbDocumentsSymbols.Checked = false;
                        attType = AttachmentTypes.Weld_Symbols;
                    }
                    else if (rbDocumentsIssued.Checked)
                    {
                        nwf.ProceduresProvided = true;
                        rbDocumentsIssued.Checked = false;
                        attType = AttachmentTypes.Client_Procedure;
                    }
                    else if (rbDocumentsHistory.Checked)
                    {
                        nwf.HistoryProvided = true;
                        rbDocumentsHistory.Checked = false;
                        attType = AttachmentTypes.Treatment_History;
                    }
                    else if (rbDocumentsPhotos.Checked)
                    {
                        nwf.PhotosProvided = true;
                        rbDocumentsPhotos.Checked = false;
                        attType = AttachmentTypes.Component_Photo;
                    }
                    else if (rbDocumentsRecord.Checked)
                    {
                        nwf.RepairProvided = true;
                        rbDocumentsRecord.Checked = false;
                        attType = AttachmentTypes.Repair_Record;
                    }
                    else if (rbDocumentsParent.Checked)
                    {
                        nwf.ParentProvided = true;
                        rbDocumentsParent.Checked = false;
                        attType = AttachmentTypes.Parent_Specification;
                    }
                    else if (rbDocumentsPWHT.Checked)
                    {
                        nwf.PWHTProvided = true;
                        rbDocumentsPWHT.Checked = false;
                        attType = AttachmentTypes.PWHT_Requirements;
                    }
                    else if (rbDocumentsNDT.Checked)
                    {
                        nwf.NDTProvided = true;
                        rbDocumentsNDT.Checked = false;
                        attType = AttachmentTypes.NDT_Standard;
                    }

                    StoreFile(e.Files[i], attType, nwf.WeldingAction.Job.QuoteNumber, typeof(NewWeldingForm), nwf.NewWeldingFormId);
                }

                ApiCalls.UpdateNewWeldingForm(nwf.NewWeldingFormId, nwf);

                this.Tag = new Tag(ApiCalls.ReadNewWeldingForm(nwf.NewWeldingFormId), TagType.New_Welding_Form);

                Load_Action();
            }
        }

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                nwf.Status = Actions.TechnicalReview;

                ApiCalls.UpdateNewWeldingForm(nwf.NewWeldingFormId, nwf);

                this.Tag = new Tag(ApiCalls.ReadNewWeldingForm(nwf.NewWeldingFormId), TagType.New_Welding_Form);
            }
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.New_Welding_Form)
            {
                NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                lvDocuments.Items.Clear();

                foreach (Attachment att in nwf.Attachments)
                {
                    ListViewItem lvItem = new ListViewItem(new string[] { att.ServerPath.Split('\\').Last(), UIFormatting.GetEnumDisplayName(att.AttachmentType) });
                    lvItem.Tag = new Tag(att, TagType.Attachment);
                    lvDocuments.Items.Add(lvItem);
                }

                lvDocuments.Refresh();
            }

            UIFormatting.ResizeColumnsFor(lvDocuments);

            if (pbDocuments != null && pbDocuments.Image != null)
            {
                pbDocuments.Image.Dispose();
            }

            if (pvDocuments != null && pvDocuments.PdfStream != null)
            {
                pvDocuments.PdfStream = null;
            }

            pvDocuments.Visible = true;
            pbDocuments.Visible = false;

            tlpDocuments.RowStyles[tlpDocuments.GetCellPosition(pvDocuments).Row].SizeType = SizeType.Percent;
            tlpDocuments.RowStyles[tlpDocuments.GetCellPosition(pvDocuments).Row].Height = 80;

            tlpDocuments.RowStyles[tlpDocuments.GetCellPosition(pbDocuments).Row].SizeType = SizeType.Percent;
            tlpDocuments.RowStyles[tlpDocuments.GetCellPosition(pbDocuments).Row].Height = 0;

            rbDocumentsDrawing.Checked = false;
            rbDocumentsFabrication.Checked = false;
            rbDocumentsSymbols.Checked = false;
            rbDocumentsIssued.Checked = false;
            rbDocumentsHistory.Checked = false;
            rbDocumentsPhotos.Checked = false;
            rbDocumentsRecord.Checked = false;
            rbDocumentsParent.Checked = false;
            rbDocumentsPWHT.Checked = false;
            rbDocumentsNDT.Checked = false;
            uplDocumentsProvide_isVisible();
        }

        private void uc_rqDocuments_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible && this.Dock == DockStyle.Fill)
            {
                if (this.Tag != null)
                {
                    Load_Action();
                }
            }
        }

        private void lvDocuments_Resize(object sender, EventArgs e)
        {
            if (this.Visible && this.Dock == Wisej.Web.DockStyle.Fill)
            {
                UIFormatting.ResizeColumnsFor(lvDocuments);
            }
        }

        private void lvDocuments_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvDocuments.SelectedIndex >= 0)
            {
                Tag itemTag = (Tag)lvDocuments.Items[lvDocuments.SelectedIndex].Tag;

                ViewAttachment(itemTag, pbDocuments, pvDocuments, tlpDocuments);
            }
        }

        private void btnDocumentsDelete_Click(object sender, EventArgs e)
        {
            if (lvDocuments.SelectedIndex >= 0)
            {
                Tag itemTag = (Tag)lvDocuments.Items[lvDocuments.SelectedIndex].Tag;

                DeleteAttachment(itemTag, pbDocuments, pvDocuments);

                Load_Action();
            }
        }

        private void rbDocumentsDrawing_CheckedChanged(object sender, EventArgs e)
        {
            uplDocumentsProvide_isVisible();
        }

        private void uplDocumentsProvide_isVisible()
        {
            bool readableCond1 = rbDocumentsDrawing.Checked || rbDocumentsFabrication.Checked || rbDocumentsHistory.Checked;
            bool readableCond2 = rbDocumentsIssued.Checked || rbDocumentsNDT.Checked || rbDocumentsParent.Checked || rbDocumentsSymbols.Checked;
            bool readableCond3 = rbDocumentsPhotos.Checked || rbDocumentsPWHT.Checked || rbDocumentsRecord.Checked;

            uplDocumentsProvide.Visible = readableCond1 || readableCond2 || readableCond3;
        }
    }
}
