﻿namespace WeldingManagement.UserControls.RequestControls
{
    partial class uc_rqDetails
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel20 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel21 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.dtpDetailsDate = new Wisej.Web.DateTimePicker();
            this.txtDetailsClient = new Wisej.Web.TextBox();
            this.txtDetailsJoint = new Wisej.Web.TextBox();
            this.txtDetailsSuggested = new Wisej.Web.TextBox();
            this.txtDetailsNominal = new Wisej.Web.TextBox();
            this.txtDetailsCategory = new Wisej.Web.TextBox();
            this.txtDetailsDrawing = new Wisej.Web.TextBox();
            this.txtDetailsMatGrade = new Wisej.Web.TextBox();
            this.txtDetailsMatStandard = new Wisej.Web.TextBox();
            this.txtDetailsStandard = new Wisej.Web.TextBox();
            this.txtDetailsComponent = new Wisej.Web.TextBox();
            this.txtDetailsJob = new Wisej.Web.TextBox();
            this.label42 = new Wisej.Web.Label();
            this.label43 = new Wisej.Web.Label();
            this.label44 = new Wisej.Web.Label();
            this.label45 = new Wisej.Web.Label();
            this.label46 = new Wisej.Web.Label();
            this.label47 = new Wisej.Web.Label();
            this.label30 = new Wisej.Web.Label();
            this.label51 = new Wisej.Web.Label();
            this.label52 = new Wisej.Web.Label();
            this.label54 = new Wisej.Web.Label();
            this.label55 = new Wisej.Web.Label();
            this.label58 = new Wisej.Web.Label();
            this.label59 = new Wisej.Web.Label();
            this.label31 = new Wisej.Web.Label();
            this.txtDetailsPosition = new Wisej.Web.TextBox();
            this.txtDetailsQuality = new Wisej.Web.TextBox();
            this.tableLayoutPanel23 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel31 = new Wisej.Web.TableLayoutPanel();
            this.btnDetailsBack = new Wisej.Web.Button();
            this.btnDetailsHome = new Wisej.Web.Button();
            this.btnDetailsNext = new Wisej.Web.Button();
            this.tableLayoutPanel24 = new Wisej.Web.TableLayoutPanel();
            this.label77 = new Wisej.Web.Label();
            this.label78 = new Wisej.Web.Label();
            this.tableLayoutPanel20.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel20.ColumnCount = 3;
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel21, 1, 3);
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel24, 1, 1);
            this.tableLayoutPanel20.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 5;
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel20.TabIndex = 4;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel21.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel1, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel23, 1, 0);
            this.tableLayoutPanel21.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel21.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 70F));
            this.tableLayoutPanel1.Controls.Add(this.dtpDetailsDate, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsClient, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsJoint, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsSuggested, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsNominal, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsCategory, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsDrawing, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsMatGrade, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsMatStandard, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsStandard, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsComponent, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsJob, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label42, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.label43, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label44, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.label45, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.label46, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.label47, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label30, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label51, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label52, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label54, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.label55, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label58, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label59, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label31, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsPosition, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.txtDetailsQuality, 1, 12);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 14;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 7.5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel1.TabIndex = 6;
            // 
            // dtpDetailsDate
            // 
            this.dtpDetailsDate.Dock = Wisej.Web.DockStyle.Fill;
            this.dtpDetailsDate.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpDetailsDate.Location = new System.Drawing.Point(310, 33);
            this.dtpDetailsDate.Name = "dtpDetailsDate";
            this.dtpDetailsDate.Size = new System.Drawing.Size(711, 24);
            this.dtpDetailsDate.TabIndex = 1;
            this.dtpDetailsDate.Value = new System.DateTime(2024, 2, 6, 13, 21, 27, 859);
            // 
            // txtDetailsClient
            // 
            this.txtDetailsClient.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsClient.Location = new System.Drawing.Point(310, 393);
            this.txtDetailsClient.Name = "txtDetailsClient";
            this.txtDetailsClient.Size = new System.Drawing.Size(711, 37);
            this.txtDetailsClient.TabIndex = 13;
            // 
            // txtDetailsJoint
            // 
            this.txtDetailsJoint.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsJoint.Location = new System.Drawing.Point(310, 273);
            this.txtDetailsJoint.Name = "txtDetailsJoint";
            this.txtDetailsJoint.Size = new System.Drawing.Size(711, 24);
            this.txtDetailsJoint.TabIndex = 9;
            // 
            // txtDetailsSuggested
            // 
            this.txtDetailsSuggested.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsSuggested.Location = new System.Drawing.Point(310, 303);
            this.txtDetailsSuggested.Name = "txtDetailsSuggested";
            this.txtDetailsSuggested.Size = new System.Drawing.Size(711, 24);
            this.txtDetailsSuggested.TabIndex = 10;
            // 
            // txtDetailsNominal
            // 
            this.txtDetailsNominal.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsNominal.Location = new System.Drawing.Point(310, 333);
            this.txtDetailsNominal.Name = "txtDetailsNominal";
            this.txtDetailsNominal.Size = new System.Drawing.Size(711, 24);
            this.txtDetailsNominal.TabIndex = 11;
            // 
            // txtDetailsCategory
            // 
            this.txtDetailsCategory.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsCategory.Location = new System.Drawing.Point(310, 243);
            this.txtDetailsCategory.Name = "txtDetailsCategory";
            this.txtDetailsCategory.Size = new System.Drawing.Size(711, 24);
            this.txtDetailsCategory.TabIndex = 8;
            // 
            // txtDetailsDrawing
            // 
            this.txtDetailsDrawing.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsDrawing.Location = new System.Drawing.Point(310, 93);
            this.txtDetailsDrawing.Name = "txtDetailsDrawing";
            this.txtDetailsDrawing.Size = new System.Drawing.Size(711, 24);
            this.txtDetailsDrawing.TabIndex = 3;
            // 
            // txtDetailsMatGrade
            // 
            this.txtDetailsMatGrade.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsMatGrade.Location = new System.Drawing.Point(310, 183);
            this.txtDetailsMatGrade.Name = "txtDetailsMatGrade";
            this.txtDetailsMatGrade.Size = new System.Drawing.Size(711, 24);
            this.txtDetailsMatGrade.TabIndex = 6;
            // 
            // txtDetailsMatStandard
            // 
            this.txtDetailsMatStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsMatStandard.Location = new System.Drawing.Point(310, 153);
            this.txtDetailsMatStandard.Name = "txtDetailsMatStandard";
            this.txtDetailsMatStandard.Size = new System.Drawing.Size(711, 24);
            this.txtDetailsMatStandard.TabIndex = 5;
            // 
            // txtDetailsStandard
            // 
            this.txtDetailsStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsStandard.Location = new System.Drawing.Point(310, 123);
            this.txtDetailsStandard.Name = "txtDetailsStandard";
            this.txtDetailsStandard.Size = new System.Drawing.Size(711, 24);
            this.txtDetailsStandard.TabIndex = 4;
            // 
            // txtDetailsComponent
            // 
            this.txtDetailsComponent.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsComponent.Location = new System.Drawing.Point(310, 63);
            this.txtDetailsComponent.Name = "txtDetailsComponent";
            this.txtDetailsComponent.Size = new System.Drawing.Size(711, 24);
            this.txtDetailsComponent.TabIndex = 2;
            // 
            // txtDetailsJob
            // 
            this.txtDetailsJob.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsJob.Location = new System.Drawing.Point(310, 3);
            this.txtDetailsJob.Name = "txtDetailsJob";
            this.txtDetailsJob.ReadOnly = true;
            this.txtDetailsJob.Size = new System.Drawing.Size(711, 24);
            this.txtDetailsJob.TabIndex = 0;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.FromName("@window");
            this.label42.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label42.Dock = Wisej.Web.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(3, 393);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(301, 37);
            this.label42.TabIndex = 18;
            this.label42.Text = "Client specified Inspection and Testing requirements";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.FromName("@window");
            this.label43.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label43.Dock = Wisej.Web.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(3, 273);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(301, 24);
            this.label43.TabIndex = 17;
            this.label43.Text = "Joint Configeration";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.FromName("@window");
            this.label44.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label44.Dock = Wisej.Web.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(3, 303);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(301, 24);
            this.label44.TabIndex = 16;
            this.label44.Text = "Suggested welding process";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.FromName("@window");
            this.label45.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label45.Dock = Wisej.Web.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(3, 333);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(301, 24);
            this.label45.TabIndex = 15;
            this.label45.Text = "Nominal tensile strength of welds";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.FromName("@window");
            this.label46.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label46.Dock = Wisej.Web.DockStyle.Fill;
            this.label46.Location = new System.Drawing.Point(3, 243);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(301, 24);
            this.label46.TabIndex = 14;
            this.label46.Text = "Welding Category";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.FromName("@window");
            this.label47.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label47.Dock = Wisej.Web.DockStyle.Fill;
            this.label47.Location = new System.Drawing.Point(3, 33);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(301, 24);
            this.label47.TabIndex = 13;
            this.label47.Text = "Date";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.FromName("@window");
            this.label30.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label30.Dock = Wisej.Web.DockStyle.Fill;
            this.label30.Location = new System.Drawing.Point(3, 93);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(301, 24);
            this.label30.TabIndex = 12;
            this.label30.Text = "Drawing Number";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.FromName("@window");
            this.label51.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label51.Dock = Wisej.Web.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(3, 183);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(301, 24);
            this.label51.TabIndex = 9;
            this.label51.Text = "Material Grade";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.FromName("@window");
            this.label52.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label52.Dock = Wisej.Web.DockStyle.Fill;
            this.label52.Location = new System.Drawing.Point(3, 153);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(301, 24);
            this.label52.TabIndex = 8;
            this.label52.Text = "Material Standard";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.FromName("@window");
            this.label54.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label54.Dock = Wisej.Web.DockStyle.Fill;
            this.label54.Location = new System.Drawing.Point(3, 363);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(301, 24);
            this.label54.TabIndex = 6;
            this.label54.Text = "Quality & acceptance requirements for welds";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.FromName("@window");
            this.label55.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label55.Dock = Wisej.Web.DockStyle.Fill;
            this.label55.Location = new System.Drawing.Point(3, 213);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(301, 24);
            this.label55.TabIndex = 5;
            this.label55.Text = "Welding Position";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.Color.FromName("@window");
            this.label58.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label58.Dock = Wisej.Web.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(3, 123);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(301, 24);
            this.label58.TabIndex = 2;
            this.label58.Text = "Welding Standard";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.Color.FromName("@window");
            this.label59.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label59.Dock = Wisej.Web.DockStyle.Fill;
            this.label59.Location = new System.Drawing.Point(3, 63);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(301, 24);
            this.label59.TabIndex = 1;
            this.label59.Text = "Component Description";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.FromName("@window");
            this.label31.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label31.Dock = Wisej.Web.DockStyle.Fill;
            this.label31.Location = new System.Drawing.Point(3, 3);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(301, 24);
            this.label31.TabIndex = 0;
            this.label31.Text = "Job / Quote Number";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDetailsPosition
            // 
            this.txtDetailsPosition.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsPosition.Location = new System.Drawing.Point(310, 213);
            this.txtDetailsPosition.Name = "txtDetailsPosition";
            this.txtDetailsPosition.Size = new System.Drawing.Size(711, 24);
            this.txtDetailsPosition.TabIndex = 7;
            // 
            // txtDetailsQuality
            // 
            this.txtDetailsQuality.Dock = Wisej.Web.DockStyle.Fill;
            this.txtDetailsQuality.Location = new System.Drawing.Point(310, 363);
            this.txtDetailsQuality.Name = "txtDetailsQuality";
            this.txtDetailsQuality.Size = new System.Drawing.Size(711, 24);
            this.txtDetailsQuality.TabIndex = 12;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 1;
            this.tableLayoutPanel23.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Controls.Add(this.tableLayoutPanel31, 0, 0);
            this.tableLayoutPanel23.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel23.TabIndex = 5;
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel31.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel31.ColumnCount = 1;
            this.tableLayoutPanel31.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel31.Controls.Add(this.btnDetailsBack, 0, 2);
            this.tableLayoutPanel31.Controls.Add(this.btnDetailsHome, 0, 3);
            this.tableLayoutPanel31.Controls.Add(this.btnDetailsNext, 0, 4);
            this.tableLayoutPanel31.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel31.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel31.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 5;
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel31.TabIndex = 4;
            // 
            // btnDetailsBack
            // 
            this.btnDetailsBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDetailsBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDetailsBack.Location = new System.Drawing.Point(3, 173);
            this.btnDetailsBack.Name = "btnDetailsBack";
            this.btnDetailsBack.Size = new System.Drawing.Size(95, 79);
            this.btnDetailsBack.TabIndex = 16;
            this.btnDetailsBack.Text = "Back";
            this.btnDetailsBack.Click += new System.EventHandler(this.btnDetailsBack_Click);
            // 
            // btnDetailsHome
            // 
            this.btnDetailsHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDetailsHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDetailsHome.Location = new System.Drawing.Point(3, 258);
            this.btnDetailsHome.Name = "btnDetailsHome";
            this.btnDetailsHome.Size = new System.Drawing.Size(95, 79);
            this.btnDetailsHome.TabIndex = 15;
            this.btnDetailsHome.Text = "Home";
            this.btnDetailsHome.Click += new System.EventHandler(this.btnDetailsHome_Click);
            // 
            // btnDetailsNext
            // 
            this.btnDetailsNext.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnDetailsNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnDetailsNext.Location = new System.Drawing.Point(3, 343);
            this.btnDetailsNext.Name = "btnDetailsNext";
            this.btnDetailsNext.Size = new System.Drawing.Size(95, 79);
            this.btnDetailsNext.TabIndex = 14;
            this.btnDetailsNext.Text = "Next";
            this.btnDetailsNext.Click += new System.EventHandler(this.btnDetailsNext_Click);
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 1;
            this.tableLayoutPanel24.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel24.Controls.Add(this.label77, 0, 1);
            this.tableLayoutPanel24.Controls.Add(this.label78, 0, 0);
            this.tableLayoutPanel24.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 2;
            this.tableLayoutPanel24.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel24.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel24.TabIndex = 0;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label77.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label77.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.label77.Dock = Wisej.Web.DockStyle.Fill;
            this.label77.Location = new System.Drawing.Point(6, 79);
            this.label77.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(1133, 35);
            this.label77.TabIndex = 1;
            this.label77.Text = "Notes";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label78.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label78.CssStyle = "border-radius: 4px;";
            this.label78.Dock = Wisej.Web.DockStyle.Fill;
            this.label78.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label78.Location = new System.Drawing.Point(6, 3);
            this.label78.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(1133, 70);
            this.label78.TabIndex = 0;
            this.label78.Text = "Welding Scope of Work";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uc_rqDetails
            // 
            this.Controls.Add(this.tableLayoutPanel20);
            this.Name = "uc_rqDetails";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_rqDetails_VisibleChanged);
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel31.ResumeLayout(false);
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel24.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel20;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel21;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TextBox txtDetailsClient;
        private Wisej.Web.TextBox txtDetailsJoint;
        private Wisej.Web.TextBox txtDetailsSuggested;
        private Wisej.Web.TextBox txtDetailsNominal;
        private Wisej.Web.TextBox txtDetailsCategory;
        private Wisej.Web.TextBox txtDetailsDrawing;
        private Wisej.Web.TextBox txtDetailsMatGrade;
        private Wisej.Web.TextBox txtDetailsMatStandard;
        private Wisej.Web.TextBox txtDetailsStandard;
        private Wisej.Web.TextBox txtDetailsComponent;
        private Wisej.Web.TextBox txtDetailsJob;
        private Wisej.Web.Label label42;
        private Wisej.Web.Label label43;
        private Wisej.Web.Label label44;
        private Wisej.Web.Label label45;
        private Wisej.Web.Label label46;
        private Wisej.Web.Label label47;
        private Wisej.Web.Label label30;
        private Wisej.Web.Label label51;
        private Wisej.Web.Label label52;
        private Wisej.Web.Label label54;
        private Wisej.Web.Label label55;
        private Wisej.Web.Label label58;
        private Wisej.Web.Label label59;
        private Wisej.Web.Label label31;
        private Wisej.Web.TextBox txtDetailsPosition;
        private Wisej.Web.TextBox txtDetailsQuality;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel23;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel31;
        private Wisej.Web.Button btnDetailsBack;
        private Wisej.Web.Button btnDetailsHome;
        private Wisej.Web.Button btnDetailsNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel24;
        private Wisej.Web.Label label77;
        private Wisej.Web.Label label78;
        private Wisej.Web.DateTimePicker dtpDetailsDate;
    }
}
