﻿namespace WeldingManagement.UserControls.WPSControls
{
    partial class uc_wpsRun
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle1 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle2 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle3 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle4 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle5 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle6 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle7 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle8 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle9 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle10 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle11 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle12 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle13 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle14 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle15 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle16 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle17 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle18 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle19 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle20 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle21 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle22 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle23 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle24 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle25 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle26 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle27 = new Wisej.Web.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_wpsRun));
            this.tableLayoutPanel33 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel34 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel36 = new Wisej.Web.TableLayoutPanel();
            this.btnRunDelete = new Wisej.Web.Button();
            this.btnRunCopy = new Wisej.Web.Button();
            this.btnRunBack = new Wisej.Web.Button();
            this.btnRunHome = new Wisej.Web.Button();
            this.btnRunNext = new Wisej.Web.Button();
            this.dgvWPSRun = new Wisej.Web.DataGridView();
            this.dgvcSide = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcPass = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcProcess = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcPosition = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcSize = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcSpecification = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcClassification = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcPolarity = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcFluxGas = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcInput = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcAmps = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcVolts = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcSpeed = new Wisej.Web.DataGridViewTextBoxColumn();
            this.tableLayoutPanel38 = new Wisej.Web.TableLayoutPanel();
            this.lblInfoNote = new Wisej.Web.LinkLabel();
            this.label111 = new Wisej.Web.Label();
            this.btnRunCopyRun = new Wisej.Web.Button();
            this.tableLayoutPanel33.SuspendLayout();
            this.tableLayoutPanel34.SuspendLayout();
            this.tableLayoutPanel36.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWPSRun)).BeginInit();
            this.tableLayoutPanel38.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel33.ColumnCount = 3;
            this.tableLayoutPanel33.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel33.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel34, 1, 3);
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel38, 1, 1);
            this.tableLayoutPanel33.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel33.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 5;
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel33.TabIndex = 5;
            // 
            // tableLayoutPanel34
            // 
            this.tableLayoutPanel34.ColumnCount = 2;
            this.tableLayoutPanel34.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel34.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel34.Controls.Add(this.tableLayoutPanel36, 0, 0);
            this.tableLayoutPanel34.Controls.Add(this.dgvWPSRun, 0, 0);
            this.tableLayoutPanel34.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel34.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel34.Name = "tableLayoutPanel34";
            this.tableLayoutPanel34.RowCount = 1;
            this.tableLayoutPanel34.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel34.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel34.TabIndex = 1;
            // 
            // tableLayoutPanel36
            // 
            this.tableLayoutPanel36.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel36.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel36.ColumnCount = 1;
            this.tableLayoutPanel36.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel36.Controls.Add(this.btnRunCopyRun, 0, 2);
            this.tableLayoutPanel36.Controls.Add(this.btnRunDelete, 0, 1);
            this.tableLayoutPanel36.Controls.Add(this.btnRunCopy, 0, 0);
            this.tableLayoutPanel36.Controls.Add(this.btnRunBack, 0, 3);
            this.tableLayoutPanel36.Controls.Add(this.btnRunHome, 0, 4);
            this.tableLayoutPanel36.Controls.Add(this.btnRunNext, 0, 5);
            this.tableLayoutPanel36.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel36.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel36.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel36.Name = "tableLayoutPanel36";
            this.tableLayoutPanel36.RowCount = 6;
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel36.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel36.TabIndex = 30;
            // 
            // btnRunDelete
            // 
            this.btnRunDelete.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnRunDelete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunDelete.Location = new System.Drawing.Point(3, 74);
            this.btnRunDelete.Name = "btnRunDelete";
            this.btnRunDelete.Size = new System.Drawing.Size(101, 65);
            this.btnRunDelete.TabIndex = 6;
            this.btnRunDelete.Text = "Delete";
            this.btnRunDelete.DoubleClick += new System.EventHandler(this.btnRunDelete_DoubleClick);
            // 
            // btnRunCopy
            // 
            this.btnRunCopy.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnRunCopy.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunCopy.Location = new System.Drawing.Point(3, 3);
            this.btnRunCopy.Name = "btnRunCopy";
            this.btnRunCopy.Size = new System.Drawing.Size(101, 65);
            this.btnRunCopy.TabIndex = 5;
            this.btnRunCopy.Text = "Copy Down Column";
            this.btnRunCopy.Click += new System.EventHandler(this.btnRunCopy_Click);
            // 
            // btnRunBack
            // 
            this.btnRunBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnRunBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunBack.Location = new System.Drawing.Point(3, 216);
            this.btnRunBack.Name = "btnRunBack";
            this.btnRunBack.Size = new System.Drawing.Size(101, 65);
            this.btnRunBack.TabIndex = 3;
            this.btnRunBack.Text = "Back";
            this.btnRunBack.Click += new System.EventHandler(this.btnRunBack_Click);
            // 
            // btnRunHome
            // 
            this.btnRunHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnRunHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunHome.Location = new System.Drawing.Point(3, 287);
            this.btnRunHome.Name = "btnRunHome";
            this.btnRunHome.Size = new System.Drawing.Size(101, 65);
            this.btnRunHome.TabIndex = 1;
            this.btnRunHome.Text = "Home";
            this.btnRunHome.Click += new System.EventHandler(this.btnRunHome_Click);
            // 
            // btnRunNext
            // 
            this.btnRunNext.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnRunNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunNext.Location = new System.Drawing.Point(3, 358);
            this.btnRunNext.Name = "btnRunNext";
            this.btnRunNext.Size = new System.Drawing.Size(101, 70);
            this.btnRunNext.TabIndex = 0;
            this.btnRunNext.Text = "Next";
            this.btnRunNext.Click += new System.EventHandler(this.btnRunNext_Click);
            // 
            // dgvWPSRun
            // 
            this.dgvWPSRun.AllowDrag = true;
            this.dgvWPSRun.AutoGenerateColumns = false;
            this.dgvWPSRun.AutoSizeColumnsMode = Wisej.Web.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgvWPSRun.AutoSizeRowsMode = Wisej.Web.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle1.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvWPSRun.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvWPSRun.ColumnHeadersHeight = 64;
            this.dgvWPSRun.Columns.AddRange(new Wisej.Web.DataGridViewColumn[] {
            this.dgvcSide,
            this.dgvcPass,
            this.dgvcProcess,
            this.dgvcPosition,
            this.dgvcSize,
            this.dgvcSpecification,
            this.dgvcClassification,
            this.dgvcPolarity,
            this.dgvcFluxGas,
            this.dgvcInput,
            this.dgvcAmps,
            this.dgvcVolts,
            this.dgvcSpeed});
            this.dgvWPSRun.CssStyle = "border-radius: 4px;";
            this.dgvWPSRun.Dock = Wisej.Web.DockStyle.Fill;
            this.dgvWPSRun.Location = new System.Drawing.Point(3, 3);
            this.dgvWPSRun.MultiSelect = false;
            this.dgvWPSRun.Name = "dgvWPSRun";
            this.dgvWPSRun.SelectionMode = Wisej.Web.DataGridViewSelectionMode.CellSelect;
            this.dgvWPSRun.Size = new System.Drawing.Size(1024, 433);
            this.dgvWPSRun.TabIndex = 29;
            this.dgvWPSRun.Resize += new System.EventHandler(this.dgvWPSRun_Resize);
            // 
            // dgvcSide
            // 
            dataGridViewCellStyle2.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcSide.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridViewCellStyle3.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcSide.HeaderStyle = dataGridViewCellStyle3;
            this.dgvcSide.HeaderText = "Side";
            this.dgvcSide.Name = "dgvcSide";
            // 
            // dgvcPass
            // 
            dataGridViewCellStyle4.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcPass.DefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcPass.HeaderStyle = dataGridViewCellStyle5;
            this.dgvcPass.HeaderText = "Pass";
            this.dgvcPass.Name = "dgvcPass";
            // 
            // dgvcProcess
            // 
            dataGridViewCellStyle6.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcProcess.DefaultCellStyle = dataGridViewCellStyle6;
            dataGridViewCellStyle7.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcProcess.HeaderStyle = dataGridViewCellStyle7;
            this.dgvcProcess.HeaderText = "Process";
            this.dgvcProcess.Name = "dgvcProcess";
            // 
            // dgvcPosition
            // 
            dataGridViewCellStyle8.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcPosition.DefaultCellStyle = dataGridViewCellStyle8;
            dataGridViewCellStyle9.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcPosition.HeaderStyle = dataGridViewCellStyle9;
            this.dgvcPosition.HeaderText = "Position";
            this.dgvcPosition.Name = "dgvcPosition";
            // 
            // dgvcSize
            // 
            dataGridViewCellStyle10.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcSize.DefaultCellStyle = dataGridViewCellStyle10;
            dataGridViewCellStyle11.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcSize.HeaderStyle = dataGridViewCellStyle11;
            this.dgvcSize.HeaderText = "Size";
            this.dgvcSize.Name = "dgvcSize";
            // 
            // dgvcSpecification
            // 
            dataGridViewCellStyle12.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcSpecification.DefaultCellStyle = dataGridViewCellStyle12;
            dataGridViewCellStyle13.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcSpecification.HeaderStyle = dataGridViewCellStyle13;
            this.dgvcSpecification.HeaderText = "Specification";
            this.dgvcSpecification.Name = "dgvcSpecification";
            // 
            // dgvcClassification
            // 
            dataGridViewCellStyle14.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcClassification.DefaultCellStyle = dataGridViewCellStyle14;
            dataGridViewCellStyle15.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcClassification.HeaderStyle = dataGridViewCellStyle15;
            this.dgvcClassification.HeaderText = "Classification";
            this.dgvcClassification.Name = "dgvcClassification";
            // 
            // dgvcPolarity
            // 
            dataGridViewCellStyle16.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcPolarity.DefaultCellStyle = dataGridViewCellStyle16;
            dataGridViewCellStyle17.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcPolarity.HeaderStyle = dataGridViewCellStyle17;
            this.dgvcPolarity.HeaderText = "Polarity";
            this.dgvcPolarity.Name = "dgvcPolarity";
            // 
            // dgvcFluxGas
            // 
            dataGridViewCellStyle18.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcFluxGas.DefaultCellStyle = dataGridViewCellStyle18;
            dataGridViewCellStyle19.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcFluxGas.HeaderStyle = dataGridViewCellStyle19;
            this.dgvcFluxGas.HeaderText = "Flux or Gas";
            this.dgvcFluxGas.Name = "dgvcFluxGas";
            // 
            // dgvcInput
            // 
            dataGridViewCellStyle20.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle20.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcInput.DefaultCellStyle = dataGridViewCellStyle20;
            dataGridViewCellStyle21.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcInput.HeaderStyle = dataGridViewCellStyle21;
            this.dgvcInput.HeaderText = "Heat Input";
            this.dgvcInput.Name = "dgvcInput";
            // 
            // dgvcAmps
            // 
            dataGridViewCellStyle22.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle22.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcAmps.DefaultCellStyle = dataGridViewCellStyle22;
            dataGridViewCellStyle23.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcAmps.HeaderStyle = dataGridViewCellStyle23;
            this.dgvcAmps.HeaderText = "Amps";
            this.dgvcAmps.Name = "dgvcAmps";
            // 
            // dgvcVolts
            // 
            dataGridViewCellStyle24.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle24.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcVolts.DefaultCellStyle = dataGridViewCellStyle24;
            dataGridViewCellStyle25.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcVolts.HeaderStyle = dataGridViewCellStyle25;
            this.dgvcVolts.HeaderText = "Volts";
            this.dgvcVolts.Name = "dgvcVolts";
            // 
            // dgvcSpeed
            // 
            dataGridViewCellStyle26.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle26.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcSpeed.DefaultCellStyle = dataGridViewCellStyle26;
            dataGridViewCellStyle27.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcSpeed.HeaderStyle = dataGridViewCellStyle27;
            this.dgvcSpeed.HeaderText = "Weld Speed";
            this.dgvcSpeed.Name = "dgvcSpeed";
            // 
            // tableLayoutPanel38
            // 
            this.tableLayoutPanel38.ColumnCount = 1;
            this.tableLayoutPanel38.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel38.Controls.Add(this.lblInfoNote, 0, 1);
            this.tableLayoutPanel38.Controls.Add(this.label111, 0, 0);
            this.tableLayoutPanel38.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel38.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel38.Name = "tableLayoutPanel38";
            this.tableLayoutPanel38.RowCount = 2;
            this.tableLayoutPanel38.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel38.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel38.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel38.TabIndex = 0;
            // 
            // lblInfoNote
            // 
            this.lblInfoNote.AutoSize = true;
            this.lblInfoNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblInfoNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblInfoNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblInfoNote.LinkArea = new Wisej.Web.LinkArea(270, 84);
            this.lblInfoNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblInfoNote.Location = new System.Drawing.Point(3, 79);
            this.lblInfoNote.Name = "lblInfoNote";
            this.lblInfoNote.Size = new System.Drawing.Size(1139, 35);
            this.lblInfoNote.TabIndex = 17;
            this.lblInfoNote.Text = resources.GetString("lblInfoNote.Text");
            this.lblInfoNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfoNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblInfoNote_LinkClicked);
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.BackColor = System.Drawing.Color.FromName("@window");
            this.label111.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label111.CssStyle = "border-radius: 4px;";
            this.label111.Dock = Wisej.Web.DockStyle.Fill;
            this.label111.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label111.Location = new System.Drawing.Point(3, 3);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(1139, 70);
            this.label111.TabIndex = 0;
            this.label111.Text = "WPS Parameters";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnRunCopyRun
            // 
            this.btnRunCopyRun.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnRunCopyRun.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunCopyRun.Location = new System.Drawing.Point(3, 145);
            this.btnRunCopyRun.Name = "btnRunCopyRun";
            this.btnRunCopyRun.Size = new System.Drawing.Size(101, 65);
            this.btnRunCopyRun.TabIndex = 7;
            this.btnRunCopyRun.Text = "Copy Run";
            this.btnRunCopyRun.Click += new System.EventHandler(this.btnRunCopyRun_Click);
            // 
            // uc_wpsRun
            // 
            this.Controls.Add(this.tableLayoutPanel33);
            this.Name = "uc_wpsRun";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_wpsRun_VisibleChanged);
            this.tableLayoutPanel33.ResumeLayout(false);
            this.tableLayoutPanel34.ResumeLayout(false);
            this.tableLayoutPanel36.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvWPSRun)).EndInit();
            this.tableLayoutPanel38.ResumeLayout(false);
            this.tableLayoutPanel38.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel33;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel34;
        private Wisej.Web.DataGridView dgvWPSRun;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcSide;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcPass;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcProcess;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcPosition;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcSize;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcSpecification;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcClassification;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcPolarity;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcFluxGas;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcInput;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcAmps;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcVolts;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcSpeed;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel38;
        private Wisej.Web.Label label111;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel36;
        private Wisej.Web.Button btnRunCopy;
        private Wisej.Web.Button btnRunBack;
        private Wisej.Web.Button btnRunHome;
        private Wisej.Web.Button btnRunNext;
        private Wisej.Web.LinkLabel lblInfoNote;
        private Wisej.Web.Button btnRunDelete;
        private Wisej.Web.Button btnRunCopyRun;
    }
}
