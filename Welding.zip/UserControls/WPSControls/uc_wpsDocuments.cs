﻿using ApiClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using Welding.DAL;
using WeldingManagement.UserControls.PopupControls;
using Wisej.Web;
using static WeldingManagement.FileManagement;

namespace WeldingManagement.UserControls.WPSControls
{
    public partial class uc_wpsDocuments : Wisej.Web.UserControl
    {
        private up_wqFileView up_wqFileView1;

        private Panel overlayPanel;

        public uc_wpsDocuments()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = System.Drawing.Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks complete button on upload screen")]
        public event EventHandler btnUploadCompleteClick;
        private void btnUploadComplete_Click(object sender, EventArgs e)
        {
            UIFormatting.StartLoader(this);

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS)
            {
                UIFormatting.StopLoader(this);
                return;
            }

            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            if (!wps.Attachments.Any(w => w.AttachmentType == AttachmentTypes.Weld_Stamp))
            {
                UIFormatting.StopLoader(this);
                return;
            }

            if (!wps.Attachments.Any(w => w.AttachmentType == AttachmentTypes.WPS_Preparation))
            {
                UIFormatting.StopLoader(this);
                return;
            }

            if (!wps.Attachments.Any(w => w.AttachmentType == AttachmentTypes.WPS_Sequence))
            {
                UIFormatting.StopLoader(this);
                return;
            }

            Update_Status();

            if (up_wqFileView1 == null)
            {
                up_wqFileView1 = new up_wqFileView();
                this.Controls.Add(up_wqFileView1);
            }

            overlayPanel.Visible = true;

            wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            if (wps.Status != Actions.Complete)
            {
                UIFormatting.StopLoader(this);
                return;
            }

            string wpsPath = TemplateCompiler.CompleteWPS(wps);

            using (FileStream fStream = new FileStream(wpsPath, FileMode.Open, FileAccess.Read))
            {
                var reader = new BinaryReader(fStream);
                var buffer = reader.ReadBytes((int)fStream.Length);
                var mem = new MemoryStream(buffer);

                up_wqFileView1.pvView_Stream = mem;
                up_wqFileView1.path = wpsPath;
                up_wqFileView1.title = "Below is a Preview of the Completed WPS";

                UIFormatting.StopLoader(this);

                up_wqFileView1.ShowPopup(new Point(this.Width / 2 - up_wqFileView1.Width / 2, this.Height / 2 - up_wqFileView1.Height / 2), up_wqFileView1_Closed);
            }

            UIFormatting.StopLoader(this);
        }

        private void up_wqFileView1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            btnUploadCompleteClick?.Invoke(this, new EventArgs());
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on upload screen")]
        public event EventHandler btnUploadHomeClick;
        private void btnUploadHome_Click(object sender, EventArgs e)
        {
            btnUploadHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on upload screen")]
        public event EventHandler btnUploadBackClick;
        private void btnUploadBack_Click(object sender, EventArgs e)
        {
            btnUploadBackClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks create sequence button on upload screen")]
        public event EventHandler btnUploadSequenceClick;
        private void btnUploadSequence_Click(object sender, EventArgs e)
        {
            btnUploadSequenceClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks create preparation button on upload screen")]
        public event EventHandler btnUploadPreparationClick;
        private void btnUploadPreparation_Click(object sender, EventArgs e)
        {
            btnUploadPreparationClick?.Invoke(this, e);
        }
        #endregion

        private void uplUploadPreparation_Uploaded(object sender, UploadedEventArgs e)
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS)
            {
                return;
            }

            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            for (int i = 0; i < e.Files.Count; i++)
            {
                StoreFile(e.Files[i], AttachmentTypes.WPS_Preparation, wps.WPQR.Welder_Qualification.WeldingAction.Job.QuoteNumber, typeof(WPS), wps.WPSId);
            }

            Load_Action();
        }

        private void uplUploadSequence_Uploaded(object sender, UploadedEventArgs e)
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS)
            {
                return;
            }

            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            for (int i = 0; i < e.Files.Count; i++)
            {
                StoreFile(e.Files[i], AttachmentTypes.WPS_Sequence, wps.WPQR.Welder_Qualification.WeldingAction.Job.QuoteNumber, typeof(WPS), wps.WPSId);
            }

            Load_Action();
        }

        private void uplUploadStamp_Uploaded(object sender, UploadedEventArgs e)
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS)
            {
                return;
            }

            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            for (int i = 0; i < e.Files.Count; i++)
            {
                StoreFile(e.Files[i], AttachmentTypes.Weld_Stamp, wps.WPQR.Welder_Qualification.WeldingAction.Job.QuoteNumber, typeof(WPS), wps.WPSId);
            }

            Load_Action();
        }

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS)
            {
                return;
            }

            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            wps.Status = Actions.Complete;

            ApiCalls.UpdateWPS(wps.WPSId, wps);

            this.Tag = new Tag(ApiCalls.ReadWPS(wps.WPSId), TagType.WPS);
        }

        private void Load_Action()
        {
            uplUploadStamp.Visible = true;
            uplUploadPreparation.Visible = true;
            btnUploadPreparation.Visible = true;
            uplUploadSequence.Visible = true;
            btnUploadSequence.Visible = true;

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS)
            {
                return;
            }

            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            lvUpload.Items.Clear();

            if (wps.Attachments.Where(w => w.AttachmentType != AttachmentTypes.Weld_Stamp).Count() > 0)
            {
                btnUploadInherit.Enabled = false;
            }
            else
            {
                btnUploadInherit.Enabled = true;
            }

            foreach (Attachment att in wps.Attachments)
            {
                ListViewItem lvItem = new ListViewItem(new string[] { att.ServerPath.Split('\\').Last(), UIFormatting.GetEnumDisplayName(att.AttachmentType) });
                lvItem.Tag = new Tag(att, TagType.Attachment);
                lvUpload.Items.Add(lvItem);

                switch (att.AttachmentType)
                {
                    case AttachmentTypes.WPS_Preparation:
                        uplUploadPreparation.Visible = false;
                        btnUploadPreparation.Visible = false;
                        break;
                    case AttachmentTypes.WPS_Sequence:
                        uplUploadSequence.Visible = false;
                        btnUploadSequence.Visible = false;
                        break;
                    case AttachmentTypes.Weld_Stamp:
                        uplUploadStamp.Visible = false;
                        break;
                }
            }

            lvUpload.Refresh();

            UIFormatting.ResizeColumnsFor(lvUpload);

            if (pbUpload != null && pbUpload.Image != null)
            {
                pbUpload.Image.Dispose();
            }

            if (pvUpload != null && pvUpload.PdfStream != null)
            {
                pvUpload.PdfStream = null;
            }

            pvUpload.Visible = true;
            pbUpload.Visible = false;

            tlpUpload.RowStyles[tlpUpload.GetCellPosition(pvUpload).Row].SizeType = SizeType.Percent;
            tlpUpload.RowStyles[tlpUpload.GetCellPosition(pvUpload).Row].Height = 80;

            tlpUpload.RowStyles[tlpUpload.GetCellPosition(pbUpload).Row].SizeType = SizeType.Percent;
            tlpUpload.RowStyles[tlpUpload.GetCellPosition(pbUpload).Row].Height = 0;
        }

        private void uc_wpsDocuments_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private void lvUpload_Resize(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            UIFormatting.ResizeColumnsFor(lvUpload);
        }

        private void lvUpload_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvUpload.SelectedIndex < 0)
            {
                return;
            }

            Tag itemTag = (Tag)lvUpload.Items[lvUpload.SelectedIndex].Tag;

            ViewAttachment(itemTag, pbUpload, pvUpload, tlpUpload);
        }

        private void btnUploadDelete_Click(object sender, EventArgs e)
        {
            if (lvUpload.SelectedIndex < 0)
            {
                return;
            }

            Tag itemTag = (Tag)lvUpload.Items[lvUpload.SelectedIndex].Tag;

            DeleteAttachment(itemTag, pbUpload, pvUpload);

            Load_Action();
        }

        private void btnUploadInherit_Click(object sender, EventArgs e)
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS)
            {
                return;
            }

            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            Attachment attWPQRSeq = wps.WPQR.Attachments.FirstOrDefault(w => w.AttachmentType == AttachmentTypes.WPQR_Sequence);
            attWPQRSeq.AttachmentType = AttachmentTypes.WPS_Sequence;
            CopyFile(attWPQRSeq, wps.WPQR.Welder_Qualification.WeldingAction.Job.QuoteNumber, typeof(WPS), wps.WPSId);

            Attachment attWPQRPrep = wps.WPQR.Attachments.FirstOrDefault(w => w.AttachmentType == AttachmentTypes.WPQR_Preparation);
            attWPQRPrep.AttachmentType = AttachmentTypes.WPS_Preparation;
            CopyFile(attWPQRPrep, wps.WPQR.Welder_Qualification.WeldingAction.Job.QuoteNumber, typeof(WPS), wps.WPSId);

            Load_Action();
        }

        private void btnUploadInherit_EnabledChanged(object sender, EventArgs e)
        {
            btnUploadInherit.BackColor = btnUploadInherit.Enabled ? Color.FromName("@buttonFace") : Color.FromName("@controlLight");
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }
    }
}
