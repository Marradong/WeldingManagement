﻿namespace WeldingManagement.UserControls.WPSControls
{
    partial class uc_wpsInfo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_wpsInfo));
            this.tableLayoutPanel25 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel26 = new Wisej.Web.TableLayoutPanel();
            this.tlpInfoInput = new Wisej.Web.TableLayoutPanel();
            this.tlpInfoAllocate = new Wisej.Web.TableLayoutPanel();
            this.label7 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.cbInfoWPS = new Wisej.Web.CheckBox();
            this.label5 = new Wisej.Web.Label();
            this.tlpInfoNew = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.txtInfoShieldTol = new Wisej.Web.TextBox();
            this.label10 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.txtInfoVoltTol = new Wisej.Web.TextBox();
            this.label4 = new Wisej.Web.Label();
            this.txtInfoAmpTol = new Wisej.Web.TextBox();
            this.txtInfoSpeedTol = new Wisej.Web.TextBox();
            this.label2 = new Wisej.Web.Label();
            this.txtInfoMaxDiameter = new Wisej.Web.TextBox();
            this.label9 = new Wisej.Web.Label();
            this.txtInfoMaxThickness = new Wisej.Web.TextBox();
            this.label8 = new Wisej.Web.Label();
            this.label101 = new Wisej.Web.Label();
            this.txtInfoJob = new Wisej.Web.TextBox();
            this.label1 = new Wisej.Web.Label();
            this.cboInfoPrepared = new Wisej.Web.ComboBox();
            this.dtpInfoDate = new Wisej.Web.DateTimePicker();
            this.cbInfoVisual = new Wisej.Web.CheckBox();
            this.cbInfoNDT = new Wisej.Web.CheckBox();
            this.cbInfoDPI = new Wisej.Web.CheckBox();
            this.cbInfoMPI = new Wisej.Web.CheckBox();
            this.cbInfoRT = new Wisej.Web.CheckBox();
            this.cbInfoUT = new Wisej.Web.CheckBox();
            this.label88 = new Wisej.Web.Label();
            this.label90 = new Wisej.Web.Label();
            this.label89 = new Wisej.Web.Label();
            this.label87 = new Wisej.Web.Label();
            this.label99 = new Wisej.Web.Label();
            this.label86 = new Wisej.Web.Label();
            this.label100 = new Wisej.Web.Label();
            this.label82 = new Wisej.Web.Label();
            this.label57 = new Wisej.Web.Label();
            this.label98 = new Wisej.Web.Label();
            this.label58 = new Wisej.Web.Label();
            this.label81 = new Wisej.Web.Label();
            this.label94 = new Wisej.Web.Label();
            this.label93 = new Wisej.Web.Label();
            this.label79 = new Wisej.Web.Label();
            this.label59 = new Wisej.Web.Label();
            this.label60 = new Wisej.Web.Label();
            this.txtInfoMinThickness = new Wisej.Web.TextBox();
            this.txtInfoPWHT = new Wisej.Web.TextBox();
            this.txtInfoInterpass = new Wisej.Web.TextBox();
            this.txtInfoMatStandard = new Wisej.Web.TextBox();
            this.txtInfoWPS = new Wisej.Web.TextBox();
            this.txtInfoMinDiameter = new Wisej.Web.TextBox();
            this.txtInfoPreheat = new Wisej.Web.TextBox();
            this.txtInfoNotes = new Wisej.Web.TextBox();
            this.txtInfoMatGrade = new Wisej.Web.TextBox();
            this.txtInfoMatPNo = new Wisej.Web.TextBox();
            this.txtInfoJoint = new Wisej.Web.TextBox();
            this.txtInfoPrep = new Wisej.Web.TextBox();
            this.txtInfoGouging = new Wisej.Web.TextBox();
            this.label102 = new Wisej.Web.Label();
            this.cboInfoWPQR = new Wisej.Web.ComboBox();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel28 = new Wisej.Web.TableLayoutPanel();
            this.btnInfoBack = new Wisej.Web.Button();
            this.btnInfoHome = new Wisej.Web.Button();
            this.btnInfoNext = new Wisej.Web.Button();
            this.tableLayoutPanel29 = new Wisej.Web.TableLayoutPanel();
            this.lblInfoNote = new Wisej.Web.LinkLabel();
            this.label104 = new Wisej.Web.Label();
            this.mscboInfoWPS = new WeldingManagement.UserControls.MultiSelectComboBox();
            this.tableLayoutPanel25.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.tlpInfoInput.SuspendLayout();
            this.tlpInfoAllocate.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tlpInfoNew.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel25.ColumnCount = 3;
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.Controls.Add(this.tableLayoutPanel26, 1, 3);
            this.tableLayoutPanel25.Controls.Add(this.tableLayoutPanel29, 1, 1);
            this.tableLayoutPanel25.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 5;
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel25.TabIndex = 4;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 2;
            this.tableLayoutPanel26.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel26.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel26.Controls.Add(this.tlpInfoInput, 0, 0);
            this.tableLayoutPanel26.Controls.Add(this.tableLayoutPanel1, 1, 0);
            this.tableLayoutPanel26.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel26.TabIndex = 1;
            // 
            // tlpInfoInput
            // 
            this.tlpInfoInput.ColumnCount = 1;
            this.tlpInfoInput.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpInfoInput.Controls.Add(this.tlpInfoAllocate, 0, 2);
            this.tlpInfoInput.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tlpInfoInput.Controls.Add(this.tlpInfoNew, 0, 1);
            this.tlpInfoInput.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpInfoInput.Location = new System.Drawing.Point(3, 3);
            this.tlpInfoInput.Name = "tlpInfoInput";
            this.tlpInfoInput.RowCount = 3;
            this.tlpInfoInput.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpInfoInput.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 80F));
            this.tlpInfoInput.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpInfoInput.Size = new System.Drawing.Size(1024, 433);
            this.tlpInfoInput.TabIndex = 6;
            // 
            // tlpInfoAllocate
            // 
            this.tlpInfoAllocate.ColumnCount = 2;
            this.tlpInfoAllocate.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpInfoAllocate.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpInfoAllocate.Controls.Add(this.label7, 0, 1);
            this.tlpInfoAllocate.Controls.Add(this.mscboInfoWPS, 1, 0);
            this.tlpInfoAllocate.Controls.Add(this.label6, 0, 0);
            this.tlpInfoAllocate.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpInfoAllocate.Location = new System.Drawing.Point(3, 356);
            this.tlpInfoAllocate.Name = "tlpInfoAllocate";
            this.tlpInfoAllocate.RowCount = 2;
            this.tlpInfoAllocate.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpInfoAllocate.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 80F));
            this.tlpInfoAllocate.Size = new System.Drawing.Size(1018, 74);
            this.tlpInfoAllocate.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromName("@window");
            this.label7.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tlpInfoAllocate.SetColumnSpan(this.label7, 2);
            this.label7.Dock = Wisej.Web.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(3, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(1012, 54);
            this.label7.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromName("@window");
            this.label6.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label6.Dock = Wisej.Web.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(3, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(503, 8);
            this.label6.TabIndex = 3;
            this.label6.Text = "Select all WPS to Allocate";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.cbInfoWPS, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1018, 33);
            this.tableLayoutPanel3.TabIndex = 5;
            // 
            // cbInfoWPS
            // 
            this.cbInfoWPS.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoWPS.BackColor = System.Drawing.Color.FromName("@window");
            this.cbInfoWPS.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbInfoWPS.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbInfoWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoWPS.Location = new System.Drawing.Point(512, 3);
            this.cbInfoWPS.Name = "cbInfoWPS";
            this.cbInfoWPS.Size = new System.Drawing.Size(503, 27);
            this.cbInfoWPS.TabIndex = 17;
            this.cbInfoWPS.Text = "New/Existing";
            this.cbInfoWPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbInfoWPS.CheckedChanged += new System.EventHandler(this.cbInfoWPS_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromName("@window");
            this.label5.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label5.Dock = Wisej.Web.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(3, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(503, 27);
            this.label5.TabIndex = 1;
            this.label5.Text = "Do you wish to create a new WPS or Allocate an Existing WPS?";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpInfoNew
            // 
            this.tlpInfoNew.ColumnCount = 6;
            this.tlpInfoNew.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 15F));
            this.tlpInfoNew.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpInfoNew.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 15F));
            this.tlpInfoNew.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpInfoNew.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 15F));
            this.tlpInfoNew.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpInfoNew.Controls.Add(this.tableLayoutPanel2, 0, 9);
            this.tlpInfoNew.Controls.Add(this.txtInfoMaxDiameter, 3, 3);
            this.tlpInfoNew.Controls.Add(this.label9, 2, 3);
            this.tlpInfoNew.Controls.Add(this.txtInfoMaxThickness, 1, 3);
            this.tlpInfoNew.Controls.Add(this.label8, 0, 3);
            this.tlpInfoNew.Controls.Add(this.label101, 4, 0);
            this.tlpInfoNew.Controls.Add(this.txtInfoJob, 5, 0);
            this.tlpInfoNew.Controls.Add(this.label1, 0, 8);
            this.tlpInfoNew.Controls.Add(this.cboInfoPrepared, 1, 1);
            this.tlpInfoNew.Controls.Add(this.dtpInfoDate, 3, 1);
            this.tlpInfoNew.Controls.Add(this.cbInfoVisual, 1, 11);
            this.tlpInfoNew.Controls.Add(this.cbInfoNDT, 0, 11);
            this.tlpInfoNew.Controls.Add(this.cbInfoDPI, 2, 11);
            this.tlpInfoNew.Controls.Add(this.cbInfoMPI, 3, 11);
            this.tlpInfoNew.Controls.Add(this.cbInfoRT, 4, 11);
            this.tlpInfoNew.Controls.Add(this.cbInfoUT, 5, 11);
            this.tlpInfoNew.Controls.Add(this.label88, 2, 0);
            this.tlpInfoNew.Controls.Add(this.label90, 0, 1);
            this.tlpInfoNew.Controls.Add(this.label89, 2, 1);
            this.tlpInfoNew.Controls.Add(this.label87, 0, 2);
            this.tlpInfoNew.Controls.Add(this.label99, 4, 1);
            this.tlpInfoNew.Controls.Add(this.label86, 2, 2);
            this.tlpInfoNew.Controls.Add(this.label100, 4, 2);
            this.tlpInfoNew.Controls.Add(this.label82, 4, 3);
            this.tlpInfoNew.Controls.Add(this.label57, 2, 4);
            this.tlpInfoNew.Controls.Add(this.label98, 0, 4);
            this.tlpInfoNew.Controls.Add(this.label58, 4, 4);
            this.tlpInfoNew.Controls.Add(this.label81, 0, 6);
            this.tlpInfoNew.Controls.Add(this.label94, 0, 7);
            this.tlpInfoNew.Controls.Add(this.label93, 2, 7);
            this.tlpInfoNew.Controls.Add(this.label79, 4, 7);
            this.tlpInfoNew.Controls.Add(this.label59, 0, 5);
            this.tlpInfoNew.Controls.Add(this.label60, 0, 10);
            this.tlpInfoNew.Controls.Add(this.txtInfoMinThickness, 1, 2);
            this.tlpInfoNew.Controls.Add(this.txtInfoPWHT, 1, 4);
            this.tlpInfoNew.Controls.Add(this.txtInfoInterpass, 5, 4);
            this.tlpInfoNew.Controls.Add(this.txtInfoMatStandard, 1, 7);
            this.tlpInfoNew.Controls.Add(this.txtInfoWPS, 3, 0);
            this.tlpInfoNew.Controls.Add(this.txtInfoMinDiameter, 3, 2);
            this.tlpInfoNew.Controls.Add(this.txtInfoPreheat, 3, 4);
            this.tlpInfoNew.Controls.Add(this.txtInfoNotes, 1, 5);
            this.tlpInfoNew.Controls.Add(this.txtInfoMatGrade, 3, 7);
            this.tlpInfoNew.Controls.Add(this.txtInfoMatPNo, 5, 7);
            this.tlpInfoNew.Controls.Add(this.txtInfoJoint, 5, 1);
            this.tlpInfoNew.Controls.Add(this.txtInfoPrep, 5, 2);
            this.tlpInfoNew.Controls.Add(this.txtInfoGouging, 5, 3);
            this.tlpInfoNew.Controls.Add(this.label102, 0, 0);
            this.tlpInfoNew.Controls.Add(this.cboInfoWPQR, 1, 0);
            this.tlpInfoNew.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpInfoNew.Location = new System.Drawing.Point(3, 42);
            this.tlpInfoNew.Name = "tlpInfoNew";
            this.tlpInfoNew.RowCount = 12;
            this.tlpInfoNew.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpInfoNew.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpInfoNew.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpInfoNew.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpInfoNew.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpInfoNew.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpInfoNew.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpInfoNew.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpInfoNew.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpInfoNew.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpInfoNew.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpInfoNew.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpInfoNew.Size = new System.Drawing.Size(1018, 308);
            this.tlpInfoNew.TabIndex = 4;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 8;
            this.tlpInfoNew.SetColumnSpan(this.tableLayoutPanel2, 6);
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.txtInfoShieldTol, 7, 0);
            this.tableLayoutPanel2.Controls.Add(this.label10, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtInfoVoltTol, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label4, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtInfoAmpTol, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtInfoSpeedTol, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.label2, 4, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 225);
            this.tableLayoutPanel2.Margin = new Wisej.Web.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1018, 25);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // txtInfoShieldTol
            // 
            this.txtInfoShieldTol.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoShieldTol.InputType.Max = "1";
            this.txtInfoShieldTol.InputType.Min = "0";
            this.txtInfoShieldTol.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtInfoShieldTol.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtInfoShieldTol.InvalidMessage = "Tolerance must be between 0-1 (to convert a percentage divide by 100)";
            this.txtInfoShieldTol.Location = new System.Drawing.Point(892, 3);
            this.txtInfoShieldTol.Name = "txtInfoShieldTol";
            this.txtInfoShieldTol.Size = new System.Drawing.Size(123, 19);
            this.txtInfoShieldTol.TabIndex = 106;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromName("@window");
            this.label10.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label10.Dock = Wisej.Web.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(765, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 19);
            this.label10.TabIndex = 105;
            this.label10.Text = "Shield Gas Tolerance";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromName("@window");
            this.label3.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label3.Dock = Wisej.Web.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 19);
            this.label3.TabIndex = 103;
            this.label3.Text = "Voltage Tolerance";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtInfoVoltTol
            // 
            this.txtInfoVoltTol.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoVoltTol.InputType.Max = "1";
            this.txtInfoVoltTol.InputType.Min = "0";
            this.txtInfoVoltTol.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtInfoVoltTol.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtInfoVoltTol.InvalidMessage = "Tolerance must be between 0-1 (to convert a percentage divide by 100)";
            this.txtInfoVoltTol.Location = new System.Drawing.Point(130, 3);
            this.txtInfoVoltTol.Name = "txtInfoVoltTol";
            this.txtInfoVoltTol.Size = new System.Drawing.Size(121, 19);
            this.txtInfoVoltTol.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromName("@window");
            this.label4.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label4.Dock = Wisej.Web.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(257, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 19);
            this.label4.TabIndex = 104;
            this.label4.Text = "Amp Tolerance";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtInfoAmpTol
            // 
            this.txtInfoAmpTol.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoAmpTol.InputType.Max = "1";
            this.txtInfoAmpTol.InputType.Min = "0";
            this.txtInfoAmpTol.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtInfoAmpTol.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtInfoAmpTol.InvalidMessage = "Tolerance must be between 0-1 (to convert a percentage divide by 100)";
            this.txtInfoAmpTol.Location = new System.Drawing.Point(384, 3);
            this.txtInfoAmpTol.Name = "txtInfoAmpTol";
            this.txtInfoAmpTol.Size = new System.Drawing.Size(121, 19);
            this.txtInfoAmpTol.TabIndex = 18;
            // 
            // txtInfoSpeedTol
            // 
            this.txtInfoSpeedTol.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoSpeedTol.InputType.Max = "1";
            this.txtInfoSpeedTol.InputType.Min = "0";
            this.txtInfoSpeedTol.InputType.Mode = Wisej.Web.TextBoxMode.Decimal;
            this.txtInfoSpeedTol.InputType.Type = Wisej.Web.TextBoxType.Number;
            this.txtInfoSpeedTol.InvalidMessage = "Tolerance must be between 0-1 (to convert a percentage divide by 100)";
            this.txtInfoSpeedTol.Location = new System.Drawing.Point(638, 3);
            this.txtInfoSpeedTol.Name = "txtInfoSpeedTol";
            this.txtInfoSpeedTol.Size = new System.Drawing.Size(121, 19);
            this.txtInfoSpeedTol.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromName("@window");
            this.label2.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(511, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 19);
            this.label2.TabIndex = 102;
            this.label2.Text = "Weld Speed Tolerance";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtInfoMaxDiameter
            // 
            this.txtInfoMaxDiameter.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMaxDiameter.Location = new System.Drawing.Point(486, 78);
            this.txtInfoMaxDiameter.Name = "txtInfoMaxDiameter";
            this.txtInfoMaxDiameter.Size = new System.Drawing.Size(187, 19);
            this.txtInfoMaxDiameter.TabIndex = 108;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromName("@window");
            this.label9.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label9.Dock = Wisej.Web.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(341, 78);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(139, 19);
            this.label9.TabIndex = 107;
            this.label9.Text = "Max Diameter (mm)";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtInfoMaxThickness
            // 
            this.txtInfoMaxThickness.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMaxThickness.Location = new System.Drawing.Point(148, 78);
            this.txtInfoMaxThickness.Name = "txtInfoMaxThickness";
            this.txtInfoMaxThickness.Size = new System.Drawing.Size(187, 19);
            this.txtInfoMaxThickness.TabIndex = 106;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromName("@window");
            this.label8.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label8.Dock = Wisej.Web.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(3, 78);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(139, 19);
            this.label8.TabIndex = 105;
            this.label8.Text = "Max Thickness (mm)";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.BackColor = System.Drawing.Color.FromName("@window");
            this.label101.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label101.Dock = Wisej.Web.DockStyle.Fill;
            this.label101.Location = new System.Drawing.Point(679, 3);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(139, 19);
            this.label101.TabIndex = 1;
            this.label101.Text = "Job Number";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtInfoJob
            // 
            this.txtInfoJob.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoJob.Location = new System.Drawing.Point(824, 3);
            this.txtInfoJob.Name = "txtInfoJob";
            this.txtInfoJob.Size = new System.Drawing.Size(191, 19);
            this.txtInfoJob.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tlpInfoNew.SetColumnSpan(this.label1, 6);
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 203);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1012, 19);
            this.label1.TabIndex = 101;
            this.label1.Text = "Tolerances (Value from 0 to 1)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cboInfoPrepared
            // 
            this.cboInfoPrepared.AutoCompleteMode = Wisej.Web.AutoCompleteMode.Filter;
            this.cboInfoPrepared.Dock = Wisej.Web.DockStyle.Fill;
            this.cboInfoPrepared.Location = new System.Drawing.Point(148, 28);
            this.cboInfoPrepared.Name = "cboInfoPrepared";
            this.cboInfoPrepared.Size = new System.Drawing.Size(187, 19);
            this.cboInfoPrepared.Sorted = true;
            this.cboInfoPrepared.TabIndex = 1;
            // 
            // dtpInfoDate
            // 
            this.dtpInfoDate.Dock = Wisej.Web.DockStyle.Fill;
            this.dtpInfoDate.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpInfoDate.Location = new System.Drawing.Point(486, 28);
            this.dtpInfoDate.Name = "dtpInfoDate";
            this.dtpInfoDate.Size = new System.Drawing.Size(187, 19);
            this.dtpInfoDate.TabIndex = 6;
            this.dtpInfoDate.Value = new System.DateTime(2024, 3, 20, 13, 45, 3, 752);
            // 
            // cbInfoVisual
            // 
            this.cbInfoVisual.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoVisual.BackColor = System.Drawing.Color.FromName("@window");
            this.cbInfoVisual.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbInfoVisual.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbInfoVisual.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoVisual.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbInfoVisual.Location = new System.Drawing.Point(148, 278);
            this.cbInfoVisual.Name = "cbInfoVisual";
            this.cbInfoVisual.Size = new System.Drawing.Size(187, 27);
            this.cbInfoVisual.TabIndex = 21;
            this.cbInfoVisual.Text = "Visual";
            this.cbInfoVisual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbInfoNDT
            // 
            this.cbInfoNDT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoNDT.BackColor = System.Drawing.Color.FromName("@window");
            this.cbInfoNDT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbInfoNDT.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbInfoNDT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoNDT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbInfoNDT.Location = new System.Drawing.Point(3, 278);
            this.cbInfoNDT.Name = "cbInfoNDT";
            this.cbInfoNDT.Size = new System.Drawing.Size(139, 27);
            this.cbInfoNDT.TabIndex = 20;
            this.cbInfoNDT.Text = "NDT";
            this.cbInfoNDT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbInfoDPI
            // 
            this.cbInfoDPI.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoDPI.BackColor = System.Drawing.Color.FromName("@window");
            this.cbInfoDPI.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbInfoDPI.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbInfoDPI.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoDPI.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbInfoDPI.Location = new System.Drawing.Point(341, 278);
            this.cbInfoDPI.Name = "cbInfoDPI";
            this.cbInfoDPI.Size = new System.Drawing.Size(139, 27);
            this.cbInfoDPI.TabIndex = 22;
            this.cbInfoDPI.Text = "DPI";
            this.cbInfoDPI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbInfoMPI
            // 
            this.cbInfoMPI.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoMPI.BackColor = System.Drawing.Color.FromName("@window");
            this.cbInfoMPI.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbInfoMPI.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbInfoMPI.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoMPI.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbInfoMPI.Location = new System.Drawing.Point(486, 278);
            this.cbInfoMPI.Name = "cbInfoMPI";
            this.cbInfoMPI.Size = new System.Drawing.Size(187, 27);
            this.cbInfoMPI.TabIndex = 23;
            this.cbInfoMPI.Text = "MPI";
            this.cbInfoMPI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbInfoRT
            // 
            this.cbInfoRT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoRT.BackColor = System.Drawing.Color.FromName("@window");
            this.cbInfoRT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbInfoRT.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbInfoRT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoRT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbInfoRT.Location = new System.Drawing.Point(679, 278);
            this.cbInfoRT.Name = "cbInfoRT";
            this.cbInfoRT.Size = new System.Drawing.Size(139, 27);
            this.cbInfoRT.TabIndex = 24;
            this.cbInfoRT.Text = "RT";
            this.cbInfoRT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbInfoUT
            // 
            this.cbInfoUT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoUT.BackColor = System.Drawing.Color.FromName("@window");
            this.cbInfoUT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbInfoUT.CssStyle = "border: 1px solid rgba(202, 80, 16, 1);";
            this.cbInfoUT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoUT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbInfoUT.Location = new System.Drawing.Point(824, 278);
            this.cbInfoUT.Name = "cbInfoUT";
            this.cbInfoUT.Size = new System.Drawing.Size(191, 27);
            this.cbInfoUT.TabIndex = 25;
            this.cbInfoUT.Text = "UT";
            this.cbInfoUT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.BackColor = System.Drawing.Color.FromName("@window");
            this.label88.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label88.Dock = Wisej.Web.DockStyle.Fill;
            this.label88.Location = new System.Drawing.Point(341, 3);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(139, 19);
            this.label88.TabIndex = 14;
            this.label88.Text = "WPS Number";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.BackColor = System.Drawing.Color.FromName("@window");
            this.label90.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label90.Dock = Wisej.Web.DockStyle.Fill;
            this.label90.Location = new System.Drawing.Point(3, 28);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(139, 19);
            this.label90.TabIndex = 12;
            this.label90.Text = "Prepared By EID";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.BackColor = System.Drawing.Color.FromName("@window");
            this.label89.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label89.Dock = Wisej.Web.DockStyle.Fill;
            this.label89.Location = new System.Drawing.Point(341, 28);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(139, 19);
            this.label89.TabIndex = 13;
            this.label89.Text = "Date";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.BackColor = System.Drawing.Color.FromName("@window");
            this.label87.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label87.Dock = Wisej.Web.DockStyle.Fill;
            this.label87.Location = new System.Drawing.Point(3, 53);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(139, 19);
            this.label87.TabIndex = 15;
            this.label87.Text = "Min Thickness (mm)";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.BackColor = System.Drawing.Color.FromName("@window");
            this.label99.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label99.Dock = Wisej.Web.DockStyle.Fill;
            this.label99.Location = new System.Drawing.Point(679, 28);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(139, 19);
            this.label99.TabIndex = 3;
            this.label99.Text = "Joint Type";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.BackColor = System.Drawing.Color.FromName("@window");
            this.label86.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label86.Dock = Wisej.Web.DockStyle.Fill;
            this.label86.Location = new System.Drawing.Point(341, 53);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(139, 19);
            this.label86.TabIndex = 16;
            this.label86.Text = "Min Diameter (mm)";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.BackColor = System.Drawing.Color.FromName("@window");
            this.label100.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label100.Dock = Wisej.Web.DockStyle.Fill;
            this.label100.Location = new System.Drawing.Point(679, 53);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(139, 19);
            this.label100.TabIndex = 2;
            this.label100.Text = "Prep Method";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.BackColor = System.Drawing.Color.FromName("@window");
            this.label82.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label82.Dock = Wisej.Web.DockStyle.Fill;
            this.label82.Location = new System.Drawing.Point(679, 78);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(139, 19);
            this.label82.TabIndex = 20;
            this.label82.Text = "Gouging Method";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.FromName("@window");
            this.label57.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label57.Dock = Wisej.Web.DockStyle.Fill;
            this.label57.Location = new System.Drawing.Point(341, 103);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(139, 19);
            this.label57.TabIndex = 39;
            this.label57.Text = "Preheat Temperature";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.BackColor = System.Drawing.Color.FromName("@window");
            this.label98.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label98.Dock = Wisej.Web.DockStyle.Fill;
            this.label98.Location = new System.Drawing.Point(3, 103);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(139, 19);
            this.label98.TabIndex = 4;
            this.label98.Text = "PWHT";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.Color.FromName("@window");
            this.label58.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label58.Dock = Wisej.Web.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(679, 103);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(139, 19);
            this.label58.TabIndex = 40;
            this.label58.Text = "Interpass Temperature";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label81.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tlpInfoNew.SetColumnSpan(this.label81, 6);
            this.label81.Dock = Wisej.Web.DockStyle.Fill;
            this.label81.Location = new System.Drawing.Point(3, 153);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(1012, 19);
            this.label81.TabIndex = 21;
            this.label81.Text = "Base Metals";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.BackColor = System.Drawing.Color.FromName("@window");
            this.label94.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label94.Dock = Wisej.Web.DockStyle.Fill;
            this.label94.Location = new System.Drawing.Point(3, 178);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(139, 19);
            this.label94.TabIndex = 8;
            this.label94.Text = "Material Standard";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.BackColor = System.Drawing.Color.FromName("@window");
            this.label93.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label93.Dock = Wisej.Web.DockStyle.Fill;
            this.label93.Location = new System.Drawing.Point(341, 178);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(139, 19);
            this.label93.TabIndex = 9;
            this.label93.Text = "Material Grade";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.BackColor = System.Drawing.Color.FromName("@window");
            this.label79.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label79.Dock = Wisej.Web.DockStyle.Fill;
            this.label79.Location = new System.Drawing.Point(679, 178);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(139, 19);
            this.label79.TabIndex = 22;
            this.label79.Text = "P / Group Number";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.Color.FromName("@window");
            this.label59.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label59.Dock = Wisej.Web.DockStyle.Fill;
            this.label59.Location = new System.Drawing.Point(3, 128);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(139, 19);
            this.label59.TabIndex = 41;
            this.label59.Text = "Notes";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label60.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tlpInfoNew.SetColumnSpan(this.label60, 6);
            this.label60.Dock = Wisej.Web.DockStyle.Fill;
            this.label60.Location = new System.Drawing.Point(3, 253);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(1012, 19);
            this.label60.TabIndex = 42;
            this.label60.Text = "Required Testing";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtInfoMinThickness
            // 
            this.txtInfoMinThickness.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMinThickness.Location = new System.Drawing.Point(148, 53);
            this.txtInfoMinThickness.Name = "txtInfoMinThickness";
            this.txtInfoMinThickness.Size = new System.Drawing.Size(187, 19);
            this.txtInfoMinThickness.TabIndex = 2;
            // 
            // txtInfoPWHT
            // 
            this.txtInfoPWHT.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPWHT.Location = new System.Drawing.Point(148, 103);
            this.txtInfoPWHT.Name = "txtInfoPWHT";
            this.txtInfoPWHT.Size = new System.Drawing.Size(187, 19);
            this.txtInfoPWHT.TabIndex = 3;
            // 
            // txtInfoInterpass
            // 
            this.txtInfoInterpass.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoInterpass.Location = new System.Drawing.Point(824, 103);
            this.txtInfoInterpass.Name = "txtInfoInterpass";
            this.txtInfoInterpass.Size = new System.Drawing.Size(191, 19);
            this.txtInfoInterpass.TabIndex = 4;
            // 
            // txtInfoMatStandard
            // 
            this.txtInfoMatStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatStandard.Location = new System.Drawing.Point(148, 178);
            this.txtInfoMatStandard.Name = "txtInfoMatStandard";
            this.txtInfoMatStandard.Size = new System.Drawing.Size(187, 19);
            this.txtInfoMatStandard.TabIndex = 14;
            // 
            // txtInfoWPS
            // 
            this.txtInfoWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoWPS.Location = new System.Drawing.Point(486, 3);
            this.txtInfoWPS.Name = "txtInfoWPS";
            this.txtInfoWPS.Size = new System.Drawing.Size(187, 19);
            this.txtInfoWPS.TabIndex = 5;
            // 
            // txtInfoMinDiameter
            // 
            this.txtInfoMinDiameter.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMinDiameter.Location = new System.Drawing.Point(486, 53);
            this.txtInfoMinDiameter.Name = "txtInfoMinDiameter";
            this.txtInfoMinDiameter.Size = new System.Drawing.Size(187, 19);
            this.txtInfoMinDiameter.TabIndex = 7;
            // 
            // txtInfoPreheat
            // 
            this.txtInfoPreheat.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPreheat.Location = new System.Drawing.Point(486, 103);
            this.txtInfoPreheat.Name = "txtInfoPreheat";
            this.txtInfoPreheat.Size = new System.Drawing.Size(187, 19);
            this.txtInfoPreheat.TabIndex = 8;
            // 
            // txtInfoNotes
            // 
            this.tlpInfoNew.SetColumnSpan(this.txtInfoNotes, 5);
            this.txtInfoNotes.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoNotes.Location = new System.Drawing.Point(148, 128);
            this.txtInfoNotes.Name = "txtInfoNotes";
            this.txtInfoNotes.Size = new System.Drawing.Size(867, 19);
            this.txtInfoNotes.TabIndex = 13;
            // 
            // txtInfoMatGrade
            // 
            this.txtInfoMatGrade.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatGrade.Location = new System.Drawing.Point(486, 178);
            this.txtInfoMatGrade.Name = "txtInfoMatGrade";
            this.txtInfoMatGrade.Size = new System.Drawing.Size(187, 19);
            this.txtInfoMatGrade.TabIndex = 15;
            // 
            // txtInfoMatPNo
            // 
            this.txtInfoMatPNo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatPNo.Location = new System.Drawing.Point(824, 178);
            this.txtInfoMatPNo.Name = "txtInfoMatPNo";
            this.txtInfoMatPNo.Size = new System.Drawing.Size(191, 19);
            this.txtInfoMatPNo.TabIndex = 16;
            // 
            // txtInfoJoint
            // 
            this.txtInfoJoint.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoJoint.Location = new System.Drawing.Point(824, 28);
            this.txtInfoJoint.Name = "txtInfoJoint";
            this.txtInfoJoint.Size = new System.Drawing.Size(191, 19);
            this.txtInfoJoint.TabIndex = 10;
            // 
            // txtInfoPrep
            // 
            this.txtInfoPrep.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPrep.Location = new System.Drawing.Point(824, 53);
            this.txtInfoPrep.Name = "txtInfoPrep";
            this.txtInfoPrep.Size = new System.Drawing.Size(191, 19);
            this.txtInfoPrep.TabIndex = 11;
            // 
            // txtInfoGouging
            // 
            this.txtInfoGouging.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoGouging.Location = new System.Drawing.Point(824, 78);
            this.txtInfoGouging.Name = "txtInfoGouging";
            this.txtInfoGouging.Size = new System.Drawing.Size(191, 19);
            this.txtInfoGouging.TabIndex = 12;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.BackColor = System.Drawing.Color.FromName("@window");
            this.label102.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.label102.Dock = Wisej.Web.DockStyle.Fill;
            this.label102.Location = new System.Drawing.Point(3, 3);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(139, 19);
            this.label102.TabIndex = 0;
            this.label102.Text = "WPQR Number";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboInfoWPQR
            // 
            this.cboInfoWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.cboInfoWPQR.Location = new System.Drawing.Point(148, 3);
            this.cboInfoWPQR.Name = "cboInfoWPQR";
            this.cboInfoWPQR.Size = new System.Drawing.Size(187, 19);
            this.cboInfoWPQR.TabIndex = 0;
            this.cboInfoWPQR.SelectedItemChanged += new System.EventHandler(this.cboInfoWPQR_SelectedItemChanged);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel28, 0, 0);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel28.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel28.ColumnCount = 1;
            this.tableLayoutPanel28.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel28.Controls.Add(this.btnInfoBack, 0, 2);
            this.tableLayoutPanel28.Controls.Add(this.btnInfoHome, 0, 3);
            this.tableLayoutPanel28.Controls.Add(this.btnInfoNext, 0, 4);
            this.tableLayoutPanel28.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel28.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 5;
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel28.TabIndex = 4;
            // 
            // btnInfoBack
            // 
            this.btnInfoBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnInfoBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoBack.Location = new System.Drawing.Point(3, 173);
            this.btnInfoBack.Name = "btnInfoBack";
            this.btnInfoBack.Size = new System.Drawing.Size(95, 79);
            this.btnInfoBack.TabIndex = 28;
            this.btnInfoBack.Text = "Back";
            this.btnInfoBack.Click += new System.EventHandler(this.btnInfoBack_Click);
            // 
            // btnInfoHome
            // 
            this.btnInfoHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnInfoHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoHome.Location = new System.Drawing.Point(3, 258);
            this.btnInfoHome.Name = "btnInfoHome";
            this.btnInfoHome.Size = new System.Drawing.Size(95, 79);
            this.btnInfoHome.TabIndex = 27;
            this.btnInfoHome.Text = "Home";
            this.btnInfoHome.Click += new System.EventHandler(this.btnInfoHome_Click);
            // 
            // btnInfoNext
            // 
            this.btnInfoNext.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnInfoNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoNext.Location = new System.Drawing.Point(3, 343);
            this.btnInfoNext.Name = "btnInfoNext";
            this.btnInfoNext.Size = new System.Drawing.Size(95, 79);
            this.btnInfoNext.TabIndex = 26;
            this.btnInfoNext.Text = "Next";
            this.btnInfoNext.Click += new System.EventHandler(this.btnInfoNext_Click);
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.ColumnCount = 1;
            this.tableLayoutPanel29.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel29.Controls.Add(this.lblInfoNote, 0, 1);
            this.tableLayoutPanel29.Controls.Add(this.label104, 0, 0);
            this.tableLayoutPanel29.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel29.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 2;
            this.tableLayoutPanel29.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel29.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel29.TabIndex = 0;
            // 
            // lblInfoNote
            // 
            this.lblInfoNote.AutoSize = true;
            this.lblInfoNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblInfoNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblInfoNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblInfoNote.LinkArea = new Wisej.Web.LinkArea(236, 84);
            this.lblInfoNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblInfoNote.Location = new System.Drawing.Point(9, 79);
            this.lblInfoNote.Margin = new Wisej.Web.Padding(9, 3, 6, 3);
            this.lblInfoNote.Name = "lblInfoNote";
            this.lblInfoNote.Size = new System.Drawing.Size(1130, 35);
            this.lblInfoNote.TabIndex = 16;
            this.lblInfoNote.Text = resources.GetString("lblInfoNote.Text");
            this.lblInfoNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfoNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblInfoNote_LinkClicked);
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.BackColor = System.Drawing.Color.FromName("@window");
            this.label104.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label104.CssStyle = "border-radius: 4px;";
            this.label104.Dock = Wisej.Web.DockStyle.Fill;
            this.label104.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label104.Location = new System.Drawing.Point(9, 3);
            this.label104.Margin = new Wisej.Web.Padding(9, 3, 6, 3);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(1130, 70);
            this.label104.TabIndex = 0;
            this.label104.Text = "WPS Information";
            this.label104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label104.DoubleClick += new System.EventHandler(this.label104_DoubleClick);
            // 
            // mscboInfoWPS
            // 
            this.mscboInfoWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.mscboInfoWPS.Location = new System.Drawing.Point(512, 3);
            this.mscboInfoWPS.Name = "mscboInfoWPS";
            this.mscboInfoWPS.Size = new System.Drawing.Size(503, 8);
            this.mscboInfoWPS.TabIndex = 4;
            // 
            // uc_wpsInfo
            // 
            this.Controls.Add(this.tableLayoutPanel25);
            this.Name = "uc_wpsInfo";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_wpsInfo_VisibleChanged);
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tlpInfoInput.ResumeLayout(false);
            this.tlpInfoAllocate.ResumeLayout(false);
            this.tlpInfoAllocate.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tlpInfoNew.ResumeLayout(false);
            this.tlpInfoNew.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel29.ResumeLayout(false);
            this.tableLayoutPanel29.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel25;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel26;
        private Wisej.Web.TableLayoutPanel tlpInfoNew;
        private Wisej.Web.CheckBox cbInfoVisual;
        private Wisej.Web.CheckBox cbInfoNDT;
        private Wisej.Web.CheckBox cbInfoDPI;
        private Wisej.Web.CheckBox cbInfoMPI;
        private Wisej.Web.CheckBox cbInfoRT;
        private Wisej.Web.CheckBox cbInfoUT;
        private Wisej.Web.Label label101;
        private Wisej.Web.Label label88;
        private Wisej.Web.Label label102;
        private Wisej.Web.Label label90;
        private Wisej.Web.Label label89;
        private Wisej.Web.Label label87;
        private Wisej.Web.Label label99;
        private Wisej.Web.Label label86;
        private Wisej.Web.Label label100;
        private Wisej.Web.Label label82;
        private Wisej.Web.Label label57;
        private Wisej.Web.Label label98;
        private Wisej.Web.Label label58;
        private Wisej.Web.Label label81;
        private Wisej.Web.Label label94;
        private Wisej.Web.Label label93;
        private Wisej.Web.Label label79;
        private Wisej.Web.Label label59;
        private Wisej.Web.Label label60;
        private Wisej.Web.TextBox txtInfoJob;
        private Wisej.Web.TextBox txtInfoMinThickness;
        private Wisej.Web.TextBox txtInfoPWHT;
        private Wisej.Web.TextBox txtInfoInterpass;
        private Wisej.Web.TextBox txtInfoMatStandard;
        private Wisej.Web.TextBox txtInfoWPS;
        private Wisej.Web.TextBox txtInfoMinDiameter;
        private Wisej.Web.TextBox txtInfoPreheat;
        private Wisej.Web.TextBox txtInfoNotes;
        private Wisej.Web.TextBox txtInfoMatGrade;
        private Wisej.Web.TextBox txtInfoMatPNo;
        private Wisej.Web.TextBox txtInfoJoint;
        private Wisej.Web.TextBox txtInfoPrep;
        private Wisej.Web.TextBox txtInfoGouging;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel29;
        private Wisej.Web.Label label104;
        private Wisej.Web.ComboBox cboInfoWPQR;
        private Wisej.Web.DateTimePicker dtpInfoDate;
        private Wisej.Web.ComboBox cboInfoPrepared;
        private Wisej.Web.TextBox txtInfoSpeedTol;
        private Wisej.Web.TextBox txtInfoAmpTol;
        private Wisej.Web.TextBox txtInfoVoltTol;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label2;
        private Wisej.Web.Label label1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel28;
        private Wisej.Web.Button btnInfoBack;
        private Wisej.Web.Button btnInfoHome;
        private Wisej.Web.Button btnInfoNext;
        private Wisej.Web.LinkLabel lblInfoNote;
        private Wisej.Web.TableLayoutPanel tlpInfoInput;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.Label label5;
        private Wisej.Web.CheckBox cbInfoWPS;
        private Wisej.Web.TableLayoutPanel tlpInfoAllocate;
        private Wisej.Web.Label label6;
        private MultiSelectComboBox mscboInfoWPS;
        private Wisej.Web.Label label7;
        private Wisej.Web.Label label8;
        private Wisej.Web.TextBox txtInfoMaxDiameter;
        private Wisej.Web.Label label9;
        private Wisej.Web.TextBox txtInfoMaxThickness;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.TextBox txtInfoShieldTol;
        private Wisej.Web.Label label10;
    }
}
