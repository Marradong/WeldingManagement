﻿using ApiClient;
using PeopleEF;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Web.Security;
using Welding.DAL;
using WeldingManagement.UserControls.PopupControls;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.WPSControls
{
    public partial class uc_wpsInfo : Wisej.Web.UserControl
    {
        private up_rqFilesView up_rqFilesView1;
        private up_hmSave up_hmSave1;
        private Panel overlayPanel;

        public uc_wpsInfo()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks next button on info screen")]
        public event EventHandler btnInfoNextClick;
        private void btnInfoNext_Click(object sender, EventArgs e)
        {
            if (cbInfoWPS.Checked && mscboInfoWPS.Get_OuputDataList().Count <= 0)
            {
                return;
            }

            UIFormatting.StartLoader(this);

            Save_Action();
            Update_Status();

            if (cbInfoWPS.Checked) 
            { 
                if (up_rqFilesView1 == null)
                {
                    up_rqFilesView1 = new up_rqFilesView();
                    this.Controls.Add(up_rqFilesView1);
                }

                up_rqFilesView1.Tag = (Tag)this.Tag;

                overlayPanel.Visible = true;

                UIFormatting.StopLoader(this);

                up_rqFilesView1.ShowPopup(new Point(this.Width / 2 - up_rqFilesView1.Width / 2, this.Height / 2 - up_rqFilesView1.Height / 2), up_rqFilesView_Closed);
            }
            else
            {
                UIFormatting.StopLoader(this);

                btnInfoNextClick?.Invoke(this, e);
            }
        }

        private void up_rqFilesView_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            btnInfoNextClick?.Invoke(this, new EventArgs());
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on info screen")]
        public event EventHandler btnInfoHomeClick;
        private void btnInfoHome_Click(object sender, EventArgs e)
        {
            if (!cbInfoWPS.Checked)
            {
                Save_Action();
            }

            btnInfoHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on info screen")]
        public event EventHandler btnInfoBackClick;
        private void btnInfoBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnInfoBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnInfoBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS || cbInfoWPS.Checked)
            {
                return;
            }

            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            wps.Status = Actions.WPSParameters;

            ApiCalls.UpdateWPS(wps.WPSId, wps);

            this.Tag = new Tag(ApiCalls.ReadWPS(wps.WPSId), TagType.WPS);
        }

        private void Save_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS)
            {
                return;
            }

            if (cbInfoWPS.Checked)
            {
                if (mscboInfoWPS.Get_OuputDataList().Count > 0 && thisTag.getTagObject() is WeldingAction)
                {
                    WeldingAction wa = ApiCalls.ReadWeldingAction(((WeldingAction)thisTag.getTagObject()).WeldingActionId);

                    wa.NewWeldingForm.OperationalReview.WPSAmount--;

                    ApiCalls.UpdateOperationalReview(wa.NewWeldingForm.OperationalReview.OperationalReviewId, wa.NewWeldingForm.OperationalReview);

                    List<object> relatedWPSs = mscboInfoWPS.Get_OuputDataList();

                    foreach (object wpsNo in relatedWPSs)
                    {
                        WPSNumberList wpsList = new WPSNumberList(wa.NewWeldingForm.OperationalReview) { WPSNumber = (string)wpsNo };

                        ApiCalls.CreateWPSNumberList(wa.NewWeldingForm.OperationalReview.OperationalReviewId, wpsList);
                    }
                }

                return;
            }

            if (cboInfoWPQR.SelectedItem == null)
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)((Tag)cboInfoWPQR.SelectedItem).getTagObject()).WPQRId);

            if (thisTag.getTagObject() is WeldingAction)
            {
                WPS newWPS = ApiCalls.CreateWPS(wpqr.WPQRId, new WPS(wpqr, wpqr.Welder_Qualification.WeldingAction) { Status = Actions.WPSInfo });

                this.Tag = new Tag(ApiCalls.ReadWPS(newWPS.WPSId), TagType.WPS);

                thisTag = (Tag)this.Tag;
            }
            else if (thisTag.getTagObject() is WPS)
            {
                WPS oldWPS = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

                if (oldWPS.WPQR.WPQRId != wpqr.WPQRId)
                {
                    ApiCalls.DeleteWPS(oldWPS.WPSId);

                    WPS createdWPS = ApiCalls.CreateWPS(wpqr.WPQRId, new WPS(wpqr, wpqr.Welder_Qualification.WeldingAction) { Status = Actions.WPSInfo });

                    this.Tag = new Tag(ApiCalls.ReadWPS(createdWPS.WPSId), TagType.WPS);

                    thisTag = (Tag)this.Tag;
                }
            }

            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            if (txtInfoWPS.Text != null)
                wps.WPSNumber = txtInfoWPS.Text;

            if (cboInfoPrepared.SelectedItem != null)
                wps.WPSPreparerEID = ((Tag)cboInfoPrepared.SelectedItem).getTagName();

            if (dtpInfoDate.Value != null)
                wps.Date = dtpInfoDate.Value;

            if (txtInfoJoint.Text != null)
                wps.JointType = txtInfoJoint.Text;

            wps.MinThickness = double.TryParse(txtInfoMinThickness.Text, out double minthickness) ? minthickness : -1;
            wps.MaxThickness = double.TryParse(txtInfoMaxThickness.Text, out double maxthickness) ? maxthickness : -1;

            wps.MinDiameter = double.TryParse(txtInfoMinDiameter.Text, out double mindiameter) ? mindiameter : -1;
            wps.MaxDiameter = double.TryParse(txtInfoMaxDiameter.Text, out double maxdiameter) ? maxdiameter : -1;

            if (txtInfoPrep.Text != null)
                wps.PrepMethod = txtInfoPrep.Text;

            wps.PWHT = double.TryParse(txtInfoPWHT.Text, out double pwht) ? pwht : -1;

            wps.Preheat = double.TryParse(txtInfoPreheat.Text, out double preheat) ? preheat : -1;

            if (txtInfoGouging.Text != null)
                wps.GougingMethod = txtInfoGouging.Text;

            wps.Interpass = double.TryParse(txtInfoInterpass.Text, out double interpass) ? interpass : -1;

            if (txtInfoNotes.Text != null)
                wps.Notes = txtInfoNotes.Text;

            if (txtInfoMatStandard.Text != null)
                wps.MaterialStd = txtInfoMatStandard.Text;

            if (txtInfoMatGrade.Text != null)
                wps.MaterialGrd = txtInfoMatGrade.Text;

            if (txtInfoMatPNo.Text != null)
                wps.MaterialPNo = txtInfoMatPNo.Text;


            wps.VoltTol = ConvertTolerance(txtInfoVoltTol.Text);
            wps.AmpTol = ConvertTolerance(txtInfoAmpTol.Text);
            wps.SpeedTol = ConvertTolerance(txtInfoSpeedTol.Text);
            wps.ShieldTol = ConvertTolerance(txtInfoShieldTol.Text);

            if (wps.WPS_Run.Count > 0)
            {
                foreach (WPS_Run wps_run in wps.WPS_Run)
                {
                    double lowerVolts = Math.Abs((double)(wps_run.VoltsExact - wps_run.VoltsExact * wps.VoltTol));
                    double upperVolts = Math.Abs((double)(wps_run.VoltsExact + wps_run.VoltsExact * wps.VoltTol));

                    double lowerAmps = Math.Abs((double)(wps_run.AmpsExact - wps_run.AmpsExact * wps.AmpTol));
                    double upperAmps = Math.Abs((double)(wps_run.AmpsExact + wps_run.AmpsExact * wps.AmpTol));

                    double lowerSpeed = Math.Abs((double)(wps_run.WeldSpeedExact - wps_run.WeldSpeedExact * wps.SpeedTol));
                    double upperSpeed = Math.Abs((double)(wps_run.WeldSpeedExact + wps_run.WeldSpeedExact * wps.SpeedTol));

                    double lowerShield = Math.Abs((double)(wps_run.ShieldGasExact - wps_run.ShieldGasExact * wps.ShieldTol));
                    double upperShield = Math.Abs((double)(wps_run.ShieldGasExact + wps_run.ShieldGasExact * wps.ShieldTol));

                    double lowerInput = Math.Abs(60 * lowerAmps * lowerVolts / (1000 * lowerSpeed));
                    double upperInput = Math.Abs(60 * upperAmps * upperVolts / (1000 * upperSpeed));

                    wps_run.Volts = Math.Round(lowerVolts, 2).ToString() + "-" + Math.Round(upperVolts, 2).ToString();
                    wps_run.Amps = Math.Round(lowerAmps, 2).ToString() + "-" + Math.Round(upperAmps, 2).ToString();
                    wps_run.WeldSpeed = Math.Round(lowerSpeed, 2).ToString() + "-" + Math.Round(upperSpeed, 2).ToString();
                    wps_run.HeatInput = Math.Round(lowerInput, 2).ToString() + "-" + Math.Round(upperInput, 2).ToString();
                    wps_run.ShieldGas = Math.Round(lowerShield, 2).ToString() + "-" + Math.Round(upperShield, 2).ToString();

                    ApiCalls.UpdateWPSRun(wps_run.WPS_RunId, wps_run);
                }
            }

            wps.NDTReq = cbInfoNDT.Checked;
            wps.VIReq = cbInfoVisual.Checked;
            wps.DPIReq = cbInfoDPI.Checked;
            wps.MPIReq = cbInfoMPI.Checked;
            wps.RTReq = cbInfoRT.Checked;
            wps.UTReq = cbInfoUT.Checked;

            ApiCalls.UpdateWPS(wps.WPSId, wps);

            this.Tag = new Tag(ApiCalls.ReadWPS(wps.WPSId), TagType.WPS);
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS)
            {
                return;
            }

            ClearFields();

            cboInfoWPQR.Items.Clear();

            List<WPQR> wpqrs = ApiCalls.ReadWPQRs();
            Tag[] wqTags = wpqrs
                .Where(wpqr => wpqr.Status == Actions.Complete)
                .Select(wpqr => new Tag(wpqr, TagType.None, wpqr.WPQRNumber)).ToArray();
            cboInfoWPQR.Items.AddRange(wqTags);

            Tag[] pplTags = QAWebApiClient.ApiCalls.GetPeople().Select(ppl => new Tag(ppl, TagType.None, ppl.EmployeeNumber)).ToArray();

            cboInfoPrepared.Items.Clear();
            cboInfoPrepared.Items.AddRange(pplTags);

            cboInfoPrepared.SelectedItem = pplTags.FirstOrDefault(tag => ((Person)tag.getTagObject()).EmployeeNumber == Application.Cookies["EmployeeNumber"]);

            object[] wpss = ApiCalls.ReadWPSs().Select(ppl => ppl.WPSNumber).ToArray();
            mscboInfoWPS.Set_InputDataList(wpss);

            if (thisTag.getTagObject() is WPS)
            {
                WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

                cboInfoWPQR.SelectedItem = wqTags.FirstOrDefault(tag => ((WPQR)tag.getTagObject()).WPQRId == wps.WPQR.WPQRId);

                txtInfoJob.Text = wps.WPQR.Welder_Qualification.WeldingAction.Job.JobNo?.ToString() ?? "";
                txtInfoWPS.Text = wps.WPSNumber?.ToString() ?? "";

                cboInfoPrepared.SelectedItem = pplTags.FirstOrDefault(tag => ((Person)tag.getTagObject()).EmployeeNumber == (wps.WPSPreparerEID?.ToString() ?? Application.Cookies["EmployeeNumber"]));

                dtpInfoDate.Value = wps.Date ?? DateTime.Now;
                txtInfoJoint.Text = wps.JointType?.ToString() ?? "";
                txtInfoMinThickness.Text = wps.MinThickness?.ToString() ?? "";
                txtInfoMaxThickness.Text = wps.MaxThickness?.ToString() ?? "";
                txtInfoMinDiameter.Text = wps.MinDiameter?.ToString() ?? "";
                txtInfoMaxDiameter.Text = wps.MaxDiameter?.ToString() ?? "";
                txtInfoPrep.Text = wps.PrepMethod?.ToString() ?? "";
                txtInfoPWHT.Text = wps.PWHT?.ToString() ?? "";
                txtInfoPreheat.Text = wps.Preheat?.ToString() ?? "";
                txtInfoGouging.Text = wps.GougingMethod?.ToString() ?? "";
                txtInfoInterpass.Text = wps.Interpass?.ToString() ?? "";
                txtInfoNotes.Text = wps.Notes?.ToString() ?? "";
                txtInfoMatStandard.Text = wps.MaterialStd?.ToString() ?? "";
                txtInfoMatGrade.Text = wps.MaterialGrd?.ToString() ?? "";
                txtInfoMatPNo.Text = wps.MaterialPNo?.ToString() ?? "";

                txtInfoVoltTol.Text = wps.VoltTol?.ToString() ?? "";
                txtInfoAmpTol.Text = wps.AmpTol?.ToString() ?? "";
                txtInfoSpeedTol.Text = wps.SpeedTol?.ToString() ?? "";
                txtInfoShieldTol.Text = wps.ShieldTol?.ToString() ?? "";

                cbInfoNDT.Checked = wps.NDTReq ?? false;
                cbInfoVisual.Checked = wps.VIReq ?? false;
                cbInfoDPI.Checked = wps.DPIReq ?? false;
                cbInfoMPI.Checked = wps.MPIReq ?? false;
                cbInfoRT.Checked = wps.RTReq ?? false;
                cbInfoUT.Checked = wps.UTReq ?? false;

                cbInfoWPS.Checked = false;
                cbInfoWPS.ReadOnly = true;
            }

            SelectInputs();

            cboInfoWPQR.Refresh();
        }

        private void uc_wpsInfo_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private void cboInfoWPQR_SelectedItemChanged(object sender, EventArgs e)
        {
            if (cboInfoWPQR.SelectedItem == null)
            {
                return;
            }

            Tag thisTag = (Tag)cboInfoWPQR.SelectedItem;

            if (thisTag == null || !(thisTag.getTagObject() is WPQR))
            {
                return;
            }

            WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

            int wpsCount = wpqr.WPS.Count + 1;
            txtInfoWPS.Text = cboInfoWPQR.SelectedText + "-" + wpsCount.ToString();

            txtInfoJob.Text = wpqr.Welder_Qualification.WeldingAction.Job.JobNo?.ToString() ?? "";

            dtpInfoDate.Value = DateTime.Now;
            txtInfoJoint.Text = wpqr.JointType?.ToString() ?? "";
            txtInfoMinThickness.Text = (wpqr.Thickness / 2)?.ToString() ?? "";
            txtInfoMaxThickness.Text = (wpqr.Thickness * 2)?.ToString() ?? "";
            txtInfoMinDiameter.Text = (wpqr.Diameter / 2)?.ToString() ?? "";
            txtInfoMaxDiameter.Text = (wpqr.Diameter * 2)?.ToString() ?? "";

            txtInfoPWHT.Text = wpqr.PWHTTemp?.ToString() ?? "";
            txtInfoPreheat.Text = wpqr.PreheatTemp?.ToString() ?? "";

            txtInfoInterpass.Text = wpqr.InterpassTemp?.ToString() ?? "";
            txtInfoNotes.Text = wpqr.Notes?.ToString() ?? "";
            txtInfoMatStandard.Text = wpqr.Welder_Qualification.Datasheet.MaterialStd?.ToString() ?? "";
            txtInfoMatGrade.Text = wpqr.Welder_Qualification.Datasheet.MaterialGrd?.ToString() ?? "";
            txtInfoMatPNo.Text = wpqr.BMGroupPNumber?.ToString() ?? "";

            cbInfoNDT.Checked = wpqr.NDTReq ?? false;
            cbInfoVisual.Checked = wpqr.VIReq ?? false;
            cbInfoDPI.Checked = wpqr.DPIReq ?? false;
            cbInfoMPI.Checked = wpqr.MPIReq ?? false;
            cbInfoRT.Checked = wpqr.RTReq ?? false;
            cbInfoUT.Checked = wpqr.UTReq ?? false;
        }

        private double ConvertTolerance(string tol)
        {
            tol = tol.Replace("-", ""); // remove negatives

            if (double.TryParse(tol, out double convertedTol))
            {
                if (convertedTol > 1 && convertedTol <= 100) // between (1, 100] (exclusive, inclusive)
                {
                    convertedTol = convertedTol / 100;
                }
                else if (convertedTol > 100)
                {
                    int magnitude = tol.ToString().Length;
                    convertedTol /= Math.Pow(10, magnitude);
                }

                return convertedTol;
            }
            else
            {
                return 0;
            }
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }

        private void label104_DoubleClick(object sender, EventArgs e)
        {
            if (UIFormatting.adminUsers.Contains(Application.Cookies["EmployeeNumber"].TrimStart('E')))
            {
                txtInfoWPS.Text = cboInfoWPQR.Text + "-1";
                txtInfoPrep.Text = "Grind";
                txtInfoGouging.Text = "Grind";
                txtInfoAmpTol.Text = "0.1";
                txtInfoVoltTol.Text = "0.1";
                txtInfoSpeedTol.Text = "0.1";
                txtInfoShieldTol.Text = "0.1";
            }
        }

        private void cbInfoWPS_CheckedChanged(object sender, EventArgs e)
        {
            SelectInputs();
        }

        private void SelectInputs()
        {
            tlpInfoInput.RowStyles[tlpInfoInput.GetRow(tlpInfoNew)].Height = cbInfoWPS.Checked ? 0 : 100;
            tlpInfoInput.RowStyles[tlpInfoInput.GetRow(tlpInfoAllocate)].Height = cbInfoWPS.Checked ? 100 : 0;
        }

        private void ClearFields()
        {
            cbInfoWPS.Checked = false;
            cboInfoWPQR.SelectedItem = null;
            cboInfoPrepared.SelectedItem = null;
            txtInfoJob.Text = "";
            dtpInfoDate.Value = DateTime.Now;
            txtInfoJoint.Text = "";
            txtInfoMinThickness.Text = "";
            txtInfoMaxThickness.Text = "";
            txtInfoMinDiameter.Text = "";
            txtInfoMaxDiameter.Text = "";
            txtInfoPrep.Text = "";
            txtInfoPWHT.Text = "";
            txtInfoPreheat.Text = "";
            txtInfoGouging.Text = "";
            txtInfoInterpass.Text = "";
            txtInfoNotes.Text = "";
            txtInfoMatStandard.Text = "";
            txtInfoMatGrade.Text = "";
            txtInfoMatPNo.Text = "";
            txtInfoVoltTol.Text = "";
            txtInfoAmpTol.Text = "";
            txtInfoSpeedTol.Text = "";
            txtInfoShieldTol.Text = "";
            cbInfoNDT.Checked = false;
            cbInfoVisual.Checked = false;
            cbInfoDPI.Checked = false;
            cbInfoMPI.Checked = false;
            cbInfoRT.Checked = false;
            cbInfoUT.Checked = false;
            mscboInfoWPS.Set_OuputDataList(new List<object>());
        }
    }
}
