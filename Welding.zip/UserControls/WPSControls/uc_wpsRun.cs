﻿using ApiClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Web.Security;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement.UserControls.WPSControls
{
    public partial class uc_wpsRun : Wisej.Web.UserControl
    {
        private up_hmSave up_hmSave1;
        private Panel overlayPanel;

        public uc_wpsRun()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks next button on upload screen")]
        public event EventHandler btnRunNextClick;
        private void btnRunNext_Click(object sender, EventArgs e)
        {
            Save_Action();
            Update_Status();

            btnRunNextClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on upload screen")]
        public event EventHandler btnRunHomeClick;
        private void btnRunHome_Click(object sender, EventArgs e)
        {
            Save_Action();

            btnRunHomeClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on upload screen")]
        public event EventHandler btnRunBackClick;
        private void btnRunBack_Click(object sender, EventArgs e)
        {
            if (up_hmSave1 == null)
            {
                up_hmSave1 = new up_hmSave();
                this.Controls.Add(up_hmSave1);
            }

            overlayPanel.Visible = true;

            up_hmSave1.ShowPopup(new Point(this.Width / 2 - up_hmSave1.Width / 2, this.Height / 2 - up_hmSave1.Height / 2), up_hmSave1_Closed);
        }

        private void up_hmSave1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            switch (up_hmSave1.ToSave)
            {
                case TriState.Indeterminant:
                    break;

                case TriState.True:
                    Save_Action();
                    btnRunBackClick?.Invoke(this, new EventArgs());
                    break;

                case TriState.False:
                    btnRunBackClick?.Invoke(this, new EventArgs());
                    break;
            }
        }
        #endregion

        private void Update_Status()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS)
            {
                return;
            }

            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            wps.Status = Actions.WPSAttachments;

            ApiCalls.UpdateWPS(wps.WPSId, wps);

            this.Tag = new Tag(ApiCalls.ReadWPS(wps.WPSId), TagType.WPS);
        }

        private void Save_Action()
        {
            List<WPS_Run> wps_Runs = (List<WPS_Run>)dgvWPSRun.DataSource;

            if (wps_Runs == null)
            {
                return;
            }

            for (int i = 0; i < wps_Runs.Count; i++)
            {
                ApiCalls.UpdateWPSRun(wps_Runs[i].WPS_RunId, wps_Runs[i]);
            }

            this.Tag = new Tag(ApiCalls.ReadWPS(((WPS)((Tag)this.Tag).getTagObject()).WPSId), TagType.WPS);
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS)
            {
                return;
            }

            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            dgvWPSRun.DataSource = null;

            dgvWPSRun.Rows.Clear();

            List<WPS_Run> wps_Runs = wps.WPS_Run.ToList();

            dgvWPSRun.Columns["dgvcSide"].DataPropertyName = "Side";
            dgvWPSRun.Columns["dgvcPass"].DataPropertyName = "Pass";
            dgvWPSRun.Columns["dgvcProcess"].DataPropertyName = "WeldingProcess";
            dgvWPSRun.Columns["dgvcPosition"].DataPropertyName = "WeldingPosition";
            dgvWPSRun.Columns["dgvcSize"].DataPropertyName = "FillerDia";
            dgvWPSRun.Columns["dgvcSpecification"].DataPropertyName = "Specification";
            dgvWPSRun.Columns["dgvcClassification"].DataPropertyName = "Classification";
            dgvWPSRun.Columns["dgvcPolarity"].DataPropertyName = "Supply";
            dgvWPSRun.Columns["dgvcFluxGas"].DataPropertyName = "ShieldGas";
            dgvWPSRun.Columns["dgvcInput"].DataPropertyName = "HeatInput";
            dgvWPSRun.Columns["dgvcAmps"].DataPropertyName = "Amps";
            dgvWPSRun.Columns["dgvcVolts"].DataPropertyName = "Volts";
            dgvWPSRun.Columns["dgvcSpeed"].DataPropertyName = "WeldSpeed";

            if (wps_Runs.Count > 0)
            {
                dgvWPSRun.DataSource = wps_Runs;
            }
            else
            {
                wps_Runs = wps.WPQR.WPQR_Run
                    .Select(wpqr =>
                    {
                        double lowerVolts = Math.Abs((double)(wpqr.Volts - wpqr.Volts * wps.VoltTol));
                        double upperVolts = Math.Abs((double)(wpqr.Volts + wpqr.Volts * wps.VoltTol));

                        double lowerAmps = Math.Abs((double)(wpqr.Amps - wpqr.Amps * wps.AmpTol));
                        double upperAmps = Math.Abs((double)(wpqr.Amps + wpqr.Amps * wps.AmpTol));

                        double lowerSpeed = Math.Abs((double)(wpqr.WeldSpeed - wpqr.WeldSpeed * wps.SpeedTol));
                        double upperSpeed = Math.Abs((double)(wpqr.WeldSpeed + wpqr.WeldSpeed * wps.SpeedTol));

                        double lowerShield = Math.Abs((double)(wpqr.ShieldGas - wpqr.ShieldGas * wps.ShieldTol));
                        double upperShield = Math.Abs((double)(wpqr.ShieldGas + wpqr.ShieldGas * wps.ShieldTol));

                        double lowerInput = Math.Abs(60 * lowerAmps * lowerVolts / (1000 * lowerSpeed));
                        double upperInput = Math.Abs(60 * upperAmps * upperVolts / (1000 * upperSpeed));

                        return ApiCalls.CreateWPSRun(wps.WPSId, new WPS_Run(wps)
                        {
                            Side = wpqr.Side,
                            Pass = wpqr.Pass.ToString(),
                            WeldingProcess = wpqr.WeldingProcess,
                            WeldingPosition = wpqr.WeldingPosition,
                            FillerDia = wpqr.FillerDia,
                            Specification = wpqr.Specification,
                            Classification = wpqr.Classification,
                            Supply = wpqr.Supply,
                            ShieldGasExact = wpqr.ShieldGas,
                            VoltsExact = wpqr.Volts,
                            AmpsExact = wpqr.Amps,
                            WeldSpeedExact = wpqr.WeldSpeed,
                            HeatInputExact = wpqr.HeatInput,
                            Volts = Math.Round(lowerVolts, 2).ToString() + "-" + Math.Round(upperVolts, 2).ToString(),
                            Amps = Math.Round(lowerAmps, 2).ToString() + "-" + Math.Round(upperAmps, 2).ToString(),
                            WeldSpeed = Math.Round(lowerSpeed, 2).ToString() + "-" + Math.Round(upperSpeed, 2).ToString(),
                            HeatInput = Math.Round(lowerInput, 2).ToString() + "-" + Math.Round(upperInput, 2).ToString(),
                            ShieldGas = Math.Round(lowerShield, 2).ToString() + "-" + Math.Round(upperShield, 2).ToString()
                        });
                    }).ToList();
                dgvWPSRun.DataSource = wps_Runs;
            }
        }

        private void uc_wpsRun_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private void dgvWPSRun_Resize(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill || this.Tag == null)
            {
                return;
            }

            UIFormatting.ResizeColumnsFor(dgvWPSRun);
        }

        private void btnRunCopy_Click(object sender, EventArgs e)
        {
            if (dgvWPSRun.SelectedCells.Count != 1)
            {
                return;
            }

            var copyVal = dgvWPSRun.SelectedCells[0].Value.ToString();
            int rowIdx = dgvWPSRun.SelectedCells[0].RowIndex;
            int colIdx = dgvWPSRun.SelectedCells[0].ColumnIndex;


            if (string.IsNullOrEmpty(copyVal))
            {
                return;
            }

            for (int i = rowIdx; i < dgvWPSRun.Rows.Count; i++)
            {
                dgvWPSRun.Rows[i].Cells[colIdx].Value = copyVal;
            }

            dgvWPSRun.Refresh();
        }

        private void lblInfoNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }

        private void btnRunDelete_DoubleClick(object sender, EventArgs e)
        {
            if (dgvWPSRun.SelectedCells.Count != 1)
            {
                return;
            }

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS)
            {
                return;
            }

            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            WPS_Run wrToDelete = (WPS_Run)dgvWPSRun.Rows[dgvWPSRun.SelectedCells[0].RowIndex].DataBoundItem;

            if (wrToDelete == null)
            {
                return;
            }

            ApiCalls.DeleteWPSRun(wrToDelete.WPS_RunId);

            this.Tag = new Tag(ApiCalls.ReadWPS(wps.WPSId), TagType.WPS);

            Load_Action();
        }

        private void btnRunCopyRun_Click(object sender, EventArgs e)
        {
            if (dgvWPSRun.SelectedCells.Count != 1)
            {
                return;
            }

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null || thisTag.getTagType() != TagType.WPS)
            {
                return;
            }

            WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

            WPS_Run wrToCopy = (WPS_Run)dgvWPSRun.Rows[dgvWPSRun.SelectedCells[0].RowIndex].DataBoundItem;

            if (wrToCopy == null)
            {
                return;
            }

            ApiCalls.CreateWPSRun(wps.WPSId, wrToCopy);

            this.Tag = new Tag(ApiCalls.ReadWPS(wps.WPSId), TagType.WPS);

            Load_Action();
        }
    }
}
