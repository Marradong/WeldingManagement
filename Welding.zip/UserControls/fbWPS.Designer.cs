﻿namespace WeldingManagement
{
    partial class fbWPS
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle1 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle2 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle3 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle4 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle5 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle6 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle7 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle8 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle9 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle10 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle11 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle12 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle13 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle14 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle15 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle16 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle17 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle18 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle19 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle20 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle21 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle22 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle23 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle24 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle25 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle26 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle27 = new Wisej.Web.DataGridViewCellStyle();
            this.Boards = new Wisej.Web.TabControl();
            this.tabWPQRInfo = new Wisej.Web.TabPage();
            this.tableLayoutPanel25 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel26 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel27 = new Wisej.Web.TableLayoutPanel();
            this.cbInfoVisual = new Wisej.Web.CheckBox();
            this.cbInfoNDT = new Wisej.Web.CheckBox();
            this.cbInfoDPI = new Wisej.Web.CheckBox();
            this.cbInfoMPI = new Wisej.Web.CheckBox();
            this.cbInfoRT = new Wisej.Web.CheckBox();
            this.cbInfoUT = new Wisej.Web.CheckBox();
            this.label101 = new Wisej.Web.Label();
            this.label88 = new Wisej.Web.Label();
            this.label102 = new Wisej.Web.Label();
            this.txtInfoWPQR = new Wisej.Web.TextBox();
            this.label90 = new Wisej.Web.Label();
            this.label89 = new Wisej.Web.Label();
            this.label87 = new Wisej.Web.Label();
            this.label99 = new Wisej.Web.Label();
            this.label86 = new Wisej.Web.Label();
            this.label100 = new Wisej.Web.Label();
            this.label82 = new Wisej.Web.Label();
            this.label57 = new Wisej.Web.Label();
            this.label98 = new Wisej.Web.Label();
            this.label58 = new Wisej.Web.Label();
            this.label81 = new Wisej.Web.Label();
            this.label94 = new Wisej.Web.Label();
            this.label93 = new Wisej.Web.Label();
            this.label79 = new Wisej.Web.Label();
            this.label59 = new Wisej.Web.Label();
            this.label60 = new Wisej.Web.Label();
            this.txtInfoJob = new Wisej.Web.TextBox();
            this.txtInfoPrepared = new Wisej.Web.TextBox();
            this.txtInfoThickness = new Wisej.Web.TextBox();
            this.txtInfoPWHT = new Wisej.Web.TextBox();
            this.txtInfoInterpass = new Wisej.Web.TextBox();
            this.txtInfoMatStandard = new Wisej.Web.TextBox();
            this.txtInfoWPS = new Wisej.Web.TextBox();
            this.txtInfoDate = new Wisej.Web.TextBox();
            this.txtInfoDiameter = new Wisej.Web.TextBox();
            this.txtInfoPreheat = new Wisej.Web.TextBox();
            this.txtInfoNotes = new Wisej.Web.TextBox();
            this.txtInfoMatGrade = new Wisej.Web.TextBox();
            this.txtInfoMatPNo = new Wisej.Web.TextBox();
            this.txtInfoJoint = new Wisej.Web.TextBox();
            this.txtInfoPrep = new Wisej.Web.TextBox();
            this.txtInfoGouging = new Wisej.Web.TextBox();
            this.tableLayoutPanel28 = new Wisej.Web.TableLayoutPanel();
            this.btnInfoBack = new Wisej.Web.Button();
            this.btnInfoHome = new Wisej.Web.Button();
            this.btnInfoNext = new Wisej.Web.Button();
            this.tableLayoutPanel29 = new Wisej.Web.TableLayoutPanel();
            this.label103 = new Wisej.Web.Label();
            this.label104 = new Wisej.Web.Label();
            this.tabWPQRRun = new Wisej.Web.TabPage();
            this.tableLayoutPanel33 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel34 = new Wisej.Web.TableLayoutPanel();
            this.dgvWPQRRun = new Wisej.Web.DataGridView();
            this.dgvcSide = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcPass = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcProcess = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcPosition = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcSize = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcSpecification = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcClassification = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcPolarity = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcFluxGas = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcInput = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcAmps = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcVolts = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvcSpeed = new Wisej.Web.DataGridViewTextBoxColumn();
            this.tableLayoutPanel35 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel36 = new Wisej.Web.TableLayoutPanel();
            this.btnRunBack = new Wisej.Web.Button();
            this.btnRunHome = new Wisej.Web.Button();
            this.btnRunNext = new Wisej.Web.Button();
            this.tableLayoutPanel38 = new Wisej.Web.TableLayoutPanel();
            this.label110 = new Wisej.Web.Label();
            this.label111 = new Wisej.Web.Label();
            this.tabUpload = new Wisej.Web.TabPage();
            this.tableLayoutPanel14 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel22 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.btnUploadBack = new Wisej.Web.Button();
            this.btnUploadHome = new Wisej.Web.Button();
            this.btnUploadComplete = new Wisej.Web.Button();
            this.tableLayoutPanel4 = new Wisej.Web.TableLayoutPanel();
            this.label76 = new Wisej.Web.Label();
            this.label1 = new Wisej.Web.Label();
            this.Boards.SuspendLayout();
            this.tabWPQRInfo.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.tabWPQRRun.SuspendLayout();
            this.tableLayoutPanel33.SuspendLayout();
            this.tableLayoutPanel34.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWPQRRun)).BeginInit();
            this.tableLayoutPanel35.SuspendLayout();
            this.tableLayoutPanel36.SuspendLayout();
            this.tableLayoutPanel38.SuspendLayout();
            this.tabUpload.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // Boards
            // 
            this.Boards.Alignment = Wisej.Web.TabAlignment.Top;
            this.Boards.BorderStyle = Wisej.Web.BorderStyle.None;
            this.Boards.Controls.Add(this.tabWPQRInfo);
            this.Boards.Controls.Add(this.tabWPQRRun);
            this.Boards.Controls.Add(this.tabUpload);
            this.Boards.Display = Wisej.Web.Display.Label;
            this.Boards.Dock = Wisej.Web.DockStyle.Fill;
            this.Boards.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Boards.Location = new System.Drawing.Point(0, 0);
            this.Boards.Name = "Boards";
            this.Boards.Orientation = Wisej.Web.Orientation.Horizontal;
            this.Boards.PageInsets = new Wisej.Web.Padding(0, 35, 0, 0);
            this.Boards.SelectedIndex = 0;
            this.Boards.Size = new System.Drawing.Size(1212, 650);
            this.Boards.TabIndex = 4;
            this.Boards.TabStop = false;
            this.Boards.Selecting += new Wisej.Web.TabControlCancelEventHandler(this.Boards_Selecting);
            // 
            // tabWPQRInfo
            // 
            this.tabWPQRInfo.Controls.Add(this.tableLayoutPanel25);
            this.tabWPQRInfo.Location = new System.Drawing.Point(0, 35);
            this.tabWPQRInfo.Name = "tabWPQRInfo";
            this.tabWPQRInfo.Size = new System.Drawing.Size(1212, 615);
            this.tabWPQRInfo.Text = "Info";
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 3;
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel25.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.Controls.Add(this.tableLayoutPanel26, 1, 3);
            this.tableLayoutPanel25.Controls.Add(this.tableLayoutPanel29, 1, 1);
            this.tableLayoutPanel25.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 5;
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel25.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel25.TabIndex = 3;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 2;
            this.tableLayoutPanel26.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel26.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel26.Controls.Add(this.tableLayoutPanel27, 0, 0);
            this.tableLayoutPanel26.Controls.Add(this.tableLayoutPanel28, 1, 0);
            this.tableLayoutPanel26.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel26.TabIndex = 1;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.ColumnCount = 6;
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 15F));
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 15F));
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 15F));
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.Controls.Add(this.cbInfoVisual, 1, 8);
            this.tableLayoutPanel27.Controls.Add(this.cbInfoNDT, 0, 8);
            this.tableLayoutPanel27.Controls.Add(this.cbInfoDPI, 2, 8);
            this.tableLayoutPanel27.Controls.Add(this.cbInfoMPI, 3, 8);
            this.tableLayoutPanel27.Controls.Add(this.cbInfoRT, 4, 8);
            this.tableLayoutPanel27.Controls.Add(this.cbInfoUT, 5, 8);
            this.tableLayoutPanel27.Controls.Add(this.label101, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.label88, 2, 0);
            this.tableLayoutPanel27.Controls.Add(this.label102, 4, 0);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoWPQR, 5, 0);
            this.tableLayoutPanel27.Controls.Add(this.label90, 0, 1);
            this.tableLayoutPanel27.Controls.Add(this.label89, 2, 1);
            this.tableLayoutPanel27.Controls.Add(this.label87, 0, 2);
            this.tableLayoutPanel27.Controls.Add(this.label99, 4, 1);
            this.tableLayoutPanel27.Controls.Add(this.label86, 2, 2);
            this.tableLayoutPanel27.Controls.Add(this.label100, 4, 2);
            this.tableLayoutPanel27.Controls.Add(this.label82, 4, 3);
            this.tableLayoutPanel27.Controls.Add(this.label57, 2, 3);
            this.tableLayoutPanel27.Controls.Add(this.label98, 0, 3);
            this.tableLayoutPanel27.Controls.Add(this.label58, 0, 4);
            this.tableLayoutPanel27.Controls.Add(this.label81, 0, 5);
            this.tableLayoutPanel27.Controls.Add(this.label94, 0, 6);
            this.tableLayoutPanel27.Controls.Add(this.label93, 2, 6);
            this.tableLayoutPanel27.Controls.Add(this.label79, 4, 6);
            this.tableLayoutPanel27.Controls.Add(this.label59, 2, 4);
            this.tableLayoutPanel27.Controls.Add(this.label60, 0, 7);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoJob, 1, 0);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoPrepared, 1, 1);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoThickness, 1, 2);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoPWHT, 1, 3);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoInterpass, 1, 4);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoMatStandard, 1, 6);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoWPS, 3, 0);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoDate, 3, 1);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoDiameter, 3, 2);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoPreheat, 3, 3);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoNotes, 3, 4);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoMatGrade, 3, 6);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoMatPNo, 5, 6);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoJoint, 5, 1);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoPrep, 5, 2);
            this.tableLayoutPanel27.Controls.Add(this.txtInfoGouging, 5, 3);
            this.tableLayoutPanel27.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 9;
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel27.TabIndex = 4;
            // 
            // cbInfoVisual
            // 
            this.cbInfoVisual.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoVisual.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbInfoVisual.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoVisual.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbInfoVisual.Location = new System.Drawing.Point(149, 387);
            this.cbInfoVisual.Name = "cbInfoVisual";
            this.cbInfoVisual.Size = new System.Drawing.Size(189, 43);
            this.cbInfoVisual.TabIndex = 77;
            this.cbInfoVisual.Text = "Visual";
            this.cbInfoVisual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbInfoNDT
            // 
            this.cbInfoNDT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoNDT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbInfoNDT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoNDT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbInfoNDT.Location = new System.Drawing.Point(3, 387);
            this.cbInfoNDT.Name = "cbInfoNDT";
            this.cbInfoNDT.Size = new System.Drawing.Size(140, 43);
            this.cbInfoNDT.TabIndex = 76;
            this.cbInfoNDT.Text = "NDT";
            this.cbInfoNDT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbInfoDPI
            // 
            this.cbInfoDPI.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoDPI.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbInfoDPI.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoDPI.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbInfoDPI.Location = new System.Drawing.Point(344, 387);
            this.cbInfoDPI.Name = "cbInfoDPI";
            this.cbInfoDPI.Size = new System.Drawing.Size(140, 43);
            this.cbInfoDPI.TabIndex = 78;
            this.cbInfoDPI.Text = "DPI";
            this.cbInfoDPI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbInfoMPI
            // 
            this.cbInfoMPI.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoMPI.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbInfoMPI.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoMPI.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbInfoMPI.Location = new System.Drawing.Point(490, 387);
            this.cbInfoMPI.Name = "cbInfoMPI";
            this.cbInfoMPI.Size = new System.Drawing.Size(189, 43);
            this.cbInfoMPI.TabIndex = 79;
            this.cbInfoMPI.Text = "MPI";
            this.cbInfoMPI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbInfoRT
            // 
            this.cbInfoRT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoRT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbInfoRT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoRT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbInfoRT.Location = new System.Drawing.Point(685, 387);
            this.cbInfoRT.Name = "cbInfoRT";
            this.cbInfoRT.Size = new System.Drawing.Size(140, 43);
            this.cbInfoRT.TabIndex = 80;
            this.cbInfoRT.Text = "RT";
            this.cbInfoRT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbInfoUT
            // 
            this.cbInfoUT.Appearance = Wisej.Web.Appearance.Switch;
            this.cbInfoUT.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbInfoUT.Dock = Wisej.Web.DockStyle.Fill;
            this.cbInfoUT.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbInfoUT.Location = new System.Drawing.Point(831, 387);
            this.cbInfoUT.Name = "cbInfoUT";
            this.cbInfoUT.Size = new System.Drawing.Size(190, 43);
            this.cbInfoUT.TabIndex = 81;
            this.cbInfoUT.Text = "UT";
            this.cbInfoUT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Dock = Wisej.Web.DockStyle.Fill;
            this.label101.Location = new System.Drawing.Point(3, 3);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(140, 42);
            this.label101.TabIndex = 1;
            this.label101.Text = "Job Number";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Dock = Wisej.Web.DockStyle.Fill;
            this.label88.Location = new System.Drawing.Point(344, 3);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(140, 42);
            this.label88.TabIndex = 14;
            this.label88.Text = "WPS Number";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Dock = Wisej.Web.DockStyle.Fill;
            this.label102.Location = new System.Drawing.Point(685, 3);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(140, 42);
            this.label102.TabIndex = 0;
            this.label102.Text = "WPQR Number";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtInfoWPQR
            // 
            this.txtInfoWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoWPQR.Location = new System.Drawing.Point(831, 3);
            this.txtInfoWPQR.Name = "txtInfoWPQR";
            this.txtInfoWPQR.Size = new System.Drawing.Size(190, 42);
            this.txtInfoWPQR.TabIndex = 25;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Dock = Wisej.Web.DockStyle.Fill;
            this.label90.Location = new System.Drawing.Point(3, 51);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(140, 42);
            this.label90.TabIndex = 12;
            this.label90.Text = "Prepared By EID";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Dock = Wisej.Web.DockStyle.Fill;
            this.label89.Location = new System.Drawing.Point(344, 51);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(140, 42);
            this.label89.TabIndex = 13;
            this.label89.Text = "Date";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Dock = Wisej.Web.DockStyle.Fill;
            this.label87.Location = new System.Drawing.Point(3, 99);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(140, 42);
            this.label87.TabIndex = 15;
            this.label87.Text = "Thickness (mm)";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Dock = Wisej.Web.DockStyle.Fill;
            this.label99.Location = new System.Drawing.Point(685, 51);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(140, 42);
            this.label99.TabIndex = 3;
            this.label99.Text = "Joint Type";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Dock = Wisej.Web.DockStyle.Fill;
            this.label86.Location = new System.Drawing.Point(344, 99);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(140, 42);
            this.label86.TabIndex = 16;
            this.label86.Text = "Diameter (mm)";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Dock = Wisej.Web.DockStyle.Fill;
            this.label100.Location = new System.Drawing.Point(685, 99);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(140, 42);
            this.label100.TabIndex = 2;
            this.label100.Text = "Prep Method";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Dock = Wisej.Web.DockStyle.Fill;
            this.label82.Location = new System.Drawing.Point(685, 147);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(140, 42);
            this.label82.TabIndex = 20;
            this.label82.Text = "Gouging Method";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Dock = Wisej.Web.DockStyle.Fill;
            this.label57.Location = new System.Drawing.Point(344, 147);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(140, 42);
            this.label57.TabIndex = 39;
            this.label57.Text = "Preheat Temperature";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Dock = Wisej.Web.DockStyle.Fill;
            this.label98.Location = new System.Drawing.Point(3, 147);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(140, 42);
            this.label98.TabIndex = 4;
            this.label98.Text = "PWHT";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Dock = Wisej.Web.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(3, 195);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(140, 42);
            this.label58.TabIndex = 40;
            this.label58.Text = "Interpass Temperature";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label81.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel27.SetColumnSpan(this.label81, 6);
            this.label81.Dock = Wisej.Web.DockStyle.Fill;
            this.label81.Location = new System.Drawing.Point(3, 243);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(1018, 42);
            this.label81.TabIndex = 21;
            this.label81.Text = "Base Metals";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Dock = Wisej.Web.DockStyle.Fill;
            this.label94.Location = new System.Drawing.Point(3, 291);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(140, 42);
            this.label94.TabIndex = 8;
            this.label94.Text = "Material Standard";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Dock = Wisej.Web.DockStyle.Fill;
            this.label93.Location = new System.Drawing.Point(344, 291);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(140, 42);
            this.label93.TabIndex = 9;
            this.label93.Text = "Material Grade";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Dock = Wisej.Web.DockStyle.Fill;
            this.label79.Location = new System.Drawing.Point(685, 291);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(140, 42);
            this.label79.TabIndex = 22;
            this.label79.Text = "P / Group Number";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Dock = Wisej.Web.DockStyle.Fill;
            this.label59.Location = new System.Drawing.Point(344, 195);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(140, 42);
            this.label59.TabIndex = 41;
            this.label59.Text = "Notes";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label60.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel27.SetColumnSpan(this.label60, 6);
            this.label60.Dock = Wisej.Web.DockStyle.Fill;
            this.label60.Location = new System.Drawing.Point(3, 339);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(1018, 42);
            this.label60.TabIndex = 42;
            this.label60.Text = "Required Testing";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtInfoJob
            // 
            this.txtInfoJob.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoJob.Location = new System.Drawing.Point(149, 3);
            this.txtInfoJob.Name = "txtInfoJob";
            this.txtInfoJob.Size = new System.Drawing.Size(189, 42);
            this.txtInfoJob.TabIndex = 82;
            // 
            // txtInfoPrepared
            // 
            this.txtInfoPrepared.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPrepared.Location = new System.Drawing.Point(149, 51);
            this.txtInfoPrepared.Name = "txtInfoPrepared";
            this.txtInfoPrepared.Size = new System.Drawing.Size(189, 42);
            this.txtInfoPrepared.TabIndex = 83;
            // 
            // txtInfoThickness
            // 
            this.txtInfoThickness.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoThickness.Location = new System.Drawing.Point(149, 99);
            this.txtInfoThickness.Name = "txtInfoThickness";
            this.txtInfoThickness.Size = new System.Drawing.Size(189, 42);
            this.txtInfoThickness.TabIndex = 84;
            // 
            // txtInfoPWHT
            // 
            this.txtInfoPWHT.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPWHT.Location = new System.Drawing.Point(149, 147);
            this.txtInfoPWHT.Name = "txtInfoPWHT";
            this.txtInfoPWHT.Size = new System.Drawing.Size(189, 42);
            this.txtInfoPWHT.TabIndex = 85;
            // 
            // txtInfoInterpass
            // 
            this.txtInfoInterpass.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoInterpass.Location = new System.Drawing.Point(149, 195);
            this.txtInfoInterpass.Name = "txtInfoInterpass";
            this.txtInfoInterpass.Size = new System.Drawing.Size(189, 42);
            this.txtInfoInterpass.TabIndex = 86;
            // 
            // txtInfoMatStandard
            // 
            this.txtInfoMatStandard.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatStandard.Location = new System.Drawing.Point(149, 291);
            this.txtInfoMatStandard.Name = "txtInfoMatStandard";
            this.txtInfoMatStandard.Size = new System.Drawing.Size(189, 42);
            this.txtInfoMatStandard.TabIndex = 87;
            // 
            // txtInfoWPS
            // 
            this.txtInfoWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoWPS.Location = new System.Drawing.Point(490, 3);
            this.txtInfoWPS.Name = "txtInfoWPS";
            this.txtInfoWPS.Size = new System.Drawing.Size(189, 42);
            this.txtInfoWPS.TabIndex = 88;
            // 
            // txtInfoDate
            // 
            this.txtInfoDate.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoDate.Location = new System.Drawing.Point(490, 51);
            this.txtInfoDate.Name = "txtInfoDate";
            this.txtInfoDate.Size = new System.Drawing.Size(189, 42);
            this.txtInfoDate.TabIndex = 89;
            // 
            // txtInfoDiameter
            // 
            this.txtInfoDiameter.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoDiameter.Location = new System.Drawing.Point(490, 99);
            this.txtInfoDiameter.Name = "txtInfoDiameter";
            this.txtInfoDiameter.Size = new System.Drawing.Size(189, 42);
            this.txtInfoDiameter.TabIndex = 90;
            // 
            // txtInfoPreheat
            // 
            this.txtInfoPreheat.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPreheat.Location = new System.Drawing.Point(490, 147);
            this.txtInfoPreheat.Name = "txtInfoPreheat";
            this.txtInfoPreheat.Size = new System.Drawing.Size(189, 42);
            this.txtInfoPreheat.TabIndex = 91;
            // 
            // txtInfoNotes
            // 
            this.tableLayoutPanel27.SetColumnSpan(this.txtInfoNotes, 3);
            this.txtInfoNotes.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoNotes.Location = new System.Drawing.Point(490, 195);
            this.txtInfoNotes.Name = "txtInfoNotes";
            this.txtInfoNotes.Size = new System.Drawing.Size(531, 42);
            this.txtInfoNotes.TabIndex = 92;
            // 
            // txtInfoMatGrade
            // 
            this.txtInfoMatGrade.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatGrade.Location = new System.Drawing.Point(490, 291);
            this.txtInfoMatGrade.Name = "txtInfoMatGrade";
            this.txtInfoMatGrade.Size = new System.Drawing.Size(189, 42);
            this.txtInfoMatGrade.TabIndex = 93;
            // 
            // txtInfoMatPNo
            // 
            this.txtInfoMatPNo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoMatPNo.Location = new System.Drawing.Point(831, 291);
            this.txtInfoMatPNo.Name = "txtInfoMatPNo";
            this.txtInfoMatPNo.Size = new System.Drawing.Size(190, 42);
            this.txtInfoMatPNo.TabIndex = 94;
            // 
            // txtInfoJoint
            // 
            this.txtInfoJoint.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoJoint.Location = new System.Drawing.Point(831, 51);
            this.txtInfoJoint.Name = "txtInfoJoint";
            this.txtInfoJoint.Size = new System.Drawing.Size(190, 42);
            this.txtInfoJoint.TabIndex = 95;
            // 
            // txtInfoPrep
            // 
            this.txtInfoPrep.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoPrep.Location = new System.Drawing.Point(831, 99);
            this.txtInfoPrep.Name = "txtInfoPrep";
            this.txtInfoPrep.Size = new System.Drawing.Size(190, 42);
            this.txtInfoPrep.TabIndex = 96;
            // 
            // txtInfoGouging
            // 
            this.txtInfoGouging.Dock = Wisej.Web.DockStyle.Fill;
            this.txtInfoGouging.Location = new System.Drawing.Point(831, 147);
            this.txtInfoGouging.Name = "txtInfoGouging";
            this.txtInfoGouging.Size = new System.Drawing.Size(190, 42);
            this.txtInfoGouging.TabIndex = 97;
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel28.ColumnCount = 1;
            this.tableLayoutPanel28.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel28.Controls.Add(this.btnInfoBack, 0, 2);
            this.tableLayoutPanel28.Controls.Add(this.btnInfoHome, 0, 3);
            this.tableLayoutPanel28.Controls.Add(this.btnInfoNext, 0, 4);
            this.tableLayoutPanel28.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 5;
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel28.TabIndex = 3;
            // 
            // btnInfoBack
            // 
            this.btnInfoBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoBack.Location = new System.Drawing.Point(3, 175);
            this.btnInfoBack.Name = "btnInfoBack";
            this.btnInfoBack.Size = new System.Drawing.Size(101, 80);
            this.btnInfoBack.TabIndex = 3;
            this.btnInfoBack.Text = "Back";
            this.btnInfoBack.Click += new System.EventHandler(this.btnInfoBack_Click);
            // 
            // btnInfoHome
            // 
            this.btnInfoHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoHome.Location = new System.Drawing.Point(3, 261);
            this.btnInfoHome.Name = "btnInfoHome";
            this.btnInfoHome.Size = new System.Drawing.Size(101, 80);
            this.btnInfoHome.TabIndex = 1;
            this.btnInfoHome.Text = "Home";
            this.btnInfoHome.Click += new System.EventHandler(this.btnInfoHome_Click);
            // 
            // btnInfoNext
            // 
            this.btnInfoNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnInfoNext.Location = new System.Drawing.Point(3, 347);
            this.btnInfoNext.Name = "btnInfoNext";
            this.btnInfoNext.Size = new System.Drawing.Size(101, 81);
            this.btnInfoNext.TabIndex = 0;
            this.btnInfoNext.Text = "Next";
            this.btnInfoNext.Click += new System.EventHandler(this.btnInfoNext_Click);
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.ColumnCount = 1;
            this.tableLayoutPanel29.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel29.Controls.Add(this.label103, 0, 1);
            this.tableLayoutPanel29.Controls.Add(this.label104, 0, 0);
            this.tableLayoutPanel29.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel29.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 2;
            this.tableLayoutPanel29.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel29.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel29.TabIndex = 0;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label103.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label103.Dock = Wisej.Web.DockStyle.Fill;
            this.label103.Location = new System.Drawing.Point(3, 79);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(1139, 35);
            this.label103.TabIndex = 1;
            this.label103.Text = "Notes";
            this.label103.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label104.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label104.Dock = Wisej.Web.DockStyle.Fill;
            this.label104.Location = new System.Drawing.Point(3, 3);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(1139, 70);
            this.label104.TabIndex = 0;
            this.label104.Text = "WPS Information";
            this.label104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabWPQRRun
            // 
            this.tabWPQRRun.Controls.Add(this.tableLayoutPanel33);
            this.tabWPQRRun.Location = new System.Drawing.Point(0, 35);
            this.tabWPQRRun.Name = "tabWPQRRun";
            this.tabWPQRRun.Size = new System.Drawing.Size(1212, 615);
            this.tabWPQRRun.Text = "Run";
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.ColumnCount = 3;
            this.tableLayoutPanel33.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel33.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel34, 1, 3);
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel38, 1, 1);
            this.tableLayoutPanel33.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel33.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 5;
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel33.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel33.TabIndex = 4;
            // 
            // tableLayoutPanel34
            // 
            this.tableLayoutPanel34.ColumnCount = 2;
            this.tableLayoutPanel34.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel34.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel34.Controls.Add(this.dgvWPQRRun, 0, 0);
            this.tableLayoutPanel34.Controls.Add(this.tableLayoutPanel35, 1, 0);
            this.tableLayoutPanel34.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel34.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel34.Name = "tableLayoutPanel34";
            this.tableLayoutPanel34.RowCount = 1;
            this.tableLayoutPanel34.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel34.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel34.TabIndex = 1;
            // 
            // dgvWPQRRun
            // 
            this.dgvWPQRRun.AutoGenerateColumns = false;
            this.dgvWPQRRun.AutoSizeColumnsMode = Wisej.Web.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgvWPQRRun.AutoSizeRowsMode = Wisej.Web.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle1.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvWPQRRun.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvWPQRRun.ColumnHeadersHeight = 64;
            this.dgvWPQRRun.Columns.AddRange(new Wisej.Web.DataGridViewColumn[] {
            this.dgvcSide,
            this.dgvcPass,
            this.dgvcProcess,
            this.dgvcPosition,
            this.dgvcSize,
            this.dgvcSpecification,
            this.dgvcClassification,
            this.dgvcPolarity,
            this.dgvcFluxGas,
            this.dgvcInput,
            this.dgvcAmps,
            this.dgvcVolts,
            this.dgvcSpeed});
            this.dgvWPQRRun.Dock = Wisej.Web.DockStyle.Fill;
            this.dgvWPQRRun.Location = new System.Drawing.Point(0, 3);
            this.dgvWPQRRun.Margin = new Wisej.Web.Padding(0, 3, 0, 3);
            this.dgvWPQRRun.MultiSelect = false;
            this.dgvWPQRRun.Name = "dgvWPQRRun";
            this.dgvWPQRRun.Size = new System.Drawing.Size(1030, 433);
            this.dgvWPQRRun.TabIndex = 29;
            // 
            // dgvcSide
            // 
            dataGridViewCellStyle2.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcSide.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridViewCellStyle3.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcSide.HeaderStyle = dataGridViewCellStyle3;
            this.dgvcSide.HeaderText = "Side";
            this.dgvcSide.Name = "dgvcSide";
            this.dgvcSide.ReadOnly = true;
            // 
            // dgvcPass
            // 
            dataGridViewCellStyle4.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcPass.DefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcPass.HeaderStyle = dataGridViewCellStyle5;
            this.dgvcPass.HeaderText = "Pass";
            this.dgvcPass.Name = "dgvcPass";
            this.dgvcPass.ReadOnly = true;
            // 
            // dgvcProcess
            // 
            dataGridViewCellStyle6.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcProcess.DefaultCellStyle = dataGridViewCellStyle6;
            dataGridViewCellStyle7.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcProcess.HeaderStyle = dataGridViewCellStyle7;
            this.dgvcProcess.HeaderText = "Process";
            this.dgvcProcess.Name = "dgvcProcess";
            // 
            // dgvcPosition
            // 
            dataGridViewCellStyle8.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcPosition.DefaultCellStyle = dataGridViewCellStyle8;
            dataGridViewCellStyle9.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcPosition.HeaderStyle = dataGridViewCellStyle9;
            this.dgvcPosition.HeaderText = "Position";
            this.dgvcPosition.Name = "dgvcPosition";
            // 
            // dgvcSize
            // 
            dataGridViewCellStyle10.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcSize.DefaultCellStyle = dataGridViewCellStyle10;
            dataGridViewCellStyle11.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcSize.HeaderStyle = dataGridViewCellStyle11;
            this.dgvcSize.HeaderText = "Size";
            this.dgvcSize.Name = "dgvcSize";
            this.dgvcSize.ReadOnly = true;
            // 
            // dgvcSpecification
            // 
            dataGridViewCellStyle12.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcSpecification.DefaultCellStyle = dataGridViewCellStyle12;
            dataGridViewCellStyle13.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcSpecification.HeaderStyle = dataGridViewCellStyle13;
            this.dgvcSpecification.HeaderText = "Specification";
            this.dgvcSpecification.Name = "dgvcSpecification";
            // 
            // dgvcClassification
            // 
            dataGridViewCellStyle14.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcClassification.DefaultCellStyle = dataGridViewCellStyle14;
            dataGridViewCellStyle15.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcClassification.HeaderStyle = dataGridViewCellStyle15;
            this.dgvcClassification.HeaderText = "Classification";
            this.dgvcClassification.Name = "dgvcClassification";
            // 
            // dgvcPolarity
            // 
            dataGridViewCellStyle16.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcPolarity.DefaultCellStyle = dataGridViewCellStyle16;
            dataGridViewCellStyle17.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcPolarity.HeaderStyle = dataGridViewCellStyle17;
            this.dgvcPolarity.HeaderText = "Polarity";
            this.dgvcPolarity.Name = "dgvcPolarity";
            this.dgvcPolarity.ReadOnly = true;
            // 
            // dgvcFluxGas
            // 
            dataGridViewCellStyle18.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcFluxGas.DefaultCellStyle = dataGridViewCellStyle18;
            dataGridViewCellStyle19.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcFluxGas.HeaderStyle = dataGridViewCellStyle19;
            this.dgvcFluxGas.HeaderText = "Flux or Gas";
            this.dgvcFluxGas.Name = "dgvcFluxGas";
            // 
            // dgvcInput
            // 
            dataGridViewCellStyle20.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle20.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcInput.DefaultCellStyle = dataGridViewCellStyle20;
            dataGridViewCellStyle21.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcInput.HeaderStyle = dataGridViewCellStyle21;
            this.dgvcInput.HeaderText = "Heat Input";
            this.dgvcInput.Name = "dgvcInput";
            // 
            // dgvcAmps
            // 
            dataGridViewCellStyle22.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle22.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcAmps.DefaultCellStyle = dataGridViewCellStyle22;
            dataGridViewCellStyle23.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcAmps.HeaderStyle = dataGridViewCellStyle23;
            this.dgvcAmps.HeaderText = "Amps";
            this.dgvcAmps.Name = "dgvcAmps";
            this.dgvcAmps.ReadOnly = true;
            // 
            // dgvcVolts
            // 
            dataGridViewCellStyle24.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle24.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcVolts.DefaultCellStyle = dataGridViewCellStyle24;
            dataGridViewCellStyle25.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcVolts.HeaderStyle = dataGridViewCellStyle25;
            this.dgvcVolts.HeaderText = "Volts";
            this.dgvcVolts.Name = "dgvcVolts";
            // 
            // dgvcSpeed
            // 
            dataGridViewCellStyle26.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle26.WrapMode = Wisej.Web.DataGridViewTriState.True;
            this.dgvcSpeed.DefaultCellStyle = dataGridViewCellStyle26;
            dataGridViewCellStyle27.Alignment = Wisej.Web.DataGridViewContentAlignment.MiddleCenter;
            this.dgvcSpeed.HeaderStyle = dataGridViewCellStyle27;
            this.dgvcSpeed.HeaderText = "Weld Speed";
            this.dgvcSpeed.Name = "dgvcSpeed";
            // 
            // tableLayoutPanel35
            // 
            this.tableLayoutPanel35.ColumnCount = 1;
            this.tableLayoutPanel35.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel36, 0, 0);
            this.tableLayoutPanel35.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel35.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel35.Name = "tableLayoutPanel35";
            this.tableLayoutPanel35.RowCount = 1;
            this.tableLayoutPanel35.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel35.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel35.TabIndex = 5;
            // 
            // tableLayoutPanel36
            // 
            this.tableLayoutPanel36.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel36.ColumnCount = 1;
            this.tableLayoutPanel36.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel36.Controls.Add(this.btnRunBack, 0, 2);
            this.tableLayoutPanel36.Controls.Add(this.btnRunHome, 0, 3);
            this.tableLayoutPanel36.Controls.Add(this.btnRunNext, 0, 4);
            this.tableLayoutPanel36.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel36.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel36.Name = "tableLayoutPanel36";
            this.tableLayoutPanel36.RowCount = 5;
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel36.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel36.TabIndex = 4;
            // 
            // btnRunBack
            // 
            this.btnRunBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunBack.Location = new System.Drawing.Point(3, 173);
            this.btnRunBack.Name = "btnRunBack";
            this.btnRunBack.Size = new System.Drawing.Size(95, 79);
            this.btnRunBack.TabIndex = 3;
            this.btnRunBack.Text = "Back";
            this.btnRunBack.Click += new System.EventHandler(this.btnRunBack_Click);
            // 
            // btnRunHome
            // 
            this.btnRunHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunHome.Location = new System.Drawing.Point(3, 258);
            this.btnRunHome.Name = "btnRunHome";
            this.btnRunHome.Size = new System.Drawing.Size(95, 79);
            this.btnRunHome.TabIndex = 1;
            this.btnRunHome.Text = "Home";
            this.btnRunHome.Click += new System.EventHandler(this.btnRunHome_Click);
            // 
            // btnRunNext
            // 
            this.btnRunNext.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRunNext.Location = new System.Drawing.Point(3, 343);
            this.btnRunNext.Name = "btnRunNext";
            this.btnRunNext.Size = new System.Drawing.Size(95, 79);
            this.btnRunNext.TabIndex = 0;
            this.btnRunNext.Text = "Next";
            this.btnRunNext.Click += new System.EventHandler(this.btnRunNext_Click);
            // 
            // tableLayoutPanel38
            // 
            this.tableLayoutPanel38.ColumnCount = 1;
            this.tableLayoutPanel38.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel38.Controls.Add(this.label110, 0, 1);
            this.tableLayoutPanel38.Controls.Add(this.label111, 0, 0);
            this.tableLayoutPanel38.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel38.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel38.Name = "tableLayoutPanel38";
            this.tableLayoutPanel38.RowCount = 2;
            this.tableLayoutPanel38.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel38.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel38.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel38.TabIndex = 0;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label110.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label110.Dock = Wisej.Web.DockStyle.Fill;
            this.label110.Location = new System.Drawing.Point(3, 79);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(1139, 35);
            this.label110.TabIndex = 1;
            this.label110.Text = "Notes";
            this.label110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label111.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label111.Dock = Wisej.Web.DockStyle.Fill;
            this.label111.Location = new System.Drawing.Point(3, 3);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(1139, 70);
            this.label111.TabIndex = 0;
            this.label111.Text = "WPQR Parameters";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabUpload
            // 
            this.tabUpload.Controls.Add(this.tableLayoutPanel14);
            this.tabUpload.Location = new System.Drawing.Point(0, 35);
            this.tabUpload.Name = "tabUpload";
            this.tabUpload.Size = new System.Drawing.Size(1212, 615);
            this.tabUpload.Text = "Upload";
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 3;
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel22, 1, 3);
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel4, 1, 1);
            this.tableLayoutPanel14.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 5;
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel14.TabIndex = 6;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel22.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel22.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel2.TabIndex = 5;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.btnUploadBack, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.btnUploadHome, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.btnUploadComplete, 0, 4);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 5;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel3.TabIndex = 4;
            // 
            // btnUploadBack
            // 
            this.btnUploadBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnUploadBack.Location = new System.Drawing.Point(3, 173);
            this.btnUploadBack.Name = "btnUploadBack";
            this.btnUploadBack.Size = new System.Drawing.Size(95, 79);
            this.btnUploadBack.TabIndex = 2;
            this.btnUploadBack.Text = "Back";
            this.btnUploadBack.Click += new System.EventHandler(this.btnUploadBack_Click);
            // 
            // btnUploadHome
            // 
            this.btnUploadHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnUploadHome.Location = new System.Drawing.Point(3, 258);
            this.btnUploadHome.Name = "btnUploadHome";
            this.btnUploadHome.Size = new System.Drawing.Size(95, 79);
            this.btnUploadHome.TabIndex = 1;
            this.btnUploadHome.Text = "Home";
            this.btnUploadHome.Click += new System.EventHandler(this.btnUploadHome_Click);
            // 
            // btnUploadComplete
            // 
            this.btnUploadComplete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnUploadComplete.Location = new System.Drawing.Point(3, 343);
            this.btnUploadComplete.Name = "btnUploadComplete";
            this.btnUploadComplete.Size = new System.Drawing.Size(95, 79);
            this.btnUploadComplete.TabIndex = 0;
            this.btnUploadComplete.Text = "Complete";
            this.btnUploadComplete.Click += new System.EventHandler(this.btnUploadComplete_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.label76, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel4.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.FromName("@focusFrame");
            this.label76.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label76.Dock = Wisej.Web.DockStyle.Fill;
            this.label76.Location = new System.Drawing.Point(3, 79);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(1139, 35);
            this.label76.TabIndex = 1;
            this.label76.Text = "Notes";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1139, 70);
            this.label1.TabIndex = 0;
            this.label1.Text = "Weld Preparation and Sequence Upload";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fbWPS
            // 
            this.Controls.Add(this.Boards);
            this.Name = "fbWPS";
            this.Size = new System.Drawing.Size(1212, 650);
            this.Boards.ResumeLayout(false);
            this.tabWPQRInfo.ResumeLayout(false);
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel27.PerformLayout();
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel29.ResumeLayout(false);
            this.tableLayoutPanel29.PerformLayout();
            this.tabWPQRRun.ResumeLayout(false);
            this.tableLayoutPanel33.ResumeLayout(false);
            this.tableLayoutPanel34.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvWPQRRun)).EndInit();
            this.tableLayoutPanel35.ResumeLayout(false);
            this.tableLayoutPanel36.ResumeLayout(false);
            this.tableLayoutPanel38.ResumeLayout(false);
            this.tableLayoutPanel38.PerformLayout();
            this.tabUpload.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TabControl Boards;
        private Wisej.Web.TabPage tabWPQRInfo;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel25;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel26;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel27;
        private Wisej.Web.Label label86;
        private Wisej.Web.Label label87;
        private Wisej.Web.Label label98;
        private Wisej.Web.Label label82;
        private Wisej.Web.Label label81;
        private Wisej.Web.Label label94;
        private Wisej.Web.Label label93;
        private Wisej.Web.Label label79;
        private Wisej.Web.TextBox txtInfoWPQR;
        private Wisej.Web.Label label101;
        private Wisej.Web.Label label89;
        private Wisej.Web.Label label90;
        private Wisej.Web.Label label88;
        private Wisej.Web.Label label99;
        private Wisej.Web.Label label100;
        private Wisej.Web.Label label57;
        private Wisej.Web.Label label102;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel28;
        private Wisej.Web.Button btnInfoBack;
        private Wisej.Web.Button btnInfoHome;
        private Wisej.Web.Button btnInfoNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel29;
        private Wisej.Web.Label label103;
        private Wisej.Web.Label label104;
        private Wisej.Web.TabPage tabWPQRRun;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel33;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel34;
        private Wisej.Web.DataGridView dgvWPQRRun;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcSide;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcPass;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcProcess;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcPosition;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcSize;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcSpecification;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcClassification;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcPolarity;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcFluxGas;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcInput;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcAmps;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcVolts;
        private Wisej.Web.DataGridViewTextBoxColumn dgvcSpeed;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel35;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel36;
        private Wisej.Web.Button btnRunBack;
        private Wisej.Web.Button btnRunHome;
        private Wisej.Web.Button btnRunNext;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel38;
        private Wisej.Web.Label label110;
        private Wisej.Web.Label label111;
        private Wisej.Web.Label label58;
        private Wisej.Web.Label label59;
        private Wisej.Web.Label label60;
        private Wisej.Web.CheckBox cbInfoVisual;
        private Wisej.Web.CheckBox cbInfoNDT;
        private Wisej.Web.CheckBox cbInfoDPI;
        private Wisej.Web.CheckBox cbInfoMPI;
        private Wisej.Web.CheckBox cbInfoRT;
        private Wisej.Web.CheckBox cbInfoUT;
        private Wisej.Web.TextBox txtInfoJob;
        private Wisej.Web.TextBox txtInfoPrepared;
        private Wisej.Web.TextBox txtInfoThickness;
        private Wisej.Web.TextBox txtInfoPWHT;
        private Wisej.Web.TextBox txtInfoInterpass;
        private Wisej.Web.TextBox txtInfoMatStandard;
        private Wisej.Web.TextBox txtInfoWPS;
        private Wisej.Web.TextBox txtInfoDate;
        private Wisej.Web.TextBox txtInfoDiameter;
        private Wisej.Web.TextBox txtInfoPreheat;
        private Wisej.Web.TextBox txtInfoNotes;
        private Wisej.Web.TextBox txtInfoMatGrade;
        private Wisej.Web.TextBox txtInfoMatPNo;
        private Wisej.Web.TextBox txtInfoJoint;
        private Wisej.Web.TextBox txtInfoPrep;
        private Wisej.Web.TextBox txtInfoGouging;
        private Wisej.Web.TabPage tabUpload;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel14;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel22;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.Button btnUploadBack;
        private Wisej.Web.Button btnUploadHome;
        private Wisej.Web.Button btnUploadComplete;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel4;
        private Wisej.Web.Label label76;
        private Wisej.Web.Label label1;
    }
}
