﻿using PdfiumViewer;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using Wisej.Ext.ClientClipboard;
using Wisej.Web;
using static WeldingManagement.FileManagement;

namespace WeldingManagement.UserControls
{
    [ToolboxItem(true),
    Description("A Filmstrip control."),
    ToolboxBitmap(typeof(FilmStrip), "FilmStrip"),
    DefaultEvent("OnSelectionChanged")]
    public partial class FilmStrip : Wisej.Web.UserControl
    {
        #region Member variables

        public event EventHandler OnThumbnailClicked;

        int pictureBoxNumber = 0, pictureBoxOffset = 5;
        int width = 0, height = 0;
        string[] folderparts;

        #endregion Member variables

        private string pictureText = "";

        private string uploadProgressMessage = "";

        public bool RenderExampleOverlay = false;

        private Image previewImage = null;


        [Category("FilmStrip preview image")]
        [Description("Stores High Resolution and renders Scaled image.")]
        [DefaultValue(null)]
        public Image PreviewImage
        {
            get
            {
                return previewImage; //Returns the retained High Resolution
            }
            set
            {
                if (value == null)
                {
                    RenderExampleOverlay = false;
                    previewImage = null;
                }
                else
                {
                    previewImage = value;  //Retain High Resolution

                }

                pbCamera.Invalidate();
            }
        }

        [Category("Filmstrip properties")]
        [Description("Preview Overlay Text.")]
        [DefaultValue(null)]
        public String PictureText
        {
            get { return pictureText; }
            set { pictureText = value; }
        }

        [Category("Filmstrip properties")]
        [Description("Upload progress Overlay Text.")]
        [DefaultValue(null)]
        public String UploadProgressMessage
        {
            get { return uploadProgressMessage; }
            set { uploadProgressMessage = value; }
        }

        [Category("Filmstrip properties")]
        [Description("Show Picture comment row")]
        [DefaultValue(null)]
        public bool ShowCommentRow
        {
            get { return tblCommentRow.Visible; }
            set { tblCommentRow.Visible = value; }
        }

        public void ShowImageIndex(int index)
        {
            foreach (var ctrl in this.FilmStripPanel.Controls)
            {
                if (ctrl.GetType() == typeof(PictureBox))
                {
                    PictureBox pb = (PictureBox)ctrl;

                    // Find index of picturebox
                    string ImageFullFilename = pb.Tag.ToString();
                    string[] folderparts = ImageFullFilename.Split('\\');
                    string itemNo = folderparts[folderparts.GetLength(0) - 1];
                    string PhotoNumber = new String(itemNo.Where(Char.IsDigit).ToArray());
                    if (PhotoNumber == index.ToString())
                    {
                        if (File.Exists(ImageFullFilename))
                        {

                            using (Bitmap bm = (Bitmap)SafeThumbnailFromFile(ImageFullFilename))
                            {
                                this.RenderExampleOverlay = false;

                                // Full Resolution Preview
                                this.PreviewImage = (Bitmap)bm.Clone();

                                this.Invalidate();
                                return;
                            }
                        }
                    }
                }
            }
        }

        public int ImageCount()
        {
            int count = 0;

            foreach (var pd in this.FilmStripPanel.Controls)
            {
                if (pd.GetType() == typeof(PictureBox))
                {
                    count++;
                }
            }
            return count - 1;  //Zero referenced index
        }

        public FilmStrip()
        {
            InitializeComponent();

            //mouse event registrations for zoom and drag with the mouse
            pbCamera.MouseWheel += PbCamera_MouseWheel;
            pbCamera.MouseDown += PbCamera_MouseDown;
            pbCamera.MouseMove += PbCamera_MouseMove;
            pbCamera.MouseUp += PbCamera_MouseUp;

            // Touch event registrations for zoom and drag with touch gestures
            pbCamera.TouchStart += PbCamera_TouchStart;
            pbCamera.TouchMove += PbCamera_TouchMove;
            pbCamera.TouchEnd += PbCamera_TouchEnd;
            pbCamera.Pinch += pbCamera_Pinch;
        }

        private void PbCamera_MouseWheel(object sender, MouseEventArgs e)
        {
            // Adjust the scale factor based on the wheel delta.
            if (e.Delta > 0) _scaleFactor *= 1.1f; // Zoom in
            else _scaleFactor /= 1.1f; // Zoom out

            pbCamera.Invalidate(); // Request a redraw
        }
        private void PbCamera_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                _isDragging = true;
                _previousLocation = e.Location;
            }
        }

        private void PbCamera_MouseMove(object sender, MouseEventArgs e)
        {
            if (_isDragging)
            {
                _offsetX += e.X - _previousLocation.X;
                _offsetY += e.Y - _previousLocation.Y;
                pbCamera.Invalidate(); // Request a redraw to update the image position
                _previousLocation = e.Location;
            }
        }

        private void PbCamera_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                _isDragging = false;
            }
        }

        private void PbCamera_TouchStart(object sender, TouchEventArgs e)
        {
            if (e.Locations.Length > 0)
            {
                _isDragging = true;
                // Use the first touch point's location as the starting point for dragging
                _previousLocation = e.Locations[0];
            }
        }

        private void PbCamera_TouchMove(object sender, TouchEventArgs e)
        {
            if (_isDragging && e.Locations.Length > 0)
            {
                // Calculate the drag offsets using the first touch point
                var currentLocation = e.Locations[0];
                _offsetX += currentLocation.X - _previousLocation.X;
                _offsetY += currentLocation.Y - _previousLocation.Y;

                pbCamera.Invalidate(); // Request a redraw to update the image position
                _previousLocation = currentLocation;
            }
        }

        private void PbCamera_TouchEnd(object sender, TouchEventArgs e)
        {
            _isDragging = false;
        }
        private void pbCamera_Pinch(object sender, PinchEventArgs e)
        {
            // Adjust the scale factor based on the pinch gesture
            if (e.Scale > 0) // Pinching outwards (zoom in)
            {
                _scaleFactor *= (float)(1 + e.Scale / 10.0f); // Adjust the scale factor to zoom in // e.Scale; 
            }
            else if (e.Scale < 0) // Pinching inwards (zoom out)
            {
                _scaleFactor /= (float)(1 - e.Scale / 10.0f); // Adjust the scale factor to zoom out
            }

            // Invalidate the pbCamera to trigger a redraw with the new scale factor
            pbCamera.Invalidate();
        }

        void ResetScale()
        {
            _scaleFactor = 1.0f; // Zoom out
            _offsetX = _offsetY = _previousLocation.X = _previousLocation.Y = 0;
            _isDragging = false;

            pbCamera.Invalidate();
        }

        public bool RemoveAllPDFs()
        {
            ControlCollection controlCollection = this.FilmStripPanel.Controls;
            Control pb;
            for (int i = pictureBoxNumber - 1; i > -1; i--)
            {
                pb = (Control)controlCollection[i * 2];
                controlCollection.Remove(pb);
                pb = (Control)controlCollection[i * 2];
                controlCollection.Remove(pb);
            }
            pictureBoxNumber = 0;
            pictureBoxOffset = 5;

            tblCommentRow.Visible = false;
            tblCommentRow.Invalidate();
            FilmStripPanel.Invalidate();

            ResetScale();

            return true;
        }

        public bool AddPictureComment(string ImagePath, string Comment = "", bool Favorite = false)
        {
            //pb.Tag = ImagePath;
            string photoPath = Path.GetDirectoryName(ImagePath);
            string commentDir = Path.Combine(photoPath, "Comments");


            // To Do
            //ServerJobPath();

            // - Directory.CreateDirectory(photoPath);
            // - Directory.CreateDirectory(commentDir);

            string CommentFilename = Path.Combine(commentDir, Path.GetFileName(ImagePath));

            CommentFilename = Path.ChangeExtension(CommentFilename, "txt");

            if (Comment == "")
            {
                if (File.Exists(CommentFilename))
                    File.Delete(CommentFilename);
            }
            else
            {
                StreamWriter file = new StreamWriter(CommentFilename, append: false);
                file.WriteLine(Comment);
                file.Close();
            }

            return true;
        }

        public bool ReadPictureComment(string ImagePath)
        {
            txtImageComment.Text = "";

            string photoPath = Path.GetDirectoryName(ImagePath);
            string commentDir = Path.Combine(photoPath, "Comments");

            // Note:  Paths Created in  ServerJobPath();

            string CommentFilename = Path.Combine(commentDir, Path.GetFileName(ImagePath));

            CommentFilename = Path.ChangeExtension(CommentFilename, "txt");

            if (File.Exists(CommentFilename))
            {
                StreamReader file = new StreamReader(CommentFilename);

                string Comment = file.ReadToEnd();

                //Put into Photo Database - make compatible with wbase -> storage
                file.Close();
                txtImageComment.Text = Comment;
            }
            return true;
        }

        private void btnFavImage_Click(object sender, EventArgs e)
        {
            if (SelectedPicturePath != "")
            {
                if (btnFavImage.ImageIndex == 0)
                    btnFavImage.ImageIndex = 1;
                else
                    btnFavImage.ImageIndex = 0;
                //Save to filesystem folder comment
                MakeFavorite(SelectedPicturePath, btnFavImage.ImageIndex);
            }

        }

        private void MakeFavorite(string ImagePath, int imageIndex)
        {
            string photoPath = Path.GetDirectoryName(ImagePath);
            string commentDir = Path.Combine(photoPath, "Comments");

            // Note:  Paths Created in  ServerJobPath();

            string FavFilename = Path.Combine(commentDir, Path.GetFileName(ImagePath));

            FavFilename = Path.ChangeExtension(FavFilename, "fav");
            if (imageIndex == 0)
            {
                if (File.Exists(FavFilename))
                {
                    File.Delete(FavFilename);
                }
            }
            else
            {
                StreamWriter file = new StreamWriter(FavFilename, append: false);
                file.WriteLine($"Fav Image:{Path.GetFileName(ImagePath)}");
                file.Close();
            }
        }

        private void ReadFavorite(string ImagePath)
        {
            btnFavImage.ImageIndex = 0;

            string photoPath = Path.GetDirectoryName(ImagePath);
            string commentDir = Path.Combine(photoPath, "Comments");

            // Note:  Paths Created in  ServerJobPath();

            string FavFilename = Path.Combine(commentDir, Path.GetFileName(ImagePath));

            FavFilename = Path.ChangeExtension(FavFilename, "fav");

            if (File.Exists(FavFilename))
            {
                btnFavImage.ImageIndex = 1;
            }
        }

        public bool AddFileThumbnail(string FilePath)
        {

            try
            {
                Label lb = new Wisej.Web.Label();

                width = 0;
                height = 0;
                folderparts = FilePath.Split('\\');

                PictureBox pb = new PictureBox();
                pb.Name = pictureBoxNumber.ToString();
                pb.Tag = FilePath;
                pb.BorderStyle = Wisej.Web.BorderStyle.Solid;

                height = FilmStripPanel.Height - 40; //Convert.ToInt32(height*0.70);
                width = Convert.ToInt32(height * 1.41); //Rectangle 16:9 ratio or 4:3
                pb.Size = new Size(width, height);
                pb.Location = new Point(pictureBoxOffset, 5);

                string itemNo = folderparts[folderparts.GetLength(0) - 1];

                string PhotoNumber = new String(itemNo.Where(Char.IsDigit).ToArray());

                lb.Text = PhotoNumber;

                lb.Size = new Size(width, 15);
                lb.Location = new Point(pictureBoxOffset, height + 4);

                // Extend to show as Favorite and Comment
                // Favorite as 

                pb.SizeMode = PictureBoxSizeMode.CenterImage;

                pb.Image = GetOrCreateThumbnailCache(FilePath);

                pb.Click += new EventHandler(FilmStripThumb_Click);

                pictureBoxOffset = pictureBoxOffset + width + 15;

                this.FilmStripPanel.Controls.Add(pb);
                this.FilmStripPanel.Controls.Add(lb);

                pb.Visible = true;
                lb.Visible = true;
                pictureBoxNumber++;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"AddFileThumbnail Error for File:{FilePath}\r\n\r\nException: {ex.Message.ToString()}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        public Image GetOrCreateThumbnailCache(string ImageFullFilename)
        {
            // Manipulating images is expensive relative to disk space, both from a memory and CPU standpoint.
            // Therefore generating the thumbnail from a full image is something you only want to do once for each full image.
            // And the best time to do it is at the time where the image is uploaded, especially as we are showing a number of these on the same page.

            string CacheFilename = GetFileCacheFilename(ImageFullFilename);
            Image thumbnail;

            if (!File.Exists(CacheFilename))
            {
                // Create the thumbnail from the in-memory image
                using (Bitmap inMemoryImage = (Bitmap)SafeThumbnailFromFile(ImageFullFilename))
                {

                    if (inMemoryImage.Height > inMemoryImage.Width)
                    {
                        thumbnail = (Image)inMemoryImage.GetThumbnailImage(Convert.ToInt32(((float)height / (float)inMemoryImage.Height) * inMemoryImage.Width), height, null, IntPtr.Zero);
                    }
                    else
                    {
                        thumbnail = (Image)inMemoryImage.GetThumbnailImage(width, Convert.ToInt32(((float)width / (float)inMemoryImage.Width) * inMemoryImage.Height), null, IntPtr.Zero);
                    }

                    // Save to file
                    thumbnail.Save(CacheFilename, ImageFormat.Jpeg);

                }
            }
            else
            {
                thumbnail = SafeThumbnailFromFile(CacheFilename);
            }

            return (Image)thumbnail;
        }

        Image SafeThumbnailFromFile(string path)
        {
            //byte[] bytes = File.ReadAllBytes(path);
            //var ms = new MemoryStream(bytes);
            //var img = Image.FromStream(ms);
            //return (Image)img.Clone();//Dont hold open file handle

            using (Stream stream = File.OpenRead(path))
            {
                using (PdfDocument pdfDocument = PdfDocument.Load(stream))
                {
                    using (Image tempThumbnail = pdfDocument.Render(0, 100, 100, 96, 96, PdfRenderFlags.Annotations))
                    {
                        return (Image)tempThumbnail.Clone();
                    }
                }
            }
        }

        public string GetFileCacheFilename(string FileFullFilename)
        {
            string filePath = Path.GetDirectoryName(FileFullFilename);
            string CacheDir = Path.Combine(filePath, "cache");

            // Note:  Paths Created in  ServerJobPath();

            string CacheFilename = Path.Combine(CacheDir, Path.GetFileName(FileFullFilename));

            CacheFilename = Path.ChangeExtension(CacheFilename, "thumb");

            return CacheFilename;
        }

        private float _scaleFactor = 1.0f;
        private bool _isDragging = false;
        private Point _previousLocation;
        private float _offsetX = 0;
        private float _offsetY = 0;

        private void pbCamera_Paint(object sender, PaintEventArgs e)
        {
            //contextMenu1.MenuItems[0].Visible = contextMenu1.MenuItems[1].Visible = false;


            base.OnPaint(e);
            // ... other drawing commands


            if (uploadProgressMessage != "")
            {
                e.Graphics.Clear(Color.White);

                RenderExampleOverlay = false;
                //Process the Image
                Font picFont = new Font("default", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
                e.Graphics.Clear(Color.White);
                e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

                string text = uploadProgressMessage;

                SizeF textSize = e.Graphics.MeasureString(text, picFont);
                PointF locationToDraw = new PointF();
                locationToDraw.X = (pbCamera.Width / 2) - (textSize.Width / 2);
                locationToDraw.Y = (pbCamera.Height / 2) - (textSize.Height / 2);

                e.Graphics.DrawString(text, picFont, Brushes.Black, locationToDraw);

                return;
            }

            // Paint the backgroundimage as this blocks OnPaintBackground 
            // and the control does not repaint correctly
            if (this.previewImage == null)
            {
                e.Graphics.Clear(Color.White);
                return;
            }

            try
            {
                // Adjust the scale factors for both directions by the _scaleFactor.
                float scale_x = _scaleFactor * (pbCamera.Width / (float)previewImage.Width);
                float scale_y = _scaleFactor * (pbCamera.Height / (float)previewImage.Height);

                // Preserve the aspect ratio by using the smaller scale factor.
                scale_x = Math.Min(scale_x, scale_y);
                scale_y = scale_x;

                float width = this.previewImage.Width * scale_x;
                float height = this.previewImage.Height * scale_x;

                // Adjust drawing position by offsets for dragging
                float drawing_cx = ((pbCamera.Width - (previewImage.Width * scale_x)) / 2) + _offsetX;
                float drawing_cy = ((pbCamera.Height - (previewImage.Height * scale_x)) / 2) + _offsetY;

                // Draw the scaled and positioned image.
                e.Graphics.DrawImage(this.previewImage, drawing_cx, drawing_cy, width, height);

                mnuCopy.MenuItems[0].Visible = true; // contextMenu1.MenuItems[1].Visible Rotate not visible

            }
            catch
            {
                //Object in Use?? TO DO Fix
            }

            if (PictureText != "")
            {
                RenderExampleOverlay = false;
                //Process the Image
                Font picFont = new Font("default", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
                e.Graphics.Clear(Color.White);
                e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

                string text = PictureText;

                SizeF textSize = e.Graphics.MeasureString(text, picFont);
                PointF locationToDraw = new PointF();
                locationToDraw.X = (pbCamera.Width / 2) - (textSize.Width / 2);
                locationToDraw.Y = (pbCamera.Height / 2) - (textSize.Height / 2);

                e.Graphics.DrawString(text, picFont, Brushes.Black, locationToDraw);
            }
            else if (RenderExampleOverlay)
            {
                Font picFont = new Font("default", 50F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);

                e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

                string text = "-- EXAMPLE --";

                SizeF textSize = e.Graphics.MeasureString(text, picFont);

                PointF locationToDraw = new PointF();
                locationToDraw.X = (pbCamera.Width / 2) - (textSize.Width / 2);
                locationToDraw.Y = (pbCamera.Height / 2) - (textSize.Height / 3);

                e.Graphics.TranslateTransform(locationToDraw.X, locationToDraw.Y);
                e.Graphics.RotateTransform(-30);
                e.Graphics.TranslateTransform(-locationToDraw.X, -locationToDraw.Y);
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                e.Graphics.DrawString(text, picFont, Brushes.Red, locationToDraw);
            }
        }

        protected void FilmStripThumb_Click(object sender, EventArgs e)
        {
            ResetScale();
            int PictureBoxNumber = 0;

            PictureBox pb = (PictureBox)sender;
            UploadProgressMessage = "";


            PictureBoxNumber = Convert.ToInt32(pb.Name);
            txtImageComment.Text = "";

            if (OnThumbnailClicked != null)
            {
                //Return Path
                OnThumbnailClicked(pb, e);

                if (pb.Tag != null)
                {
                    SelectedPicturePath = pb.Tag.ToString();

                    ReadPictureComment(SelectedPicturePath);
                    ReadFavorite(SelectedPicturePath);
                    tblCommentRow.Visible = true;
                }
                else
                {
                    pb.Image = null;
                }
            }
            else
            {
                SelectedPicturePath = "";
                tblCommentRow.Visible = false;
            }
            pb = null;
        }

        //Key for comments
        string SelectedPicturePath = "";

        private void btnUpdateComment_Click(object sender, EventArgs e)
        {
            if (SelectedPicturePath != "")
            {
                //Save to filesystem folder comment
                AddPictureComment(SelectedPicturePath, txtImageComment.Text);
            }
        }

        private void contextMenu_Copy_Click(object sender, EventArgs e)
        {
            CopyPictoClipboard();
        }

        private void mnuCopySmall_Click(object sender, EventArgs e)
        {
            if (PreviewImage != null)
            {
                this.ShowLoader = true;

                //648 x 480
                ClientClipboard.WriteImage((Image)PreviewImage.GetThumbnailImage(640, 480, null, IntPtr.Zero), ClipboardResult);
                this.ShowLoader = false;
                MessageBox.Show("Image Copied to Clipboard Ok");
            }
        }

        private void mnuCopyMedium_Click(object sender, EventArgs e)
        {
            if (PreviewImage != null)
            {
                this.ShowLoader = true;

                //648 x 480
                ClientClipboard.WriteImage((Image)PreviewImage.GetThumbnailImage(800, 600, null, IntPtr.Zero), ClipboardResult);
                this.ShowLoader = false;
                MessageBox.Show("Image Copied to Clipboard Ok");
            }
        }

        private void mnuCopyFull_Click(object sender, EventArgs e)
        {
            CopyPictoClipboard();
        }

        private void menuSaveAs_Click(object sender, EventArgs e)
        {
            if (PreviewImage != null)
            {
                if (sender is PictureBox)
                {
                    string filename = ((PictureBox)sender).Tag.ToString();

                    Application.DownloadAndOpen("_blank", PreviewImage, filename);
                }
            }
        }


        public void CopyPictoClipboard()
        {
            if (PreviewImage != null)
            {
                this.ShowLoader = true;
                ClientClipboard.WriteImage(PreviewImage, ClipboardResult);
                this.ShowLoader = false;
                MessageBox.Show("Image Copied to Clipboard Ok");
            }
        }

        public static void ClipboardResult()
        {
            Debug.WriteLine("Copied to clipboard :)");
        }

        private void FilmStrip_Load(object sender, EventArgs e)
        {

        }

        private void menuCopy_Popup(object sender, EventArgs e)
        {
            if (PreviewImage != null)
            {

            }
        }

        private void FilmStrip_Resize(object sender, EventArgs e)
        {
            this.FilmStripPanel.Size = new System.Drawing.Size(this.Width, this.Height);
            this.FilmStripPanel.AutoScroll = true;
        }
    }
}
