﻿namespace WeldingManagement.UserControls.PopupControls
{
    partial class up_rqFilesView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.tlpPopupDocuments = new Wisej.Web.TableLayoutPanel();
            this.pbDocuments = new Wisej.Web.PictureBox();
            this.pvDocuments = new Wisej.Web.PdfViewer();
            this.lvDocuments = new Wisej.Web.ListView();
            this.chName = new Wisej.Web.ColumnHeader();
            this.chType = new Wisej.Web.ColumnHeader();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.btnPopupCancel = new Wisej.Web.Button();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.btnPopupClose = new Wisej.Web.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.tlpPopupDocuments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDocuments)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tlpPopupDocuments, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // tlpPopupDocuments
            // 
            this.tlpPopupDocuments.BackColor = System.Drawing.Color.FromName("@window");
            this.tlpPopupDocuments.ColumnCount = 2;
            this.tlpPopupDocuments.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 30F));
            this.tlpPopupDocuments.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 70F));
            this.tlpPopupDocuments.Controls.Add(this.pbDocuments, 0, 1);
            this.tlpPopupDocuments.Controls.Add(this.pvDocuments, 1, 0);
            this.tlpPopupDocuments.Controls.Add(this.lvDocuments, 0, 0);
            this.tlpPopupDocuments.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpPopupDocuments.Location = new System.Drawing.Point(3, 30);
            this.tlpPopupDocuments.Margin = new Wisej.Web.Padding(3, 0, 3, 0);
            this.tlpPopupDocuments.Name = "tlpPopupDocuments";
            this.tlpPopupDocuments.RowCount = 2;
            this.tlpPopupDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpPopupDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpPopupDocuments.Size = new System.Drawing.Size(1206, 535);
            this.tlpPopupDocuments.TabIndex = 2;
            // 
            // pbDocuments
            // 
            this.pbDocuments.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pbDocuments.Dock = Wisej.Web.DockStyle.Fill;
            this.pbDocuments.Location = new System.Drawing.Point(364, 270);
            this.pbDocuments.Name = "pbDocuments";
            this.pbDocuments.Size = new System.Drawing.Size(839, 262);
            this.pbDocuments.SizeMode = Wisej.Web.PictureBoxSizeMode.Zoom;
            // 
            // pvDocuments
            // 
            this.pvDocuments.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pvDocuments.Dock = Wisej.Web.DockStyle.Fill;
            this.pvDocuments.Location = new System.Drawing.Point(364, 3);
            this.pvDocuments.Name = "pvDocuments";
            this.pvDocuments.Size = new System.Drawing.Size(839, 261);
            this.pvDocuments.TabIndex = 6;
            // 
            // lvDocuments
            // 
            this.lvDocuments.Columns.AddRange(new Wisej.Web.ColumnHeader[] {
            this.chName,
            this.chType});
            this.lvDocuments.Dock = Wisej.Web.DockStyle.Fill;
            this.lvDocuments.Location = new System.Drawing.Point(3, 3);
            this.lvDocuments.Name = "lvDocuments";
            this.tlpPopupDocuments.SetRowSpan(this.lvDocuments, 2);
            this.lvDocuments.Size = new System.Drawing.Size(355, 529);
            this.lvDocuments.TabIndex = 5;
            this.lvDocuments.View = Wisej.Web.View.Details;
            this.lvDocuments.SelectedIndexChanged += new System.EventHandler(this.lvDocuments_SelectedIndexChanged);
            // 
            // chName
            // 
            this.chName.Name = "chName";
            this.chName.Text = "File Name";
            // 
            // chType
            // 
            this.chType.Name = "chType";
            this.chType.Text = "Category";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.Controls.Add(this.btnPopupCancel, 1, 0);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 565);
            this.tableLayoutPanel3.Margin = new Wisej.Web.Padding(3, 0, 3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1206, 47);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // btnPopupCancel
            // 
            this.btnPopupCancel.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnPopupCancel.Dock = Wisej.Web.DockStyle.Fill;
            this.btnPopupCancel.Location = new System.Drawing.Point(405, 3);
            this.btnPopupCancel.Name = "btnPopupCancel";
            this.btnPopupCancel.Size = new System.Drawing.Size(396, 41);
            this.btnPopupCancel.TabIndex = 3;
            this.btnPopupCancel.Text = "Close";
            this.btnPopupCancel.Click += new System.EventHandler(this.btnPopupCancel_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.Controls.Add(this.btnPopupClose, 1, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1206, 24);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // btnPopupClose
            // 
            this.btnPopupClose.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.btnPopupClose.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnPopupClose.Dock = Wisej.Web.DockStyle.Fill;
            this.btnPopupClose.Location = new System.Drawing.Point(1176, 0);
            this.btnPopupClose.Margin = new Wisej.Web.Padding(0);
            this.btnPopupClose.Name = "btnPopupClose";
            this.btnPopupClose.Size = new System.Drawing.Size(30, 24);
            this.btnPopupClose.TabIndex = 1;
            this.btnPopupClose.Text = "x";
            this.btnPopupClose.Click += new System.EventHandler(this.btnPopupClose_Click);
            // 
            // up_rqFilesView
            // 
            this.AutoHide = false;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.CssStyle = "border-radius: 4px;";
            this.Name = "up_rqFilesView";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.up_rqFilesView_VisibleChanged);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tlpPopupDocuments.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbDocuments)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tlpPopupDocuments;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.Button btnPopupCancel;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.Button btnPopupClose;
        private Wisej.Web.ListView lvDocuments;
        private Wisej.Web.ColumnHeader chName;
        private Wisej.Web.ColumnHeader chType;
        private Wisej.Web.PdfViewer pvDocuments;
        private Wisej.Web.PictureBox pbDocuments;
    }
}
