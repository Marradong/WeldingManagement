﻿using ApiClient;
using QAWorxLink;
using System;
using System.Collections.Generic;
using System.Linq;
using Welding.DAL;
using Wisej.Web;

namespace WeldingManagement.UserControls.HomeControls
{
    public partial class up_hmJob : Wisej.Web.UserPopup
    {
        public up_hmJob()
        {
            InitializeComponent();
        }

        private void txtPopupJob_Click(object sender, EventArgs e)
        {
            txtPopupJob.Select(0, 0);
        }

        private void txtPopupJob_TextChanged(object sender, EventArgs e)
        {
            AutoFillFields();
        }

        private void btnPopupClose_Click(object sender, EventArgs e)
        {
            ClearFields(true);

            this.Close();
        }

        private void btnPopupSave_Click(object sender, EventArgs e)
        {
            if (txtPopupJob.Text.Length == 9 && (cbPopupWQ.Checked || cbPopupWPQR.Checked || cbPopupWPS.Checked))
            {
                ManualCreateJob(txtPopupJob.Text.ToString());
            }
        }

        private void txtPopupJob_KeyPress(object sender, KeyPressEventArgs e)
        {
            AutoFillFields();
        }

        private void ManualCreateJob(string jobNo)
        {
            JobDetail QAWorxJob = QAWebApiClient.ApiCalls.Get_JobBasic(jobNo, System.Reflection.Assembly.GetExecutingAssembly().GetName().Name, "ManualCreateJob", Application.Cookies["EmployeeNumber"]);

            List<Job> jobs = ApiClient.ApiCalls.ReadJobs();

            Job saveJob;

            if (jobs.Where(j => j.JobNo == jobNo).Count() > 0)
            {
                saveJob = ApiClient.ApiCalls.ReadJob(jobs.Where(j => j.JobNo == jobNo).First().JobId);

                OperationalReview or = ApiClient.ApiCalls.ReadOperationalReview(saveJob.WeldingActions.First().NewWeldingForm.OperationalReview.OperationalReviewId);

                or.WPSAmount = cbPopupWPS.Checked ? (short)(or.WPSAmount + 1) : or.WPSAmount;
                or.WPQRAmount = cbPopupWPQR.Checked ? (short)(or.WPQRAmount + 1) : or.WPQRAmount;
                or.WeldersAmount = (cbPopupWQ.Checked || cbPopupWPQR.Checked) ? (short)(or.WeldersAmount + 1) : or.WeldersAmount;

                ApiClient.ApiCalls.UpdateOperationalReview(or.OperationalReviewId, or);
            }
            else
            {
                saveJob = ApiClient.ApiCalls.CreateJobDefault(jobNo, Application.Cookies["EmployeeNumber"]);

                saveJob.JobNo = jobNo;

                if (!string.IsNullOrEmpty(QAWorxJob.ClientPo))
                    saveJob.PurchaseOrderNo = QAWorxJob.ClientPo.ToString();

                if (!string.IsNullOrEmpty(QAWorxJob.Cust))
                    saveJob.Client = QAWorxJob.Cust.ToString();

                if (!string.IsNullOrEmpty(QAWorxJob.ItemDescription))
                    saveJob.ItemDescription = QAWorxJob.ItemDescription.ToString();

                if (!string.IsNullOrEmpty(QAWorxJob.Division))
                    saveJob.Division = QAWorxJob.Division.ToString();

                saveJob.ClientManagerEID = "";

                ApiClient.ApiCalls.UpdateJob(saveJob.JobId, saveJob);

                saveJob = ApiClient.ApiCalls.ReadJob(saveJob.JobId);
                NewWeldingForm nwf = ApiClient.ApiCalls.ReadNewWeldingForm(saveJob.WeldingActions.FirstOrDefault().NewWeldingForm.NewWeldingFormId);

                nwf.MatrixOutput = null;
                nwf.DrawingNumber = "N/A";
                nwf.ComponentDescription = "N/A";
                nwf.WeldingStandard = "N/A";
                nwf.WeldingCategory = "N/A";
                nwf.MaterialStd = "N/A";
                nwf.MaterialGrd = "N/A";
                nwf.NominalStrength = "N/A";
                nwf.WeldPosition = "N/A";
                nwf.SuggestedProcess = "N/A";
                nwf.JointConfiguration = "N/A";
                nwf.QualityReqs = "N/A";
                nwf.ClientReqs = "N/A";
                nwf.DrawingProvided = false;
                nwf.SymbolsProvided = false;
                nwf.RepairProvided = false;
                nwf.PWHTProvided = false;
                nwf.SpecificationsProvided = false;
                nwf.ProceduresProvided = false;
                nwf.PhotosProvided = false;
                nwf.ParentProvided = false;
                nwf.NDTProvided = false;
                nwf.HistoryProvided = false;
                nwf.CoverCosts = true;
                nwf.WPSReference = "N/A";
                nwf.Date = DateTime.Now;
                nwf.ManagerReviewDate = DateTime.Now;
                nwf.ClientManagerEID = Application.Cookies["EmployeeNumber"];
                nwf.Status = Actions.Complete;

                ApiClient.ApiCalls.UpdateNewWeldingForm(nwf.NewWeldingFormId, nwf);

                nwf = ApiClient.ApiCalls.ReadNewWeldingForm(nwf.NewWeldingFormId);
                TechnicalReview tr = new TechnicalReview(nwf.NewWeldingFormId, nwf);
                OperationalReview or = new OperationalReview(nwf.NewWeldingFormId, nwf);

                tr.Considerations = "N/A";
                tr.ExtraCosts = "N/A";
                tr.Date = DateTime.Now;
                tr.TechnicalReviewerEID = Application.Cookies["EmployeeNumber"];

                or.Date = DateTime.Now;
                or.TrainedStaff = false;
                or.TrainedStaffComments = "N/A";
                or.Facilities = false;
                or.FacilitiesComments = "N/A";
                or.Equipment = false;
                or.EquipmentComments = "N/A";
                or.ThirdParty = false;
                or.ThirdPartyComments = "N/A";
                or.WPS = false;
                or.WPSAmount = cbPopupWPS.Checked ? (short)1 : (short)0;
                or.WPQR = false;
                or.WPQRAmount = cbPopupWPQR.Checked ? (short)1 : (short)0;
                or.Welders = false;
                or.WeldersAmount = (cbPopupWQ.Checked || cbPopupWPQR.Checked) ? (short)1 : (short)0;
                or.SubContractors = false;
                or.SubComments = "N/A";
                or.Storage = false;
                or.StorageComments = "N/A";
                or.PWHT = false;
                or.PWHTComments = "N/A";
                or.GeneralComments = "N/A";
                or.ExtraCosts = "N/A";
                or.OperationalReviewerEID = Application.Cookies["EmployeeNumber"];

                ApiClient.ApiCalls.CreateTechnicalReview(nwf.NewWeldingFormId, tr);
                ApiClient.ApiCalls.CreateOperationalReview(nwf.NewWeldingFormId, or);
            }
            

            ClearFields(true);

            this.Close();
        }

        private void AutoFillFields()
        {
            if (txtPopupJob.Text.Length == 9)
            {
                string jobNo = txtPopupJob.Text.ToString();

                JobDetail QAWorxJob = QAWebApiClient.ApiCalls.Get_JobBasic(jobNo, "Welding Management", "Get Job Basic", Application.Cookies["EmployeeNumber"]);

                if (!string.IsNullOrEmpty(QAWorxJob.Cust))
                    txtPopupClient.Text = QAWorxJob.Cust.ToString();

                if (!string.IsNullOrEmpty(QAWorxJob.Division))
                    txtPopupDivision.Text = QAWorxJob.Division.ToString();

                if (!string.IsNullOrEmpty(QAWorxJob.ClientPo))
                    txtPopupPO.Text = QAWorxJob.ClientPo.ToString();

                if (!string.IsNullOrEmpty(QAWorxJob.ItemDescription))
                    txtPopupTitle.Text = QAWorxJob.ItemDescription.ToString();
            }
        }

        private void ClearFields(bool all = false)
        {
            if (all)
            {
                txtPopupJob.Text = "";
                cbPopupWQ.Checked = false;
                cbPopupWPQR.Checked = false;
                cbPopupWPS.Checked = false;
            }

            txtPopupClient.Text = "";
            txtPopupDivision.Text = "";
            txtPopupPO.Text = "";
            txtPopupTitle.Text = "";
        }
    }
}
