﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ApiClient;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.FileManagement;

namespace WeldingManagement.UserControls.PopupControls
{
    public partial class up_rqFilesView : Wisej.Web.UserPopup
    {
        public up_rqFilesView()
        {
            InitializeComponent();
        }

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null) 
            {
                return;
            }

            WeldingAction wa;

            switch (thisTag.getTagType())
            {
                case TagType.New_Welding_Form:
                    
                    NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);

                    lvDocuments.Items.Clear();

                    foreach (Attachment att in nwf.Attachments)
                    {
                        ListViewItem lvItem = new ListViewItem(new string[] { att.ServerPath.Split('\\').Last(), att.AttachmentType.ToString() });
                        lvItem.Tag = new Tag(att, TagType.Attachment);
                        lvDocuments.Items.Add(lvItem);
                    }

                    lvDocuments.Refresh();

                    break;

                case TagType.WPS:

                    wa = ApiCalls.ReadWeldingAction(((WeldingAction)thisTag.getTagObject()).WeldingActionId);

                    AddDocuments(wa, false);

                    break;

                case TagType.Welding_Action:

                    wa = ApiCalls.ReadWeldingAction(((WeldingAction)thisTag.getTagObject()).WeldingActionId);

                    AddDocuments(wa, true);

                    break;
            }

            UIFormatting.ResizeColumnsFor(lvDocuments);

            pvDocuments.Visible = true;
            pbDocuments.Visible = false;

            tlpPopupDocuments.RowStyles[tlpPopupDocuments.GetCellPosition(pvDocuments).Row].SizeType = SizeType.Percent;
            tlpPopupDocuments.RowStyles[tlpPopupDocuments.GetCellPosition(pvDocuments).Row].Height = 100;

            tlpPopupDocuments.RowStyles[tlpPopupDocuments.GetCellPosition(pbDocuments).Row].SizeType = SizeType.Percent;
            tlpPopupDocuments.RowStyles[tlpPopupDocuments.GetCellPosition(pbDocuments).Row].Height = 0;
        }

        private void lvDocuments_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvDocuments.SelectedIndex < 0)
            {
                return;
            }

            Tag itemTag = (Tag)lvDocuments.Items[lvDocuments.SelectedIndex].Tag;

            if (itemTag.getTagType() == TagType.New_Welding_Form)
            {
                ViewAttachment(itemTag, pbDocuments, pvDocuments, tlpPopupDocuments);
            }
            else
            {
                ViewAttachment((string)itemTag.getTagObject(), pbDocuments, pvDocuments, tlpPopupDocuments);
            }
        }

        private void up_rqFilesView_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Tag == null)
            {
                return;
            }

            Load_Action();
        }

        private void btnPopupCancel_Click(object sender, EventArgs e)
        {
            CleanClose();
        }

        private void btnPopupClose_Click(object sender, EventArgs e)
        {
            CleanClose();
        }

        private void CleanClose()
        {
            this.Tag = null;
            pbDocuments.Image = null;
            pvDocuments.PdfStream = null;
            lvDocuments.Items.Clear();
            lvDocuments.Refresh();
            this.Close();
        }

        private void AddDocuments(WeldingAction wa, bool includeAll)
        {
            List<WPS> wpsList = ApiCalls.ReadWPSs();

            lvDocuments.Items.Clear();

            foreach (WPSNumberList wpsNo in wa.NewWeldingForm.OperationalReview.WPSNumberLists)
            {
                WPS wps = wpsList.First(w => w.WPSNumber == wpsNo.WPSNumber);

                wps.WPQR.Welder_Qualification.WeldingAction.Job.JobNo = wa.Job.JobNo;

                if (wps.Status == Actions.Complete)
                {
                    string wpsPath = TemplateCompiler.CompleteWPS(wps);

                    using (FileStream fStream = new FileStream(wpsPath, FileMode.Open, FileAccess.Read))
                    {
                        var reader = new BinaryReader(fStream);
                        var buffer = reader.ReadBytes((int)fStream.Length);
                        var mem = new MemoryStream(buffer);

                        ListViewItem lvItem = new ListViewItem(new string[] { wpsPath.Split('\\').Last(), AttachmentTypes.Other.ToString() });
                        lvItem.Tag = new Tag(wpsPath, TagType.WPS);
                        lvDocuments.Items.Add(lvItem);
                    }
                }
            }

            if (!includeAll)
            {
                lvDocuments.Refresh();
                return;
            }

            foreach (Welder_Qualification welderQual in wa.Welder_Qualification)
            {
                Welder_Qualification wq = ApiCalls.ReadWelderQualification(welderQual.Welder_QualificationId);

                if (wq.Status == Actions.Complete)
                {
                    string wqPath = TemplateCompiler.CompleteWelderQual(wq);

                    using (FileStream fStream = new FileStream(wqPath, FileMode.Open, FileAccess.Read))
                    {
                        var reader = new BinaryReader(fStream);
                        var buffer = reader.ReadBytes((int)fStream.Length);
                        var mem = new MemoryStream(buffer);

                        ListViewItem lvItem = new ListViewItem(new string[] { wqPath.Split('\\').Last(), AttachmentTypes.Other.ToString() });
                        lvItem.Tag = new Tag(wqPath, TagType.Welder_Qualification);
                        lvDocuments.Items.Add(lvItem);
                    }
                }
            }

            foreach (WPQR wp in wa.WPQRs)
            {
                WPQR wpqr = ApiCalls.ReadWPQR(wp.WPQRId);

                if (wpqr.Status == Actions.Complete)
                {
                    string wpqrPath = TemplateCompiler.CompleteWPQR(wpqr);

                    using (FileStream fStream = new FileStream(wpqrPath, FileMode.Open, FileAccess.Read))
                    {
                        var reader = new BinaryReader(fStream);
                        var buffer = reader.ReadBytes((int)fStream.Length);
                        var mem = new MemoryStream(buffer);

                        ListViewItem lvItem = new ListViewItem(new string[] { wpqrPath.Split('\\').Last(), AttachmentTypes.Other.ToString() });
                        lvItem.Tag = new Tag(wpqrPath, TagType.WPQR);
                        lvDocuments.Items.Add(lvItem);
                    }
                }
            }

            foreach (WPS wp in wa.WPS)
            {
                WPS wps = ApiCalls.ReadWPS(wp.WPSId);

                if (wps.Status == Actions.Complete)
                {
                    string wpsPath = TemplateCompiler.CompleteWPS(wps);

                    using (FileStream fStream = new FileStream(wpsPath, FileMode.Open, FileAccess.Read))
                    {
                        var reader = new BinaryReader(fStream);
                        var buffer = reader.ReadBytes((int)fStream.Length);
                        var mem = new MemoryStream(buffer);

                        ListViewItem lvItem = new ListViewItem(new string[] { wpsPath.Split('\\').Last(), AttachmentTypes.Other.ToString() });
                        lvItem.Tag = new Tag(wpsPath, TagType.WPS);
                        lvDocuments.Items.Add(lvItem);
                    }
                }
            }

            lvDocuments.Refresh();
        }
    }
}
