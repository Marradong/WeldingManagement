﻿namespace WeldingManagement.UserControls.PopupControls
{
    partial class up_wqFileView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel4 = new Wisej.Web.TableLayoutPanel();
            this.lblTitle = new Wisej.Web.Label();
            this.panel1 = new Wisej.Web.Panel();
            this.pvFile = new Wisej.Web.PdfViewer();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.btnPopupClose = new Wisej.Web.Button();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.btnPopupPrint = new Wisej.Web.Button();
            this.btnPopupCancel = new Wisej.Web.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 3);
            this.tableLayoutPanel1.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1200, 600);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.lblTitle, 0, 0);
            this.tableLayoutPanel4.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel4.Margin = new Wisej.Web.Padding(3, 0, 3, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1194, 30);
            this.tableLayoutPanel4.TabIndex = 4;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.lblTitle.CssStyle = "box-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), inset 0px 4px 6px rgba(" +
    "255, 255, 255, 0.2);\r\noverflow: hidden;";
            this.lblTitle.Dock = Wisej.Web.DockStyle.Fill;
            this.lblTitle.Location = new System.Drawing.Point(0, 0);
            this.lblTitle.Margin = new Wisej.Web.Padding(0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(1194, 30);
            this.lblTitle.TabIndex = 6;
            this.lblTitle.Text = "label1";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromName("@window");
            this.panel1.Controls.Add(this.pvFile);
            this.panel1.Dock = Wisej.Web.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 60);
            this.panel1.Margin = new Wisej.Web.Padding(3, 0, 3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1194, 490);
            this.panel1.TabIndex = 3;
            // 
            // pvFile
            // 
            this.pvFile.Dock = Wisej.Web.DockStyle.Fill;
            this.pvFile.Location = new System.Drawing.Point(0, 0);
            this.pvFile.Name = "pvFile";
            this.pvFile.Size = new System.Drawing.Size(1194, 490);
            this.pvFile.TabIndex = 1;
            this.pvFile.Click += new System.EventHandler(this.pvFile_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel3.Controls.Add(this.btnPopupClose, 1, 0);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1194, 24);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // btnPopupClose
            // 
            this.btnPopupClose.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.btnPopupClose.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnPopupClose.Dock = Wisej.Web.DockStyle.Fill;
            this.btnPopupClose.Location = new System.Drawing.Point(1164, 0);
            this.btnPopupClose.Margin = new Wisej.Web.Padding(0);
            this.btnPopupClose.Name = "btnPopupClose";
            this.btnPopupClose.Size = new System.Drawing.Size(30, 24);
            this.btnPopupClose.TabIndex = 1;
            this.btnPopupClose.Text = "x";
            this.btnPopupClose.Click += new System.EventHandler(this.btnPopupClose_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.btnPopupPrint, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnPopupCancel, 2, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 550);
            this.tableLayoutPanel2.Margin = new Wisej.Web.Padding(3, 0, 3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1194, 47);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // btnPopupPrint
            // 
            this.btnPopupPrint.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnPopupPrint.Dock = Wisej.Web.DockStyle.Fill;
            this.btnPopupPrint.Location = new System.Drawing.Point(301, 3);
            this.btnPopupPrint.Name = "btnPopupPrint";
            this.btnPopupPrint.Size = new System.Drawing.Size(292, 41);
            this.btnPopupPrint.TabIndex = 0;
            this.btnPopupPrint.Text = "Print";
            this.btnPopupPrint.Click += new System.EventHandler(this.btnPopupPrint_Click);
            // 
            // btnPopupCancel
            // 
            this.btnPopupCancel.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnPopupCancel.Dock = Wisej.Web.DockStyle.Fill;
            this.btnPopupCancel.Location = new System.Drawing.Point(599, 3);
            this.btnPopupCancel.Name = "btnPopupCancel";
            this.btnPopupCancel.Size = new System.Drawing.Size(292, 41);
            this.btnPopupCancel.TabIndex = 1;
            this.btnPopupCancel.Text = "Close";
            this.btnPopupCancel.Click += new System.EventHandler(this.btnPopupCancel_Click);
            // 
            // up_wqFileView
            // 
            this.AutoHide = false;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.CssStyle = "border-radius: 4px;";
            this.Name = "up_wqFileView";
            this.Size = new System.Drawing.Size(1200, 600);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.Button btnPopupPrint;
        private Wisej.Web.Button btnPopupCancel;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.Button btnPopupClose;
        private Wisej.Web.Panel panel1;
        private Wisej.Web.PdfViewer pvFile;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel4;
        private Wisej.Web.Label lblTitle;
    }
}
