﻿namespace WeldingManagement
{
    partial class up_hmSave
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.label1 = new Wisej.Web.Label();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.btnPopupCancel = new Wisej.Web.Button();
            this.btnPopupDontSave = new Wisej.Web.Button();
            this.btnPopupSave = new Wisej.Web.Button();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.btnPopupClose = new Wisej.Web.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(500, 250);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromName("@window");
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 30);
            this.label1.Margin = new Wisej.Web.Padding(3, 0, 3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(494, 190);
            this.label1.TabIndex = 3;
            this.label1.Text = "WARNING: Any unsaved changes may be lost. \r\nDo you wish to save your changes.";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel3.ColumnCount = 7;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.Controls.Add(this.btnPopupCancel, 5, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnPopupDontSave, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnPopupSave, 1, 0);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 220);
            this.tableLayoutPanel3.Margin = new Wisej.Web.Padding(3, 0, 3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(494, 27);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // btnPopupCancel
            // 
            this.btnPopupCancel.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnPopupCancel.Dock = Wisej.Web.DockStyle.Fill;
            this.btnPopupCancel.Location = new System.Drawing.Point(314, 3);
            this.btnPopupCancel.Name = "btnPopupCancel";
            this.btnPopupCancel.Size = new System.Drawing.Size(83, 21);
            this.btnPopupCancel.TabIndex = 4;
            this.btnPopupCancel.Text = "Cancel";
            this.btnPopupCancel.Click += new System.EventHandler(this.btnPopupCancel_Click);
            // 
            // btnPopupDontSave
            // 
            this.btnPopupDontSave.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnPopupDontSave.Dock = Wisej.Web.DockStyle.Fill;
            this.btnPopupDontSave.Location = new System.Drawing.Point(203, 3);
            this.btnPopupDontSave.Name = "btnPopupDontSave";
            this.btnPopupDontSave.Size = new System.Drawing.Size(83, 21);
            this.btnPopupDontSave.TabIndex = 3;
            this.btnPopupDontSave.Text = "Don\'t Save";
            this.btnPopupDontSave.Click += new System.EventHandler(this.btnPopupDontSave_Click);
            // 
            // btnPopupSave
            // 
            this.btnPopupSave.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnPopupSave.Dock = Wisej.Web.DockStyle.Fill;
            this.btnPopupSave.Location = new System.Drawing.Point(92, 3);
            this.btnPopupSave.Name = "btnPopupSave";
            this.btnPopupSave.Size = new System.Drawing.Size(83, 21);
            this.btnPopupSave.TabIndex = 2;
            this.btnPopupSave.Text = "Save";
            this.btnPopupSave.Click += new System.EventHandler(this.btnPopupSave_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.Controls.Add(this.btnPopupClose, 1, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(494, 24);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // btnPopupClose
            // 
            this.btnPopupClose.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.btnPopupClose.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnPopupClose.Dock = Wisej.Web.DockStyle.Fill;
            this.btnPopupClose.Location = new System.Drawing.Point(464, 0);
            this.btnPopupClose.Margin = new Wisej.Web.Padding(0);
            this.btnPopupClose.Name = "btnPopupClose";
            this.btnPopupClose.Size = new System.Drawing.Size(30, 24);
            this.btnPopupClose.TabIndex = 1;
            this.btnPopupClose.Text = "x";
            this.btnPopupClose.Click += new System.EventHandler(this.btnPopupClose_Click);
            // 
            // up_hmSave
            // 
            this.AutoHide = false;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.CssStyle = "border-radius: 4px;";
            this.Name = "up_hmSave";
            this.Size = new System.Drawing.Size(500, 250);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.Button btnPopupSave;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.Button btnPopupClose;
        private Wisej.Web.Label label1;
        private Wisej.Web.Button btnPopupCancel;
        private Wisej.Web.Button btnPopupDontSave;
    }
}
