﻿using System;
using Wisej.Web;
using static WeldingManagement.Helpers.GenericHelpers;

namespace WeldingManagement
{
    public partial class up_hmSave : UserPopup
    {
        private TriState _ToSave = TriState.Indeterminant;
        
        public TriState ToSave 
        {  
            get 
            { 
                return _ToSave;
            }
        }

        public up_hmSave()
        {
            InitializeComponent();
        }

        private void btnPopupSave_Click(object sender, EventArgs e)
        {
            _ToSave = TriState.True;

            this.Close();
        }

        private void btnPopupDontSave_Click(object sender, EventArgs e)
        {
            _ToSave = TriState.False;

            this.Close();
        }

        private void btnPopupCancel_Click(object sender, EventArgs e)
        {
            _ToSave = TriState.Indeterminant;

            this.Close();
        }

        private void btnPopupClose_Click(object sender, EventArgs e)
        {
            _ToSave = TriState.Indeterminant;

            this.Close();
        }
    }
}
