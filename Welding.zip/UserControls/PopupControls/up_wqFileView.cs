﻿using System;
using System.IO;
using ApiClient;
using Welding.DAL;
using Wisej.Web;
using static WeldingManagement.TemplateCompiler;

namespace WeldingManagement.UserControls.PopupControls
{
    public partial class up_wqFileView : Wisej.Web.UserPopup
    {
        private string _lbl = null;

        public string title
        {
            get
            {
                return _lbl;
            }

            set
            {
                _lbl = value;
                lblTitle.Text = value;
            }
        }

        private string _path = null;

        public string path
        {
            get
            {
                return _path;
            }

            set
            {
                _path = value;
            }
        }

        private Stream _stream = null;

        public Stream pvView_Stream 
        {  
            get 
            { 
                return _stream; 
            }

            set
            {
                _stream = value;
                pvFile.PdfStream = value;
                pvFile.Refresh();
            }
        }

        public up_wqFileView()
        {
            InitializeComponent();
        }

        private void btnPopupClose_Click(object sender, EventArgs e)
        {
            CleanClose();
        }

        private void btnPopupCancel_Click(object sender, EventArgs e)
        {
            CleanClose();
        }

        private void btnPopupPrint_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.path))
            {
                DownloadPDF(this.path);

                CleanClose();
            }
        }

        private void CleanClose()
        {
            this.pvView_Stream = null;
            this.path = null;
            this.title = null;
            this.Close();
        }

        private void pvFile_Click(object sender, EventArgs e)
        {
            // Prevent close
        }
    }
}
