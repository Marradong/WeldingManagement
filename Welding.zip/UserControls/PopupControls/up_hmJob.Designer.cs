﻿namespace WeldingManagement.UserControls.HomeControls
{
    partial class up_hmJob
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel4 = new Wisej.Web.TableLayoutPanel();
            this.cbPopupWPS = new Wisej.Web.CheckBox();
            this.cbPopupWPQR = new Wisej.Web.CheckBox();
            this.cbPopupWQ = new Wisej.Web.CheckBox();
            this.label2 = new Wisej.Web.Label();
            this.txtPopupJob = new Wisej.Web.MaskedTextBox();
            this.txtPopupPO = new Wisej.Web.TextBox();
            this.txtPopupClient = new Wisej.Web.TextBox();
            this.txtPopupDivision = new Wisej.Web.TextBox();
            this.txtPopupTitle = new Wisej.Web.TextBox();
            this.label1 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.label4 = new Wisej.Web.Label();
            this.label5 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.btnPopupSave = new Wisej.Web.Button();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.btnPopupClose = new Wisej.Web.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(600, 349);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel4.ColumnCount = 4;
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 30F));
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 23F));
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 23F));
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 23F));
            this.tableLayoutPanel4.Controls.Add(this.cbPopupWPS, 3, 5);
            this.tableLayoutPanel4.Controls.Add(this.cbPopupWPQR, 2, 5);
            this.tableLayoutPanel4.Controls.Add(this.cbPopupWQ, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.label2, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.txtPopupJob, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.txtPopupPO, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.txtPopupClient, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.txtPopupDivision, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.txtPopupTitle, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label4, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label6, 0, 4);
            this.tableLayoutPanel4.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel4.Margin = new Wisej.Web.Padding(3, 0, 3, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 6;
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(594, 289);
            this.tableLayoutPanel4.TabIndex = 2;
            // 
            // cbPopupWPS
            // 
            this.cbPopupWPS.Appearance = Wisej.Web.Appearance.Switch;
            this.cbPopupWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.cbPopupWPS.Location = new System.Drawing.Point(459, 243);
            this.cbPopupWPS.Name = "cbPopupWPS";
            this.cbPopupWPS.Size = new System.Drawing.Size(132, 43);
            this.cbPopupWPS.TabIndex = 16;
            this.cbPopupWPS.Text = "WPS";
            // 
            // cbPopupWPQR
            // 
            this.cbPopupWPQR.Appearance = Wisej.Web.Appearance.Switch;
            this.cbPopupWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.cbPopupWPQR.Location = new System.Drawing.Point(321, 243);
            this.cbPopupWPQR.Name = "cbPopupWPQR";
            this.cbPopupWPQR.Size = new System.Drawing.Size(132, 43);
            this.cbPopupWPQR.TabIndex = 15;
            this.cbPopupWPQR.Text = "WPQR";
            // 
            // cbPopupWQ
            // 
            this.cbPopupWQ.Appearance = Wisej.Web.Appearance.Switch;
            this.cbPopupWQ.Dock = Wisej.Web.DockStyle.Fill;
            this.cbPopupWQ.Location = new System.Drawing.Point(183, 243);
            this.cbPopupWQ.Name = "cbPopupWQ";
            this.cbPopupWQ.Size = new System.Drawing.Size(132, 43);
            this.cbPopupWQ.TabIndex = 14;
            this.cbPopupWQ.Text = "WQ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 243);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 43);
            this.label2.TabIndex = 13;
            this.label2.Text = "Required Actions";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtPopupJob
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.txtPopupJob, 3);
            this.txtPopupJob.Dock = Wisej.Web.DockStyle.Fill;
            this.txtPopupJob.Location = new System.Drawing.Point(183, 3);
            this.txtPopupJob.Mask = "00000-000";
            this.txtPopupJob.Name = "txtPopupJob";
            this.txtPopupJob.Size = new System.Drawing.Size(408, 42);
            this.txtPopupJob.TabIndex = 12;
            this.txtPopupJob.Click += new System.EventHandler(this.txtPopupJob_Click);
            this.txtPopupJob.TextChanged += new System.EventHandler(this.txtPopupJob_TextChanged);
            this.txtPopupJob.KeyPress += new Wisej.Web.KeyPressEventHandler(this.txtPopupJob_KeyPress);
            // 
            // txtPopupPO
            // 
            this.txtPopupPO.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel4.SetColumnSpan(this.txtPopupPO, 3);
            this.txtPopupPO.Dock = Wisej.Web.DockStyle.Fill;
            this.txtPopupPO.Location = new System.Drawing.Point(183, 195);
            this.txtPopupPO.Name = "txtPopupPO";
            this.txtPopupPO.ReadOnly = true;
            this.txtPopupPO.Size = new System.Drawing.Size(408, 42);
            this.txtPopupPO.TabIndex = 11;
            // 
            // txtPopupClient
            // 
            this.txtPopupClient.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel4.SetColumnSpan(this.txtPopupClient, 3);
            this.txtPopupClient.Dock = Wisej.Web.DockStyle.Fill;
            this.txtPopupClient.Location = new System.Drawing.Point(183, 147);
            this.txtPopupClient.Name = "txtPopupClient";
            this.txtPopupClient.ReadOnly = true;
            this.txtPopupClient.Size = new System.Drawing.Size(408, 42);
            this.txtPopupClient.TabIndex = 10;
            // 
            // txtPopupDivision
            // 
            this.txtPopupDivision.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel4.SetColumnSpan(this.txtPopupDivision, 3);
            this.txtPopupDivision.Dock = Wisej.Web.DockStyle.Fill;
            this.txtPopupDivision.Location = new System.Drawing.Point(183, 99);
            this.txtPopupDivision.Name = "txtPopupDivision";
            this.txtPopupDivision.ReadOnly = true;
            this.txtPopupDivision.Size = new System.Drawing.Size(408, 42);
            this.txtPopupDivision.TabIndex = 9;
            // 
            // txtPopupTitle
            // 
            this.txtPopupTitle.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel4.SetColumnSpan(this.txtPopupTitle, 3);
            this.txtPopupTitle.Dock = Wisej.Web.DockStyle.Fill;
            this.txtPopupTitle.Location = new System.Drawing.Point(183, 51);
            this.txtPopupTitle.Name = "txtPopupTitle";
            this.txtPopupTitle.ReadOnly = true;
            this.txtPopupTitle.Size = new System.Drawing.Size(408, 42);
            this.txtPopupTitle.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Job Number";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = Wisej.Web.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(174, 42);
            this.label3.TabIndex = 2;
            this.label3.Text = "Job Title";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = Wisej.Web.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(3, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(174, 42);
            this.label4.TabIndex = 3;
            this.label4.Text = "Division";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = Wisej.Web.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(3, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(174, 42);
            this.label5.TabIndex = 4;
            this.label5.Text = "Client";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = Wisej.Web.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(3, 195);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(174, 42);
            this.label6.TabIndex = 5;
            this.label6.Text = "PO Number";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.btnPopupSave, 1, 0);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 319);
            this.tableLayoutPanel3.Margin = new Wisej.Web.Padding(3, 0, 3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(594, 27);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // btnPopupSave
            // 
            this.btnPopupSave.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnPopupSave.Dock = Wisej.Web.DockStyle.Fill;
            this.btnPopupSave.Location = new System.Drawing.Point(240, 3);
            this.btnPopupSave.Name = "btnPopupSave";
            this.btnPopupSave.Size = new System.Drawing.Size(112, 21);
            this.btnPopupSave.TabIndex = 2;
            this.btnPopupSave.Text = "Add Job";
            this.btnPopupSave.Click += new System.EventHandler(this.btnPopupSave_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.Controls.Add(this.btnPopupClose, 1, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(594, 24);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // btnPopupClose
            // 
            this.btnPopupClose.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.btnPopupClose.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnPopupClose.Dock = Wisej.Web.DockStyle.Fill;
            this.btnPopupClose.Location = new System.Drawing.Point(564, 0);
            this.btnPopupClose.Margin = new Wisej.Web.Padding(0);
            this.btnPopupClose.Name = "btnPopupClose";
            this.btnPopupClose.Size = new System.Drawing.Size(30, 24);
            this.btnPopupClose.TabIndex = 1;
            this.btnPopupClose.Text = "x";
            this.btnPopupClose.Click += new System.EventHandler(this.btnPopupClose_Click);
            // 
            // up_hmJob
            // 
            this.AutoHide = false;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.Controls.Add(this.tableLayoutPanel1);
            this.CssStyle = "border-radius: 4px;\r\n";
            this.Name = "up_hmJob";
            this.Size = new System.Drawing.Size(600, 349);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel4;
        private Wisej.Web.Label label1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.Button btnPopupSave;
        private Wisej.Web.Button btnPopupClose;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label5;
        private Wisej.Web.Label label6;
        private Wisej.Web.TextBox txtPopupPO;
        private Wisej.Web.TextBox txtPopupClient;
        private Wisej.Web.TextBox txtPopupDivision;
        private Wisej.Web.TextBox txtPopupTitle;
        private Wisej.Web.MaskedTextBox txtPopupJob;
        private Wisej.Web.CheckBox cbPopupWPS;
        private Wisej.Web.CheckBox cbPopupWPQR;
        private Wisej.Web.CheckBox cbPopupWQ;
        private Wisej.Web.Label label2;
    }
}
