﻿using ApiClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Welding.DAL;
using Wisej.Web;

namespace WeldingManagement.UserControls.NDTControls
{
    public partial class uc_ndtEntry : Wisej.Web.UserControl
    {
        public uc_ndtEntry()
        {
            InitializeComponent();

            dtpEntryDate.Value = DateTime.Now;
        }

        #region Navigation
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on entry screen")]
        public event EventHandler btnEntrySubmitClick;
        private void btnEntrySubmit_Click(object sender, EventArgs e)
        {
            btnEntrySubmitClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on entry screen")]
        public event EventHandler btnEntryBackClick;
        private void btnEntryBack_Click(object sender, EventArgs e)
        {
            btnEntryBackClick?.Invoke(this, e);
        }
        #endregion
        
        private void Load_Action()
        {
            string[] eNumbers = QAWebApiClient.ApiCalls.GetPeople().Select(ppl => ppl.EmployeeNumber).ToArray();

            cboEntryWelder.Items.Clear();
            cboEntryWelder.Items.AddRange(eNumbers);
            cboEntryWelder.Refresh();

            object[] wpss = ApiClient.ApiCalls.ReadWPSs().Select(wps => new Tag(wps, TagType.WPS, wps.WPSNumber)).ToArray();
            mscboEntryWPS.Set_InputDataList(wpss);
            mscboEntryWPS.ClearSelection();

            cboEntryType.DataSource = Enum.GetValues(typeof(NDTTestType));
            cboEntryType.Refresh();

            lvEntryQuals.Items.Clear();
            lvEntryQuals.Refresh();

            UIFormatting.ResizeColumnsFor(lvEntryQuals);
        }

        private void btnEntryAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(mscboEntryWPS.ToString()) ||
                cboEntryWelder.SelectedItem == null ||
                string.IsNullOrEmpty(dtpEntryDate.Text) ||
                string.IsNullOrEmpty(txtEntryReport.Text) ||
                string.IsNullOrEmpty(cboEntryType.Text) ||
                string.IsNullOrEmpty(txtEntryPNo.Text))
            {
                return;
            }

            List<WPS> wpsList = (mscboEntryWPS.Get_OuputDataList().OfType<Tag>().ToArray()).Select(tag => (WPS)tag.getTagObject()).ToList();

            foreach (WPS wps in wpsList)
            {
                NDT_Record newNDT = new NDT_Record(wps)
                {
                    WelderEID = cboEntryWelder.SelectedItem.ToString(),
                    WeldersName = QAWebApiClient.ApiCalls.GetPerson(cboEntryWelder.SelectedItem.ToString()).EmployeeName ?? "",
                    ReportNumber = txtEntryReport.Text,
                    TestType = (NDTTestType)cboEntryType.SelectedItem,
                    PNumber = txtEntryPNo.Text,
                    TestDate = dtpEntryDate.Value,
                    ExpiryDate = dtpEntryDate.Value.AddMonths(6),
                    WPSNumber = wps.WPSNumber
                };

                newNDT = ApiCalls.CreateNDTRecord(wps.WPSId, newNDT);

                ListViewItem newQual = new ListViewItem(new[]
                    {
                        newNDT.WelderEID.ToString(),
                        newNDT.WPS.WPSNumber.ToString(),
                        newNDT.TestDate?.ToString("dd/MM/yyyy"),
                        newNDT.ReportNumber,
                        newNDT.TestType.ToString(),
                        newNDT.PNumber
                    }
                );

                newQual.Tag = new Tag(newNDT, TagType.NDT);

                lvEntryQuals.Items.Add(newQual);
            }

            lvEntryQuals.Refresh();

            cboEntryWelder.SelectedItem = null;
            mscboEntryWPS.Set_OuputDataList(new List<object>());
            dtpEntryDate.Value = DateTime.Now;
            txtEntryReport.Clear();
            cboEntryType.SelectedItem = null;
            txtEntryPNo.Clear();
        }

        private void txtEntryPNo_MouseDown(object sender, MouseEventArgs e)
        {
            txtEntryPNo.SelectionStart = 1;
        }

        private void uc_ndtEntry_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible && this.Dock == DockStyle.Fill)
            {
                Load_Action();
            }
        }

        private void lvEntryQuals_Resize(object sender, EventArgs e)
        {
            if (this.Visible && this.Dock == DockStyle.Fill)
            {
                UIFormatting.ResizeColumnsFor(lvEntryQuals);
            } 
        }

        private void lvEntryQuals_ItemDoubleClick(object sender, ItemClickEventArgs e)
        {
            if (lvEntryQuals.SelectedItems.Count <= 0)
            {
                return;
            }

            if (lvEntryQuals.SelectedItems[0] == null)
            {
                return;
            }

            Tag selectedTag = (Tag)lvEntryQuals.SelectedItems[0].Tag;

            if (selectedTag == null || selectedTag.getTagType() != TagType.NDT)
            {
                return;
            }

            NDT_Record selectedNDT = ApiCalls.ReadNDTRecord(((NDT_Record)selectedTag.getTagObject()).NDT_RecordId);

            if (cboEntryWelder.Items.Contains(selectedNDT.WelderEID))
            {
                cboEntryWelder.SelectedItem = selectedNDT.WelderEID;
            }
            
            mscboEntryWPS.Set_OuputDataList(new List<object>() { new Tag(selectedNDT.WPS, TagType.WPS, selectedNDT.WPS.WPSNumber) });

            dtpEntryDate.Value = selectedNDT.TestDate ?? DateTime.Now;
            txtEntryReport.Text = selectedNDT.ReportNumber;

            if (cboEntryType.Items.Contains(selectedNDT.TestType))
            {
                cboEntryType.SelectedItem = selectedNDT.TestType;
            }
            
            txtEntryPNo.Text = selectedNDT.PNumber;
        }

        private void btnEntryDelete_Click(object sender, EventArgs e)
        {
            if (lvEntryQuals.SelectedItems.Count <= 0)
            {
                return;
            }

            if (lvEntryQuals.SelectedItems[0] == null)
            {
                return;
            }

            Tag selectedTag = (Tag)lvEntryQuals.SelectedItems[0].Tag;

            if (selectedTag == null || selectedTag.getTagType() != TagType.NDT)
            {
                return;
            }

            NDT_Record ndtToDelete = ApiCalls.ReadNDTRecord(((NDT_Record)selectedTag.getTagObject()).NDT_RecordId);

            ApiCalls.DeleteNDTRecord(ndtToDelete.NDT_RecordId);

            lvEntryQuals.Items.Remove(lvEntryQuals.SelectedItems[0]);
            lvEntryQuals.Refresh();
        }

        private void lblEntryNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }
    }
}
