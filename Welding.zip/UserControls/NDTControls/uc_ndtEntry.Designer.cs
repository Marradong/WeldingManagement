﻿namespace WeldingManagement.UserControls.NDTControls
{
    partial class uc_ndtEntry
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_ndtEntry));
            this.tableLayoutPanel20 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel21 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel23 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel31 = new Wisej.Web.TableLayoutPanel();
            this.btnEntryDelete = new Wisej.Web.Button();
            this.btnEntryBack = new Wisej.Web.Button();
            this.btnEntryAdd = new Wisej.Web.Button();
            this.btnEntrySubmit = new Wisej.Web.Button();
            this.tableLayoutPanel22 = new Wisej.Web.TableLayoutPanel();
            this.cboEntryWelder = new Wisej.Web.ComboBox();
            this.mscboEntryWPS = new WeldingManagement.UserControls.MultiSelectComboBox();
            this.txtEntryPNo = new Wisej.Web.MaskedTextBox();
            this.cboEntryType = new Wisej.Web.ComboBox();
            this.dtpEntryDate = new Wisej.Web.DateTimePicker();
            this.lvEntryQuals = new Wisej.Web.ListView();
            this.chID = new Wisej.Web.ColumnHeader();
            this.chWPS = new Wisej.Web.ColumnHeader();
            this.chDate = new Wisej.Web.ColumnHeader();
            this.chReport = new Wisej.Web.ColumnHeader();
            this.chType = new Wisej.Web.ColumnHeader();
            this.chPNo = new Wisej.Web.ColumnHeader();
            this.txtEntryReport = new Wisej.Web.TextBox();
            this.label71 = new Wisej.Web.Label();
            this.label72 = new Wisej.Web.Label();
            this.label73 = new Wisej.Web.Label();
            this.label74 = new Wisej.Web.Label();
            this.label75 = new Wisej.Web.Label();
            this.label76 = new Wisej.Web.Label();
            this.tableLayoutPanel24 = new Wisej.Web.TableLayoutPanel();
            this.label78 = new Wisej.Web.Label();
            this.lblEntryNote = new Wisej.Web.LinkLabel();
            this.tableLayoutPanel20.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel20.ColumnCount = 3;
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel20.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel21, 1, 3);
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel24, 1, 1);
            this.tableLayoutPanel20.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 5;
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel20.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel20.TabIndex = 4;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel21.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel23, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel22, 0, 0);
            this.tableLayoutPanel21.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel21.TabIndex = 1;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 1;
            this.tableLayoutPanel23.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Controls.Add(this.tableLayoutPanel31, 0, 0);
            this.tableLayoutPanel23.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel23.TabIndex = 5;
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel31.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel31.ColumnCount = 1;
            this.tableLayoutPanel31.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel31.Controls.Add(this.btnEntryDelete, 0, 0);
            this.tableLayoutPanel31.Controls.Add(this.btnEntryBack, 0, 3);
            this.tableLayoutPanel31.Controls.Add(this.btnEntryAdd, 0, 1);
            this.tableLayoutPanel31.Controls.Add(this.btnEntrySubmit, 0, 4);
            this.tableLayoutPanel31.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel31.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel31.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 5;
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel31.TabIndex = 4;
            // 
            // btnEntryDelete
            // 
            this.btnEntryDelete.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnEntryDelete.Dock = Wisej.Web.DockStyle.Fill;
            this.btnEntryDelete.Location = new System.Drawing.Point(3, 3);
            this.btnEntryDelete.Name = "btnEntryDelete";
            this.btnEntryDelete.Size = new System.Drawing.Size(95, 79);
            this.btnEntryDelete.TabIndex = 4;
            this.btnEntryDelete.Text = "Delete";
            this.btnEntryDelete.Click += new System.EventHandler(this.btnEntryDelete_Click);
            // 
            // btnEntryBack
            // 
            this.btnEntryBack.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnEntryBack.Dock = Wisej.Web.DockStyle.Fill;
            this.btnEntryBack.Location = new System.Drawing.Point(3, 258);
            this.btnEntryBack.Name = "btnEntryBack";
            this.btnEntryBack.Size = new System.Drawing.Size(95, 79);
            this.btnEntryBack.TabIndex = 3;
            this.btnEntryBack.Text = "Back";
            this.btnEntryBack.Click += new System.EventHandler(this.btnEntryBack_Click);
            // 
            // btnEntryAdd
            // 
            this.btnEntryAdd.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnEntryAdd.Dock = Wisej.Web.DockStyle.Fill;
            this.btnEntryAdd.Location = new System.Drawing.Point(3, 88);
            this.btnEntryAdd.Name = "btnEntryAdd";
            this.btnEntryAdd.Size = new System.Drawing.Size(95, 79);
            this.btnEntryAdd.TabIndex = 2;
            this.btnEntryAdd.Text = "Add Row";
            this.btnEntryAdd.Click += new System.EventHandler(this.btnEntryAdd_Click);
            // 
            // btnEntrySubmit
            // 
            this.btnEntrySubmit.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnEntrySubmit.Dock = Wisej.Web.DockStyle.Fill;
            this.btnEntrySubmit.Location = new System.Drawing.Point(3, 343);
            this.btnEntrySubmit.Name = "btnEntrySubmit";
            this.btnEntrySubmit.Size = new System.Drawing.Size(95, 79);
            this.btnEntrySubmit.TabIndex = 1;
            this.btnEntrySubmit.Text = "Submit";
            this.btnEntrySubmit.Click += new System.EventHandler(this.btnEntrySubmit_Click);
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 6;
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.Controls.Add(this.cboEntryWelder, 0, 1);
            this.tableLayoutPanel22.Controls.Add(this.mscboEntryWPS, 1, 1);
            this.tableLayoutPanel22.Controls.Add(this.txtEntryPNo, 5, 1);
            this.tableLayoutPanel22.Controls.Add(this.cboEntryType, 4, 1);
            this.tableLayoutPanel22.Controls.Add(this.dtpEntryDate, 2, 1);
            this.tableLayoutPanel22.Controls.Add(this.lvEntryQuals, 0, 2);
            this.tableLayoutPanel22.Controls.Add(this.txtEntryReport, 3, 1);
            this.tableLayoutPanel22.Controls.Add(this.label71, 5, 0);
            this.tableLayoutPanel22.Controls.Add(this.label72, 4, 0);
            this.tableLayoutPanel22.Controls.Add(this.label73, 3, 0);
            this.tableLayoutPanel22.Controls.Add(this.label74, 2, 0);
            this.tableLayoutPanel22.Controls.Add(this.label75, 1, 0);
            this.tableLayoutPanel22.Controls.Add(this.label76, 0, 0);
            this.tableLayoutPanel22.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 3;
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 60F));
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(1024, 433);
            this.tableLayoutPanel22.TabIndex = 4;
            // 
            // cboEntryWelder
            // 
            this.cboEntryWelder.AutoCompleteMode = Wisej.Web.AutoCompleteMode.Filter;
            this.cboEntryWelder.Dock = Wisej.Web.DockStyle.Fill;
            this.cboEntryWelder.Location = new System.Drawing.Point(3, 51);
            this.cboEntryWelder.Name = "cboEntryWelder";
            this.cboEntryWelder.Size = new System.Drawing.Size(164, 90);
            this.cboEntryWelder.Sorted = true;
            this.cboEntryWelder.TabIndex = 87;
            // 
            // mscboEntryWPS
            // 
            this.mscboEntryWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.mscboEntryWPS.Location = new System.Drawing.Point(173, 51);
            this.mscboEntryWPS.Name = "mscboEntryWPS";
            this.mscboEntryWPS.Size = new System.Drawing.Size(164, 90);
            this.mscboEntryWPS.TabIndex = 86;
            // 
            // txtEntryPNo
            // 
            this.txtEntryPNo.Dock = Wisej.Web.DockStyle.Fill;
            this.txtEntryPNo.Location = new System.Drawing.Point(853, 51);
            this.txtEntryPNo.Mask = "P000000";
            this.txtEntryPNo.Name = "txtEntryPNo";
            this.txtEntryPNo.Size = new System.Drawing.Size(168, 90);
            this.txtEntryPNo.TabIndex = 36;
            this.txtEntryPNo.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            this.txtEntryPNo.MouseDown += new Wisej.Web.MouseEventHandler(this.txtEntryPNo_MouseDown);
            // 
            // cboEntryType
            // 
            this.cboEntryType.Dock = Wisej.Web.DockStyle.Fill;
            this.cboEntryType.Location = new System.Drawing.Point(683, 51);
            this.cboEntryType.Name = "cboEntryType";
            this.cboEntryType.Size = new System.Drawing.Size(164, 90);
            this.cboEntryType.TabIndex = 32;
            // 
            // dtpEntryDate
            // 
            this.dtpEntryDate.Dock = Wisej.Web.DockStyle.Fill;
            this.dtpEntryDate.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpEntryDate.Location = new System.Drawing.Point(343, 51);
            this.dtpEntryDate.Name = "dtpEntryDate";
            this.dtpEntryDate.Size = new System.Drawing.Size(164, 90);
            this.dtpEntryDate.TabIndex = 31;
            this.dtpEntryDate.Value = new System.DateTime(2024, 8, 2, 0, 0, 0, 0);
            // 
            // lvEntryQuals
            // 
            this.lvEntryQuals.Columns.AddRange(new Wisej.Web.ColumnHeader[] {
            this.chID,
            this.chWPS,
            this.chDate,
            this.chReport,
            this.chType,
            this.chPNo});
            this.tableLayoutPanel22.SetColumnSpan(this.lvEntryQuals, 6);
            this.lvEntryQuals.Dock = Wisej.Web.DockStyle.Fill;
            this.lvEntryQuals.Location = new System.Drawing.Point(3, 147);
            this.lvEntryQuals.Name = "lvEntryQuals";
            this.lvEntryQuals.Size = new System.Drawing.Size(1018, 283);
            this.lvEntryQuals.TabIndex = 28;
            this.lvEntryQuals.View = Wisej.Web.View.Details;
            this.lvEntryQuals.ItemDoubleClick += new Wisej.Web.ItemClickEventHandler(this.lvEntryQuals_ItemDoubleClick);
            this.lvEntryQuals.Resize += new System.EventHandler(this.lvEntryQuals_Resize);
            // 
            // chID
            // 
            this.chID.Name = "chID";
            this.chID.Text = "Welder ID";
            this.chID.Width = 150;
            // 
            // chWPS
            // 
            this.chWPS.Name = "chWPS";
            this.chWPS.Text = "WPS";
            this.chWPS.Width = 150;
            // 
            // chDate
            // 
            this.chDate.Name = "chDate";
            this.chDate.Text = "Date";
            this.chDate.Width = 150;
            // 
            // chReport
            // 
            this.chReport.Name = "chReport";
            this.chReport.Text = "Report Number";
            this.chReport.Width = 150;
            // 
            // chType
            // 
            this.chType.Name = "chType";
            this.chType.Text = "Test Type";
            this.chType.Width = 150;
            // 
            // chPNo
            // 
            this.chPNo.Name = "chPNo";
            this.chPNo.Text = "P Number";
            this.chPNo.Width = 150;
            // 
            // txtEntryReport
            // 
            this.txtEntryReport.Dock = Wisej.Web.DockStyle.Fill;
            this.txtEntryReport.Location = new System.Drawing.Point(513, 51);
            this.txtEntryReport.Name = "txtEntryReport";
            this.txtEntryReport.Size = new System.Drawing.Size(164, 90);
            this.txtEntryReport.TabIndex = 17;
            this.txtEntryReport.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label71.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label71.Dock = Wisej.Web.DockStyle.Fill;
            this.label71.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label71.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label71.Location = new System.Drawing.Point(853, 3);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(168, 42);
            this.label71.TabIndex = 5;
            this.label71.Text = "QAWorx P Number";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label72.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label72.Dock = Wisej.Web.DockStyle.Fill;
            this.label72.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label72.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label72.Location = new System.Drawing.Point(683, 3);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(164, 42);
            this.label72.TabIndex = 4;
            this.label72.Text = "Test Type";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label73.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label73.Dock = Wisej.Web.DockStyle.Fill;
            this.label73.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label73.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label73.Location = new System.Drawing.Point(513, 3);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(164, 42);
            this.label73.TabIndex = 3;
            this.label73.Text = "Report Number";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label74.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label74.Dock = Wisej.Web.DockStyle.Fill;
            this.label74.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label74.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label74.Location = new System.Drawing.Point(343, 3);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(164, 42);
            this.label74.TabIndex = 2;
            this.label74.Text = "Date";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label75.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label75.Dock = Wisej.Web.DockStyle.Fill;
            this.label75.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label75.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label75.Location = new System.Drawing.Point(173, 3);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(164, 42);
            this.label75.TabIndex = 1;
            this.label75.Text = "WPS Number";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.FromName("@highlight");
            this.label76.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label76.Dock = Wisej.Web.DockStyle.Fill;
            this.label76.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label76.ForeColor = System.Drawing.Color.FromName("@buttonText");
            this.label76.Location = new System.Drawing.Point(3, 3);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(164, 42);
            this.label76.TabIndex = 0;
            this.label76.Text = "Welder ID";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 1;
            this.tableLayoutPanel24.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel24.Controls.Add(this.lblEntryNote, 0, 1);
            this.tableLayoutPanel24.Controls.Add(this.label78, 0, 0);
            this.tableLayoutPanel24.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 2;
            this.tableLayoutPanel24.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel24.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel24.TabIndex = 0;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.label78.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label78.CssStyle = "border-radius: 4px;";
            this.label78.Dock = Wisej.Web.DockStyle.Fill;
            this.label78.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label78.Location = new System.Drawing.Point(6, 3);
            this.label78.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(1133, 70);
            this.label78.TabIndex = 0;
            this.label78.Text = "Welding Test Datasheet Parameters";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEntryNote
            // 
            this.lblEntryNote.AutoSize = true;
            this.lblEntryNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblEntryNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblEntryNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblEntryNote.LinkArea = new Wisej.Web.LinkArea(363, 84);
            this.lblEntryNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblEntryNote.Location = new System.Drawing.Point(6, 79);
            this.lblEntryNote.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.lblEntryNote.Name = "lblEntryNote";
            this.lblEntryNote.Size = new System.Drawing.Size(1133, 35);
            this.lblEntryNote.TabIndex = 3;
            this.lblEntryNote.Text = resources.GetString("lblEntryNote.Text");
            this.lblEntryNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblEntryNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblEntryNote_LinkClicked);
            // 
            // uc_ndtEntry
            // 
            this.Controls.Add(this.tableLayoutPanel20);
            this.Name = "uc_ndtEntry";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_ndtEntry_VisibleChanged);
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel31.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel22.PerformLayout();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel24.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel20;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel21;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel23;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel31;
        private Wisej.Web.Button btnEntryBack;
        private Wisej.Web.Button btnEntryAdd;
        private Wisej.Web.Button btnEntrySubmit;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel22;
        private Wisej.Web.MaskedTextBox txtEntryPNo;
        private Wisej.Web.ComboBox cboEntryType;
        private Wisej.Web.DateTimePicker dtpEntryDate;
        private Wisej.Web.ListView lvEntryQuals;
        private Wisej.Web.ColumnHeader chID;
        private Wisej.Web.ColumnHeader chWPS;
        private Wisej.Web.ColumnHeader chDate;
        private Wisej.Web.ColumnHeader chReport;
        private Wisej.Web.ColumnHeader chType;
        private Wisej.Web.ColumnHeader chPNo;
        private Wisej.Web.TextBox txtEntryReport;
        private Wisej.Web.Label label71;
        private Wisej.Web.Label label72;
        private Wisej.Web.Label label73;
        private Wisej.Web.Label label74;
        private Wisej.Web.Label label75;
        private Wisej.Web.Label label76;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel24;
        private Wisej.Web.Label label78;
        private MultiSelectComboBox mscboEntryWPS;
        private Wisej.Web.ComboBox cboEntryWelder;
        private Wisej.Web.Button btnEntryDelete;
        private Wisej.Web.LinkLabel lblEntryNote;
    }
}
