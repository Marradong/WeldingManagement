﻿
namespace ToolTrack
{
    partial class LoginNumPad
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.label1 = new Wisej.Web.Label();
            this.TxtPassword = new Wisej.Web.MaskedTextBox();
            this.NumBack = new Wisej.Web.Button();
            this.Num9 = new Wisej.Web.Button();
            this.Num6 = new Wisej.Web.Button();
            this.Num3 = new Wisej.Web.Button();
            this.Num0 = new Wisej.Web.Button();
            this.Num8 = new Wisej.Web.Button();
            this.Num5 = new Wisej.Web.Button();
            this.Num2 = new Wisej.Web.Button();
            this.NumClear = new Wisej.Web.Button();
            this.Num7 = new Wisej.Web.Button();
            this.Num4 = new Wisej.Web.Button();
            this.Num1 = new Wisej.Web.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromName("@a4");
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 8F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 27F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 1.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 27F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 1.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 27F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 8F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.TxtPassword, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.NumBack, 5, 9);
            this.tableLayoutPanel1.Controls.Add(this.Num9, 5, 7);
            this.tableLayoutPanel1.Controls.Add(this.Num6, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.Num3, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.Num0, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.Num8, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.Num5, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.Num2, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.NumClear, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.Num7, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.Num4, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.Num1, 1, 3);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 18F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 1F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 18F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 1F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 18F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 1F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 18F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 1F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 18F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(424, 635);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.TabStop = true;
            // 
            // label1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.label1, 5);
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(36, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(348, 26);
            this.label1.TabIndex = 13;
            this.label1.Text = "EMP ID  -  DOB";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TxtPassword
            // 
            this.TxtPassword.AutoSize = false;
            this.TxtPassword.BackColor = System.Drawing.Color.FromName("@a5");
            this.TxtPassword.BorderStyle = Wisej.Web.BorderStyle.None;
            this.tableLayoutPanel1.SetColumnSpan(this.TxtPassword, 5);
            this.TxtPassword.CssStyle = "border-radius: 8px;\r\nbox-shadow: 2px 4px 6px rgba(0, 0, 0, 0.15);";
            this.TxtPassword.Dock = Wisej.Web.DockStyle.Fill;
            this.TxtPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtPassword.Location = new System.Drawing.Point(36, 35);
            this.TxtPassword.Mask = "0000 - 00/00/00";
            this.TxtPassword.MaxLength = 10;
            this.TxtPassword.Name = "TxtPassword";
            this.TxtPassword.ReadOnly = true;
            this.TxtPassword.RejectInputOnFirstFailure = true;
            this.TxtPassword.Size = new System.Drawing.Size(348, 109);
            this.TxtPassword.TabIndex = 0;
            this.TxtPassword.TextAlign = Wisej.Web.HorizontalAlignment.Center;
            this.TxtPassword.KeyDown += new Wisej.Web.KeyEventHandler(this.TxtPassword_KeyDown);
            this.TxtPassword.KeyPress += new Wisej.Web.KeyPressEventHandler(this.TxtPassword_KeyPress);
            // 
            // NumBack
            // 
            this.NumBack.Dock = Wisej.Web.DockStyle.Fill;
            this.NumBack.Focusable = false;
            this.NumBack.Font = new System.Drawing.Font("default", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NumBack.ImageSource = "icon-undo";
            this.NumBack.Location = new System.Drawing.Point(281, 524);
            this.NumBack.Margin = new Wisej.Web.Padding(8);
            this.NumBack.Name = "NumBack";
            this.NumBack.Size = new System.Drawing.Size(98, 103);
            this.NumBack.TabIndex = 12;
            this.NumBack.Text = "BACK";
            this.NumBack.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.NumBack.TextImageRelation = Wisej.Web.TextImageRelation.ImageAboveText;
            // 
            // Num9
            // 
            this.Num9.Dock = Wisej.Web.DockStyle.Fill;
            this.Num9.Focusable = false;
            this.Num9.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Num9.Location = new System.Drawing.Point(281, 403);
            this.Num9.Margin = new Wisej.Web.Padding(8);
            this.Num9.Name = "Num9";
            this.Num9.Size = new System.Drawing.Size(98, 99);
            this.Num9.TabIndex = 9;
            this.Num9.Text = "9";
            // 
            // Num6
            // 
            this.Num6.Dock = Wisej.Web.DockStyle.Fill;
            this.Num6.Focusable = false;
            this.Num6.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Num6.Location = new System.Drawing.Point(281, 282);
            this.Num6.Margin = new Wisej.Web.Padding(8);
            this.Num6.Name = "Num6";
            this.Num6.Size = new System.Drawing.Size(98, 99);
            this.Num6.TabIndex = 6;
            this.Num6.Text = "6";
            // 
            // Num3
            // 
            this.Num3.Dock = Wisej.Web.DockStyle.Fill;
            this.Num3.Focusable = false;
            this.Num3.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Num3.Location = new System.Drawing.Point(281, 161);
            this.Num3.Margin = new Wisej.Web.Padding(8);
            this.Num3.Name = "Num3";
            this.Num3.Size = new System.Drawing.Size(98, 99);
            this.Num3.TabIndex = 3;
            this.Num3.Text = "3";
            // 
            // Num0
            // 
            this.Num0.Dock = Wisej.Web.DockStyle.Fill;
            this.Num0.Focusable = false;
            this.Num0.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Num0.Location = new System.Drawing.Point(161, 524);
            this.Num0.Margin = new Wisej.Web.Padding(8);
            this.Num0.Name = "Num0";
            this.Num0.Size = new System.Drawing.Size(98, 103);
            this.Num0.TabIndex = 11;
            this.Num0.Text = "0";
            // 
            // Num8
            // 
            this.Num8.Dock = Wisej.Web.DockStyle.Fill;
            this.Num8.Focusable = false;
            this.Num8.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Num8.Location = new System.Drawing.Point(161, 403);
            this.Num8.Margin = new Wisej.Web.Padding(8);
            this.Num8.Name = "Num8";
            this.Num8.Size = new System.Drawing.Size(98, 99);
            this.Num8.TabIndex = 8;
            this.Num8.Text = "8";
            // 
            // Num5
            // 
            this.Num5.Dock = Wisej.Web.DockStyle.Fill;
            this.Num5.Focusable = false;
            this.Num5.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Num5.Location = new System.Drawing.Point(161, 282);
            this.Num5.Margin = new Wisej.Web.Padding(8);
            this.Num5.Name = "Num5";
            this.Num5.Size = new System.Drawing.Size(98, 99);
            this.Num5.TabIndex = 5;
            this.Num5.Text = "5";
            // 
            // Num2
            // 
            this.Num2.Dock = Wisej.Web.DockStyle.Fill;
            this.Num2.Focusable = false;
            this.Num2.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Num2.Location = new System.Drawing.Point(161, 161);
            this.Num2.Margin = new Wisej.Web.Padding(8);
            this.Num2.Name = "Num2";
            this.Num2.Size = new System.Drawing.Size(98, 99);
            this.Num2.TabIndex = 2;
            this.Num2.Text = "2";
            // 
            // NumClear
            // 
            this.NumClear.Dock = Wisej.Web.DockStyle.Fill;
            this.NumClear.Focusable = false;
            this.NumClear.Font = new System.Drawing.Font("default", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NumClear.ImageSource = "icon-refresh";
            this.NumClear.Location = new System.Drawing.Point(41, 524);
            this.NumClear.Margin = new Wisej.Web.Padding(8);
            this.NumClear.Name = "NumClear";
            this.NumClear.Size = new System.Drawing.Size(98, 103);
            this.NumClear.TabIndex = 10;
            this.NumClear.Text = "CLEAR";
            this.NumClear.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.NumClear.TextImageRelation = Wisej.Web.TextImageRelation.ImageAboveText;
            // 
            // Num7
            // 
            this.Num7.Dock = Wisej.Web.DockStyle.Fill;
            this.Num7.Focusable = false;
            this.Num7.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Num7.Location = new System.Drawing.Point(41, 403);
            this.Num7.Margin = new Wisej.Web.Padding(8);
            this.Num7.Name = "Num7";
            this.Num7.Size = new System.Drawing.Size(98, 99);
            this.Num7.TabIndex = 7;
            this.Num7.Text = "7";
            // 
            // Num4
            // 
            this.Num4.Dock = Wisej.Web.DockStyle.Fill;
            this.Num4.Focusable = false;
            this.Num4.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Num4.Location = new System.Drawing.Point(41, 282);
            this.Num4.Margin = new Wisej.Web.Padding(8);
            this.Num4.Name = "Num4";
            this.Num4.Size = new System.Drawing.Size(98, 99);
            this.Num4.TabIndex = 4;
            this.Num4.Text = "4";
            // 
            // Num1
            // 
            this.Num1.Dock = Wisej.Web.DockStyle.Fill;
            this.Num1.Focusable = false;
            this.Num1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Num1.Location = new System.Drawing.Point(41, 161);
            this.Num1.Margin = new Wisej.Web.Padding(8);
            this.Num1.Name = "Num1";
            this.Num1.Size = new System.Drawing.Size(98, 99);
            this.Num1.TabIndex = 1;
            this.Num1.Text = "1";
            // 
            // LoginNumPad
            // 
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromName("@table-row-background-odd");
            this.Controls.Add(this.tableLayoutPanel1);
            this.CssStyle = "overflow: hidden; \r\nborder-radius: 16px;\r\nbox-shadow: 2px 4px 6px rgba(0, 0, 0, 0" +
    ".15);";
            this.KeyPreview = true;
            this.Name = "LoginNumPad";
            this.Size = new System.Drawing.Size(424, 635);
            this.Load += new System.EventHandler(this.NumPad_Load);
            this.KeyPress += new Wisej.Web.KeyPressEventHandler(this.FrmMain_KeyPress);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.Button NumBack;
        private Wisej.Web.Button Num9;
        private Wisej.Web.Button Num6;
        private Wisej.Web.Button Num3;
        private Wisej.Web.Button Num0;
        private Wisej.Web.Button Num8;
        private Wisej.Web.Button Num5;
        private Wisej.Web.Button Num2;
        private Wisej.Web.Button NumClear;
        private Wisej.Web.Button Num7;
        private Wisej.Web.Button Num4;
        private Wisej.Web.Button Num1;
        private Wisej.Web.MaskedTextBox TxtPassword;
        private Wisej.Web.Label label1;
    }
}
