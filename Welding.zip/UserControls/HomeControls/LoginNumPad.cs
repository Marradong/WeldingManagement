﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Wisej.Web;

namespace ToolTrack
{
    public partial class LoginNumPad : Wisej.Web.UserControl
    {

        public delegate void onChange();
        public event onChange OnChange;

        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public bool HidePassword
        {
            set
            {
                if (value)
                {
                    TxtPassword.PasswordChar = '●';
                    TxtPassword.Invalidate();
                }
                else
                {
                    TxtPassword.PasswordChar = '\0'; 
                    TxtPassword.Invalidate();
                }
            }
        }

        private string EmpIdAndDOB = "";
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public string EmployeeIdAndDOB
        {
            get { 
                return EmpIdAndDOB;
            }
            set
            {
                TxtPassword.Text = value;
                EmpIdAndDOB = value;

                //Create Text Changed Event
                //Bubble back onChange event
                OnChange?.Invoke();
            }
        }

        public LoginNumPad()
        {
            InitializeComponent();

            Num1.MouseUp += new MouseEventHandler(this.NumericMouseUp);
            Num2.MouseUp += new MouseEventHandler(this.NumericMouseUp);
            Num3.MouseUp += new MouseEventHandler(this.NumericMouseUp);
            Num4.MouseUp += new MouseEventHandler(this.NumericMouseUp);
            Num5.MouseUp += new MouseEventHandler(this.NumericMouseUp);
            Num6.MouseUp += new MouseEventHandler(this.NumericMouseUp);
            Num7.MouseUp += new MouseEventHandler(this.NumericMouseUp);
            Num8.MouseUp += new MouseEventHandler(this.NumericMouseUp);
            Num9.MouseUp += new MouseEventHandler(this.NumericMouseUp);
            Num0.MouseUp += new MouseEventHandler(this.NumericMouseUp);

            NumBack.MouseUp += new MouseEventHandler(this.Backspace_MouseUp);
            NumClear.MouseUp += new MouseEventHandler(this.BuClear_MouseUp);
        }

        private void BuClear_MouseUp(object sender, MouseEventArgs e)
        {
            EmployeeIdAndDOB= "";
        }

        private void Backspace_MouseUp(object sender, MouseEventArgs e)
        {
            if (EmployeeIdAndDOB.Length > 0)
                EmployeeIdAndDOB = EmpIdAndDOB.Substring(0, EmpIdAndDOB.Length - 1);
        }


        private void NumericMouseUp(object sender, EventArgs e)
        {
            EmployeeIdAndDOB += ((Button)sender).Text;
        }


        private void KeyEvent(Char e)
        {
            if (e == (char)Keys.Enter)
            {
               // Next();
            }
            if (e == (char)Keys.Escape)
            {
                //Clear
            }
        }

       
        private void FrmMain_KeyPress(object sender, KeyPressEventArgs e)
        {
            Key_pressed(e);
        }

        public void Key_pressed(KeyPressEventArgs e)
        {
            double retNum;

            bool isNum = Double.TryParse(Convert.ToString(e.KeyChar), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);

            if (isNum)
            {
                EmployeeIdAndDOB += e.KeyChar;
            }
            else
            {
                if ((e.KeyChar == (Char)Keys.Clear) | (e.KeyChar == (Char)Keys.Delete))
                {
                    EmployeeIdAndDOB = "";
                    
                }
                else if (e.KeyChar == (Char)Keys.Back)
                {
                    if (EmployeeIdAndDOB.Length > 0)
                        EmployeeIdAndDOB = EmpIdAndDOB.Substring(0, EmpIdAndDOB.Length - 1);
                }
            }
        }
        private IEnumerable<Control> GetControlHierarchy(Control root)
        {
            var queue = new Queue<Control>();

            queue.Enqueue(root);

            do
            {
                var control = queue.Dequeue();

                yield return control;

                foreach (var child in control.Controls.OfType<Control>())
                    queue.Enqueue(child);

            } while (queue.Count > 0);

        }

        private void NumPad_Load(object sender, EventArgs e)
        {

            this.ActiveControl = TxtPassword;
        }

        private void TxtPassword_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void TxtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
    }
}
