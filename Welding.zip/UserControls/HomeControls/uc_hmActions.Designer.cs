﻿namespace WeldingManagement.UserControls.HomeControls
{
    partial class uc_hmActions
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_hmActions));
            this.tlp1 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.tlpHomeFilter = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel6 = new Wisej.Web.TableLayoutPanel();
            this.btnHomeClear = new Wisej.Web.Button();
            this.tableLayoutPanel5 = new Wisej.Web.TableLayoutPanel();
            this.txtHomeJob = new Wisej.Web.MaskedTextBox();
            this.cboHomeType = new Wisej.Web.ComboBox();
            this.cboHomeStatus = new Wisej.Web.ComboBox();
            this.label3 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.label1 = new Wisej.Web.Label();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.btnHomeSearchJobs = new Wisej.Web.Button();
            this.btnHomeSearchWPQR = new Wisej.Web.Button();
            this.btnHomeSearchWQ = new Wisej.Web.Button();
            this.btnHomeSearchWPS = new Wisej.Web.Button();
            this.btnHomeRefresh = new Wisej.Web.Button();
            this.tlpHomeActions = new Wisej.Web.TableLayoutPanel();
            this.lvHomeActions = new Wisej.Web.ListView();
            this.columnHeader3 = new Wisej.Web.ColumnHeader();
            this.columnHeader4 = new Wisej.Web.ColumnHeader();
            this.columnHeader5 = new Wisej.Web.ColumnHeader();
            this.tlpHomeButtons = new Wisej.Web.TableLayoutPanel();
            this.btnHomeResetDb = new Wisej.Web.Button();
            this.btnRemoveAction = new Wisej.Web.Button();
            this.btnHomeAddWPS = new Wisej.Web.Button();
            this.btnHomeNewJob = new Wisej.Web.Button();
            this.btnHomeNDT = new Wisej.Web.Button();
            this.btnHomeAddWPQR = new Wisej.Web.Button();
            this.btnHomeAddWQ = new Wisej.Web.Button();
            this.btnHomeStatus = new Wisej.Web.Button();
            this.btnHomePrint = new Wisej.Web.Button();
            this.btnHomeDeleteJob = new Wisej.Web.Button();
            this.btnHomeRequest = new Wisej.Web.Button();
            this.btnWelderQualification = new Wisej.Web.Button();
            this.btnHomeWPQR = new Wisej.Web.Button();
            this.btnHomeWPS = new Wisej.Web.Button();
            this.lvHomeJobs = new Wisej.Web.ListView();
            this.columnHeader1 = new Wisej.Web.ColumnHeader();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.lblHomeNote = new Wisej.Web.LinkLabel();
            this.lblHomeTitle = new Wisej.Web.Label();
            this.tlp1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tlpHomeFilter.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tlpHomeActions.SuspendLayout();
            this.tlpHomeButtons.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlp1
            // 
            this.tlp1.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tlp1.ColumnCount = 3;
            this.tlp1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tlp1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tlp1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tlp1.Controls.Add(this.tableLayoutPanel3, 1, 3);
            this.tlp1.Controls.Add(this.tableLayoutPanel2, 1, 1);
            this.tlp1.Dock = Wisej.Web.DockStyle.Fill;
            this.tlp1.Location = new System.Drawing.Point(0, 0);
            this.tlp1.Name = "tlp1";
            this.tlp1.RowCount = 5;
            this.tlp1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tlp1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlp1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tlp1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tlp1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tlp1.Size = new System.Drawing.Size(1212, 615);
            this.tlp1.TabIndex = 1;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 85F));
            this.tableLayoutPanel3.Controls.Add(this.tlpHomeFilter, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.tlpHomeActions, 0, 1);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 80F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // tlpHomeFilter
            // 
            this.tlpHomeFilter.ColumnCount = 4;
            this.tlpHomeFilter.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 40F));
            this.tlpHomeFilter.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tlpHomeFilter.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 30F));
            this.tlpHomeFilter.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpHomeFilter.Controls.Add(this.tableLayoutPanel6, 1, 0);
            this.tlpHomeFilter.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tlpHomeFilter.Controls.Add(this.tableLayoutPanel1, 2, 0);
            this.tlpHomeFilter.Controls.Add(this.btnHomeRefresh, 3, 0);
            this.tlpHomeFilter.CssStyle = "overflow: hidden;";
            this.tlpHomeFilter.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpHomeFilter.Location = new System.Drawing.Point(3, 3);
            this.tlpHomeFilter.Name = "tlpHomeFilter";
            this.tlpHomeFilter.RowCount = 1;
            this.tlpHomeFilter.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpHomeFilter.Size = new System.Drawing.Size(1139, 81);
            this.tlpHomeFilter.TabIndex = 3;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.btnHomeClear, 0, 0);
            this.tableLayoutPanel6.CssStyle = "overflow: hidden;";
            this.tableLayoutPanel6.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(458, 0);
            this.tableLayoutPanel6.Margin = new Wisej.Web.Padding(3, 0, 3, 0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(107, 81);
            this.tableLayoutPanel6.TabIndex = 17;
            // 
            // btnHomeClear
            // 
            this.btnHomeClear.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeClear.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeClear.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnHomeClear.Location = new System.Drawing.Point(0, 0);
            this.btnHomeClear.Margin = new Wisej.Web.Padding(0);
            this.btnHomeClear.Name = "btnHomeClear";
            this.btnHomeClear.Size = new System.Drawing.Size(107, 81);
            this.btnHomeClear.TabIndex = 1;
            this.btnHomeClear.Text = "Clear Filter";
            this.btnHomeClear.Click += new System.EventHandler(this.btnHomeClear_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel5.BorderStyle = Wisej.Web.BorderStyle.Dotted;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Absolute, 100F));
            this.tableLayoutPanel5.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 85F));
            this.tableLayoutPanel5.Controls.Add(this.txtHomeJob, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.cboHomeType, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.cboHomeStatus, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel5.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel5.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 0);
            this.tableLayoutPanel5.Margin = new Wisej.Web.Padding(3, 0, 3, 0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 3;
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(449, 81);
            this.tableLayoutPanel5.TabIndex = 16;
            // 
            // txtHomeJob
            // 
            this.txtHomeJob.Dock = Wisej.Web.DockStyle.Fill;
            this.txtHomeJob.Location = new System.Drawing.Point(103, 3);
            this.txtHomeJob.Mask = "00000-000";
            this.txtHomeJob.Name = "txtHomeJob";
            this.txtHomeJob.Size = new System.Drawing.Size(341, 20);
            this.txtHomeJob.TabIndex = 6;
            this.txtHomeJob.Click += new System.EventHandler(this.txtHomeJob_Click);
            this.txtHomeJob.KeyPress += new Wisej.Web.KeyPressEventHandler(this.txtHomeJob_KeyPress);
            // 
            // cboHomeType
            // 
            this.cboHomeType.Dock = Wisej.Web.DockStyle.Fill;
            this.cboHomeType.Location = new System.Drawing.Point(103, 55);
            this.cboHomeType.Name = "cboHomeType";
            this.cboHomeType.Size = new System.Drawing.Size(341, 21);
            this.cboHomeType.TabIndex = 5;
            this.cboHomeType.SelectedIndexChanged += new System.EventHandler(this.cboHomeType_SelectedIndexChanged);
            // 
            // cboHomeStatus
            // 
            this.cboHomeStatus.Dock = Wisej.Web.DockStyle.Fill;
            this.cboHomeStatus.Location = new System.Drawing.Point(103, 29);
            this.cboHomeStatus.Name = "cboHomeStatus";
            this.cboHomeStatus.Size = new System.Drawing.Size(341, 20);
            this.cboHomeStatus.TabIndex = 4;
            this.cboHomeStatus.SelectedIndexChanged += new System.EventHandler(this.cboHomeStatus_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = Wisej.Web.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Action Type";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Action Status";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Job Number";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.btnHomeSearchJobs, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnHomeSearchWPQR, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnHomeSearchWQ, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnHomeSearchWPS, 1, 0);
            this.tableLayoutPanel1.CssStyle = "overflow: hidden;";
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(571, 0);
            this.tableLayoutPanel1.Margin = new Wisej.Web.Padding(3, 0, 3, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(335, 81);
            this.tableLayoutPanel1.TabIndex = 15;
            // 
            // btnHomeSearchJobs
            // 
            this.btnHomeSearchJobs.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeSearchJobs.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeSearchJobs.Location = new System.Drawing.Point(170, 43);
            this.btnHomeSearchJobs.Margin = new Wisej.Web.Padding(3, 3, 0, 0);
            this.btnHomeSearchJobs.Name = "btnHomeSearchJobs";
            this.btnHomeSearchJobs.Size = new System.Drawing.Size(165, 38);
            this.btnHomeSearchJobs.TabIndex = 14;
            this.btnHomeSearchJobs.Text = "Search Jobs";
            this.btnHomeSearchJobs.Click += new System.EventHandler(this.btnHomeSearchJobs_Click);
            // 
            // btnHomeSearchWPQR
            // 
            this.btnHomeSearchWPQR.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeSearchWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeSearchWPQR.Location = new System.Drawing.Point(0, 43);
            this.btnHomeSearchWPQR.Margin = new Wisej.Web.Padding(0, 3, 3, 0);
            this.btnHomeSearchWPQR.Name = "btnHomeSearchWPQR";
            this.btnHomeSearchWPQR.Size = new System.Drawing.Size(164, 38);
            this.btnHomeSearchWPQR.TabIndex = 10;
            this.btnHomeSearchWPQR.Text = "Search WPQR";
            this.btnHomeSearchWPQR.Click += new System.EventHandler(this.btnHomeSearchWPQR_Click);
            // 
            // btnHomeSearchWQ
            // 
            this.btnHomeSearchWQ.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeSearchWQ.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeSearchWQ.Location = new System.Drawing.Point(0, 0);
            this.btnHomeSearchWQ.Margin = new Wisej.Web.Padding(0, 0, 3, 3);
            this.btnHomeSearchWQ.Name = "btnHomeSearchWQ";
            this.btnHomeSearchWQ.Size = new System.Drawing.Size(164, 37);
            this.btnHomeSearchWQ.TabIndex = 12;
            this.btnHomeSearchWQ.Text = "Search Qualifications";
            this.btnHomeSearchWQ.Click += new System.EventHandler(this.btnHomeSearchWQ_Click);
            // 
            // btnHomeSearchWPS
            // 
            this.btnHomeSearchWPS.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeSearchWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeSearchWPS.Location = new System.Drawing.Point(170, 0);
            this.btnHomeSearchWPS.Margin = new Wisej.Web.Padding(3, 0, 0, 3);
            this.btnHomeSearchWPS.Name = "btnHomeSearchWPS";
            this.btnHomeSearchWPS.Size = new System.Drawing.Size(165, 37);
            this.btnHomeSearchWPS.TabIndex = 13;
            this.btnHomeSearchWPS.Text = "Search WPS";
            this.btnHomeSearchWPS.Click += new System.EventHandler(this.btnHomeSearchWPS_Click);
            // 
            // btnHomeRefresh
            // 
            this.btnHomeRefresh.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeRefresh.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeRefresh.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnHomeRefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHomeRefresh.ImageSource = "icon-redo";
            this.btnHomeRefresh.ImageSpacing = 15;
            this.btnHomeRefresh.Location = new System.Drawing.Point(912, 0);
            this.btnHomeRefresh.Margin = new Wisej.Web.Padding(3, 0, 3, 0);
            this.btnHomeRefresh.Name = "btnHomeRefresh";
            this.btnHomeRefresh.Size = new System.Drawing.Size(224, 81);
            this.btnHomeRefresh.TabIndex = 14;
            this.btnHomeRefresh.Text = "Refresh";
            this.btnHomeRefresh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHomeRefresh.Click += new System.EventHandler(this.btnHomeRefresh_Click);
            // 
            // tlpHomeActions
            // 
            this.tlpHomeActions.ColumnCount = 3;
            this.tlpHomeActions.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 40F));
            this.tlpHomeActions.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 40F));
            this.tlpHomeActions.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpHomeActions.Controls.Add(this.lvHomeActions, 1, 0);
            this.tlpHomeActions.Controls.Add(this.tlpHomeButtons, 2, 0);
            this.tlpHomeActions.Controls.Add(this.lvHomeJobs, 0, 0);
            this.tlpHomeActions.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpHomeActions.Location = new System.Drawing.Point(3, 90);
            this.tlpHomeActions.Name = "tlpHomeActions";
            this.tlpHomeActions.RowCount = 1;
            this.tlpHomeActions.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpHomeActions.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tlpHomeActions.Size = new System.Drawing.Size(1139, 346);
            this.tlpHomeActions.TabIndex = 2;
            // 
            // lvHomeActions
            // 
            this.lvHomeActions.Columns.AddRange(new Wisej.Web.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.lvHomeActions.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px 16px 24px rgba(255, 255, 255, 0.5);\r\nb" +
    "order: 1px solid rgba(202, 81, 16, 0.75);\r\noverflow: hidden;";
            this.lvHomeActions.Dock = Wisej.Web.DockStyle.Fill;
            this.lvHomeActions.Location = new System.Drawing.Point(458, 3);
            this.lvHomeActions.Name = "lvHomeActions";
            this.lvHomeActions.Size = new System.Drawing.Size(449, 340);
            this.lvHomeActions.TabIndex = 1;
            this.lvHomeActions.View = Wisej.Web.View.Details;
            this.lvHomeActions.SelectedIndexChanged += new System.EventHandler(this.lvHomeActions_SelectedIndexChanged);
            this.lvHomeActions.Resize += new System.EventHandler(this.HomeListViewResize);
            // 
            // columnHeader3
            // 
            this.columnHeader3.Name = "columnHeader3";
            this.columnHeader3.Text = "Action Status";
            this.columnHeader3.Width = 240;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Name = "columnHeader4";
            this.columnHeader4.Text = "Action Type";
            this.columnHeader4.Width = 120;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Name = "columnHeader5";
            this.columnHeader5.Text = "Notes";
            // 
            // tlpHomeButtons
            // 
            this.tlpHomeButtons.BackColor = System.Drawing.Color.FromName("@window");
            this.tlpHomeButtons.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tlpHomeButtons.ColumnCount = 2;
            this.tlpHomeButtons.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpHomeButtons.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tlpHomeButtons.Controls.Add(this.btnHomeResetDb, 1, 5);
            this.tlpHomeButtons.Controls.Add(this.btnRemoveAction, 1, 1);
            this.tlpHomeButtons.Controls.Add(this.btnHomeAddWPS, 0, 5);
            this.tlpHomeButtons.Controls.Add(this.btnHomeNewJob, 0, 6);
            this.tlpHomeButtons.Controls.Add(this.btnHomeNDT, 0, 7);
            this.tlpHomeButtons.Controls.Add(this.btnHomeAddWPQR, 0, 4);
            this.tlpHomeButtons.Controls.Add(this.btnHomeAddWQ, 0, 3);
            this.tlpHomeButtons.Controls.Add(this.btnHomeStatus, 1, 3);
            this.tlpHomeButtons.Controls.Add(this.btnHomePrint, 1, 2);
            this.tlpHomeButtons.Controls.Add(this.btnHomeDeleteJob, 1, 0);
            this.tlpHomeButtons.Controls.Add(this.btnHomeRequest, 1, 4);
            this.tlpHomeButtons.Controls.Add(this.btnWelderQualification, 0, 0);
            this.tlpHomeButtons.Controls.Add(this.btnHomeWPQR, 0, 1);
            this.tlpHomeButtons.Controls.Add(this.btnHomeWPS, 0, 2);
            this.tlpHomeButtons.CssStyle = "border-radius: 4px;";
            this.tlpHomeButtons.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpHomeButtons.Location = new System.Drawing.Point(913, 3);
            this.tlpHomeButtons.Name = "tlpHomeButtons";
            this.tlpHomeButtons.RowCount = 8;
            this.tlpHomeButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpHomeButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpHomeButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpHomeButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpHomeButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpHomeButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpHomeButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpHomeButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tlpHomeButtons.Size = new System.Drawing.Size(223, 340);
            this.tlpHomeButtons.TabIndex = 1;
            // 
            // btnHomeResetDb
            // 
            this.btnHomeResetDb.BackColor = System.Drawing.Color.FromName("@switchOn");
            this.btnHomeResetDb.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeResetDb.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeResetDb.Location = new System.Drawing.Point(113, 213);
            this.btnHomeResetDb.Name = "btnHomeResetDb";
            this.btnHomeResetDb.Size = new System.Drawing.Size(105, 36);
            this.btnHomeResetDb.TabIndex = 18;
            this.btnHomeResetDb.Text = "<RESET DB>";
            this.btnHomeResetDb.DoubleClick += new System.EventHandler(this.btnHomeResetDb_DoubleClick);
            // 
            // btnRemoveAction
            // 
            this.btnRemoveAction.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnRemoveAction.Dock = Wisej.Web.DockStyle.Fill;
            this.btnRemoveAction.Location = new System.Drawing.Point(113, 45);
            this.btnRemoveAction.Name = "btnRemoveAction";
            this.btnRemoveAction.Size = new System.Drawing.Size(105, 36);
            this.btnRemoveAction.TabIndex = 17;
            this.btnRemoveAction.Text = "Remove Action";
            this.btnRemoveAction.Click += new System.EventHandler(this.btnRemoveAction_Click);
            // 
            // btnHomeAddWPS
            // 
            this.btnHomeAddWPS.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeAddWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeAddWPS.Location = new System.Drawing.Point(3, 213);
            this.btnHomeAddWPS.Name = "btnHomeAddWPS";
            this.btnHomeAddWPS.Size = new System.Drawing.Size(104, 36);
            this.btnHomeAddWPS.TabIndex = 16;
            this.btnHomeAddWPS.Text = "Add New WPS";
            this.btnHomeAddWPS.Click += new System.EventHandler(this.btnHomeAddWPS_Click);
            // 
            // btnHomeNewJob
            // 
            this.btnHomeNewJob.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeNewJob.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeNewJob.Location = new System.Drawing.Point(3, 255);
            this.btnHomeNewJob.Name = "btnHomeNewJob";
            this.btnHomeNewJob.Size = new System.Drawing.Size(104, 36);
            this.btnHomeNewJob.TabIndex = 8;
            this.btnHomeNewJob.Text = "Create a Job";
            this.btnHomeNewJob.Click += new System.EventHandler(this.btnHomeNewJob_Click);
            // 
            // btnHomeNDT
            // 
            this.btnHomeNDT.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeNDT.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeNDT.Location = new System.Drawing.Point(3, 297);
            this.btnHomeNDT.Name = "btnHomeNDT";
            this.btnHomeNDT.Size = new System.Drawing.Size(104, 38);
            this.btnHomeNDT.TabIndex = 6;
            this.btnHomeNDT.Text = "Enter NDT";
            this.btnHomeNDT.Click += new System.EventHandler(this.btnHomeNDT_Click);
            // 
            // btnHomeAddWPQR
            // 
            this.btnHomeAddWPQR.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeAddWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeAddWPQR.Location = new System.Drawing.Point(3, 171);
            this.btnHomeAddWPQR.Name = "btnHomeAddWPQR";
            this.btnHomeAddWPQR.Size = new System.Drawing.Size(104, 36);
            this.btnHomeAddWPQR.TabIndex = 15;
            this.btnHomeAddWPQR.Text = "Add New WPQR";
            this.btnHomeAddWPQR.Click += new System.EventHandler(this.btnHomeAddWPQR_Click);
            // 
            // btnHomeAddWQ
            // 
            this.btnHomeAddWQ.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeAddWQ.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeAddWQ.Location = new System.Drawing.Point(3, 129);
            this.btnHomeAddWQ.Name = "btnHomeAddWQ";
            this.btnHomeAddWQ.Size = new System.Drawing.Size(104, 36);
            this.btnHomeAddWQ.TabIndex = 14;
            this.btnHomeAddWQ.Text = "Add New Welder Qualification";
            this.btnHomeAddWQ.Click += new System.EventHandler(this.btnHomeAddWQ_Click);
            // 
            // btnHomeStatus
            // 
            this.btnHomeStatus.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeStatus.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeStatus.Location = new System.Drawing.Point(113, 129);
            this.btnHomeStatus.Name = "btnHomeStatus";
            this.btnHomeStatus.Size = new System.Drawing.Size(105, 36);
            this.btnHomeStatus.TabIndex = 11;
            this.btnHomeStatus.Text = "Change Status";
            this.btnHomeStatus.Click += new System.EventHandler(this.btnHomeStatus_Click);
            // 
            // btnHomePrint
            // 
            this.btnHomePrint.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomePrint.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomePrint.Location = new System.Drawing.Point(113, 87);
            this.btnHomePrint.Name = "btnHomePrint";
            this.btnHomePrint.Size = new System.Drawing.Size(105, 36);
            this.btnHomePrint.TabIndex = 9;
            this.btnHomePrint.Text = "Test Print";
            this.btnHomePrint.Click += new System.EventHandler(this.btnHomePrint_Click);
            // 
            // btnHomeDeleteJob
            // 
            this.btnHomeDeleteJob.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeDeleteJob.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeDeleteJob.Location = new System.Drawing.Point(113, 3);
            this.btnHomeDeleteJob.Name = "btnHomeDeleteJob";
            this.btnHomeDeleteJob.Size = new System.Drawing.Size(105, 36);
            this.btnHomeDeleteJob.TabIndex = 7;
            this.btnHomeDeleteJob.Text = "Delete Job";
            this.btnHomeDeleteJob.Click += new System.EventHandler(this.btnHomeDeleteJob_Click);
            // 
            // btnHomeRequest
            // 
            this.btnHomeRequest.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeRequest.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeRequest.Location = new System.Drawing.Point(113, 171);
            this.btnHomeRequest.Name = "btnHomeRequest";
            this.btnHomeRequest.Size = new System.Drawing.Size(105, 36);
            this.btnHomeRequest.TabIndex = 1;
            this.btnHomeRequest.Text = "Request Welding\r\non Job -> FOR LATER USE";
            this.btnHomeRequest.Click += new System.EventHandler(this.btnHomeRequest_Click);
            // 
            // btnWelderQualification
            // 
            this.btnWelderQualification.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnWelderQualification.Dock = Wisej.Web.DockStyle.Fill;
            this.btnWelderQualification.Location = new System.Drawing.Point(3, 3);
            this.btnWelderQualification.Name = "btnWelderQualification";
            this.btnWelderQualification.Size = new System.Drawing.Size(104, 36);
            this.btnWelderQualification.TabIndex = 2;
            this.btnWelderQualification.Text = "Complete Welder Qualification\r\n";
            this.btnWelderQualification.Click += new System.EventHandler(this.btnWelderQualification_Click);
            // 
            // btnHomeWPQR
            // 
            this.btnHomeWPQR.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeWPQR.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeWPQR.Location = new System.Drawing.Point(3, 45);
            this.btnHomeWPQR.Name = "btnHomeWPQR";
            this.btnHomeWPQR.Size = new System.Drawing.Size(104, 36);
            this.btnHomeWPQR.TabIndex = 4;
            this.btnHomeWPQR.Text = "Complete WPQR";
            this.btnHomeWPQR.Click += new System.EventHandler(this.btnHomeWPQR_Click);
            // 
            // btnHomeWPS
            // 
            this.btnHomeWPS.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnHomeWPS.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHomeWPS.Location = new System.Drawing.Point(3, 87);
            this.btnHomeWPS.Name = "btnHomeWPS";
            this.btnHomeWPS.Size = new System.Drawing.Size(104, 36);
            this.btnHomeWPS.TabIndex = 5;
            this.btnHomeWPS.Text = "Complete WPS";
            this.btnHomeWPS.Click += new System.EventHandler(this.btnHomeWPS_Click);
            // 
            // lvHomeJobs
            // 
            this.lvHomeJobs.Columns.AddRange(new Wisej.Web.ColumnHeader[] {
            this.columnHeader1});
            this.lvHomeJobs.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px 16px 24px rgba(255, 255, 255, 0.5);\r\nb" +
    "order: 1px solid rgba(202, 81, 16, 0.75);\r\noverflow: hidden;";
            this.lvHomeJobs.Dock = Wisej.Web.DockStyle.Fill;
            this.lvHomeJobs.Location = new System.Drawing.Point(3, 3);
            this.lvHomeJobs.Name = "lvHomeJobs";
            this.lvHomeJobs.Size = new System.Drawing.Size(449, 340);
            this.lvHomeJobs.TabIndex = 0;
            this.lvHomeJobs.View = Wisej.Web.View.Details;
            this.lvHomeJobs.SelectedIndexChanged += new System.EventHandler(this.lvHomeJobs_SelectedIndexChanged);
            this.lvHomeJobs.Resize += new System.EventHandler(this.HomeListViewResize);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Name = "columnHeader1";
            this.columnHeader1.Text = "Job / Quote Number";
            this.columnHeader1.Width = 240;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.lblHomeNote, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblHomeTitle, 0, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // lblHomeNote
            // 
            this.lblHomeNote.AutoSize = true;
            this.lblHomeNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblHomeNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblHomeNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblHomeNote.LinkArea = new Wisej.Web.LinkArea(256, 84);
            this.lblHomeNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblHomeNote.Location = new System.Drawing.Point(6, 79);
            this.lblHomeNote.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.lblHomeNote.Name = "lblHomeNote";
            this.lblHomeNote.Size = new System.Drawing.Size(1133, 35);
            this.lblHomeNote.TabIndex = 2;
            this.lblHomeNote.Text = resources.GetString("lblHomeNote.Text");
            this.lblHomeNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHomeNote.LinkClicked += new Wisej.Web.LinkLabelLinkClickedEventHandler(this.lblHomeNote_LinkClicked);
            // 
            // lblHomeTitle
            // 
            this.lblHomeTitle.AutoSize = true;
            this.lblHomeTitle.BackColor = System.Drawing.Color.FromName("@window");
            this.lblHomeTitle.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.lblHomeTitle.CssStyle = "border-radius: 4px;";
            this.lblHomeTitle.Dock = Wisej.Web.DockStyle.Fill;
            this.lblHomeTitle.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblHomeTitle.Location = new System.Drawing.Point(6, 3);
            this.lblHomeTitle.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.lblHomeTitle.Name = "lblHomeTitle";
            this.lblHomeTitle.Size = new System.Drawing.Size(1133, 70);
            this.lblHomeTitle.TabIndex = 0;
            this.lblHomeTitle.Text = "Welding Management System";
            this.lblHomeTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHomeTitle.DoubleClick += new System.EventHandler(this.lblHomeTitle_DoubleClick);
            // 
            // uc_hmActions
            // 
            this.Controls.Add(this.tlp1);
            this.Dock = Wisej.Web.DockStyle.Fill;
            this.Name = "uc_hmActions";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_hmActions_VisibleChanged);
            this.tlp1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tlpHomeFilter.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tlpHomeActions.ResumeLayout(false);
            this.tlpHomeButtons.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tlp1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.TableLayoutPanel tlpHomeButtons;
        private Wisej.Web.Button btnHomeRequest;
        private Wisej.Web.Button btnWelderQualification;
        private Wisej.Web.Button btnHomeWPQR;
        private Wisej.Web.Button btnHomeWPS;
        private Wisej.Web.Button btnHomeNDT;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.Label lblHomeTitle;
        private Wisej.Web.Button btnHomeDeleteJob;
        private Wisej.Web.TableLayoutPanel tlpHomeActions;
        private Wisej.Web.ListView lvHomeJobs;
        private Wisej.Web.ColumnHeader columnHeader1;
        private Wisej.Web.ListView lvHomeActions;
        private Wisej.Web.ColumnHeader columnHeader3;
        private Wisej.Web.Button btnHomeNewJob;
        private Wisej.Web.ColumnHeader columnHeader4;
        private Wisej.Web.ColumnHeader columnHeader5;
        private Wisej.Web.Button btnHomePrint;
        private Wisej.Web.Button btnHomeSearchWPQR;
        private Wisej.Web.Button btnHomeStatus;
        private Wisej.Web.Button btnHomeSearchWQ;
        private Wisej.Web.TableLayoutPanel tlpHomeFilter;
        private Wisej.Web.Button btnHomeSearchWPS;
        private Wisej.Web.Button btnRemoveAction;
        private Wisej.Web.Button btnHomeAddWPS;
        private Wisej.Web.Button btnHomeAddWPQR;
        private Wisej.Web.Button btnHomeAddWQ;
        private Wisej.Web.Button btnHomeRefresh;
        private Wisej.Web.Button btnHomeResetDb;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel5;
        private Wisej.Web.ComboBox cboHomeType;
        private Wisej.Web.ComboBox cboHomeStatus;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label2;
        private Wisej.Web.Label label1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel6;
        private Wisej.Web.Button btnHomeClear;
        private Wisej.Web.MaskedTextBox txtHomeJob;
        private Wisej.Web.LinkLabel lblHomeNote;
        private Wisej.Web.Button btnHomeSearchJobs;
    }
}
