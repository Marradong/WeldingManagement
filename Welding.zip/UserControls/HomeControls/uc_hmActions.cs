﻿using ApiClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using Welding.DAL;
using WeldingManagement.Helpers;
using Wisej.Web;
using static WeldingManagement.TemplateCompiler;
using static WeldingManagement.UIFormatting;

namespace WeldingManagement.UserControls.HomeControls
{
    public partial class uc_hmActions : UserControl
    {
        private up_hmJob up_hmJob1;

        private Panel overlayPanel;

        private bool adminMode;

        public uc_hmActions()
        {
            InitializeComponent();

            this.SuspendLayout();

            adminMode = Debugger.IsAttached;

            ResizeAdminBar();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();

            this.ResumeLayout();
        }

        #region Navigation Events
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks request button on home screen")]
        public event EventHandler btnHomeRequestClick;
        private void btnHomeRequest_Click(object sender, EventArgs e)
        {
            if (lvHomeJobs.SelectedItems.Count != 0)
            {
                btnHomeRequestClick?.Invoke(this, e);
            }
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks Welder Qualification button on home screen")]
        public event EventHandler btnWelderQualificationClick;
        private void btnWelderQualification_Click(object sender, EventArgs e)
        {
            btnWelderQualificationClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks WPQR button on home screen")]
        public event EventHandler btnHomeWPQRClick;
        private void btnHomeWPQR_Click(object sender, EventArgs e)
        {
            btnHomeWPQRClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks WPS button on home screen")]
        public event EventHandler btnHomeWPSClick;
        private void btnHomeWPS_Click(object sender, EventArgs e)
        {
            btnHomeWPSClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks NDT button on home screen")]
        public event EventHandler btnHomeNDTClick;
        private void btnHomeNDT_Click(object sender, EventArgs e)
        {
            btnHomeNDTClick?.Invoke(this, e);
        }


        #region Search Events

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks search WPQR button on home screen")]
        public event EventHandler btnHomeSearchWPQRClick;
        private void btnHomeSearchWPQR_Click(object sender, EventArgs e)
        {
            btnHomeSearchWPQRClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks search WPQR button on home screen")]
        public event EventHandler btnHomeSearchWQClick;
        private void btnHomeSearchWQ_Click(object sender, EventArgs e)
        {
            btnHomeSearchWQClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks search WPQR button on home screen")]
        public event EventHandler btnHomeSearchWPSClick;
        private void btnHomeSearchWPS_Click(object sender, EventArgs e)
        {
            btnHomeSearchWPSClick?.Invoke(this, e);
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks search Jobs button on home screen")]
        public event EventHandler btnHomeSearchJobClick;
        private void btnHomeSearchJobs_Click(object sender, EventArgs e)
        {
            btnHomeSearchJobClick?.Invoke(this, e);
        }

        #endregion
        #endregion

        private void uc_hmActions_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill)
            {
                return;
            }

            this.Tag = null;

            Load_Jobs();
        }

        #region User Functions
        private void btnHomeRefresh_Click(object sender, EventArgs e)
        {
            Load_Jobs();
        }

        private void btnHomeNewJob_Click(object sender, EventArgs e)
        {
            if (up_hmJob1 == null)
            {
                up_hmJob1 = new up_hmJob();
                this.Controls.Add(up_hmJob1);
            }

            overlayPanel.Visible = true;

            up_hmJob1.ShowPopup(new Point(this.Width / 2 - up_hmJob1.Width / 2, this.Height / 2 - up_hmJob1.Height / 2), up_hmJob1_Closed);
        }

        private void up_hmJob1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;

            Load_Jobs();
        }

        private void btnHomeAddWQ_Click(object sender, EventArgs e)
        {
            AddTask(TagType.Welder_Qualification);
        }

        private void btnHomeAddWPQR_Click(object sender, EventArgs e)
        {
            AddTask(TagType.WPQR);
        }

        private void btnHomeAddWPS_Click(object sender, EventArgs e)
        {
            AddTask(TagType.WPS);
        }
        #endregion

        #region ListView Operations
        private void lvHomeJobs_SelectedIndexChanged(object sender, EventArgs e)
        {
            Load_Actions_For_Job();
        }

        private void lvHomeActions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvHomeActions.SelectedIndex < 0)
            {
                return;
            }

            this.Tag = lvHomeActions.Items[lvHomeActions.SelectedIndex].Tag;

            changeButtonColors();
        }

        private void Load_Actions_For_Job()
        {
            if (lvHomeJobs.SelectedIndex < 0)
            {
                return;
            }

            Tag selectedTag = (Tag)lvHomeJobs.Items[lvHomeJobs.SelectedIndex].Tag;

            if (selectedTag.getTagType() != TagType.Job)
            {
                return;
            }

            Job selectedJob = ApiCalls.ReadJob(((Job)selectedTag.getTagObject()).JobId);

            Load_Actions(selectedJob);
        }

        private void Load_Actions(Job jobToLoad)
        {
            this.Tag = null;

            lvHomeActions.Items.Clear();

            foreach (WeldingAction wa in jobToLoad.WeldingActions)
            {
                if (wa.Status != Actions.Complete && wa.NewWeldingForm != null)
                {
                    if (wa.NewWeldingForm.Status != Actions.Complete)
                    {
                        AddItemToListView(GetEnumDisplayName(wa.NewWeldingForm.Status), wa.NewWeldingForm, TagType.New_Welding_Form, lvHomeActions);

                        lvHomeActions.Refresh();
                        changeButtonColors();
                        return;
                    }

                    AddStartedToLv(wa);

                    AddBlankToLv(wa);
                }
            }

            lvHomeActions.Refresh();
            changeButtonColors();
        }

        private void Load_Jobs(string jobFilter = "")
        {
            this.Tag = null;

            lvHomeJobs.ClearSelection();
            lvHomeActions.ClearSelection();

            lvHomeJobs.Items.Clear();
            lvHomeActions.Items.Clear();

            cboHomeStatus.Items.Clear();
            cboHomeType.Items.Clear();

            cboHomeStatus.Items.AddRange(Enum.GetNames(typeof(Actions)));
            cboHomeType.Items.AddRange(Enum.GetNames(typeof(TagType)));

            cboHomeStatus.Refresh();
            cboHomeType.Refresh();

            List<Job> jobs = ApiCalls.ReadJobs();

            if (!string.IsNullOrEmpty(jobFilter))
            {
                jobs = jobs = jobs.Where(j => j.JobNo.Contains(jobFilter)).ToList();
            }

            foreach (Job job in jobs)
            {
                if (!CheckComplete(job))
                {
                    AddItemToListView(job.JobNo != null ? job.JobNo.ToString() : job.QuoteNumber?.ToString(), job, TagType.Job, lvHomeJobs);
                }
            }

            lvHomeActions.Refresh();
            lvHomeJobs.Refresh();
            changeButtonColors();
        }

        private void AddStartedToLv(WeldingAction wa)
        {
            AddItemsToListView(wa.Welder_Qualification, TagType.Welder_Qualification,
                wq => new string[]
                {
                    GetEnumDisplayName(wq.Status),
                    GetEnumDisplayName(TagType.Welder_Qualification),
                    $"{wq.Datasheet.WelderEID}, IWP{wq.Datasheet.WPQRNumber}"
                });

            AddItemsToListView(wa.WPQRs, TagType.WPQR,
                wpqr => new string[]
                {
                    GetEnumDisplayName(wpqr.Status),
                    GetEnumDisplayName(TagType.WPQR),
                    $"IWP{wpqr.WPQRNumber}"
                });

            AddItemsToListView(wa.WPS, TagType.WPS,
                wps => new string[]
                {
                    GetEnumDisplayName(wps.Status),
                    GetEnumDisplayName(TagType.WPS),
                    $"WPS{wps.WPSNumber}"
                });
        }

        private void AddBlankToLv(WeldingAction wa)
        {
            if (wa.NewWeldingForm.OperationalReview == null)
            {
                return;
            }

            AddItemsToListView(wa, wa.NewWeldingForm.OperationalReview.WeldersAmount,
                wa.Welder_Qualification.Count,
                Actions.WelderTestInformation,
                TagType.Welder_Qualification);

            AddItemsToListView(wa, wa.NewWeldingForm.OperationalReview.WPQRAmount,
                wa.WPQRs.Count,
                Actions.WPQRSelectWelderQual,
                TagType.WPQR);

            AddItemsToListView(wa, wa.NewWeldingForm.OperationalReview.WPSAmount,
                wa.WPS.Count,
                Actions.WPSInfo,
                TagType.WPS);
        }

        private void AddItemsToListView(WeldingAction wa, int? amount, int count, Actions action, TagType tagType)
        {
            if (amount == null)
            {
                return;
            }

            int remainder = amount.Value - count;

            if (remainder <= 0)
            {
                return;
            }

            for (int i = 0; i < remainder; i++)
            {
                AddItemToListView(GetEnumDisplayName(action), wa, tagType, lvHomeActions);
            }
        }

        private void AddItemsToListView<T>(IEnumerable<T> items, TagType tagType, Func<T, string[]> getDescription) where T : class
        {
            var lvItems = items
                .Select(item =>
                {
                    var lvItem = new ListViewItem(getDescription(item))
                    {
                        Tag = new Tag(item, tagType)
                    };
                    return lvItem;
                })
                .ToArray();
            lvHomeActions.Items.AddRange(lvItems);
        }

        private void AddItemToListView(string header, object obj, TagType tagType, ListView lv)
        {
            ListViewItem lvItem = new ListViewItem(tagType == TagType.Job ? new[] { header } : new[] { header, GetEnumDisplayName(tagType) })
            {
                Tag = new Tag(obj, tagType)
            };
            lv.Items.Add(lvItem);
        }

        private void HomeListViewResize(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill)
            {
                return;
            }

            ResizeColumnsFor(lvHomeJobs);
            ResizeColumnsFor(lvHomeActions);
        }
        #endregion

        #region Admin Functions
        private void btnHomeDeleteJob_Click(object sender, EventArgs e)
        {
            if (lvHomeJobs.SelectedIndex < 0)
            {
                return;
            }

            Tag selectedTag = (Tag)lvHomeJobs.Items[lvHomeJobs.SelectedIndex].Tag;

            if (selectedTag.getTagType() != TagType.Job)
            {
                return;
            }

            ApiCalls.DeleteJob(((Job)selectedTag.getTagObject()).JobId);

            Load_Jobs();
        }

        private void btnHomePrint_Click(object sender, EventArgs e)
        {
            if (this.Tag == null)
            {
                return;
            }

            Tag thisTag = (Tag)this.Tag;

            switch (thisTag.getTagType())
            {
                case TagType.Welder_Qualification:

                    Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);

                    if (wq.Status == Actions.Complete)
                    {
                        string path = CompleteWelderQual(wq);
                        DownloadPDF(path);
                    }
                    break;

                case TagType.WPQR:

                    WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);

                    if (wpqr.Status == Actions.Complete)
                    {
                        string path = CompleteWPQR(wpqr);
                        DownloadPDF(path);
                    }
                    break;

                case TagType.WPS:

                    WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);

                    if (wps.Status == Actions.Complete)
                    {
                        string path = CompleteWPS(wps);
                        DownloadPDF(path);
                    }
                    break;
            }
        }

        private void btnHomeStatus_Click(object sender, EventArgs e)
        {
            if (this.Tag == null)
            {
                return;
            }

            Tag thisTag = (Tag)this.Tag;

            switch (thisTag.getTagType())
            {
                case TagType.New_Welding_Form:
                    NewWeldingForm nwf = ApiCalls.ReadNewWeldingForm(((NewWeldingForm)thisTag.getTagObject()).NewWeldingFormId);
                    nwf.Status = Actions.WeldingMatrix;
                    ApiCalls.UpdateNewWeldingForm(nwf.NewWeldingFormId, nwf);
                    break;

                case TagType.Welder_Qualification:
                    Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)thisTag.getTagObject()).Welder_QualificationId);
                    wq.Status = Actions.WelderTestInformation;
                    ApiCalls.UpdateWelderQualification(wq.Welder_QualificationId, wq);
                    break;

                case TagType.WPQR:
                    WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)thisTag.getTagObject()).WPQRId);
                    wpqr.Status = Actions.WPQRInformation;
                    ApiCalls.UpdateWPQR(wpqr.WPQRId, wpqr);
                    break;

                case TagType.WPS:
                    WPS wps = ApiCalls.ReadWPS(((WPS)thisTag.getTagObject()).WPSId);
                    wps.Status = Actions.WPSInfo;
                    ApiCalls.UpdateWPS(wps.WPSId, wps);
                    break;
            }


            if (lvHomeJobs.Items[lvHomeJobs.SelectedIndex].Tag == null)
            {
                Load_Jobs();
            }
            else
            {
                Tag selectedTag = (Tag)lvHomeJobs.Items[lvHomeJobs.SelectedIndex].Tag;

                if (selectedTag.getTagType() == TagType.Job)
                {
                    Job selectedJob = ApiCalls.ReadJob(((Job)selectedTag.getTagObject()).JobId);
                    Load_Actions(selectedJob);
                }
            }
        }

        private void btnRemoveAction_Click(object sender, EventArgs e)
        {
            if (lvHomeActions.SelectedIndex < 0)
            {
                return;
            }

            Tag selectedTag = (Tag)lvHomeActions.Items[lvHomeActions.SelectedIndex].Tag;

            if (selectedTag == null)
            {
                return;
            }

            WeldingAction wa;

            switch (selectedTag.getTagType())
            {
                case TagType.Welder_Qualification:

                    if (selectedTag.getTagObject() is Welder_Qualification)
                    {
                        Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Welder_Qualification)selectedTag.getTagObject()).Welder_QualificationId);

                        if (wq.Status != Actions.Complete)
                        {
                            wa = ApiCalls.ReadWeldingAction(wq.WeldingAction.WeldingActionId);

                            if (wa.NewWeldingForm.Status == Actions.Complete)
                            {
                                OperationalReview or = ApiCalls.ReadOperationalReview(wa.NewWeldingForm.OperationalReview.OperationalReviewId);
                                or.WeldersAmount = (short)(or.WeldersAmount - 1 ?? 0);
                                ApiCalls.UpdateOperationalReview(or.OperationalReviewId, or);
                            }

                            ApiCalls.DeleteWelderQualification(wq.Welder_QualificationId);
                        }
                    }
                    else
                    {
                        wa = ApiCalls.ReadWeldingAction(((WeldingAction)selectedTag.getTagObject()).WeldingActionId);

                        if (wa.NewWeldingForm.Status == Actions.Complete)
                        {
                            OperationalReview or = ApiCalls.ReadOperationalReview(wa.NewWeldingForm.OperationalReview.OperationalReviewId);
                            or.WeldersAmount = (short)(or.WeldersAmount - 1 ?? 0);
                            ApiCalls.UpdateOperationalReview(or.OperationalReviewId, or);
                        }
                    }

                    break;
                case TagType.WPQR:

                    if (selectedTag.getTagObject() is WPQR)
                    {
                        WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)selectedTag.getTagObject()).WPQRId);

                        if (wpqr.Status != Actions.Complete)
                        {
                            wa = ApiCalls.ReadWeldingAction(wpqr.Welder_Qualification.WeldingAction.WeldingActionId);

                            if (wa.NewWeldingForm.Status == Actions.Complete)
                            {
                                OperationalReview or = ApiCalls.ReadOperationalReview(wa.NewWeldingForm.OperationalReview.OperationalReviewId);
                                or.WPQRAmount = (short)(or.WPQRAmount - 1 ?? 0);
                                ApiCalls.UpdateOperationalReview(or.OperationalReviewId, or);
                            }

                            ApiCalls.DeleteWPQR(wpqr.WPQRId);
                        }
                    }
                    else
                    {
                        wa = ApiCalls.ReadWeldingAction(((WeldingAction)selectedTag.getTagObject()).WeldingActionId);

                        if (wa.NewWeldingForm.Status == Actions.Complete)
                        {
                            OperationalReview or = ApiCalls.ReadOperationalReview(wa.NewWeldingForm.OperationalReview.OperationalReviewId);
                            or.WPQRAmount = (short)(or.WPQRAmount - 1 ?? 0);
                            ApiCalls.UpdateOperationalReview(or.OperationalReviewId, or);
                        }
                    }

                    break;
                case TagType.WPS:

                    if (selectedTag.getTagObject() is WPS)
                    {
                        WPS wps = ApiCalls.ReadWPS(((WPS)selectedTag.getTagObject()).WPSId);

                        if (wps.Status != Actions.Complete)
                        {
                            wa = ApiCalls.ReadWeldingAction(wps.WPQR.Welder_Qualification.WeldingAction.WeldingActionId);

                            if (wa.NewWeldingForm.Status == Actions.Complete)
                            {
                                OperationalReview or = ApiCalls.ReadOperationalReview(wa.NewWeldingForm.OperationalReview.OperationalReviewId);
                                or.WPSAmount = (short)(or.WPSAmount - 1 ?? 0);
                                ApiCalls.UpdateOperationalReview(or.OperationalReviewId, or);
                            }

                            ApiCalls.DeleteWPS(wps.WPSId);
                        }
                    }
                    else
                    {
                        wa = ApiCalls.ReadWeldingAction(((WeldingAction)selectedTag.getTagObject()).WeldingActionId);

                        if (wa.NewWeldingForm.Status == Actions.Complete)
                        {
                            OperationalReview or = ApiCalls.ReadOperationalReview(wa.NewWeldingForm.OperationalReview.OperationalReviewId);
                            or.WPSAmount = (short)(or.WPSAmount - 1 ?? 0);
                            ApiCalls.UpdateOperationalReview(or.OperationalReviewId, or);
                        }
                    }

                    break;
            }

            Load_Jobs();
        }

        private void btnHomeResetDb_DoubleClick(object sender, EventArgs e)
        {
            string ENumber = Application.Cookies["EmployeeNumber"].TrimStart('E');

            ApiCalls.InitialiseDb(ENumber);
        }
        #endregion

        #region Helper Methods
        private void AddTask(TagType taskType)
        {
            if (lvHomeJobs.SelectedIndex < 0)
            {
                return;
            }

            Tag selectedTag = (Tag)lvHomeJobs.Items[lvHomeJobs.SelectedIndex].Tag;

            if (selectedTag == null || selectedTag.getTagType() != TagType.Job)
            {
                return;
            }

            Job selectedJob = ApiCalls.ReadJob(((Job)selectedTag.getTagObject()).JobId);

            WeldingAction wa = selectedJob.WeldingActions.FirstOrDefault(w => w.NewWeldingForm.Status == Actions.Complete);

            if (wa == null)
            {
                return;
            }

            wa = ApiCalls.ReadWeldingAction(wa.WeldingActionId);

            if (wa.NewWeldingForm.OperationalReview == null)
            {
                return;
            }

            OperationalReview or = ApiCalls.ReadOperationalReview(wa.NewWeldingForm.OperationalReview.OperationalReviewId);

            switch (taskType)
            {
                case TagType.Welder_Qualification:
                    or.WeldersAmount = (short)((or.WeldersAmount ?? 0) + 1);
                    break;
                case TagType.WPQR:
                    or.WPQRAmount = (short)((or.WPQRAmount ?? 0) + 1);
                    break;
                case TagType.WPS:
                    or.WPSAmount = (short)((or.WPSAmount ?? 0) + 1);
                    break;
            }

            ApiCalls.UpdateOperationalReview(or.OperationalReviewId, or);

            Job updatedJob = ApiCalls.ReadJob(selectedJob.JobId);
            lvHomeJobs.Items[lvHomeJobs.SelectedIndex].Tag = new Tag(updatedJob, TagType.Job);
            Load_Actions(updatedJob);
        }

        private bool CheckComplete(Job job)
        {
            if (adminMode)
            {
                return false;
            }

            return GenericHelpers.CheckComplete(job);
        }

        private void changeButtonColors()
        {
            this.SuspendLayout();

            SetBackForeColours(btnHomeRequest, "@toolbar", "@controlText");
            SetBackForeColours(btnWelderQualification, "@toolbar", "@controlText");
            SetBackForeColours(btnHomeWPQR, "@toolbar", "@controlText");
            SetBackForeColours(btnHomeWPS, "@toolbar", "@controlText");

            if (this.Tag == null)
            {
                this.ResumeLayout();
                return;
            }


            switch (((Tag)this.Tag).getTagType())
            {
                case TagType.New_Welding_Form:
                    SetBackForeColours(btnHomeRequest, "@buttonFace", "@buttonText");
                    break;

                case TagType.Welder_Qualification:
                    SetBackForeColours(btnWelderQualification, "@buttonFace", "@buttonText");
                    break;

                case TagType.WPQR:
                    SetBackForeColours(btnHomeWPQR, "@buttonFace", "@buttonText");
                    break;

                case TagType.WPS:
                    SetBackForeColours(btnHomeWPS, "@buttonFace", "@buttonText");
                    break;
            }

            this.ResumeLayout();
        }

        private string GetFilterJobString()
        {
            return txtHomeJob.Text.Length <= 6 ? txtHomeJob.Text.Replace("-", " ").Trim() : txtHomeJob.Text.Trim();
        }

        private void FilterByCBO(ComboBox cbo, int colIdx)
        {
            Load_Actions_For_Job();

            if (cbo.SelectedIndex < 0)
            {
                return;
            }

            for (int i = lvHomeActions.Items.Count - 1; i >= 0; i--)
            {
                ListViewItem item = lvHomeActions.Items[i];
                if (item.SubItems[colIdx].Text != cbo.Text)
                {
                    lvHomeActions.Items.Remove(lvHomeActions.Items[i]);
                }
            }
        }

        private void ResizeAdminBar()
        {
            tlpHomeButtons.ColumnStyles[tlpHomeButtons.GetColumn(btnHomeDeleteJob)].Width = adminMode ? 50 : 0;
            tlpHomeActions.ColumnStyles[tlpHomeActions.GetColumn(tlpHomeButtons)].Width = adminMode ? 20 : 10;
            tlpHomeFilter.ColumnStyles[tlpHomeFilter.GetColumn(btnHomeRefresh)].Width = adminMode ? 20 : 10;
        }
        #endregion

        #region Filter Functions
        private void btnHomeClear_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(GetFilterJobString()))
            {
                Load_Actions_For_Job();
            }
            else
            {
                Load_Jobs();
            }

            txtHomeJob.Text = string.Empty;

            cboHomeStatus.SelectedItem = null;
            cboHomeType.SelectedItem = null;

            cboHomeStatus.Refresh();
            cboHomeType.Refresh();
        }

        private void txtHomeJob_Click(object sender, EventArgs e)
        {
            string filterTxt = GetFilterJobString();
            txtHomeJob.Select(filterTxt.Length, 0);
        }

        private void txtHomeJob_KeyPress(object sender, KeyPressEventArgs e)
        {
            string filterTxt = GetFilterJobString();
            Load_Jobs(filterTxt);
        }

        private void cboHomeStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            FilterByCBO(cboHomeStatus, 0);
        }

        private void cboHomeType_SelectedIndexChanged(object sender, EventArgs e)
        {
            FilterByCBO(cboHomeType, 1);
        }
        #endregion

        private void lblHomeNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }

        private void lblHomeTitle_DoubleClick(object sender, EventArgs e)
        {
            if (adminUsers.Contains(Application.Cookies["EmployeeNumber"].TrimStart('E')))
            {
                adminMode = !adminMode;

                ResizeAdminBar();
            }
        }
    }
}
