﻿using QAWebApiClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using ToolTrack;
using Welding.DAL;
using Wisej.Web;

namespace WeldingManagement.UserControls.HomeControls
{
    public partial class uc_hmLogin : Wisej.Web.UserControl
    {
        private readonly float[] portraitColStyles = new float[] { 20F, 60F, 20F };
        private readonly float[] landscapeColStyles = new float[] { 30F, 40F, 30F };

        public uc_hmLogin()
        {
            InitializeComponent();
        }

        private void loginPad_OnChange()
        {
            if (loginPad.EmployeeIdAndDOB.Length == 10)
            {
                ProcessLogin();
            }
            else
            {
                loginPad.HidePassword = false;
            }
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user successfully logs in")]
        public event EventHandler userLoginSuccess;
        private void ProcessLogin()
        {
            loginPad.HidePassword = true;
            loginPad.Refresh();

            if (!ApiCalls.ValidLogin(loginPad.EmployeeIdAndDOB))
            {
                HandleInvalidLogin();
                return;
            }

            StoreLoginDetails();
            FetchAndStoreEmployeeDetails();

            userLoginSuccess?.Invoke(this, new EventArgs());

            ResetNumPad();
        }

        private void StoreLoginDetails()
        {
            Wisej.Web.Application.Cookies.Add("LoggedIn", "True", DateTime.Now.AddDays(30));
            Application.Session.LoggedIn = Application.Cookies["LoggedIn"];
        }

        private void FetchAndStoreEmployeeDetails()
        {
            try
            {
                string empNumber = loginPad.EmployeeIdAndDOB.Substring(0, 4);
                PeopleEF.Person person = ApiCalls.GetPerson(empNumber);

                string EmployeeName = person.EmployeeName;
                string Department = person.Department;
                string WorkRole = person.WorkRole.ToUpper().Trim();
                string EmployeeNumber = person.EmployeeNumber;

                SetEmployeeDetailsCookies(EmployeeName, Department, WorkRole, EmployeeNumber);
                Application.Session.WorkRole = WorkRole;

                CheckAndUpdateAccessPermissions(empNumber);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error fetching employee details: " + ex.Message);
                // Handle exception
            }
        }

        private void SetEmployeeDetailsCookies(string employeeName, string department, string workRole, string EmployeeNumber)
        {
            Wisej.Web.Application.Cookies.Add("EmployeeName", employeeName, DateTime.Now.AddYears(30));
            Wisej.Web.Application.Cookies.Add("Department", department, DateTime.Now.AddYears(30));
            Wisej.Web.Application.Cookies.Add("Role", workRole, DateTime.Now.AddYears(30));
            Wisej.Web.Application.Cookies.Add("EmployeeNumber", EmployeeNumber, DateTime.Now.AddYears(30));

            Application.Session.EmployeeName = employeeName;
            Application.Session.Department = department;
            Application.Session.WorkRole = workRole;
        }

        private void CheckAndUpdateAccessPermissions(string empNumber)
        {
            var specialAccessNumbers = new List<string> { "2596", "3215", "1541", "2930" };
            if (specialAccessNumbers.Any(empNumber.Contains))
            {
                Application.Session.WeldingAccess = "ADMIN";
            }
            else
            {
                Application.Session.WeldingAccess = "DENIED";
            }
            Wisej.Web.Application.Cookies.Add("WeldingAccess", Application.Session.WeldingAccess, DateTime.Now.AddYears(30));
        }

        private void HandleInvalidLogin()
        {
            // Handle invalid login
            //MessageBox.Show("Log in error ??", "ERROR: LOG IN", MessageBoxButtons.OK, MessageBoxIcon.Error);
            ResetNumPad();
        }

        private void ResetNumPad()
        {
            loginPad.EmployeeIdAndDOB = "";
            loginPad.HidePassword = false;
            loginPad.Refresh();
        }

        private void loginPad_ResponsiveProfileChanged(object sender, ResponsiveProfileChangedEventArgs e)
        {
            //Used to be landscape and rotated to portrait, so collapse side menu list so its easier
            if (!IsLandscape())
            {
                //Outer Container Cols
                ChangeColStyles(LayoutMain, portraitColStyles);
            }
            else
            {
                //Outer Container Cols
                ChangeColStyles(LayoutMain, landscapeColStyles);
            }
        }

        bool IsLandscape()
        {
            bool isLandscape = true;
            var width = Application.Browser.Size.Width;
            var height = Application.Browser.Size.Height;
            var aspectRatio = (double)width / height;
            const double landscapeThreshold = 1.0;
            if (aspectRatio < landscapeThreshold) { isLandscape = false; }
            return isLandscape;
        }

        private void ChangeColStyles(TableLayoutPanel panel, float[] percentages)
        {
            for (int i = 0; i < percentages.Length; i++) { panel.ColumnStyles[i].Width = percentages[i]; }
            panel.PerformLayout();
        }
    }
}
