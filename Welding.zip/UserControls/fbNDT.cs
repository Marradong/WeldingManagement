﻿using System;
using System.ComponentModel;
using System.Drawing;
using Wisej.Web;

namespace WeldingManagement
{
    public partial class fbNDT : Wisej.Web.UserControl
    {
        #region FlipBoard
        bool IsDesignMode = (LicenseManager.UsageMode == LicenseUsageMode.Designtime);
        bool checkCancel = true;

        [Category("Board")]
        [Description("Number to display")]
        private void Boards_Selecting(object sender, TabControlCancelEventArgs e)
        {
            e.Cancel = checkCancel;
            checkCancel = true;
        }

        private BoardId showBoard = BoardId.Entry;
        public BoardId ShowBoard
        {
            get
            {
                return showBoard;
            }
            set
            {
                showBoard = value;
                checkCancel = false;

                //Change Boards
                Boards.SelectedIndex = (int)showBoard;
                Boards.Refresh();

                //Exectute Board Show Code
                switch (ShowBoard)
                {
                    case BoardId.Entry:

                        string LoggedIn = "True";
                        if (LoggedIn == "True")
                        {
                            Boards.SelectedIndex = (int)BoardId.Entry;
                            Boards.Refresh();
                        }
                        else
                        {
                            //txtUserName.Text = txtEmpId.Text = txtPassword.Text = "";
                            //if (txtUserName.Text == "")
                            //    txtUserName.Text = Environment.UserName;

                            Boards.SelectedIndex = (int)BoardId.Entry;
                        }

                        break;
                    case BoardId.Popup:
                        break;
                }
            }
        }

        public enum BoardId
        {
            Entry = 0,
            Popup = 1
        }

        public fbNDT()
        {
            InitializeComponent();

            Boards.BorderStyle = Wisej.Web.BorderStyle.None;
            Boards.ItemSize = new Size(1, 1); //Hide Tabs - they are not selectable
            Boards.SizeMode = TabSizeMode.Fixed;

            foreach (TabPage tab in Boards.TabPages)
            {
                tab.Text = "";
                tab.BackColor = Color.White;
            }
        }
        #endregion

        private void btnEntryNext_Click(object sender, EventArgs e)
        {
            // TODO
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on entry screen")]
        public event EventHandler btnEntryHomeClick;
        private void btnEntryHome_Click(object sender, EventArgs e)
        {
            btnEntryHomeClick?.Invoke(this, e);
            this.ShowBoard = BoardId.Entry;
            this.Refresh();
        }

        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks back button on entry screen")]
        public event EventHandler btnEntryBackClick;
        private void btnEntryBack_Click(object sender, EventArgs e)
        {
            btnEntryBackClick?.Invoke(this, e);
            this.ShowBoard = BoardId.Entry;
            this.Refresh();
        }

        private void btnEntryAdd_Click(object sender, EventArgs e)
        {
            if(!(string.IsNullOrEmpty(txtEntryID.Text) || 
                string.IsNullOrEmpty(cbEntryWPS.Text) || 
                string.IsNullOrEmpty(dtpEntryDate.Text) || 
                string.IsNullOrEmpty(txtEntryReport.Text) || 
                string.IsNullOrEmpty(txtEntryType.Text) ||
                string.IsNullOrEmpty(txtEntryPNo.Text))) 
            {
                ListViewItem newQual = new ListViewItem(new[] 
                    { 
                        txtEntryID.Text, 
                        cbEntryWPS.Text, 
                        dtpEntryDate.Text, 
                        txtEntryReport.Text, 
                        txtEntryType.Text, 
                        txtEntryPNo.Text 
                    }
                );


                lvEntryQuals.Items.Add(newQual);
                lvEntryQuals.Refresh();

                txtEntryID.Clear();
                cbEntryWPS.Text = null;
                dtpEntryDate.Value = DateTime.Now;
                txtEntryReport.Clear();
                txtEntryType.SelectedItem = null;
                txtEntryPNo.Clear();
            }
        }

        private void lvEntryQuals_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtEntryID.Text=lvEntryQuals.SelectedItems[0].SubItems[chID.Index].Text;
            cbEntryWPS.Text=lvEntryQuals.SelectedItems[0].SubItems[chWPS.Index].Text;
            dtpEntryDate.Value=DateTime.Parse(lvEntryQuals.SelectedItems[0].SubItems[chDate.Index].Text);
        }

        private void clbWPSList_AfterItemCheck(object sender, ItemCheckEventArgs e)
        {
            string comboString = "";

            foreach (string checkedItem in clbWPSList.CheckedItems)
            {
                comboString += checkedItem + ", ";
            }

            if (!comboString.Equals("")) 
            {
                comboString = comboString.Remove(comboString.Length-2);
            }

            this.cbEntryWPS.Text = comboString;
        }

        private void txtEntryPNo_MouseDown(object sender, MouseEventArgs e)
        {
            txtEntryPNo.SelectionStart = 1;
        }

        private void txtEntryID_MouseDown(object sender, MouseEventArgs e)
        {
            txtEntryID.SelectionStart = 1;
        }

        private void txtEntrySearch_KeyDown(object sender, KeyEventArgs e)
        {
            //TODO
        }
    }
}
