﻿namespace WeldingManagement.UserControls.SearchControls
{
    partial class uc_scJob
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_scJob));
            this.tableLayoutPanel14 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel22 = new Wisej.Web.TableLayoutPanel();
            this.tlpDocuments = new Wisej.Web.TableLayoutPanel();
            this.label3 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.txtSearchFilter5 = new Wisej.Web.TextBox();
            this.txtSearchFilter4 = new Wisej.Web.TextBox();
            this.txtSearchFilter3 = new Wisej.Web.TextBox();
            this.txtSearchFilter2 = new Wisej.Web.TextBox();
            this.txtSearchFilter1 = new Wisej.Web.TextBox();
            this.cboSearchFilter5 = new Wisej.Web.ComboBox();
            this.lvSearch = new Wisej.Web.ListView();
            this.tableLayoutPanel26 = new Wisej.Web.TableLayoutPanel();
            this.tableLayoutPanel27 = new Wisej.Web.TableLayoutPanel();
            this.btnSearchView = new Wisej.Web.Button();
            this.btnSearchFilters = new Wisej.Web.Button();
            this.btnSearchHome = new Wisej.Web.Button();
            this.tableLayoutPanel28 = new Wisej.Web.TableLayoutPanel();
            this.lblSearchNote = new Wisej.Web.LinkLabel();
            this.lblSearchTitle = new Wisej.Web.Label();
            this.cboSearchFilter4 = new Wisej.Web.ComboBox();
            this.cboSearchFilter3 = new Wisej.Web.ComboBox();
            this.cboSearchFilter2 = new Wisej.Web.ComboBox();
            this.cboSearchFilter1 = new Wisej.Web.ComboBox();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tlpDocuments.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.BackColor = System.Drawing.Color.FromName("@toolbar");
            this.tableLayoutPanel14.ColumnCount = 3;
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 95F));
            this.tableLayoutPanel14.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel22, 1, 3);
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel28, 1, 1);
            this.tableLayoutPanel14.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 5;
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 72.5F));
            this.tableLayoutPanel14.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 2.5F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(1212, 615);
            this.tableLayoutPanel14.TabIndex = 8;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 90F));
            this.tableLayoutPanel22.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 10F));
            this.tableLayoutPanel22.Controls.Add(this.tlpDocuments, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel26, 1, 0);
            this.tableLayoutPanel22.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(33, 156);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(1145, 439);
            this.tableLayoutPanel22.TabIndex = 1;
            // 
            // tlpDocuments
            // 
            this.tlpDocuments.ColumnCount = 2;
            this.tlpDocuments.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 25F));
            this.tlpDocuments.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 75F));
            this.tlpDocuments.Controls.Add(this.label3, 1, 0);
            this.tlpDocuments.Controls.Add(this.label2, 0, 0);
            this.tlpDocuments.Controls.Add(this.txtSearchFilter5, 1, 5);
            this.tlpDocuments.Controls.Add(this.txtSearchFilter4, 1, 4);
            this.tlpDocuments.Controls.Add(this.txtSearchFilter3, 1, 3);
            this.tlpDocuments.Controls.Add(this.txtSearchFilter2, 1, 2);
            this.tlpDocuments.Controls.Add(this.txtSearchFilter1, 1, 1);
            this.tlpDocuments.Controls.Add(this.cboSearchFilter5, 0, 5);
            this.tlpDocuments.Controls.Add(this.cboSearchFilter4, 0, 4);
            this.tlpDocuments.Controls.Add(this.cboSearchFilter3, 0, 3);
            this.tlpDocuments.Controls.Add(this.cboSearchFilter2, 0, 2);
            this.tlpDocuments.Controls.Add(this.cboSearchFilter1, 0, 1);
            this.tlpDocuments.Controls.Add(this.lvSearch, 0, 6);
            this.tlpDocuments.Dock = Wisej.Web.DockStyle.Fill;
            this.tlpDocuments.Location = new System.Drawing.Point(3, 3);
            this.tlpDocuments.Name = "tlpDocuments";
            this.tlpDocuments.RowCount = 7;
            this.tlpDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tlpDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tlpDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tlpDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tlpDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tlpDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 6F));
            this.tlpDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 70F));
            this.tlpDocuments.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tlpDocuments.Size = new System.Drawing.Size(1024, 433);
            this.tlpDocuments.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label3.Dock = Wisej.Web.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(259, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(762, 18);
            this.label3.TabIndex = 18;
            this.label3.Text = "Filter By Column Contents";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromName("@hotTrack");
            this.label2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(250, 18);
            this.label2.TabIndex = 17;
            this.label2.Text = "Select Filter Columns";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSearchFilter5
            // 
            this.txtSearchFilter5.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSearchFilter5.Location = new System.Drawing.Point(259, 123);
            this.txtSearchFilter5.Name = "txtSearchFilter5";
            this.txtSearchFilter5.Size = new System.Drawing.Size(762, 18);
            this.txtSearchFilter5.TabIndex = 14;
            this.txtSearchFilter5.TextChanged += new System.EventHandler(this.txtSearchFilter1_TextChanged);
            // 
            // txtSearchFilter4
            // 
            this.txtSearchFilter4.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSearchFilter4.Location = new System.Drawing.Point(259, 99);
            this.txtSearchFilter4.Name = "txtSearchFilter4";
            this.txtSearchFilter4.Size = new System.Drawing.Size(762, 18);
            this.txtSearchFilter4.TabIndex = 13;
            this.txtSearchFilter4.TextChanged += new System.EventHandler(this.txtSearchFilter1_TextChanged);
            // 
            // txtSearchFilter3
            // 
            this.txtSearchFilter3.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSearchFilter3.Location = new System.Drawing.Point(259, 75);
            this.txtSearchFilter3.Name = "txtSearchFilter3";
            this.txtSearchFilter3.Size = new System.Drawing.Size(762, 18);
            this.txtSearchFilter3.TabIndex = 12;
            this.txtSearchFilter3.TextChanged += new System.EventHandler(this.txtSearchFilter1_TextChanged);
            // 
            // txtSearchFilter2
            // 
            this.txtSearchFilter2.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSearchFilter2.Location = new System.Drawing.Point(259, 51);
            this.txtSearchFilter2.Name = "txtSearchFilter2";
            this.txtSearchFilter2.Size = new System.Drawing.Size(762, 18);
            this.txtSearchFilter2.TabIndex = 11;
            this.txtSearchFilter2.TextChanged += new System.EventHandler(this.txtSearchFilter1_TextChanged);
            // 
            // txtSearchFilter1
            // 
            this.txtSearchFilter1.Dock = Wisej.Web.DockStyle.Fill;
            this.txtSearchFilter1.Location = new System.Drawing.Point(259, 27);
            this.txtSearchFilter1.Name = "txtSearchFilter1";
            this.txtSearchFilter1.Size = new System.Drawing.Size(762, 18);
            this.txtSearchFilter1.TabIndex = 10;
            this.txtSearchFilter1.TextChanged += new System.EventHandler(this.txtSearchFilter1_TextChanged);
            // 
            // cboSearchFilter5
            // 
            this.cboSearchFilter5.Dock = Wisej.Web.DockStyle.Fill;
            this.cboSearchFilter5.Location = new System.Drawing.Point(3, 123);
            this.cboSearchFilter5.Name = "cboSearchFilter5";
            this.cboSearchFilter5.Size = new System.Drawing.Size(250, 18);
            this.cboSearchFilter5.TabIndex = 9;
            // 
            // lvSearch
            // 
            this.tlpDocuments.SetColumnSpan(this.lvSearch, 2);
            this.lvSearch.CssStyle = "border-radius: 4px;";
            this.lvSearch.Dock = Wisej.Web.DockStyle.Fill;
            this.lvSearch.Location = new System.Drawing.Point(3, 147);
            this.lvSearch.Name = "lvSearch";
            this.lvSearch.Size = new System.Drawing.Size(1018, 283);
            this.lvSearch.TabIndex = 4;
            this.lvSearch.View = Wisej.Web.View.Details;
            this.lvSearch.SelectedIndexChanged += new System.EventHandler(this.lvSearch_SelectedIndexChanged);
            this.lvSearch.Resize += new System.EventHandler(this.lvSearch_Resize);
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 1;
            this.tableLayoutPanel26.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Controls.Add(this.tableLayoutPanel27, 0, 0);
            this.tableLayoutPanel26.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(1033, 3);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(109, 433);
            this.tableLayoutPanel26.TabIndex = 5;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.BackColor = System.Drawing.Color.FromName("@window");
            this.tableLayoutPanel27.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel27.ColumnCount = 1;
            this.tableLayoutPanel27.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel27.Controls.Add(this.btnSearchView, 0, 3);
            this.tableLayoutPanel27.Controls.Add(this.btnSearchFilters, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.btnSearchHome, 0, 4);
            this.tableLayoutPanel27.CssStyle = "border-radius: 4px;";
            this.tableLayoutPanel27.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 5;
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 20F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(103, 427);
            this.tableLayoutPanel27.TabIndex = 4;
            // 
            // btnSearchView
            // 
            this.btnSearchView.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnSearchView.Dock = Wisej.Web.DockStyle.Fill;
            this.btnSearchView.Location = new System.Drawing.Point(3, 258);
            this.btnSearchView.Name = "btnSearchView";
            this.btnSearchView.Size = new System.Drawing.Size(95, 79);
            this.btnSearchView.TabIndex = 4;
            this.btnSearchView.Text = "View Documents";
            this.btnSearchView.Visible = false;
            this.btnSearchView.Click += new System.EventHandler(this.btnSearchView_Click);
            // 
            // btnSearchFilters
            // 
            this.btnSearchFilters.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnSearchFilters.Dock = Wisej.Web.DockStyle.Fill;
            this.btnSearchFilters.Location = new System.Drawing.Point(3, 3);
            this.btnSearchFilters.Name = "btnSearchFilters";
            this.btnSearchFilters.Size = new System.Drawing.Size(95, 79);
            this.btnSearchFilters.TabIndex = 2;
            this.btnSearchFilters.Text = "Clear Filters";
            this.btnSearchFilters.Click += new System.EventHandler(this.btnSearchFilters_Click);
            // 
            // btnSearchHome
            // 
            this.btnSearchHome.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.btnSearchHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnSearchHome.Location = new System.Drawing.Point(3, 343);
            this.btnSearchHome.Name = "btnSearchHome";
            this.btnSearchHome.Size = new System.Drawing.Size(95, 79);
            this.btnSearchHome.TabIndex = 1;
            this.btnSearchHome.Text = "Home";
            this.btnSearchHome.Click += new System.EventHandler(this.btnSearchHome_Click);
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.ColumnCount = 1;
            this.tableLayoutPanel28.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel28.Controls.Add(this.lblSearchNote, 0, 1);
            this.tableLayoutPanel28.Controls.Add(this.lblSearchTitle, 0, 0);
            this.tableLayoutPanel28.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(33, 18);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 2;
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 65F));
            this.tableLayoutPanel28.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 35F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(1145, 117);
            this.tableLayoutPanel28.TabIndex = 0;
            // 
            // lblSearchNote
            // 
            this.lblSearchNote.AutoSize = true;
            this.lblSearchNote.BackColor = System.Drawing.Color.FromName("@menuHighlight");
            this.lblSearchNote.CssStyle = "border-radius: 4px;\r\nbox-shadow: inset 0px -8px 12px rgba(255, 255, 255, 0.4), in" +
    "set 0px 4px 6px rgba(255, 255, 255, 0.2);\r\nborder: 1px solid rgba(202, 80, 16, 0" +
    ".5);\r\noverflow: hidden;";
            this.lblSearchNote.Dock = Wisej.Web.DockStyle.Fill;
            this.lblSearchNote.LinkArea = new Wisej.Web.LinkArea(333, 84);
            this.lblSearchNote.LinkBehavior = Wisej.Web.LinkBehavior.HoverUnderline;
            this.lblSearchNote.Location = new System.Drawing.Point(6, 79);
            this.lblSearchNote.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.lblSearchNote.Name = "lblSearchNote";
            this.lblSearchNote.Size = new System.Drawing.Size(1133, 35);
            this.lblSearchNote.TabIndex = 3;
            this.lblSearchNote.Text = resources.GetString("lblSearchNote.Text");
            this.lblSearchNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSearchTitle
            // 
            this.lblSearchTitle.AutoSize = true;
            this.lblSearchTitle.BackColor = System.Drawing.Color.FromName("@window");
            this.lblSearchTitle.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.lblSearchTitle.CssStyle = "border-radius: 4px;";
            this.lblSearchTitle.Dock = Wisej.Web.DockStyle.Fill;
            this.lblSearchTitle.Font = new System.Drawing.Font("default", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblSearchTitle.Location = new System.Drawing.Point(6, 3);
            this.lblSearchTitle.Margin = new Wisej.Web.Padding(6, 3, 6, 3);
            this.lblSearchTitle.Name = "lblSearchTitle";
            this.lblSearchTitle.Size = new System.Drawing.Size(1133, 70);
            this.lblSearchTitle.TabIndex = 0;
            this.lblSearchTitle.Text = "Search Jobs";
            this.lblSearchTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cboSearchFilter4
            // 
            this.cboSearchFilter4.Dock = Wisej.Web.DockStyle.Fill;
            this.cboSearchFilter4.Location = new System.Drawing.Point(3, 99);
            this.cboSearchFilter4.Name = "cboSearchFilter4";
            this.cboSearchFilter4.Size = new System.Drawing.Size(250, 18);
            this.cboSearchFilter4.TabIndex = 8;
            // 
            // cboSearchFilter3
            // 
            this.cboSearchFilter3.Dock = Wisej.Web.DockStyle.Fill;
            this.cboSearchFilter3.Location = new System.Drawing.Point(3, 75);
            this.cboSearchFilter3.Name = "cboSearchFilter3";
            this.cboSearchFilter3.Size = new System.Drawing.Size(250, 18);
            this.cboSearchFilter3.TabIndex = 7;
            // 
            // cboSearchFilter2
            // 
            this.cboSearchFilter2.Dock = Wisej.Web.DockStyle.Fill;
            this.cboSearchFilter2.Location = new System.Drawing.Point(3, 51);
            this.cboSearchFilter2.Name = "cboSearchFilter2";
            this.cboSearchFilter2.Size = new System.Drawing.Size(250, 18);
            this.cboSearchFilter2.TabIndex = 6;
            // 
            // cboSearchFilter1
            // 
            this.cboSearchFilter1.Dock = Wisej.Web.DockStyle.Fill;
            this.cboSearchFilter1.Location = new System.Drawing.Point(3, 27);
            this.cboSearchFilter1.Name = "cboSearchFilter1";
            this.cboSearchFilter1.Size = new System.Drawing.Size(250, 18);
            this.cboSearchFilter1.TabIndex = 5;
            // 
            // uc_scJob
            // 
            this.Controls.Add(this.tableLayoutPanel14);
            this.Name = "uc_scJob";
            this.Size = new System.Drawing.Size(1212, 615);
            this.VisibleChanged += new System.EventHandler(this.uc_scJob_VisibleChanged);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tlpDocuments.ResumeLayout(false);
            this.tlpDocuments.PerformLayout();
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel28.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel14;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel22;
        private Wisej.Web.TableLayoutPanel tlpDocuments;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label2;
        private Wisej.Web.TextBox txtSearchFilter5;
        private Wisej.Web.TextBox txtSearchFilter4;
        private Wisej.Web.TextBox txtSearchFilter3;
        private Wisej.Web.TextBox txtSearchFilter2;
        private Wisej.Web.TextBox txtSearchFilter1;
        private Wisej.Web.ComboBox cboSearchFilter5;
        private Wisej.Web.ListView lvSearch;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel26;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel27;
        private Wisej.Web.Button btnSearchView;
        private Wisej.Web.Button btnSearchFilters;
        private Wisej.Web.Button btnSearchHome;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel28;
        private Wisej.Web.LinkLabel lblSearchNote;
        private Wisej.Web.Label lblSearchTitle;
        private Wisej.Web.ComboBox cboSearchFilter4;
        private Wisej.Web.ComboBox cboSearchFilter3;
        private Wisej.Web.ComboBox cboSearchFilter2;
        private Wisej.Web.ComboBox cboSearchFilter1;
    }
}
