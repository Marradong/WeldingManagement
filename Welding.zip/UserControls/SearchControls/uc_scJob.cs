﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using ApiClient;
using Welding.DAL;
using WeldingManagement.Helpers;
using WeldingManagement.UserControls.PopupControls;
using Wisej.Web;

namespace WeldingManagement.UserControls.SearchControls
{
    public partial class uc_scJob : Wisej.Web.UserControl
    {
        private up_rqFilesView up_rqFilesView1;
        private Panel overlayPanel;

        public uc_scJob()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = System.Drawing.Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        private List<string> columns = new List<string>()
        {
            "Job Number",
            "Welder Qualification/s Completed On Job",
            "WPQR/s Developed On Job",
            "WPS/s Developed On Job",
            "WPS/s Developed",
            "WPS/s Allocated",
            "Welding Action's Status"
        };

        #region Navigation
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on search screen")]
        public event EventHandler btnSearchHomeClick;
        private void btnSearchHome_Click(object sender, EventArgs e)
        {
            btnSearchHomeClick?.Invoke(this, e);
        }
        #endregion

        private void Load_Action()
        {
            lvSearch.Columns.Clear();

            foreach (string column in columns)
            {
                lvSearch.Columns.Add(new ColumnHeader() { Text = column.ToString(), Name = column.ToString() });
                cboSearchFilter1.Items.Add(column.ToString());
                cboSearchFilter2.Items.Add(column.ToString());
                cboSearchFilter3.Items.Add(column.ToString());
                cboSearchFilter4.Items.Add(column.ToString());
                cboSearchFilter5.Items.Add(column.ToString());
            }

            AddFilteredItems();
        }

        private void uc_scJob_VisibleChanged(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill)
            {
                return;
            }

            Load_Action();
        }

        private void AddFilteredItems()
        {
            List<Job> jobs = ApiCalls.ReadJobs();

            if (jobs == null || jobs.Count <= 0)
            {
                return;
            }

            List<ListViewItem> lvItems = new List<ListViewItem>();
            string filter, propertyName;

            foreach (Job job in jobs)
            {
                WeldingAction wa = job.WeldingActions.First();

                ListViewItem lvItem = new ListViewItem(new string[]
                {
                    job.JobNo,
                    wa.Welder_Qualification.Count() > 0 ? "Yes" : "No",
                    wa.WPQRs.Count() > 0 ? "Yes" : "No",
                    wa.WPS.Count() > 0 ? "Yes" : "No",
                    string.Join(",", wa.WPS.Select(w => w.WPSNumber)),
                    string.Join(",", wa.NewWeldingForm.OperationalReview.WPSNumberLists.Select(w => w.WPSNumber)),
                    GenericHelpers.CheckComplete(job) ? "Complete" : "In Progress"
                })
                {
                    Tag = new Tag(job, TagType.Job)
                };

                lvItems.Add(lvItem);
            }

            if (txtSearchFilter1.Text != "" && cboSearchFilter1.SelectedItem != null)
            {
                filter = txtSearchFilter1.Text;
                propertyName = cboSearchFilter1.SelectedItem.ToString();

                lvItems = GenericHelpers.FilterItems(lvItems, filter, propertyName, lvSearch);
            }

            if (txtSearchFilter2.Text != "" && cboSearchFilter2.SelectedItem != null)
            {
                filter = txtSearchFilter2.Text;
                propertyName = cboSearchFilter2.SelectedItem.ToString();

                lvItems = GenericHelpers.FilterItems(lvItems, filter, propertyName, lvSearch);
            }

            if (txtSearchFilter3.Text != "" && cboSearchFilter3.SelectedItem != null)
            {
                filter = txtSearchFilter1.Text;
                propertyName = cboSearchFilter1.SelectedItem.ToString();

                lvItems = GenericHelpers.FilterItems(lvItems, filter, propertyName, lvSearch);
            }

            if (txtSearchFilter4.Text != "" && cboSearchFilter4.SelectedItem != null)
            {
                filter = txtSearchFilter1.Text;
                propertyName = cboSearchFilter1.SelectedItem.ToString();

                lvItems = GenericHelpers.FilterItems(lvItems, filter, propertyName, lvSearch);
            }

            if (txtSearchFilter5.Text != "" && cboSearchFilter5.SelectedItem != null)
            {
                filter = txtSearchFilter1.Text;
                propertyName = cboSearchFilter1.SelectedItem.ToString();

                lvItems = GenericHelpers.FilterItems(lvItems, filter, propertyName, lvSearch);
            }

            lvSearch.Items.Clear();
            lvSearch.Items.AddRange(lvItems.ToArray());
            lvSearch.Refresh();

            UIFormatting.ResizeColumnsFor(lvSearch);
        }

        private void txtSearchFilter1_TextChanged(object sender, EventArgs e)
        {
            AddFilteredItems();
        }

        private void btnSearchFilters_Click(object sender, EventArgs e)
        {
            cboSearchFilter1.SelectedItem = null;
            cboSearchFilter2.SelectedItem = null;
            cboSearchFilter3.SelectedItem = null;
            cboSearchFilter4.SelectedItem = null;
            cboSearchFilter5.SelectedItem = null;

            txtSearchFilter1.Text = "";
            txtSearchFilter2.Text = "";
            txtSearchFilter3.Text = "";
            txtSearchFilter4.Text = "";
            txtSearchFilter5.Text = "";

            AddFilteredItems();
        }

        private void lvSearch_Resize(object sender, EventArgs e)
        {
            if (!this.Visible || this.Dock != DockStyle.Fill)
            {
                return;
            }

            UIFormatting.ResizeColumnsFor(lvSearch);
        }

        private void btnSearchView_Click(object sender, EventArgs e)
        {
            if (lvSearch.SelectedItems.Count <= 0)
            {
                return;
            }

            Tag itemTag = (Tag)lvSearch.Items[lvSearch.SelectedIndex].Tag;

            if (itemTag == null || itemTag.getTagType() != TagType.Job)
            {
                return;
            }

            if (up_rqFilesView1 == null)
            {
                up_rqFilesView1 = new up_rqFilesView();
                this.Controls.Add(up_rqFilesView1);
            }

            WeldingAction wa = ApiCalls.ReadWeldingAction(((Job)itemTag.getTagObject()).WeldingActions.FirstOrDefault().WeldingActionId);

            up_rqFilesView1.Tag = new Tag(wa, TagType.Welding_Action);

            overlayPanel.Visible = true;

            up_rqFilesView1.ShowPopup(new Point(this.Width / 2 - up_rqFilesView1.Width / 2, this.Height / 2 - up_rqFilesView1.Height / 2), up_rqFilesView_Closed);
        }

        private void up_rqFilesView_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;
        }

        private void lvSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnSearchView.Visible = lvSearch.SelectedItems.Count > 0;
        }
    }
}
