﻿using ApiClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using Welding.DAL;
using WeldingManagement.Helpers;
using WeldingManagement.UserControls.PopupControls;
using Wisej.Web;
using static WeldingManagement.TemplateCompiler;
using static WeldingManagement.UIFormatting;

namespace WeldingManagement.UserControls
{
    public partial class uc_scGeneric : Wisej.Web.UserControl
    {
        private up_wqFileView up_wqFileView1;
        private Panel overlayPanel;
        public uc_scGeneric()
        {
            InitializeComponent();

            overlayPanel = new Panel
            {
                Size = this.Size,
                Location = this.Location,
                BackColor = System.Drawing.Color.FromArgb(128, 0, 0, 0),
                Visible = false,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(overlayPanel);
            overlayPanel.BringToFront();
        }

        #region Navigation
        [Browsable(true)]
        [Category("Action")]
        [Description("Invoked when user clicks home button on search screen")]
        public event EventHandler btnSearchHomeClick;
        private void btnSearchHome_Click(object sender, EventArgs e)
        {
            btnSearchHomeClick?.Invoke(this, e);
        }
        #endregion

        private void Load_Action()
        {
            Tag thisTag = (Tag)this.Tag;

            if (thisTag.getTagType() == TagType.WPQR)
            {
                object[] columns = typeof(WPQR).GetProperties()
                .Where(p => !IsNavigationProperty(p))
                .Select(p => GetPropertyDisplayName<WPQR>(p.Name))
                .ToArray();

                mscboSearchColumns.Set_InputDataList(columns);

                mscboSearchColumns.Set_OuputDataList(WPQRStdColumns());

                ResizeColumnsFor(lvSearch);
            }
            else if (thisTag.getTagType() == TagType.Welder_Qualification)
            {
                object[] dsProperties = typeof(Datasheet).GetProperties()
                .Where(p => !IsNavigationProperty(p))
                .Select(p => GetPropertyDisplayName<Datasheet>(p.Name))
                .ToArray();

                object[] ndtProperties = typeof(NDT_Record).GetProperties()
                    .Where(p => !IsNavigationProperty(p))
                    .Select(p => GetPropertyDisplayName<NDT_Record>(p.Name))
                    .ToArray();

                object[] columns = dsProperties.Concat(ndtProperties).ToArray();

                mscboSearchColumns.Set_InputDataList(columns);

                mscboSearchColumns.Set_OuputDataList(QualificationStdColumns());

                ResizeColumnsFor(lvSearch);
            }
            else if (thisTag.getTagType() == TagType.WPS)
            {
                object[] columns = typeof(WPS).GetProperties()
                .Where(p => !IsNavigationProperty(p))
                .Select(p => GetPropertyDisplayName<WPS>(p.Name))
                .ToArray();

                mscboSearchColumns.Set_InputDataList(columns);

                mscboSearchColumns.Set_OuputDataList(WPSStdColumns());

                ResizeColumnsFor(lvSearch);
            }
        }

        private void mscboSearchColumns_SelectionChanged(object sender, EventArgs e)
        {
            List<object> columns = mscboSearchColumns.Get_OuputDataList();

            if (columns.Count == 0)
            {
                return;
            }

            lvSearch.Columns.Clear();
            cboSearchFilter1.Items.Clear();
            cboSearchFilter2.Items.Clear();
            cboSearchFilter3.Items.Clear();
            cboSearchFilter4.Items.Clear();
            cboSearchFilter5.Items.Clear();

            foreach (object column in columns)
            {
                lvSearch.Columns.Add(new ColumnHeader() { Text = column.ToString(), Name = column.ToString() });
                cboSearchFilter1.Items.Add(column.ToString());
                cboSearchFilter2.Items.Add(column.ToString());
                cboSearchFilter3.Items.Add(column.ToString());
                cboSearchFilter4.Items.Add(column.ToString());
                cboSearchFilter5.Items.Add(column.ToString());
            }

            cboSearchFilter1.Refresh();
            cboSearchFilter2.Refresh();
            cboSearchFilter3.Refresh();
            cboSearchFilter4.Refresh();
            cboSearchFilter5.Refresh();

            AddFilteredItems(columns);

            ResizeColumnsFor(lvSearch);
        }

        private void uc_scWPQR_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible && this.Dock == DockStyle.Fill)
            {
                if (this.Tag != null)
                {
                    Load_Action();

                    Tag thisTag = (Tag)this.Tag;

                    switch (thisTag.getTagType()) 
                    {
                        case TagType.WPQR:
                            lblSearchTitle.Text = "Search WPQRs";
                            break;
                        case TagType.Welder_Qualification:
                            lblSearchTitle.Text = "Search Welder Qualifications";
                            break;
                        case TagType.WPS:
                            lblSearchTitle.Text = "Search WPSs";
                            break;
                    }
                }
            }
        }

        private void btnSearchFilters_Click(object sender, EventArgs e)
        {
            cboSearchFilter1.SelectedItem = null;
            cboSearchFilter2.SelectedItem = null;
            cboSearchFilter3.SelectedItem = null;
            cboSearchFilter4.SelectedItem = null;
            cboSearchFilter5.SelectedItem = null;

            txtSearchFilter1.Text = "";
            txtSearchFilter2.Text = "";
            txtSearchFilter3.Text = "";
            txtSearchFilter4.Text = "";
            txtSearchFilter5.Text = "";

            AddFilteredItems(mscboSearchColumns.Get_OuputDataList());
        }

        private void btnSearchColumns_Click(object sender, EventArgs e)
        {
            mscboSearchColumns.ClearSelection();

            lvSearch.Columns.Clear();
            lvSearch.Items.Clear();

            lvSearch.Refresh();
        }

        private void txtSearchFilter1_TextChanged(object sender, EventArgs e)
        {
            AddFilteredItems(mscboSearchColumns.Get_OuputDataList());
        }

        #region Helpers
        private bool IsNavigationProperty(PropertyInfo property)
        {
            bool isCollection = typeof(System.Collections.IEnumerable).IsAssignableFrom(property.PropertyType) && property.PropertyType != typeof(string);
            bool isComplexType = property.PropertyType.IsClass && property.PropertyType != typeof(string);
            bool isInterface = property.PropertyType.IsInterface && !isCollection;

            bool isEnum = property.PropertyType.IsEnum;

            return (isCollection || isComplexType || isInterface) && !isEnum;
        }

        private void AddFilteredItems(List<object> columns)
        {
            lvSearch.Items.Clear();

            List<object> items;

            Tag thisTag = (Tag)this.Tag;

            if (thisTag == null)
            {
                return;
            }

            switch (thisTag.getTagType())
            {
                case TagType.WPQR:
                    items = ApiCalls.ReadWPQRs()
                                    .Cast<object>()
                                    .ToList();
                    break;

                case TagType.Welder_Qualification:
                    items = ApiCalls.ReadDatasheets()
                                    .Cast<object>()
                                    .Concat(ApiCalls.ReadNDTRecords().Cast<object>())
                                    .ToList();
                    break;

                case TagType.WPS:
                    items = ApiCalls.ReadWPSs()
                                    .Cast<object>()
                                    .ToList();
                    break;

                default:
                    return;
            }

            int i;

            foreach (var item in items)
            {
                ListViewItem newItem = new ListViewItem();

                newItem.Tag = new Tag(item, thisTag.getTagType());

                i = 0;

                foreach (object column in columns)
                {
                    var property = GetPropertyByDisplayName(item.GetType(), column.ToString());

                    if (property != null)
                    {
                        var value = property.GetValue(item);

                        string valueString = value?.ToString() ?? string.Empty;

                        if (i == 0)
                        {
                            newItem.SubItems[0].Text = valueString;
                        }
                        else
                        {
                            newItem.SubItems.Add(valueString);
                        }
                        i++;
                    }
                    // specific to application
                    else
                    {
                        newItem.SubItems.Add("");

                        try
                        {
                            NDT_Record ndt = (NDT_Record)item;

                            if (ndt != null)
                            {
                                Datasheet datasheet = ndt.WPS.WPQR.Welder_Qualification.Datasheet;

                                property = GetPropertyByDisplayName<Datasheet>(column.ToString());

                                if (property != null)
                                {
                                    var value = property.GetValue(datasheet);

                                    string valueString = value?.ToString() ?? string.Empty;

                                    newItem.SubItems[i].Text = valueString;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex);
                        }

                        i++;
                    }
                }
                lvSearch.Items.Add(newItem);
            }

            var lvItems = lvSearch.Items.Cast<ListViewItem>().ToList();

            string filter;
            string propertyName;

            if (txtSearchFilter1.Text != "" && cboSearchFilter1.SelectedItem != null)
            {
                filter = txtSearchFilter1.Text;
                propertyName = cboSearchFilter1.SelectedItem.ToString();

                lvItems = GenericHelpers.FilterItems(lvItems, filter, propertyName, lvSearch);
            }

            if (txtSearchFilter2.Text != "" && cboSearchFilter2.SelectedItem != null)
            {
                filter = txtSearchFilter2.Text;
                propertyName = cboSearchFilter2.SelectedItem.ToString();

                lvItems = GenericHelpers.FilterItems(lvItems, filter, propertyName, lvSearch);
            }

            if (txtSearchFilter3.Text != "" && cboSearchFilter3.SelectedItem != null)
            {
                filter = txtSearchFilter1.Text;
                propertyName = cboSearchFilter1.SelectedItem.ToString();

                lvItems = GenericHelpers.FilterItems(lvItems, filter, propertyName, lvSearch);
            }

            if (txtSearchFilter4.Text != "" && cboSearchFilter4.SelectedItem != null)
            {
                filter = txtSearchFilter1.Text;
                propertyName = cboSearchFilter1.SelectedItem.ToString();

                lvItems = GenericHelpers.FilterItems(lvItems, filter, propertyName, lvSearch);
            }

            if (txtSearchFilter5.Text != "" && cboSearchFilter5.SelectedItem != null)
            {
                filter = txtSearchFilter1.Text;
                propertyName = cboSearchFilter1.SelectedItem.ToString();

                lvItems = GenericHelpers.FilterItems(lvItems, filter, propertyName, lvSearch);
            }

            lvSearch.Items.Clear();
            lvSearch.Items.AddRange(lvItems.ToArray());
        }

        private List<object> WPSStdColumns()
        {
            List<object> columns = new List<object>
            {
                GetPropertyDisplayName<WPS>(nameof(WPS.WPSNumber)),
                GetPropertyDisplayName<WPS>(nameof(WPS.JointType)),
                GetPropertyDisplayName<WPS>(nameof(WPS.MinThickness)),
                GetPropertyDisplayName<WPS>(nameof(WPS.MinDiameter))
            };

            return columns;
        }

        private List<object> WPQRStdColumns()
        {
            List<object> columns = new List<object> 
            {
                GetPropertyDisplayName<WPQR>(nameof(WPQR.WPQRNumber)),
                GetPropertyDisplayName<WPQR>(nameof(WPQR.JointType)),
                GetPropertyDisplayName<WPQR>(nameof(WPQR.WeldingType)),
                GetPropertyDisplayName<WPQR>(nameof(WPQR.WeldingStandard)),
                GetPropertyDisplayName<WPQR>(nameof(WPQR.Position)),
                GetPropertyDisplayName<WPQR>(nameof(WPQR.Thickness)),
                GetPropertyDisplayName<WPQR>(nameof(WPQR.Diameter)),
                GetPropertyDisplayName<WPQR>(nameof(WPQR.FillerSize))           
            };

            return columns;
        }

        private List<object> QualificationStdColumns()
        {
            List<object> columns = new List<object>
            {
                GetPropertyDisplayName<NDT_Record>(nameof(NDT_Record.WeldersName)),
                GetPropertyDisplayName<NDT_Record>(nameof(NDT_Record.WelderEID)),
                GetPropertyDisplayName<Datasheet>(nameof(Datasheet.WeldingStandard)),
                GetPropertyDisplayName<Datasheet>(nameof(Datasheet.WeldingPosition)),
                GetPropertyDisplayName<Datasheet>(nameof(Datasheet.WeldingProcess)),
                GetPropertyDisplayName<NDT_Record>(nameof(NDT_Record.WPSNumber)),
                GetPropertyDisplayName<Datasheet>(nameof(Datasheet.WPQRNumber)),
                GetPropertyDisplayName<Datasheet>(nameof(Datasheet.MaterialStd)),
                GetPropertyDisplayName<Datasheet>(nameof(Datasheet.MaterialGrd)),
                GetPropertyDisplayName<Datasheet>(nameof(Datasheet.MaterialThickness)),
                GetPropertyDisplayName<Datasheet>(nameof(Datasheet.TestDate)),
                GetPropertyDisplayName<Datasheet>(nameof(Datasheet.ExpiryDate)),
                GetPropertyDisplayName<NDT_Record>(nameof(NDT_Record.ReportNumber)),
                GetPropertyDisplayName<NDT_Record>(nameof(NDT_Record.TestType)),
                GetPropertyDisplayName<NDT_Record>(nameof(NDT_Record.PNumber))
            };

            return columns;
        }
        #endregion

        private void lvSearch_Resize(object sender, EventArgs e)
        {
            if (this.Visible && this.Dock == Wisej.Web.DockStyle.Fill)
            {
                ResizeColumnsFor(lvSearch);
            }
        }

        private void lvSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnSearchView.Visible = false;

            if (lvSearch.SelectedIndex < 0)
            {
                return;
            }

            Tag itemTag = (Tag)lvSearch.Items[lvSearch.SelectedIndex].Tag;

            if (itemTag == null)
            {
                return;
            }

            if (itemTag.getTagObject() is WPQR || itemTag.getTagObject() is Datasheet || itemTag.getTagObject() is WPS)
            {
                btnSearchView.Visible = true;
            }
        }

        private void btnSearchView_Click(object sender, EventArgs e)
        {
            if (lvSearch.SelectedIndex < 0)
            {
                return;
            }

            Tag itemTag = (Tag)lvSearch.Items[lvSearch.SelectedIndex].Tag;

            if (itemTag == null)
            {
                return;
            }

            StartLoader(this);

            if (up_wqFileView1 == null)
            {
                up_wqFileView1 = new up_wqFileView();
                this.Controls.Add(up_wqFileView1);
            }

            if (itemTag.getTagObject() is WPQR)
            {
                WPQR wpqr = ApiCalls.ReadWPQR(((WPQR)itemTag.getTagObject()).WPQRId);

                if (wpqr.Status == Actions.Complete)
                {
                    string wpqrPath = CompleteWPQR(wpqr);

                    using (FileStream fStream = new FileStream(wpqrPath, FileMode.Open, FileAccess.Read))
                    {
                        var reader = new BinaryReader(fStream);
                        var buffer = reader.ReadBytes((int)fStream.Length);
                        var mem = new MemoryStream(buffer);

                        up_wqFileView1.pvView_Stream = mem;
                        up_wqFileView1.path = wpqrPath;
                        up_wqFileView1.title = "Below is a Preview of the WPQR";

                        StopLoader(this);

                        up_wqFileView1.ShowPopup(new Point(this.Width / 2 - up_wqFileView1.Width / 2, this.Height / 2 - up_wqFileView1.Height / 2), up_wqFileView1_Closed);
                    }
                }
            }
            else if (itemTag.getTagObject() is Datasheet)
            {
                Welder_Qualification wq = ApiCalls.ReadWelderQualification(((Datasheet)itemTag.getTagObject()).Welder_Qualification.Welder_QualificationId);

                if (wq.Status == Actions.Complete)
                {
                    Datasheet ds = ApiCalls.ReadDatasheet(wq.Datasheet.DatasheetId);
                    Visual_Inspection vi = ApiCalls.ReadVisualInspection(wq.Visual_Inspection.Visual_InspectionId);

                    string welderQualPath = CompleteWelderQual(wq);

                    using (FileStream fStream = new FileStream(welderQualPath, FileMode.Open, FileAccess.Read))
                    {
                        var reader = new BinaryReader(fStream);
                        var buffer = reader.ReadBytes((int)fStream.Length);
                        var mem = new MemoryStream(buffer);

                        up_wqFileView1.pvView_Stream = mem;
                        up_wqFileView1.path = welderQualPath;
                        up_wqFileView1.title = "Below is a Preview of the Welder Qualification";

                        overlayPanel.Visible = true;

                        StopLoader(this);

                        up_wqFileView1.ShowPopup(new Point(this.Width / 2 - up_wqFileView1.Width / 2, this.Height / 2 - up_wqFileView1.Height / 2), up_wqFileView1_Closed);
                    }
                }
            }
            else if (itemTag.getTagObject() is WPS)
            {
                WPS wps = ApiCalls.ReadWPS(((WPS)itemTag.getTagObject()).WPSId);

                if (wps.Status == Actions.Complete)
                {
                    string wpsPath = CompleteWPS(wps, false);

                    using (FileStream fStream = new FileStream(wpsPath, FileMode.Open, FileAccess.Read))
                    {
                        var reader = new BinaryReader(fStream);
                        var buffer = reader.ReadBytes((int)fStream.Length);
                        var mem = new MemoryStream(buffer);

                        up_wqFileView1.pvView_Stream = mem;
                        up_wqFileView1.path = wpsPath;
                        up_wqFileView1.title = "Below is a Preview of the WPS";

                        StopLoader(this);

                        up_wqFileView1.ShowPopup(new Point(this.Width / 2 - up_wqFileView1.Width / 2, this.Height / 2 - up_wqFileView1.Height / 2), up_wqFileView1_Closed);
                    }
                }
            }

            StopLoader(this);
        }

        private void up_wqFileView1_Closed(UserPopup up)
        {
            overlayPanel.Visible = false;
        }

        private void lblSearchNote_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Navigate("https://camcoeng.sharepoint.com/sites/Base/SitePages/Welding-Management-System.aspx", "_blank");
        }
    }
}
