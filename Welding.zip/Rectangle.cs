﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web;

namespace WeldingManagement
{
    public class RotatedRectangle
    {
        private Point location;
        public Point Location
        {
            get
            {
                return location;
            }
            set
            {
                location = value;
            }
        }

        private Point topLeft;
        public Point TopLeft
        {
            get
            {
                return topLeft;
            }
            set
            {
                topLeft = value;
            }
        }

        private Point topRight;
        public Point TopRight
        {
            get
            {
                return topRight;
            }
            set
            {
                topRight = value;
            }
        }

        private Point bottomLeft;
        public Point BottomLeft
        {
            get
            {
                return bottomLeft;
            }
            set
            {
                bottomLeft = value;
            }
        }

        private Point bottomRight;
        public Point BottomRight
        {
            get
            {
                return bottomRight;
            }
            set
            {
                bottomRight = value;
            }
        }

        private int height;
        public int Height
        {
            get
            {
                return height;
            }
            set
            {
                height = value;
            }
        }

        private int width;
        public int Width
        {
            get
            {
                return width;
            }
            set
            {
                width = value;
            }
        }

        private double angle;
        public double Angle
        {
            get
            {
                return angle;
            }
            set
            {
                angle = value;
            }
        }

        public RotatedRectangle()
        {
            Location = new Point();
            Width = 0;
            Height = 0;
            TopLeft = new Point();
            TopRight = new Point();
            BottomLeft = new Point();
            BottomRight = new Point();
            Angle = 0;
        }

        public RotatedRectangle(int x1, int y1, int x2, int y2, double angle)
        {
            CreateRectangle(x1, y1, x2, y2, angle);
        }

        public RotatedRectangle(Point topLeft, Point bottomRight, double angle)
        {
            CreateRectangle(topLeft.X, topLeft.Y, bottomRight.X, bottomRight.Y, angle);
        }

        public void CreateRectangle(int x1, int y1, int x2, int y2, double angle)
        {
            Location = new Point(x1, y1);
            Angle = angle;

            // Convert to new Coordinate system to check if the shape is flipped or not
            (int new_x1, int new_y1) = ConvertToShapeCoords(x1, y1);
            (int new_x2, int new_y2) = ConvertToShapeCoords(x2, y2);

            bool xFlip = new_x2 < new_x1;
            bool yFlip = new_y2 < new_y1;

            (int x3, int y3) = ConvertToGlobalCoords(new_x2, new_y1);
            (int x4, int y4) = ConvertToGlobalCoords(new_x1, new_y2);

            Width = Math.Abs(new_x2 - new_x1);
            Height = Math.Abs(new_y2 - new_y1);

            if (xFlip && yFlip)
            {
                TopLeft = new Point(x2, y2);
                BottomRight = new Point(x1, y1);

                TopRight = new Point(x4, y4);
                BottomLeft = new Point(x3, y3);
            }
            else if (xFlip)
            {
                BottomLeft = new Point(x2, y2);
                TopRight = new Point(x1, y1);

                TopLeft = new Point(x3, y3);
                BottomRight = new Point(x4, y4);
            }
            else if (yFlip)
            {
                TopRight = new Point(x2, y2);
                BottomLeft = new Point(x1, y1);

                TopLeft = new Point(x4, y4);
                BottomRight = new Point(x3, y3);
            }
            else
            {
                TopLeft = new Point(x1, y1);
                BottomRight = new Point(x2, y2);

                TopRight = new Point(x3, y3);
                BottomLeft = new Point(x4, y4);
            }
        }

        public (int, int) ConvertToShapeCoords(int x, int y)
        {
            double cos = Math.Cos(DegreeToRadian(Angle));
            double sin = Math.Sin(DegreeToRadian(Angle));

            int new_x = (int)Math.Round(y * sin + x * cos);
            int new_y = (int)Math.Round(y * cos - x * sin);

            return (new_x, new_y);
        }

        public (int, int) ConvertToGlobalCoords(int x, int y)
        {
            double cos = Math.Cos(DegreeToRadian(-Angle));
            double sin = Math.Sin(DegreeToRadian(-Angle));

            int old_x = (int)Math.Round(y * sin + x * cos);
            int old_y = (int)Math.Round(y * cos - x * sin);

            return (old_x, old_y);
        }



        private double DegreeToRadian(double degree)
        {
            return degree * Math.PI / 180.0;
        }
    }
}