﻿using Microsoft.AspNet.SignalR.Client;
using System;
using System.Threading.Tasks;


namespace SignalRClient
{
    internal class Program
    {
        static void Main(string[] args)
        {
            RunSignalRClient().Wait();
        }

        static async Task RunSignalRClient()
        {
            var connection = new HubConnection("http://localhost:8080");
            var myHubProxy = connection.CreateHubProxy("MyHub"); // Replace 'MyHub' with your actual hub name

            // Handle connection lifecycle events
            connection.Closed += () => Console.WriteLine("Connection closed");
            connection.Error += ex => Console.WriteLine("Error: " + ex.Message);
            
           

            try
            {
                await connection.Start();
                Console.WriteLine("Connected to the hub");

                // Subscribe to messages from the hub
                myHubProxy.On<string, string>("broadcastMessage", (name, message) =>
                {
                    Console.WriteLine($"{name}: {message}");
                });

                // Subscribe to chat messages
                myHubProxy.On<string, string>("ReceiveMessage", (name, message) =>
                {
                    Console.WriteLine($"{name}: {message}");
                });

                // Publishing a message to the hub
                Console.WriteLine("CHAT STARTED");

                // Chat loop
                while (true)
                {
                    Console.Write("Enter your message (or 'exit' to quit): ");
                    string userMessage = Console.ReadLine();

                    // Exit condition
                    if (userMessage.Equals("exit", StringComparison.OrdinalIgnoreCase))
                    {
                        break;
                    }

                    // Publishing a message to the hub
                    await myHubProxy.Invoke("SendMessage", "ConsoleClient", userMessage);
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while connecting to the hub: " + ex.Message);
            }

            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
            connection.Stop();
        }
    }
}
