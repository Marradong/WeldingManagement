﻿using Microsoft.AspNet.SignalR.Client;
using System;
using System.ComponentModel;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Wisej.Web;
using GemBox;
using GemBox.Document;

namespace WeldingManagement
{
    static class Program
    {
        static void Main()
        {
            CultureInfo australiaCulture = new CultureInfo("en-AU");
            Thread.CurrentThread.CurrentCulture = australiaCulture;
            Thread.CurrentThread.CurrentUICulture = australiaCulture;

            Debug.WriteLine(string.Join(Environment.NewLine, Enumerable.Repeat(string.Empty, 100)));

            string username = Environment.UserName;
            string Pc = Environment.MachineName;

#if DEBUG
            string Mode = " - Debugging : <DEBUG> ";
#else
            string Mode = " - PRODUCTION : <RELEASE> ";
#endif

            username += Mode; // " : Debugger Attached";

            string startupomsg = $"-- {DateTime.Now.ToString("hh:mm:ss tt")}  STARTUP : {Pc} - {username} --";

            Debug.Print(startupomsg);

            string connectionString = ConfigurationManager.ConnectionStrings["WeldingManagementSystemDb"].ConnectionString;
            var connectionStringBuilder = new SqlConnectionStringBuilder(connectionString);
            //{data source=.\SQLEXPRESS;Integrated Security=SSPI;AttachDBFilename=|DataDirectory|aspnetdb.mdf;User Instance=true}
            Debug.Print(connectionString);

            //set GemBox license
            ComponentInfo.SetLicense("DN-2022Nov29-OfnwD/IYv7sQWi1lj79LdKiHXo9lrP/yDJyicjcSbQZyiIPLmY9bZE9PNQKn62WkF1sbnxbs5WcGVRCetLpDXG1Q7RA==A");

            Application.SessionTimeout += Application_SessionTimeout;
            Application.ApplicationRefresh += Application_ApplicationRefresh;
            Application.HashChanged += Application_ApplicationRefresh;

            Application.MainPage = new FrmMain();

            CheckLoggedIn();
        }
        private static void Application_ApplicationRefresh(object sender, EventArgs e)
        {
            //Reload on page reload etc
        }

        private static void Application_SessionTimeout(object sender, HandledEventArgs e)
        {
            // override default timeout management
            e.Handled = true;

            // use your own timeout manager
            //TimeoutManager.DoManage();
        }

        static void CheckLoggedIn()
        {
            if (Application.Cookies["LoggedIn"] == "True")
            {
                var EmpId = Application.Cookies["EmployeeNumber"];
                Debug.WriteLine("Employee Number: " + EmpId);
                Debug.WriteLine("Auto Logged in from Cookie");

                Application.Session.EmpId = EmpId;
                Application.Session.EmployeeNumber = Application.Cookies["EmployeeNumber"];
                Application.Session.EmployeeName = Application.Cookies["EmployeeName"];
                Application.Session.Department = Application.Cookies["Department"];
                Application.Session.WorkRole = Application.Cookies["Role"];
            }
            else
            {
                Application.Session.LoggedIn = false;
                Application.Session.EmpId = "";
                Application.Session.EmployeeNumber = "";
                Application.Session.EmployeeName = "";
                Application.Session.Department = "";
                Application.Session.WorkRole = "";
            }
        }
    }
}