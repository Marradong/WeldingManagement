﻿using System;
using Welding.DAL;
using WeldingManagement.UserControls;
using WeldingManagement.UserControls.DatasheetControls;
using WeldingManagement.UserControls.HomeControls;
using WeldingManagement.UserControls.NDTControls;
using WeldingManagement.UserControls.QualificationControls;
using WeldingManagement.UserControls.RequestControls;
using WeldingManagement.UserControls.SearchControls;
using WeldingManagement.UserControls.VisualControls;
using WeldingManagement.UserControls.WPQRControls;
using WeldingManagement.UserControls.WPSControls;
using Wisej.Web;


namespace WeldingManagement
{
    public partial class FrmMain : Page
    {
        #region User Control Definitions
        private uc_scGeneric uc_scWPQR1;
        private uc_scJob uc_scJob1;

        private uc_ndtEntry uc_ndtEntry1;

        private uc_wpsDocuments uc_wpsDocuments1;
        private uc_wpsRun uc_wpsRun1;
        private uc_wpsInfo uc_wpsInfo1;

        private uc_wpqrDocuments uc_wpqrDocuments1;
        private uc_wpqrContinued uc_wpqrContinued1;
        private uc_wpqrDetails uc_wpqrDetails1;
        private uc_wpqrRun uc_wpqrRun1;
        private uc_wpqrInfo uc_wpqrInfo1;
        private uc_wpqrSelect uc_wpqrSelect1;

        private uc_wqReports uc_wqReports1;
        private uc_wqInspection uc_wqInspection1;
        private uc_wqDrawing uc_wqDrawing1;
        private uc_wqConsumable uc_wqConsumable1;
        private uc_wqRun uc_wqRun1;
        private uc_wqInfo uc_wqInfo1;

        private uc_rqReview uc_rqReview1;
        private uc_rqOperational uc_rqOperational1;
        private uc_rqTechnical uc_rqTechnical1;
        private uc_rqDocuments uc_rqDocuments1;
        private uc_rqDetails uc_rqDetails1;
        private uc_rqMatrix uc_rqMatrix1;

        private uc_hmActions uc_hmActions1;
        private uc_hmLogin uc_hmLogin1;
        #endregion

        #region Initialisation
        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            if (Application.Cookies["LoggedIn"] == "True")
            {
                Navigation.FromHome(Init_hmActions, null);
            }
            else
            {
                Navigation.FromHome(Init_hmLogin, null);
            }
        }

        #region Initialise User Controls

        #region Init Home
        private UserControl Init_hmActions()
        {
            if (uc_hmActions1 == null)
            {
                uc_hmActions1 = new uc_hmActions() { Visible = false };

                this.Controls.Add(uc_hmActions1);

                uc_hmActions1.btnHomeRequestClick += uc_hmActions1_btnHomeRequestClick;
                uc_hmActions1.btnWelderQualificationClick += uc_hmActions1_btnWelderQualificationClick;
                uc_hmActions1.btnHomeWPQRClick += uc_hmActions1_btnHomeWPQRClick;
                uc_hmActions1.btnHomeWPSClick += uc_hmActions1_btnHomeWPSClick;
                uc_hmActions1.btnHomeNDTClick += uc_hmActions1_btnHomeNDTClick;
                uc_hmActions1.btnHomeSearchWPQRClick += uc_hmActions1_btnHomeSearchWPQRClick;
                uc_hmActions1.btnHomeSearchWQClick += uc_hmActions1_btnHomeSearchWQClick;
                uc_hmActions1.btnHomeSearchWPSClick += uc_hmActions1_btnHomeSearchWPSClick;
                uc_hmActions1.btnHomeSearchJobClick += uc_hmActions1_btnHomeSearchJobClick;
            }
            return uc_hmActions1;
        }

        private UserControl Init_hmLogin()
        {
            if (uc_hmLogin1 == null)
            {
                uc_hmLogin1 = new uc_hmLogin() { Visible = false };

                this.Controls.Add(uc_hmLogin1);

                uc_hmLogin1.userLoginSuccess += uc_hmLogin1_userLoginSuccess;
            }
            return uc_hmLogin1;
        }

        #endregion

        #region Init Request

        private UserControl Init_rqMatrix()
        {
            if (uc_rqMatrix1 == null)
            {
                uc_rqMatrix1 = new uc_rqMatrix() { Visible = false };

                this.Controls.Add(uc_rqMatrix1);

                uc_rqMatrix1.btnMatrixBackClick += uc_rqMatrix1_btnMatrixBackClick;
                uc_rqMatrix1.btnMatrixHomeClick += uc_rqMatrix1_btnMatrixHomeClick;
                uc_rqMatrix1.btnMatrixNextClick += uc_rqMatrix1_btnMatrixNextClick;
            }
            return uc_rqMatrix1;
        }

        private UserControl Init_rqDetails()
        {
            if (uc_rqDetails1 == null)
            {
                uc_rqDetails1 = new uc_rqDetails() { Visible = false };

                this.Controls.Add(uc_rqDetails1);

                uc_rqDetails1.btnDetailsBackClick += uc_rqDetails1_btnDetailsBackClick;
                uc_rqDetails1.btnDetailsHomeClick += uc_rqDetails1_btnDetailsHomeClick;
                uc_rqDetails1.btnDetailsNextClick += uc_rqDetails1_btnDetailsNextClick;
            }
            return uc_rqDetails1;
        }

        private UserControl Init_rqDocuments()
        {
            if (uc_rqDocuments1 == null)
            {
                uc_rqDocuments1 = new uc_rqDocuments() { Visible = false };

                this.Controls.Add(uc_rqDocuments1);

                uc_rqDocuments1.btnDocumentsBackClick += uc_rqDocuments1_btnDocumentsBackClick;
                uc_rqDocuments1.btnDocumentsHomeClick += uc_rqDocuments1_btnDocumentsHomeClick;
                uc_rqDocuments1.btnDocumentsCompleteClick += uc_rqDocuments1_btnDocumentsCompleteClick;
            }
            return uc_rqDocuments1;
        }

        private UserControl Init_rqTechnical()
        {
            if (uc_rqTechnical1 == null)
            {
                uc_rqTechnical1 = new uc_rqTechnical() { Visible = false };

                this.Controls.Add(uc_rqTechnical1);

                uc_rqTechnical1.btnTechnicalBackClick += uc_rqTechnical1_btnTechnicalBackClick;
                uc_rqTechnical1.btnTechnicalHomeClick += uc_rqTechnical1_btnTechnicalHomeClick;
                uc_rqTechnical1.btnTechnicalNextClick += uc_rqTechnical1_btnTechnicalNextClick;
            }
            return uc_rqTechnical1;
        }

        private UserControl Init_rqOperational()
        {
            if (uc_rqOperational1 == null)
            {
                uc_rqOperational1 = new uc_rqOperational() { Visible = false };

                this.Controls.Add(uc_rqOperational1);

                uc_rqOperational1.btnOperationBackClick += uc_rqOperational1_btnOperationBackClick;
                uc_rqOperational1.btnOperationHomeClick += uc_rqOperational1_btnOperationHomeClick;
                uc_rqOperational1.btnOperationCompleteClick += uc_rqOperational1_btnOperationCompleteClick;
            }
            return uc_rqOperational1;
        }

        private UserControl Init_rqReview()
        {
            if (uc_rqReview1 == null)
            {
                uc_rqReview1 = new uc_rqReview() { Visible = false };

                this.Controls.Add(uc_rqReview1);

                uc_rqReview1.btnManagerBackClick += uc_rqReview1_btnManagerBackClick;
                uc_rqReview1.btnManagerHomeClick += uc_rqReview1_btnManagerHomeClick;
                uc_rqReview1.btnManagerCompleteClick += uc_rqReview1_btnManagerCompleteClick;
            }
            return uc_rqReview1;
        }

        #endregion

        #region Init Welder Qualification

        private UserControl Init_wqInfo()
        {
            if (uc_wqInfo1 == null)
            {
                uc_wqInfo1 = new uc_wqInfo() { Visible = false };

                this.Controls.Add(uc_wqInfo1);

                uc_wqInfo1.btnInfoBackClick += uc_wqInfo1_btnInfoBackClick;
                uc_wqInfo1.btnInfoHomeClick += uc_wqInfo1_btnInfoHomeClick;
                uc_wqInfo1.btnInfoNextClick+= uc_wqInfo1_btnInfoNextClick;
            }
            return uc_wqInfo1;
        }

        private UserControl Init_wqRun()
        {
            if (uc_wqRun1 == null)
            {
                uc_wqRun1 = new uc_wqRun() { Visible = false };

                this.Controls.Add(uc_wqRun1);

                uc_wqRun1.btnRunBackClick += uc_wqRun1_btnRunBackClick;
                uc_wqRun1.btnRunHomeClick += uc_wqRun1_btnRunHomeClick;
                uc_wqRun1.btnRunNextClick += uc_wqRun1_btnRunNextClick;
            }
            return uc_wqRun1;
        }

        private UserControl Init_wqConsumable()
        {
            if (uc_wqConsumable1 == null)
            {
                uc_wqConsumable1 = new uc_wqConsumable() { Visible = false };

                this.Controls.Add(uc_wqConsumable1);

                uc_wqConsumable1.btnConsumableBackClick += uc_wqConsumable1_btnConsumableBackClick;
                uc_wqConsumable1.btnConsumableHomeClick += uc_wqConsumable1_btnConsumableHomeClick;
                uc_wqConsumable1.btnConsumableNextClick += uc_wqConsumable1_btnConsumableNextClick;
            }
            return uc_wqConsumable1;
        }

        private UserControl Init_wqDrawing()
        {
            if (uc_wqDrawing1 == null)
            {
                uc_wqDrawing1 = new uc_wqDrawing() { Visible = false };

                this.Controls.Add(uc_wqDrawing1);

                uc_wqDrawing1.btnDrawingBackClick += uc_wqDrawing1_btnDrawingBackClick;
                uc_wqDrawing1.btnDrawingHomeClick += uc_wqDrawing1_btnDrawingHomeClick;
                uc_wqDrawing1.btnDrawingCompleteClick += uc_wqDrawing1_btnDrawingCompleteClick;
            }
            return uc_wqDrawing1;
        }

        private UserControl Init_wqInspection()
        {
            if (uc_wqInspection1 == null)
            {
                uc_wqInspection1 = new uc_wqInspection() { Visible = false };

                this.Controls.Add(uc_wqInspection1);

                uc_wqInspection1.btnVisualBackClick += uc_wqInspection1_btnVisualBackClick;
                uc_wqInspection1.btnVisualHomeClick += uc_wqInspection1_btnVisualHomeClick;
                uc_wqInspection1.btnVisualCompleteClick += uc_wqInspection1_btnVisualCompleteClick;
            }
            return uc_wqInspection1;
        }

        private UserControl Init_wqReports()
        {
            if (uc_wqReports1 == null)
            {
                uc_wqReports1 = new uc_wqReports() { Visible = false };

                this.Controls.Add(uc_wqReports1);

                uc_wqReports1.btnUploadBackClick += uc_wqReports1_btnUploadBackClick;
                uc_wqReports1.btnUploadHomeClick += uc_wqReports1_btnUploadHomeClick;
                uc_wqReports1.btnUploadCompleteClick += uc_wqReports1_btnUploadCompleteClick;
            }
            return uc_wqReports1;
        }

        #endregion

        #region Init WPQR

        private UserControl Init_wpqrSelect()
        {
            if (uc_wpqrSelect1 == null)
            {
                uc_wpqrSelect1 = new uc_wpqrSelect() { Visible = false };

                this.Controls.Add(uc_wpqrSelect1);

                uc_wpqrSelect1.btnSelectBackClick += uc_wpqrSelect1_btnSelectBackClick;
                uc_wpqrSelect1.btnSelectHomeClick += uc_wpqrSelect1_btnSelectHomeClick;
                uc_wpqrSelect1.btnSelectNextClick += uc_wpqrSelect1_btnSelectNextClick;
            }
            return uc_wpqrSelect1;
        }

        private UserControl Init_wpqrInfo()
        {
            if (uc_wpqrInfo1 == null)
            {
                uc_wpqrInfo1 = new uc_wpqrInfo() { Visible = false };

                this.Controls.Add(uc_wpqrInfo1);

                uc_wpqrInfo1.btnInfoBackClick += uc_wpqrInfo1_btnInfoBackClick;
                uc_wpqrInfo1.btnInfoHomeClick += uc_wpqrInfo1_btnInfoHomeClick;
                uc_wpqrInfo1.btnInfoNextClick += uc_wpqrInfo1_btnInfoNextClick;
            }
            return uc_wpqrInfo1;
        }

        private UserControl Init_wpqrRun()
        {
            if (uc_wpqrRun1 == null)
            {
                uc_wpqrRun1 = new uc_wpqrRun() { Visible = false };

                this.Controls.Add(uc_wpqrRun1);

                uc_wpqrRun1.btnRunBackClick += uc_wpqrRun1_btnRunBackClick;
                uc_wpqrRun1.btnRunHomeClick += uc_wpqrRun1_btnRunHomeClick;
                uc_wpqrRun1.btnRunNextClick += uc_wpqrRun1_btnRunNextClick;
            }
            return uc_wpqrRun1;
        }

        private UserControl Init_wpqrDetails()
        {
            if (uc_wpqrDetails1 == null)
            {
                uc_wpqrDetails1 = new uc_wpqrDetails() { Visible = false };

                this.Controls.Add(uc_wpqrDetails1);

                uc_wpqrDetails1.btnDetailsBackClick += uc_wpqrDetails1_btnDetailsBackClick;
                uc_wpqrDetails1.btnDetailsHomeClick += uc_wpqrDetails1_btnDetailsHomeClick;
                uc_wpqrDetails1.btnDetailsNextClick += uc_wpqrDetails1_btnDetailsNextClick;
            }
            return uc_wpqrDetails1;
        }

        private UserControl Init_wpqrContinued()
        {
            if (uc_wpqrContinued1 == null)
            {
                uc_wpqrContinued1 = new uc_wpqrContinued() { Visible = false };

                this.Controls.Add(uc_wpqrContinued1);

                uc_wpqrContinued1.btnContBackClick += uc_wpqrContinued1_btnContBackClick;
                uc_wpqrContinued1.btnContHomeClick += uc_wpqrContinued1_btnContHomeClick;
                uc_wpqrContinued1.btnContNextClick += uc_wpqrContinued1_btnContNextClick;
            }
            return uc_wpqrContinued1;
        }

        private UserControl Init_wpqrDocuments()
        {
            if (uc_wpqrDocuments1 == null)
            {
                uc_wpqrDocuments1 = new uc_wpqrDocuments() { Visible = false };

                this.Controls.Add(uc_wpqrDocuments1);

                uc_wpqrDocuments1.btnUploadBackClick += uc_wpqrDocuments1_btnUploadBackClick;
                uc_wpqrDocuments1.btnUploadHomeClick += uc_wpqrDocuments1_btnUploadHomeClick;
                uc_wpqrDocuments1.btnUploadCompleteClick += uc_wpqrDocuments1_btnUploadCompleteClick;
                uc_wpqrDocuments1.btnUploadPreparationClick += uc_wpqrDocuments1_btnUploadPreparationClick;
                uc_wpqrDocuments1.btnUploadSequenceClick += uc_wpqrDocuments1_btnUploadSequenceClick;
            }
            return uc_wpqrDocuments1;
        }

        #endregion

        #region Init WPS

        private UserControl Init_wpsInfo()
        {
            if (uc_wpsInfo1 == null)
            {
                uc_wpsInfo1 = new uc_wpsInfo() { Visible = false };

                this.Controls.Add(uc_wpsInfo1);

                uc_wpsInfo1.btnInfoBackClick += uc_wpsInfo1_btnInfoBackClick;
                uc_wpsInfo1.btnInfoHomeClick += uc_wpsInfo1_btnInfoHomeClick;
                uc_wpsInfo1.btnInfoNextClick += uc_wpsInfo1_btnInfoNextClick;
            }
            return uc_wpsInfo1;
        }

        private UserControl Init_wpsRun()
        {
            if (uc_wpsRun1 == null)
            {
                uc_wpsRun1 = new uc_wpsRun() { Visible = false };

                this.Controls.Add(uc_wpsRun1);

                uc_wpsRun1.btnRunBackClick += uc_wpsRun1_btnRunBackClick;
                uc_wpsRun1.btnRunHomeClick += uc_wpsRun1_btnRunHomeClick;
                uc_wpsRun1.btnRunNextClick += uc_wpsRun1_btnRunNextClick;
            }
            return uc_wpsRun1;
        }

        private UserControl Init_wpsDocuments()
        {
            if (uc_wpsDocuments1 == null)
            {
                uc_wpsDocuments1 = new uc_wpsDocuments() { Visible = false };

                this.Controls.Add(uc_wpsDocuments1);

                uc_wpsDocuments1.btnUploadBackClick += uc_wpsDocuments1_btnUploadBackClick;
                uc_wpsDocuments1.btnUploadHomeClick += uc_wpsDocuments1_btnUploadHomeClick;
                uc_wpsDocuments1.btnUploadCompleteClick += uc_wpsDocuments1_btnUploadCompleteClick;
                uc_wpsDocuments1.btnUploadPreparationClick += uc_wpsDocuments1_btnUploadPreparationClick;
                uc_wpsDocuments1.btnUploadSequenceClick += uc_wpsDocuments1_btnUploadSequenceClick;
            }
            return uc_wpsDocuments1;
        }

        #endregion

        #region Init NDT Entry

        private UserControl Init_ndtEntry()
        {
            if (uc_ndtEntry1 == null)
            {
                uc_ndtEntry1 = new uc_ndtEntry() { Visible = false };

                this.Controls.Add(uc_ndtEntry1);

                uc_ndtEntry1.btnEntryBackClick += uc_ndtEntry1_btnEntryBackClick;
                uc_ndtEntry1.btnEntrySubmitClick += uc_ndtEntry1_btnEntrySubmitClick;
            }
            return uc_ndtEntry1;
        }

        #endregion

        #region Init Search

        private UserControl Init_scGeneric()
        {
            if (uc_scWPQR1 == null)
            {
                uc_scWPQR1 = new uc_scGeneric() { Visible = false };

                this.Controls.Add(uc_scWPQR1);

                uc_scWPQR1.btnSearchHomeClick += uc_scWPQR1_btnSearchHomeClick;
            }
            return uc_scWPQR1;
        }

        private UserControl Init_scJob1() 
        {
            if (uc_scJob1 == null)
            {
                uc_scJob1 = new uc_scJob() { Visible = false };

                this.Controls.Add(uc_scJob1);

                uc_scJob1.btnSearchHomeClick += uc_scJob1_btnSearchHomeClick;
            }
            return uc_scJob1;
        }

        #endregion

        #endregion

        #endregion

        #region Navigation Functions

        #region Login Page
        private void uc_hmLogin1_userLoginSuccess(object sender, EventArgs e)
        {
            Navigation.FromHome(Init_hmActions, null);
        }
        #endregion

        #region Actions Page
        private void uc_hmActions1_btnHomeRequestClick(object sender, EventArgs e)
        {
            Tag homeTag = (Tag)uc_hmActions1.Tag;

            if (homeTag?.getTagType() != TagType.New_Welding_Form)
            {
                return;
            }

            NewWeldingForm nwf = (NewWeldingForm)homeTag.getTagObject();

            switch (nwf.Status)
            {
                case Actions.WeldingMatrix:
                    Navigation.FromHome(Init_rqMatrix, homeTag);
                    break;

                case Actions.WeldingScope:
                    Navigation.FromHome(Init_rqDetails, homeTag);
                    break;

                case Actions.ProvideDocumentation:
                    Navigation.FromHome(Init_rqDocuments, homeTag);
                    break;

                case Actions.TechnicalReview:
                    Navigation.FromHome(Init_rqTechnical, homeTag);
                    break;

                case Actions.OperationalReview:
                    Navigation.FromHome(Init_rqOperational, homeTag);
                    break;

                case Actions.ManagerReview:
                    Navigation.FromHome(Init_rqReview, homeTag);
                    break;
            }
        }

        private void uc_hmActions1_btnWelderQualificationClick(object sender, EventArgs e)
        {
            Tag homeTag = (Tag)uc_hmActions1.Tag;

            if (homeTag?.getTagType() != TagType.Welder_Qualification)
            {
                return;
            }

            if (homeTag.getTagObject() is WeldingAction)
            {
                Navigation.FromHome(Init_wqInfo, homeTag);
            }
            else if (homeTag.getTagObject() is Welder_Qualification)
            {
                Welder_Qualification wq = (Welder_Qualification)homeTag.getTagObject();

                switch (wq.Status)
                {
                    case Actions.WelderTestInformation:
                        Navigation.FromHome(Init_wqInfo, homeTag);
                        break;

                    case Actions.WelderTestParameters:
                        Navigation.FromHome(Init_wqRun, homeTag);
                        break;

                    case Actions.Consumables:
                        Navigation.FromHome(Init_wqConsumable, homeTag);
                        break;

                    case Actions.WeldSequence:
                        Navigation.FromHome(Init_wqDrawing, homeTag);
                        break;

                    case Actions.VisualInspection:
                        Navigation.FromHome(Init_wqInspection, homeTag);
                        break;

                    case Actions.NataReports:
                        Navigation.FromHome(Init_wqReports, homeTag);
                        break;
                }
            }
        }

        private void uc_hmActions1_btnHomeWPQRClick(object sender, EventArgs e)
        {
            Tag homeTag = (Tag)uc_hmActions1.Tag;

            if (homeTag?.getTagType() != TagType.WPQR)
            {
                return;
            }

            if (homeTag.getTagObject() is WeldingAction)
            {
                Navigation.FromHome(Init_wpqrSelect, homeTag);
            }
            else if (homeTag.getTagObject() is WPQR)
            {
                WPQR wpqr = (WPQR)homeTag.getTagObject();

                switch (wpqr.Status)
                {
                    case Actions.WPQRSelectWelderQual:
                        Navigation.FromHome(Init_wpqrSelect, homeTag);
                        break;

                    case Actions.WPQRInformation:
                        Navigation.FromHome(Init_wpqrInfo, homeTag);
                        break;

                    case Actions.WPQRParameters:
                        Navigation.FromHome(Init_wpqrRun, homeTag);
                        break;

                    case Actions.WPQRDetails:
                        Navigation.FromHome(Init_wpqrDetails, homeTag);
                        break;

                    case Actions.WPQRDetailsContinued:
                        Navigation.FromHome(Init_wpqrContinued, homeTag);
                        break;

                    case Actions.WPQRAttachments:
                        Navigation.FromHome(Init_wpqrDocuments, homeTag);
                        break;
                }
            }
        }

        private void uc_hmActions1_btnHomeWPSClick(object sender, EventArgs e)
        {
            Tag homeTag = (Tag)uc_hmActions1.Tag;

            if (homeTag?.getTagType() != TagType.WPS)
            {
                return;
            }

            if (homeTag.getTagObject() is WeldingAction)
            {
                Navigation.FromHome(Init_wpsInfo, homeTag);
            }
            else if (homeTag.getTagObject() is WPS)
            {
                WPS wps = (WPS)homeTag.getTagObject();

                switch (wps.Status)
                {
                    case Actions.WPSInfo:
                        Navigation.FromHome(Init_wpsInfo, homeTag);
                        break;

                    case Actions.WPSParameters:
                        Navigation.FromHome(Init_wpsRun, homeTag);
                        break;

                    case Actions.WPSAttachments:
                        Navigation.FromHome(Init_wpsDocuments, homeTag);
                        break;
                }
            }
        }

        private void uc_hmActions1_btnHomeNDTClick(object sender, EventArgs e)
        {
            Navigation.FromHome(Init_ndtEntry, null);
        }

        private void uc_hmActions1_btnHomeSearchWPQRClick(object sender, EventArgs e)
        {
            Navigation.FromHome(Init_scGeneric, new Tag(null, TagType.WPQR));
        }

        private void uc_hmActions1_btnHomeSearchWQClick(object sender, EventArgs e)
        {
            Navigation.FromHome(Init_scGeneric, new Tag(null, TagType.Welder_Qualification));
        }

        private void uc_hmActions1_btnHomeSearchWPSClick(object sender, EventArgs e)
        {
            Navigation.FromHome(Init_scGeneric, new Tag(null, TagType.WPS));
        }

        private void uc_hmActions1_btnHomeSearchJobClick(object sender, EventArgs e)
        {
            Navigation.FromHome(Init_scJob1, new Tag(null, TagType.Job));
        }
        #endregion

        #region Matrix (Request) Page
        private void uc_rqMatrix1_btnMatrixBackClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_rqMatrix1_btnMatrixHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_rqMatrix1_btnMatrixNextClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_rqDetails, (UserControl)sender);
        }

        #endregion

        #region Details (Request) Page
        private void uc_rqDetails1_btnDetailsBackClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_rqMatrix, (UserControl)sender);
        }

        private void uc_rqDetails1_btnDetailsHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_rqDetails1_btnDetailsNextClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_rqDocuments, (UserControl)sender);
        }
        #endregion

        #region Documents (Request) Page
        private void uc_rqDocuments1_btnDocumentsBackClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_rqDetails, (UserControl)sender);
        }

        private void uc_rqDocuments1_btnDocumentsCompleteClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_rqDocuments1_btnDocumentsHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }
        #endregion

        #region Technical (Request) Page
        private void uc_rqTechnical1_btnTechnicalBackClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_rqTechnical1_btnTechnicalNextClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_rqOperational, (UserControl)sender);
        }

        private void uc_rqTechnical1_btnTechnicalHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }
        #endregion

        #region Operational (Request) Page
        private void uc_rqOperational1_btnOperationBackClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_rqOperational, (UserControl)sender);
        }

        private void uc_rqOperational1_btnOperationCompleteClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_rqOperational1_btnOperationHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        #endregion

        #region Manager (Request) Page
        private void uc_rqReview1_btnManagerBackClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_rqReview1_btnManagerHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_rqReview1_btnManagerCompleteClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }
        #endregion

        #region Information (Datasheet) Page

        private void uc_wqInfo1_btnInfoBackClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wqInfo1_btnInfoHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wqInfo1_btnInfoNextClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wqRun, (UserControl)sender);
        }

        #endregion

        #region Run (Datasheet) Page
        private void uc_wqRun1_btnRunBackClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wqInfo, (UserControl)sender);
        }

        private void uc_wqRun1_btnRunHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wqRun1_btnRunNextClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wqConsumable, (UserControl)sender);
        }

        #endregion

        #region Consumable (Datasheet) Page
        private void uc_wqConsumable1_btnConsumableBackClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wqRun, (UserControl)sender);
        }

        private void uc_wqConsumable1_btnConsumableHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wqConsumable1_btnConsumableNextClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wqDrawing, (UserControl)sender);
        }
        #endregion

        #region Drawing (Datasheet) Page
        private void uc_wqDrawing1_btnDrawingBackClick(object sender, EventArgs e)
        {
            Tag drawingTag = (Tag)uc_wqDrawing1.Tag;

            if (drawingTag == null)
            {
                return;
            }

            switch (drawingTag.getTagType())
            {
                case TagType.WPQR_Sequence:
                case TagType.WPQR_Preparation:
                    Navigation.ToControl(Init_wpqrDocuments, (UserControl)sender);
                    break;

                case TagType.WPS_Sequence:
                case TagType.WPS_Preparation:
                    Navigation.ToControl(Init_wpsDocuments, (UserControl)sender);
                    break;

                case TagType.Welder_Qualification:
                    Navigation.ToControl(Init_wqConsumable, (UserControl)sender);
                    break;
            }
        }

        private void uc_wqDrawing1_btnDrawingCompleteClick(object sender, EventArgs e)
        {
            Tag drawingTag = (Tag)uc_wqDrawing1.Tag;

            if (drawingTag == null)
            {
                return;
            }

            switch (drawingTag.getTagType())
            {
                case TagType.WPQR_Sequence:
                case TagType.WPQR_Preparation:
                    ((Tag)uc_wqDrawing1.Tag).setTagType(TagType.WPQR);
                    Navigation.ToControl(Init_wpqrDocuments, uc_wqDrawing1);
                    break;
                case TagType.WPS_Sequence:
                case TagType.WPS_Preparation:
                    ((Tag)uc_wqDrawing1.Tag).setTagType(TagType.WPS);
                    Navigation.ToControl(Init_wpsDocuments, uc_wqDrawing1);
                    break;
                case TagType.Welder_Qualification:
                    Navigation.ToControl(Init_wqInspection, (UserControl)sender);
                    break;
            }
        }

        private void uc_wqDrawing1_btnDrawingHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        #endregion

        #region Visual Inspection Page
        private void uc_wqInspection1_btnVisualBackClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wqDrawing, (UserControl)sender);
        }

        private void uc_wqInspection1_btnVisualCompleteClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wqReports, (UserControl)sender);
        }

        private void uc_wqInspection1_btnVisualHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        #endregion

        #region Reports (Welder Qualification) Page
        private void uc_wqReports1_btnUploadBackClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wqInspection, (UserControl)sender);
        }

        private void uc_wqReports1_btnUploadCompleteClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wqReports1_btnUploadHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }
        #endregion

        #region Select (WPQR) Page
        private void uc_wpqrSelect1_btnSelectBackClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpqrSelect1_btnSelectHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpqrSelect1_btnSelectNextClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wpqrInfo, (UserControl)sender);
        }
        #endregion

        #region Information (WPQR) Page
        private void uc_wpqrInfo1_btnInfoBackClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpqrInfo1_btnInfoHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpqrInfo1_btnInfoNextClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wpqrRun, (UserControl)sender);
        }

        #endregion

        #region Run (WPQR) Page
        private void uc_wpqrRun1_btnRunBackClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wpqrInfo, (UserControl)sender);
        }

        private void uc_wpqrRun1_btnRunHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpqrRun1_btnRunNextClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wpqrDetails, (UserControl)sender);
        }

        #endregion

        #region Details (WPQR) Page
        private void uc_wpqrDetails1_btnDetailsBackClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wpqrRun, (UserControl)sender);
        }

        private void uc_wpqrDetails1_btnDetailsHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpqrDetails1_btnDetailsNextClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wpqrContinued, (UserControl)sender);
        }

        #endregion

        #region Details Continued (WPQR) Page
        private void uc_wpqrContinued1_btnContBackClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wpqrDetails, (UserControl)sender);
        }

        private void uc_wpqrContinued1_btnContHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpqrContinued1_btnContNextClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wpqrDocuments, (UserControl)sender);
        }
        #endregion

        #region Documents (WPQR) Page
        private void uc_wpqrDocuments1_btnUploadBackClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wpqrContinued, (UserControl)sender);
        }

        private void uc_wpqrDocuments1_btnUploadCompleteClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpqrDocuments1_btnUploadHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpqrDocuments1_btnUploadPreparationClick(object sender, EventArgs e)
        {
            Tag documentsTag = (Tag)uc_wpqrDocuments1.Tag;

            if (documentsTag == null)
            {
                return;
            }

            ((Tag)uc_wpqrDocuments1.Tag).setTagType(TagType.WPQR_Preparation);
            Navigation.ToControl(Init_wqDrawing, uc_wpqrDocuments1);
        }

        private void uc_wpqrDocuments1_btnUploadSequenceClick(object sender, EventArgs e)
        {
            Tag documentsTag = (Tag)uc_wpqrDocuments1.Tag;

            if (documentsTag == null)
            {
                return;
            }

            ((Tag)uc_wpqrDocuments1.Tag).setTagType(TagType.WPQR_Sequence);
            Navigation.ToControl(Init_wqDrawing, uc_wpqrDocuments1);
        }

        #endregion

        #region Information (WPS) Page
        private void uc_wpsInfo1_btnInfoBackClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpsInfo1_btnInfoHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpsInfo1_btnInfoNextClick(object sender, EventArgs e)
        {
            Tag homeTag = (Tag)((UserControl)sender).Tag;

            if (homeTag.getTagObject() is WeldingAction)
            {
                Navigation.ToHome((UserControl)sender, uc_hmActions1);
            }
            else
            {
                Navigation.ToControl(Init_wpsRun, (UserControl)sender);
            }
        }
        #endregion

        #region Run (WPS) Page
        private void uc_wpsRun1_btnRunBackClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wpsInfo, (UserControl)sender);
        }

        private void uc_wpsRun1_btnRunHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpsRun1_btnRunNextClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wpsDocuments, (UserControl)sender);
        }
        #endregion

        #region Documents (WPS) Page
        private void uc_wpsDocuments1_btnUploadBackClick(object sender, EventArgs e)
        {
            Navigation.ToControl(Init_wpsRun, (UserControl)sender);
        }

        private void uc_wpsDocuments1_btnUploadCompleteClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpsDocuments1_btnUploadHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_wpsDocuments1_btnUploadPreparationClick(object sender, EventArgs e)
        {
            Tag documentsTag = (Tag)uc_wpsDocuments1.Tag;

            if (documentsTag == null)
            {
                return;
            }

            ((Tag)uc_wpsDocuments1.Tag).setTagType(TagType.WPS_Preparation);
            Navigation.ToControl(Init_wqDrawing, uc_wpsDocuments1);
        }

        private void uc_wpsDocuments1_btnUploadSequenceClick(object sender, EventArgs e)
        {
            Tag documentsTag = (Tag)uc_wpsDocuments1.Tag;

            if (documentsTag == null)
            {
                return;
            }

            ((Tag)uc_wpsDocuments1.Tag).setTagType(TagType.WPS_Sequence);
            Navigation.ToControl(Init_wqDrawing, uc_wpsDocuments1);
        }
        #endregion

        #region Entry (NDT) Page
        private void uc_ndtEntry1_btnEntryBackClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        private void uc_ndtEntry1_btnEntrySubmitClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }

        #endregion

        #region Search (WPQR/Welder Qualification) Page
        private void uc_scWPQR1_btnSearchHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }
        #endregion

        #region Search (Job) Page
        private void uc_scJob1_btnSearchHomeClick(object sender, EventArgs e)
        {
            Navigation.ToHome((UserControl)sender, uc_hmActions1);
        }
        #endregion

        #endregion
    }
}
