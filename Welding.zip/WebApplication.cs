﻿
using System;
using Wisej.Web;

namespace WeldingManagement
{
	public partial class WebApplication : Page
	{
		public WebApplication()
		{
			InitializeComponent();
		}
	}
}
